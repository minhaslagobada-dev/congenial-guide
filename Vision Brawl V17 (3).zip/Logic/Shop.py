from Utils.Helpers import Helpers
import json
import time
from Database.DatabaseManager import DataBase

class Shop:
    """
    << Shop Offers IDs List >>

    0 = Free Brawl Box
    1 = Gold
    2 = Random Brawler
    3 = Brawler
    4 = Skin
    5 = StarPower/ Gadget
    6 = Brawl Box
    7 = Tickets
    8 = Power Points (for a specific brawler)
    9 = Token Doubler
    10 = Mega Box
    11 = Keys (???)
    12 = Power Points
    13 = EventSlot (???)
    14 = Big Box
    15 = AdBox (not working anymore)
    16 = Gems

    """



    offers = "шайлушай"

    def loadOffers(self):
    	self.offers=[]        
    	with open("JSON/offers.json", "r") as f:
    		data = json.load(f)
    		for i in data.values():
    			self.offers.append(i)
    def UpdateOfferData(self, i):
    	with open("JSON/offers.json", "r") as f:
    		data = json.load(f)
    	data[str(i)]["WhoBuyed"].append(int(self.player.low_id))
    	data[str(i)]["Cost"] + 1337
    	with open("JSON/offers.json", "w") as f:
    		json.dump(data, f, ensure_ascii=False)
    def RemoveOffer(self, i):
    	with open("JSON/offers.json", "r") as f:
    		data = json.load(f)
    	data.pop(str(i))
    	with open("JSON/offers.json", "w") as f:
    		json.dump(data, f, ensure_ascii=False)
    gold = [
        {
            'Cost': 20,
            'Amount': 150
        },

        {
            'Cost': 50,
            'Amount': 400
        },

        {
            'Cost': 140,
            'Amount': 1200
        }

    ]

    boxes = [
        {
            'Name': 'Big Box',
            'Cost': 30,
            'Multiplier': 1
        },

        {
            'Name': 'Mega Box',
            'Cost': 80,
            'Multiplier': 1
        }

    ]


    token_doubler = {

        'Cost': 50,
        'Amount': 1000
    }

    def Timer(self):
        result = time.localtime(int(time.time()))
        return (86400 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)))

    def encodeShopOffers(self):
        Shop.loadOffers(self)
        Timer = Shop.Timer(self)
        wow = self.offers
        count = len(wow)
        self.writeVint(count)
        for i in range(count):
            item = wow[i]

            if item['ID'][0] != 0 and item['ID'][1] != 0 and item['ID'][2] != 0 and item['ID'][3] != 0:
                self.writeVint(4)
                self.writeVint(item['ID'][0]) # ItemID
                self.writeVint(item['Multiplier'][0]) # Ammount
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0]) # ItemID                
                self.writeVint(item['ID'][1]) # ItemID
                self.writeVint(item['Multiplier'][1]) # Ammount
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1]) # ItemID
                
                self.writeVint(item['ID'][2]) # ItemID
                self.writeVint(item['Multiplier'][2]) # Ammount
                self.writeScId(16, item['BrawlerID'][2])
                self.writeVint(item['SkinID'][2]) # ItemID
                self.writeVint(item['ID'][3]) # ItemID
                self.writeVint(item['Multiplier'][3]) # Ammount
                self.writeScId(16, item['BrawlerID'][3])
                self.writeVint(item['SkinID'][3]) # ItemID
                
                
                
                
                
                
                
                
                
            
            elif item['ID'][0] != 0 and item['ID'][1] != 0 and item['ID'][2] != 0:
                self.writeVint(3)
                self.writeVint(item['ID'][0]) # ItemID
                self.writeVint(item['Multiplier'][0]) # Ammount
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0]) # ItemID                
                self.writeVint(item['ID'][1]) # ItemID
                self.writeVint(item['Multiplier'][1]) # Ammount
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1]) # ItemID
                
                self.writeVint(item['ID'][2]) # ItemID
                self.writeVint(item['Multiplier'][2]) # Ammount
                self.writeScId(16, item['BrawlerID'][2])
                self.writeVint(item['SkinID'][2]) # ItemID
                
                
                
                
                
                
            elif item['ID'][0] != 0 and item['ID'][1] != 0:
                self.writeVint(2)
                self.writeVint(item['ID'][0]) # ItemID
                self.writeVint(item['Multiplier'][0]) # Ammount
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0]) # ItemID
                
                self.writeVint(item['ID'][1]) # ItemID
                self.writeVint(item['Multiplier'][1]) # Ammount
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1]) # ItemID
                
                
                
                
                
                
            else:
                self.writeVint(1)
                self.writeVint(item['ID'][0]) # ItemID
                self.writeVint(item['Multiplier'][0]) # Ammount
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0]) # ItemID
            self.writeVint(item['ShopType'])  # [0 = Offer, 2 = Skins 3 = Star Shop]
            
            self.writeVint(item['Cost'])  # Cost

            Timer = Helpers.ShopTimer(self)
            	
            self.writeVint(Timer) # Timer

            self.writeVint(2)# 2—removes 'new', 0—does nothing, 1—'new'
            self.writeVint(100)
            if self.player.low_id in item["WhoBuyed"]:
            		self.writeBoolean(True)
            else:
            		self.writeBoolean(False)

            self.writeBoolean(False)
            self.writeBoolean(item['ShopDisplay'])  # [0 = Normal, 1 = Daily Deals]
            self.writeVint(item['OldCost'])
            self.writeVint(0)

            self.writeInt(0)
            self.write_string_reference(item['OfferTitle']) # Item name

            self.writeBoolean(False)