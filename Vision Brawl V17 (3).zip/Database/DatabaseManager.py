from Logic.Player import Players
import sqlite3
import sys
import json
import os
from Utils.Helpers import Helpers
import sqlite3 as sql
from tinydb import TinyDB, Query, database
import os, json,datetime


db_folder = os.path.join("Database", "Player")
os.makedirs(db_folder, exist_ok=True)

db_path = os.path.join(db_folder, "data.db")

conn = sqlite3.connect(db_path, check_same_thread=False)
cursor = conn.cursor()

print(f"[DATABASE] Connecting to SQLite database at {db_path}...")

cursor.execute('''
CREATE TABLE IF NOT EXISTS accounts (
    token TEXT PRIMARY KEY,
    lowID INTEGER UNIQUE,
    trophies INTEGER,
    data TEXT
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS gamerooms (
    room_id INTEGER PRIMARY KEY,
    data TEXT
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS clubs (
    clubID INTEGER PRIMARY KEY,
    name TEXT,
    data TEXT
)
''')
conn.commit()
print("[DATABASE] Successfully connected to SQLite database!")

class SQLiteCollection:
    def __init__(self, table_name, key_field):
        self.table_name = table_name
        self.key_field = key_field

    def find_one(self, query, *args, **kwargs):
        if not query:
            cursor.execute(f'SELECT data FROM {self.table_name} LIMIT 1')
        elif self.key_field in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE {self.key_field} = ?', (query[self.key_field],))
        elif 'token' in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE token = ?', (query['token'],))
        elif 'lowID' in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE lowID = ?', (query['lowID'],))
        elif 'room_id' in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE room_id = ?', (query['room_id'],))
        elif 'clubID' in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE clubID = ?', (query['clubID'],))
        else:
            cursor.execute(f'SELECT data FROM {self.table_name} LIMIT 1')
        row = cursor.fetchone()
        return json.loads(row[0]) if row else None

    def find(self, query=None, *args, **kwargs):
        cursor.execute(f'SELECT data FROM {self.table_name}')
        rows = cursor.fetchall()
        return [json.loads(r[0]) for r in rows]

    def insert_one(self, data):
        key_val = data.get(self.key_field) or data.get('room_id') or data.get('clubID') or data.get('token')
        name_val = data.get('name', '') if self.table_name == 'clubs' else None
        if self.table_name == 'clubs':
            cursor.execute(f'INSERT OR REPLACE INTO {self.table_name} (clubID, name, data) VALUES (?, ?, ?)', (key_val, name_val, json.dumps(data)))
        elif self.table_name == 'accounts':
            cursor.execute(f'INSERT OR REPLACE INTO {self.table_name} (token, lowID, trophies, data) VALUES (?, ?, ?, ?)', 
                           (data.get('token'), data.get('lowID'), data.get('trophies', 0), json.dumps(data)))
        else:
            cursor.execute(f'INSERT OR REPLACE INTO {self.table_name} (room_id, data) VALUES (?, ?)', (key_val, json.dumps(data)))
        conn.commit()

    def update_one(self, query, update_data):
        key_val = query.get(self.key_field) or query.get('lowID') or query.get('token') or query.get('room_id') or query.get('clubID')
        set_data = update_data.get('$set', update_data)
        
        if self.key_field in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE {self.key_field} = ?', (query[self.key_field],))
        elif 'token' in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE token = ?', (query['token'],))
        elif 'lowID' in query:
            cursor.execute(f'SELECT data FROM {self.table_name} WHERE lowID = ?', (query['lowID'],))
        
        row = cursor.fetchone()
        if row:
            acc = json.loads(row[0])
            for k, v in set_data.items():
                acc[k] = v
            
            if self.table_name == 'accounts':
                cursor.execute('UPDATE accounts SET data = ?, trophies = ? WHERE token = ? OR lowID = ?', 
                               (json.dumps(acc), acc.get('trophies', 0), query.get('token'), query.get('lowID')))
            elif self.table_name == 'clubs':
                cursor.execute('UPDATE clubs SET data = ? WHERE clubID = ?', (json.dumps(acc), query.get('clubID')))
            conn.commit()

    def delete_one(self, query):
        key_val = query.get('room_id') or query.get('clubID') or query.get('lowID')
        field = 'room_id' if 'room_id' in query else ('clubID' if 'clubID' in query else 'lowID')
        cursor.execute(f'DELETE FROM {self.table_name} WHERE {field} = ?', (key_val,))
        conn.commit()

accounts = SQLiteCollection('accounts', 'token')
gamerooms = SQLiteCollection('gamerooms', 'room_id')
clubs = SQLiteCollection('clubs', 'clubID')

class DataBase:
    def loadAccount(self):
        user_data = accounts.find_one({'token': self.player.token})
        if user_data:
            self.player.name = user_data["name"]
            self.player.low_id = user_data["lowID"]
            self.player.IsFacebookLinked = user_data["isFBLinked"]
            self.player.FacebookID = user_data["facebookID"]
            self.player.club_low_id = user_data["clubID"]
            self.player.club_role = user_data["clubRole"]
            self.player.player_experience = user_data["playerExp"]
            self.player.solo_wins = user_data["soloWins"]
            self.player.duo_wins = user_data["duoWins"]
            self.player.ThreeVSThree_wins = user_data["3vs3Wins"]
            self.player.gems = user_data["gems"]
            self.player.online = user_data["online"]
            self.player.gold = user_data["gold"]
            self.player.tickets = user_data["tickets"]
            self.player.tokensdoubler = user_data["tokensdoubler"]
            self.player.battle_tokens = user_data["availableTokens"]
            self.player.brawler_id = user_data["brawlerID"]
            self.player.skin_id = user_data["skinID"]
            self.player.profile_icon = user_data["profileIcon"]
            self.player.brawl_boxes = user_data["brawlBoxes"]
            self.player.big_boxes = user_data["bigBoxes"]
            self.player.brawlers_skins = user_data["brawlersSkins"]
            self.player.name_color = user_data["namecolor"]
            self.player.notifications = user_data["notifications"]
            self.player.Brawler_starPower = user_data["brawlerStarPower"]
            self.player.DoNotDistrubMessage = user_data["DoNotDistrub"]
            self.player.UnlockedSkins = user_data["UnlockedSkins"]
            self.player.room_id = user_data["roomID"]
            self.player.brawlers_trophies_in_rank = user_data["brawlersTrophiesForRank"]
            self.player.brawlers_upgradium = user_data["brawlersUpgradePoints"]
            self.player.Brawler_level = user_data["brawlerPowerLevel"]
            self.player.brawlers_trophies = user_data["brawlersTrophies"]
            self.player.trophy_road = user_data["trophyRoad"]
            self.player.friends = user_data.get("friends", [])
            
            
            if self.player.UnlockType == "Off":
                self.player.BrawlersUnlockedState = user_data["UnlockedBrawlers"]
            player_total_trophies = 0
            for BrawlerID in self.player.brawlers_trophies.keys():
                player_total_trophies += self.player.brawlers_trophies[BrawlerID]
            self.player.trophies = player_total_trophies
            DataBase.replaceValue(self, 'trophies', self.player.trophies)
            if self.player.trophies < user_data["highesttrophies"]:
                self.player.highest_trophies = user_data["highesttrophies"]
            else:
                self.player.highest_trophies = self.player.trophies
                DataBase.replaceValue(self, 'highesttrophies', self.player.highest_trophies)
                
    def createAccount(self):
        Players.CreateNewBrawlersList()
        cursor.execute('SELECT MAX(lowID) FROM accounts')
        max_row = cursor.fetchone()
        self.player.low_id = (max_row[0] + 1) if max_row and max_row[0] is not None else 1  
    
        data = {
            "token": str(self.player.token),
            "name": self.player.name,
            "lowID": self.player.low_id,
            "clubID": 0,
            "clubRole": 0,
            "isFBLinked": 0,
            "facebookID": self.player.FacebookID,
            "playerExp": self.player.max_experience,
            "experience": self.player.player_experience,
            "soloWins": self.player.solo_wins,
            "duoWins": self.player.duo_wins,
            "3vs3Wins": self.player.ThreeVSThree_wins,
            "gems": self.player.gems,
            "online": self.player.online,
            "gold": self.player.gold,
            "notifications": self.player.notifications,
            "tokensdoubler": self.player.tokensdoubler,
            "availableTokens": self.player.battle_tokens,
            "tickets": self.player.tickets,
            "UnlockedSkins": self.player.UnlockedSkins,
            "brawlerID": 0,
            "skinID": 0,
            "trophies": self.player.trophies,
            "highesttrophies": self.player.trophies,
            "profileIcon": 0,
            "namecolor": self.player.name_color,
            "brawlBoxes": self.player.brawl_boxes,
            "bigBoxes": self.player.big_boxes,
            "brawlerStarPower": self.player.Brawler_starPower,
            "DoNotDistrub": self.player.DoNotDistrubMessage,
            "roomID": 0,
            "brawlersSkins": self.player.brawlers_skins,
            "brawlersTrophies": self.player.brawlers_trophies,
            "brawlersTrophiesForRank": self.player.brawlers_trophies_in_rank,
            "brawlersUpgradePoints": self.player.brawlers_upgradium,
            "brawlerPowerLevel": self.player.Brawler_level,
            "UnlockedBrawlers": self.player.BrawlersUnlockedState,
            "trophyRoad": self.player.trophy_road,
            "friends": []
        }
        
        existing_account = accounts.find_one({"lowID": data["lowID"]})
    
        if existing_account:
            print(f"Record with lowID {data['lowID']} already exists. Updating record...")
            accounts.update_one({"lowID": data["lowID"]}, data)
            print("Record successfully updated.")
        else:
            accounts.insert_one(data)
            print("Record successfully added.")

    def get_friends(self, lowID):
        acc = accounts.find_one({'lowID': int(lowID)})
        return acc.get("friends", []) if acc else []

    def update_friends(self, lowID, friends_list):
        accounts.update_one({'lowID': int(lowID)}, {"friends": friends_list})
        
    def getAllPlayers(self):
        cursor.execute('SELECT data FROM accounts ORDER BY trophies DESC LIMIT 200')
        rows = cursor.fetchall()
        return [json.loads(row[0]) for row in rows]
        
    def getSpecifiedValue(self, value_name):
        account = accounts.find_one({'token': self.token})
        if account:
            self.requested_val = account.get(value_name)
    def loadbyID(self, ID):
        cursor.execute('SELECT data FROM accounts WHERE lowID = ?', (int(ID),))
        row = cursor.fetchone()
        if row:
            return json.loads(row[0])
        return {}

    def loadbyID2(self, ID):
        self.conn = sql.connect("Database/Player/data.db")
        self.cur = self.conn.cursor()
        
        self.cur.execute("SELECT * FROM accounts WHERE lowID = ?", (int(ID),))
        row = self.cur.fetchone()
        
        self.conn.close()
        
        return row

    def replaceValue(self, value_name, new_value):
        accounts.update_one(
            {'token': self.player.token},
            {value_name: new_value}
        )

    def replaceOtherValue(self, target, value_name, new_value):
        accounts.update_one(
            {'lowID': target},
            {value_name: new_value}
        )    

    def addNotification(self, target, id, read=True, text="", sender=0):
        notif = DataBase.loadOtherAccount(self, target).get("notifications", [])
        notif.append({"id": id,
             "read": read,
             "time": Helpers.GetTime(self),
             "text": text,
             "sender": sender})
        DataBase.replaceOtherValue(self, target, "notifications", notif)
        
    def loadOtherAccount(self, target):
        return accounts.find_one({"lowID": int(target)}) or {}
        
    def get_shop_offers(self):
        acc = accounts.find_one({})
        return acc.get("Shop", []) if acc else []
    
    def createClub(self, clubid):
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        self.cur.execute(f"CREATE TABLE IF NOT EXISTS clubs (clubID INT, name TEXT, desc TEXT, region TEXT, badgeID INT, type INT, trophiesneeded INT, friendlyfamily INT, trophies INT, members JSON, notif JSON)")
        self.c.execute(f"CREATE TABLE IF NOT EXISTS chats (clubID INT, Event INT, Tick INT, plrid INT, plrname TEXT, plrrole INT, Msg TEXT)")
        self.con.commit()
        self.conn.commit()
        data = {"members": {self.player.low_id:self.player.name}}
        notif = {}
        var = clubid,str(self.clubName),str(self.clubdescription),"ES",self.clubbadgeID,self.clubtype,self.clubtrophiesneeded,self.clubfriendlyfamily,self.player.trophies,json.dumps(data), json.dumps(notif)
        self.cur.execute(f"INSERT INTO clubs VALUES (?,?,?,?,?,?,?,?,?,?,?)", var)
        self.conn.commit()

        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?,?)"
        var = clubid, 2, 1, self.player.low_id, str(self.player.name), 2, "Welcome To Your New Club!"
        self.c.execute(sss, var)
        self.con.commit()
    def setNotifData(self, text, by):
        self.conn = sql.connect("Database/Club/clubs.db")
        self.cur = self.conn.cursor()
        self.cur.execute("SELECT * FROM clubs WHERE clubID=?", (self.player.club_low_id,))
        fetch = self.cur.fetchall()
        if fetch:
               notifData = json.loads(fetch[0][10])
               l = str(len(notifData))
               notifData[l]={}
               notifData[l]["text"]=text
               notifData[l]["by"]=by
               notifData[l]["timer"]=datetime.datetime.timestamp(datetime.datetime.now())
               self.cur.execute("UPDATE clubs SET notif=? WHERE clubID=?", (json.dumps(notifData),self.player.club_low_id))
               self.conn.commit()
               self.conn.close()
    def CountClub(self):
        self.AllianceCount = 0
        self.club_list = []
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        try:
                        self.cur.execute(f"SELECT * FROM clubs")
                        fetch = self.cur.fetchall()
                        if len(fetch)>0:
                            for i in fetch:
                                self.club_list.append(int(i[0]))
                                self.AllianceCount+=1
                        self.conn.close()
                        self.con.close()
        except:
            pass
            
    def LeaderClub(self):
        self.AllianceCount = 0
        self.club_list = []
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        try:
                        self.cur.execute(f"SELECT * FROM clubs ORDER BY trophies DESC LIMIT 200")
                        fetch = self.cur.fetchall()
                        if len(fetch)>0:
                            for i in fetch:
                                self.club_list.append(int(i[0]))
                                self.AllianceCount+=1
                        self.conn.close()
                        self.con.close()
        except:
            pass
	
	
    def loadClub(self, clubid):
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
                for i in fetch:
                    self.clubmembercount = 0
                    self.plrids = []
                    self.clubName = i[1]
                    self.clubdescription = i[2]
                    self.clubregion = i[3]
                    
                    self.clubbadgeID = i[4]
                    self.clubtype = i[5]
                    self.clubtrophiesneeded = i[6]
                    self.clubfriendlyfamily = i[7]
                    try:
                        self.notifData = json.loads(i[10])
                    except:
                        self.cur.execute("ALTER TABLE clubs ADD COLUMN notif JSON")
                        self.conn.commit()
                    self.clubtrophies = 0
                    data = json.loads(i[9])
                    for ID in data["members"]:
                             if ID != "members":
                                 self.plrids.append(int(ID))
                                 self.clubmembercount += 1
                                 DataBase.GetMemberData(self, int(ID))
                                 self.clubtrophies += self.plrtrophies
                    #self.cur.execute(f"UPDATE clubs SET trophies={self.clubtrophies} WHERE clubID={clubid}")
                    #self.cur.execute(f"UPDATE clubs SET trophies={self.clubtrophies} WHERE clubID={clubid}")
                    self.conn.commit()
                    self.conn.close()
                    self.con.close()
                    

    def AddMember(self, AllianceID, PlayerID, PlayerName, Action):
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        query = Query()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={AllianceID}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
            data = json.loads(fetch[0][9])
            if Action == 0:
                self.chat.execute(f"DELETE FROM chats WHERE clubID={AllianceID}")
                self.cur.execute(f"DELETE FROM clubs WHERE clubID={AllianceID}")
                self.con.commit()
                self.conn.commit()
            elif Action == 1:
               data["members"][str(PlayerID)] = PlayerName
               self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?",(json.dumps(data),AllianceID))
               ol = fetch[0][8]
               self.cur.execute(f"UPDATE clubs SET trophies={ol+self.player.trophies} WHERE clubID={AllianceID}")
               self.conn.commit()
            elif Action == 2:
                   data['members'].pop(str(PlayerID))
                   self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?", (json.dumps(data), AllianceID))
                   ol = fetch[0][8]
                   self.cur.execute(f"UPDATE clubs SET trophies={ol-self.player.trophies} WHERE clubID={AllianceID}")
                   self.conn.commit()
            self.con.close()
            self.conn.close()
    def GetMemberData(self, Low_id):
        try:
                    self.players = DataBase.getAllPlayers(self)
                    for i in range(len(self.players)):
                        if self.players[i]['lowID'] == int(Low_id):
                            self.lowplrid = self.players[i]['lowID']
                            self.plrrole = self.players[i]["clubRole"]
                            self.plrtrophies = self.players[i]["trophies"]
                            self.plrname = self.players[i]["name"]
                            self.plricon = self.players[i]["profileIcon"]
                            self.plrnamecolor = self.players[i]["namecolor"]
                            self.plrexperience = self.players[i]["playerExp"]
                            self.plrstatus = self.players[i]["online"]


        except Exception as e:
            self.lowplrid = 1
            self.plrrole = 0
            self.plrtrophies = 0
            self.plrname = "Falied to load account!"
            self.plricon = 5
            self.plrnamecolor = 1
            self.plrexperience = 999
            self.plrstatus = 0

    def replaceClubValue(self, target, inf1, inf2, inf3, inf4, inf5):
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        query = Query()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={self.player.club_low_id}")
        fetch = self.chat.fetchall()
        if 1==1:
            
            self.cur.execute(f"UPDATE clubs SET desc='{inf1}' WHERE clubID={self.player.club_low_id}")
            self.cur.execute(f"UPDATE clubs SET badgeID={inf2} WHERE clubID={self.player.club_low_id}")
            self.cur.execute(f"UPDATE clubs SET type={inf3} WHERE clubID={self.player.club_low_id}")
            self.cur.execute(f"UPDATE clubs SET trophiesneeded={inf4} WHERE clubID={self.player.club_low_id}")
            self.cur.execute(f"UPDATE clubs SET friendlyfamily={inf5} WHERE clubID={self.player.club_low_id}")
            
            self.conn.commit()
            self.conn.close()
            self.con.close()

    def GetmsgCount(self, clubID):
        clubid = clubID
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats WHERE clubID={clubID}")
        fetch = self.chat.fetchall()
        if len(fetch)>0:
            self.MessageCount = len(fetch)
        else:
            self.MessageCount = 1
        self.conn.close()
        self.con.close()

    def Addmsg(self, clubID, event, tick, Low_id, name, role, msg):
        clubid = self.player.club_low_id
        self.conn = sql.connect("Database/Club/clubs.db")
        self.con = sql.connect("Database/Club/chats.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats WHERE clubID={clubID}")
        fetch = self.chat.fetchall()
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?,?)"
        var = clubid, event, len(fetch)+1, Low_id, name, role, msg
        self.chat.execute(sss, var)
        self.con.commit()
        self.con.close()
        self.conn.close()
    def DeleteAllMsg(self, clubID):
        self.con = sql.connect("Database/Club/chats.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats WHERE clubID={clubID}")
        fetch = self.chat.fetchall()
        if len(fetch)>=50:
            self.chat.execute(f"DELETE FROM chats WHERE clubID={clubID}")
            self.con.commit()