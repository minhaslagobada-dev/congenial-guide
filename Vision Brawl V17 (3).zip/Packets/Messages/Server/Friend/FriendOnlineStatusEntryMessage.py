from Utils.Writer import Writer

class FriendOnlineStatusEntryMessage(Writer):

    def __init__(self, client, player, lowID, status, room_id):
        super().__init__(client)
        self.id = 24555
        self.player = player 
        self.lowID = lowID
        self.status = status
        self.room_id = room_id

    def encode(self):
        self.writeInt(0)
        self.writeInt(self.lowID)  # LowID
        self.writeBoolean(True)
        self.writeInt(0)
        self.writeInt(self.lowID)  # LowID
        self.writeVint(self.status)  # Status (Online, In a game, etc.)
        self.writeVint(0)  # If it's 0 above, set it to 1 here and it will appear as offline
        if self.room_id > 0:
            self.writeBoolean(True)
        else:
            self.writeBoolean(False)
            
        self.writeBoolean(False)