from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Friend.FriendOnlineStatusEntryMessage import (
    FriendOnlineStatusEntryMessage,
)
from Utils.Writer import Writer
import json


class FriendListMessage(Writer):

  def __init__(self, client, player):
    super().__init__(client)
    self.id = 20105
    self.player = player

  def encode(self):
    account_data = DataBase.loadbyID(self, self.player.low_id)

    friends_json = account_data.get("friends", "[]")
    if isinstance(friends_json, str):
      try:
        friends = json.loads(friends_json)
      except json.JSONDecodeError:
        friends = []
    else:
      friends = friends_json or []

    self.writeInt(0)
    self.writeBoolean(True)
    self.writeInt(len(friends))

    for data in friends:
      if not isinstance(data, dict) or "id" not in data:
        continue

      friend_data = DataBase.loadbyID(self, data["id"])

      self.writeInt(0)  # HighID
      self.writeInt(data["id"])  # LowID

      self.writeString()
      self.writeString()
      self.writeString()
      self.writeString()
      self.writeString()
      self.writeString()

      self.writeInt(friend_data.get("trophies", 0))  # Trophies
      self.writeInt(data.get("state", 1))  # Friend state 0 = friend, 1 = not friend, etc.
      self.writeInt(0)
      self.writeInt(0)
      self.writeInt(0)

      self.writeBoolean(False)

      self.writeString()
      self.writeInt(0)

      self.writeBoolean(True)  # ?? is a player?

      self.writeString(f"{friend_data.get('name', 'Player')}")
      self.writeVint(100)
      self.writeVint(28000000 + friend_data.get("profileIcon", 0))
      #self.writeVint(43000000 + friend_data.get("namecolor", 0))
      self.writeVint(0)

      FriendOnlineStatusEntryMessage(self.client, self.player, data["id"], friend_data.get("status", 2), friend_data.get("room_id", 0)).send()