from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Utils.Gameroom import Gameroom
from Utils.Helpers import Helpers
import json
from Utils.G import Gameroom

class TeamGameroomDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.playerCount = 1

    def encode(self):
        with open('config.json', 'r') as file:
            config = json.load(file)
            rooms = Gameroom()
            roomInfo = rooms.get_room_id(self.player.room_id)
        
            self.writeVint(roomInfo['roomType'])
            self.writeVint(0)#?
            self.writeVint(1) # Max players

            self.writeInt(0)#High Id Room
            self.writeInt(self.player.room_id)#Room ID

            self.writeVint(100)#Timestamp
            self.writeVint(0)#?
            self.writeVint(0)#?
            self.writeVint(1)#Slot index
            
            self.writeScId(15, self.player.map_id)# MapID

            for plr in roomInfo['players']:
                # Player
                self.writeVint(len(roomInfo['players']))
                self.writeVint(plr['OWNER'])# Gameroom owner boolean
                account_data = DataBase.loadbyID(self, plr['plrID'])
                self.writeInt(0) # HighID
                self.writeInt(plr['plrID'])# LowID

                brawler_id = account_data.get("brawlerID", 0)
                skin_id = account_data.get("skinID", 0)
                brawlers_trophies = account_data.get("brawlersTrophies", {})
                brawler_trophies = int(brawlers_trophies.get(str(brawler_id), 0))

                self.writeScId(16, brawler_id)# BrawlerID
                self.writeScId(29, skin_id)                                #
                self.writeVint(brawler_trophies)
                self.writeVint(brawler_trophies)
                self.writeVint(self.player.Brawler_level[str(self.player.brawler_id)])# Power level

                self.writeVint(plr['STAT'])# Player State | 11: Events, 10: Brawlers, 9: Writing..., 8: Training, 7: Spectactor, 6: Offline, 5: End Combat Screen, 4: Searching, 3: Not Ready, 2: AFK, 1: In Combat, 0: OffLine
                self.writeVint(plr['READY'])    # Is ready
                self.writeVint(0)     # Team | 0: Blue, 1: Red
                self.writeVint(0)

                self.writeString(f"{plr['NAME']}")                  # Player name
                self.writeVint(100)
                self.writeVint(28000000 + self.player.profile_icon)  # Player icon
                self.writeVint(43000000 + self.player.name_color)    #
                
                self.writeScId(0, 0)       # Starpower

            self.writeVint(0)
            self.writeVint(0)
            self.writeVint(2)