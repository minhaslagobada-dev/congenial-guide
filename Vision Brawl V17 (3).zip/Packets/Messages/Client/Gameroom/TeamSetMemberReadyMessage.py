from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader
from Utils.G import Gameroom

class TeamSetMemberReadyMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.isReady = self.read_Vint()

    def process(self):
        rooms = Gameroom()
        roomInfo = rooms.get_room_id(self.player.room_id)
        
        if roomInfo:
            for plr in roomInfo['players']:
                if plr['plrID'] == self.player.low_id:
                    plr['READY'] = self.player.isReady
                    break
            
            for player in roomInfo['players']:
                TeamGameroomDataMessage(self.client, self.player).sendWithLowID(player['plrID'])