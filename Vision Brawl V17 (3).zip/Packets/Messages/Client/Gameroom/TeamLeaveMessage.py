from Database.DatabaseManager import DataBase

from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage

from Utils.Reader import BSMessageReader
from Utils.G import Gameroom


class TeamLeaveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        rooms = Gameroom()
        roomInfo = rooms.get_room_id(self.player.room_id)
        for player in roomInfo['players']:
            if player['plrID'] == self.player.low_id:
                roomInfo['players'].remove(player)
        roomInfo['Tick'] += 1
        new_msg = {'smstick':roomInfo['Tick'],'id':self.player.low_id,'name':self.player.name,'event':4,'type':103,'senderID':self.player.low_id,'senderN':self.player.name}
        roomInfo['msg'].append(new_msg)
        for player in roomInfo['players']:
            TeamGameroomDataMessage(self.client, self.player).sendWithLowID(player['plrID'])
            #TeamStream(self.client, self.player).sendWithLowID(player['plrID'])
        TeamLeftMessage(self.client, self.player).send()