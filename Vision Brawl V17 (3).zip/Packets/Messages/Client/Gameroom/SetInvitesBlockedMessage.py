from Packets.Messages.Server.Gameroom.SetInvitesBlockedOkMessage import SetInvitesBlockedOkMessage
from Database.DatabaseManager import DataBase

from Utils.Reader import BSMessageReader


class SetInvitesBlockedMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        value = self.read_Vint()
        # Se guarda siempre como 0 o 1
        self.player.DoNotDistrubMessage = 1 if value else 0

    def process(self):
        DataBase.replaceValue(self, 'DoNotDistrub', self.player.DoNotDistrubMessage)
        SetInvitesBlockedOkMessage(self.client, self.player).send()