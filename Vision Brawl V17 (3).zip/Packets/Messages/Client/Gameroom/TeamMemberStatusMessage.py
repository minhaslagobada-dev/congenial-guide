from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader
from Database.DatabaseManager import DataBase
from Utils.G import Gameroom

class TeamMemberStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.state = 0

    def decode(self):
        self.state = self.read_Vint()
        self.player.pin = self.read_Vint()
        self.player.mode = self.read_Vint()

    def process(self):
        rooms = Gameroom()
        roomInfo = rooms.get_room_id(self.player.room_id)
        for player in roomInfo['players']:
            if player['plrID'] == self.player.low_id:
                player['STAT'] = self.state
        for player in roomInfo['players']:
            TeamGameroomDataMessage(self.client, self.player).sendByID(player['plrID'])