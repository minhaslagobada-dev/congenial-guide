from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage

from Utils.Reader import BSMessageReader

from Packets.Messages.Server.Gameroom.TeamLeaveOkMessage import TeamLeaveOkMessage
from Utils.G import Gameroom


class GoHomeFromOfflinePractiseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        TeamLeaveOkMessage(self.client, self.player).send()
        OwnHomeDataMessage(self.client, self.player).send()
        