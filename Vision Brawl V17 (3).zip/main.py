import logging
import socket
import time
import os
from threading import *

from Logic.Device import Device
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Utils.Config import Config
from Packets.Messages.Server.Home.LobbyInfoMessage import LobbyInfoMessage

#logging.basicConfig(filename="errors.log", level=logging.INFO, filemode="w")


def _(*args):
	print('[INFO]', end=' ')
	for arg in args:
		print(arg, end=' ')
	print()


class Server:
	Clients = {"ClientCounts": 0, "Clients": {}}
	ThreadCount = 0
	Lock = Lock()

	def __init__(self, ip: str, port: int):
		self.server = socket.socket()
		self.port = port
		self.ip = ip

	def start(self):
		if not os.path.exists('./config.json'):
			print("Creating config.json...")
			Config.create_config(self)

		self.server.bind((self.ip, self.port))
		_(f'Server started! Ip: {self.ip}, Port: {self.port}')
		self.server.listen()
		while True:
			client, address = self.server.accept()
			_(f'New connection! Ip: {address[0]}')
			with Server.Lock:
				Server.ThreadCount += 1
				Server.Clients["ClientCounts"] = Server.ThreadCount
			ClientThread(client, address).start()


class ClientThread(Thread):
	def __init__(self, client, address):
		super().__init__()
		self.client = client
		self.address = address
		self.device = Device(self.client)
		self.player = Players(self.device)
		self.disconnected = False

	def recvall(self, length: int):
		data = b''
		while len(data) < length:
			s = self.client.recv(length - len(data))
			if not s:
				print("Receive Error!")
				break
			data += s
		return data

	def disconnect(self):
		with Server.Lock:
			if self.disconnected:
				return
			self.disconnected = True

			print(f"[INFO] Ip: {self.address[0]} disconnected!")
			try:
				self.client.close()
			except OSError:
				pass

			key = str(getattr(self.player, 'low_id', None))
			entry = Server.Clients["Clients"].get(key)
			if entry and entry["SocketInfo"] is self.client:
				del Server.Clients["Clients"][key]

			Server.ThreadCount = max(0, Server.ThreadCount - 1)
			Server.Clients["ClientCounts"] = Server.ThreadCount

	def run(self):
		last_packet = time.time()
		try:
			while True:
				header = self.client.recv(7)
				if len(header) == 0:
					break

				last_packet = time.time()
				packet_id = int.from_bytes(header[:2], 'big')
				length = int.from_bytes(header[2:5], 'big')
				data = self.recvall(length)
				LobbyInfoMessage(self.client, self.player, Server.ThreadCount).send()

				if packet_id in packets:
					_(f'Received packet! Id: {packet_id}')
					message = packets[packet_id](self.client, self.player, data)
					message.decode()
					message.process()

					if packet_id == 10101:
						with Server.Lock:
							Server.Clients["Clients"][str(self.player.low_id)] = {"SocketInfo": self.client}
							Server.Clients["ClientCounts"] = Server.ThreadCount
						self.player.ClientDict = Server.Clients

				else:
					_(f'Packet not handled! Id: {packet_id}')

				if time.time() - last_packet > 10:
					break
		except (ConnectionAbortedError, ConnectionResetError, TimeoutError, OSError):
			pass
		finally:
			self.disconnect()


if __name__ == '__main__':
	server = Server('0.0.0.0', 9339)
	server.start()