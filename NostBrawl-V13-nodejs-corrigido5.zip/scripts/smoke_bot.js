'use strict'

// smoke_bot — prova o motor de polling do TelegramBot contra um Telegram de
// mentira (HTTP local): propriedade única do token, 409 limitado, stop
// abortando long-poll, token fatal, init único e comandos preservados.

const http = require('http')
const TelegramBot = require('../Store/TelegramBot')

let CHECKS = 0
function ok (name, cond) {
  if (!cond) {
    console.error(`FALHOU: ${name}`)
    process.exit(1)
  }
  CHECKS += 1
  console.log('ok', name)
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function fakeStore (mode = 'embedded', botPolling = 'auto') {
  return {
    config: {
      BotToken: 'test-token',
      BotPolling: botPolling,
      Mode: mode,
      AdminIds: [7],
      PublicUrl: 'http://loja.test',
      StarCents: 40
    },
    _audit () {},
    createGiftCardCents (admin, cents) {
      return { code: 'AAAA-BBBB-CCCC', cents }
    },
    createGiftCard (user, stars) {
      return { code: 'DDDD-EEEE-FFFF', cents: stars * 40 }
    }
  }
}

// plan(method, payload, state) -> [status, body] | 'hang'
function tgServer (plan) {
  const calls = []
  const server = http.createServer((req, res) => {
    const method = req.url.split('/').pop()
    let raw = ''
    req.on('data', (chunk) => { raw += chunk })
    req.on('end', () => {
      let payload = {}
      try { payload = JSON.parse(raw || '{}') } catch (e) { /* corpo vazio */ }
      calls.push({ method, payload })
      const action = plan(method, payload, calls)
      if (action === 'hang') {
        // segura até o cliente abortar (ou o teste acabar)
        req.on('close', () => { try { res.end() } catch (e) {} })
        return
      }
      const [status, body] = action
      res.writeHead(status, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify(body))
    })
  })
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, calls, url: `http://127.0.0.1:${server.address().port}` })
    })
  })
}

function makeBot (tg, store) {
  const bot = new TelegramBot(store)
  bot.apiBase = tg.url
  return bot
}

const ME = { ok: true, result: { id: 99, username: 'lakey_test_bot' } }
const NO_UPDATES = { ok: true, result: [] }
const CONFLICT = [409, { ok: false, error_code: 409, description: 'Conflict: terminated by other getUpdates request' }]

async function scenarioHappyPath () {
  let updatesSent = false
  const tg = await tgServer((method, payload) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [200, ME]
    if (method === 'getUpdates') {
      if (!updatesSent) {
        updatesSent = true
        return [200, { ok: true, result: [{ update_id: 100, message: { message_id: 1, from: { id: 7 }, chat: { id: 42 }, text: '/start' } }] }]
      }
      return [200, NO_UPDATES]
    }
    if (method === 'sendMessage') return [200, { ok: true, result: {} }]
    return [200, { ok: true, result: {} }]
  })
  const bot = makeBot(tg, fakeStore())
  bot.start()
  await sleep(350)
  await bot.stop()
  tg.server.close()

  const methods = tg.calls.map((c) => c.method)
  ok('start: deleteWebhook ANTES de getMe ANTES de getUpdates',
    methods[0] === 'deleteWebhook' && methods[1] === 'getMe' && methods[2] === 'getUpdates')
  ok('update /start processado (sendMessage ao chat 42)',
    tg.calls.some((c) => c.method === 'sendMessage' && c.payload.chat_id === 42))
  const offsets = tg.calls.filter((c) => c.method === 'getUpdates').map((c) => c.payload.offset)
  ok('offset avançou após o update (101)', offsets.includes(101))
  ok('getUpdates usa long-poll (timeout informado)', tg.calls.some((c) => c.method === 'getUpdates' && c.payload.timeout === 25))
}

async function scenarioAdminPreserved () {
  const tg = await tgServer((method) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [200, ME]
    if (method === 'getUpdates') {
      return [200, { ok: true, result: [{ update_id: 1, message: { message_id: 2, from: { id: 7 }, chat: { id: 7 }, text: '/gerar 10' } }] }]
    }
    return [200, { ok: true, result: {} }]
  })
  const bot = makeBot(tg, fakeStore())
  bot.start()
  await sleep(350)
  await bot.stop()
  tg.server.close()
  const card = tg.calls.find((c) => c.method === 'sendMessage' && /AAAA-BBBB-CCCC/.test(c.payload.text || ''))
  ok('funcionalidade preservada: /gerar do admin emite gift card', Boolean(card))
}

async function scenarioConflict () {
  const tg = await tgServer((method) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [200, ME]
    if (method === 'getUpdates') return CONFLICT
    return [200, { ok: true, result: {} }]
  })
  const bot = makeBot(tg, fakeStore())
  bot.conflictLimit = 3
  bot.conflictBackoffMs = 40
  const t0 = Date.now()
  bot.start()
  await bot._loop // o loop termina SOZINHO ao atingir o limite de conflitos
  const elapsed = Date.now() - t0
  tg.server.close()
  const polls = tg.calls.filter((c) => c.method === 'getUpdates').length
  ok('409: exatamente N tentativas (limite respeitado, sem loop infinito)', polls === 3)
  ok('409: backoff respeitado (tempo total coerente)', elapsed >= 80 && elapsed < 4000)
  ok('409: poller encerrou cedendo o token (stopped)', bot.stopped === true)
}

async function scenarioStopAbortsLongPoll () {
  const tg = await tgServer((method) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [200, ME]
    if (method === 'getUpdates') return 'hang'
    return [200, { ok: true, result: {} }]
  })
  const bot = makeBot(tg, fakeStore())
  bot.start()
  await sleep(150) // garante que o getUpdates está em voo
  const t0 = Date.now()
  await bot.stop()
  const elapsed = Date.now() - t0
  tg.server.close()
  ok('stop() aborta long-poll em voo em < 2s', elapsed < 2000)
  ok('stop() deixa o bot marcado como parado', bot.stopped === true)
}

async function scenarioFatalToken () {
  const tg = await tgServer((method) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [401, { ok: false, error_code: 401, description: 'Unauthorized' }]
    return [200, { ok: true, result: {} }]
  })
  const bot = makeBot(tg, fakeStore())
  bot.start()
  await sleep(250)
  tg.server.close()
  const polls = tg.calls.filter((c) => c.method === 'getUpdates').length
  ok('token inválido: nunca chega a pollar (getUpdates = 0)', polls === 0)
  ok('token inválido: loop encerrado', bot.stopped === true)
}

async function scenarioOwnershipRules () {
  // agent + auto: NUNCA toca na API
  const tg = await tgServer(() => [200, { ok: true, result: {} }])
  const agentBot = makeBot(tg, fakeStore('agent', 'auto'))
  agentBot.start()
  await sleep(200)
  ok('Modo agent + BotPolling=auto → zero chamadas à API', tg.calls.length === 0)
  ok('start() em agent nem inicia loop', agentBot.started === false)

  // agent + BotPolling=true: polling forçado funciona
  const tg2 = await tgServer((method) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [200, ME]
    return [200, NO_UPDATES]
  })
  const forced = makeBot(tg2, fakeStore('agent', true))
  forced.start()
  await sleep(250)
  ok('Modo agent + BotPolling=true → polling forçado ativo', tg2.calls.some((c) => c.method === 'getUpdates'))

  // start() duplicado: um único loop (um único deleteWebhook/getMe)
  forced.start()
  await sleep(200)
  await forced.stop()
  tg2.server.close()
  const claims = tg2.calls.filter((c) => c.method === 'getMe').length
  ok('start() duplicado ignorado (getMe chamado 1x)', claims === 1)
}

async function scenarioTransientBackoff () {
  let failed = false
  const tg = await tgServer((method) => {
    if (method === 'deleteWebhook') return [200, { ok: true, result: true }]
    if (method === 'getMe') return [200, ME]
    if (method === 'getUpdates') {
      if (!failed) {
        failed = true
        return [500, { ok: false, description: 'Internal server error' }]
      }
      return [200, NO_UPDATES]
    }
    return [200, { ok: true, result: {} }]
  })
  const bot = makeBot(tg, fakeStore())
  bot.start()
  await sleep(2600) // espera o backoff transitório (2s) + novo ciclo
  await bot.stop()
  tg.server.close()
  const polls = tg.calls.filter((c) => c.method === 'getUpdates').length
  ok('erro transitório recupera (500 → polling retomado)', polls >= 2)
}

async function main () {
  await scenarioHappyPath()
  await scenarioAdminPreserved()
  await scenarioConflict()
  await scenarioStopAbortsLongPoll()
  await scenarioFatalToken()
  await scenarioOwnershipRules()
  await scenarioTransientBackoff()
  console.log(`smoke_bot: TODOS OS ${CHECKS} CHECKS PASSARAM`)
  process.exit(0)
}

setTimeout(() => { console.error('smoke_bot: TIMEOUT global'); process.exit(1) }, 30000).unref()
main().catch((error) => { console.error('smoke_bot: exceção', error); process.exit(1) })
