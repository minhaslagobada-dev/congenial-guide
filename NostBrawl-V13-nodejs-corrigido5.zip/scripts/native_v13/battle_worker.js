'use strict'
// Port of battle_worker.py.
// Persistent original ARM64 battle engine; JSON-lines IPC, never gameplay JS.
//
// Native failures terminate the worker: resuming a half-executed C++ call
// could corrupt every match sharing its allocator. The parent must abort
// those sessions.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { NativePlacements } = require('./native_battle_results')
const P = require('./lib/pycompat')
const { ValueError, getitem, dictGet, contains, truthy, dumps, loads, isNonFatal, encodeUtf8 } = P

const MAX_LINE = 131072
let exiting = false
function send (value, callback) {
  const line = dumps(value) + '\n'
  if (callback) process.stdout.write(line, callback)
  else process.stdout.write(line)
}
function integer (value, low, high) {
  if (!(typeof value === 'number' && Number.isInteger(value)) && typeof value !== 'bigint') throw new ValueError('Integer outside allowed range')
  if (!(value >= low && value <= high)) throw new ValueError('Integer outside allowed range')
  return Number(value)
}
function identity (value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(value)) throw new ValueError('Invalid match ID')
  return value
}
function rowDefinition (table, row) {
  const definition = {}
  table.names.forEach((name, i) => { if (i < row.length) definition[name] = row[i] })
  return definition
}
function indexOfKey (map, key) { let i = 0; for (const k of map.keys()) { if (k === key) return i; i++ } return -1 }

async function main () {
  const n = await NativeV13.create({ heap_bytes: 0x8000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 })
  n.decrypt(); const root = path.resolve(__dirname, '..', '..')
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets')); const matches = new Map(); const placements = new Map()
  send({ event: 'ready', engine: 'original-v13-arm64' })
  // The roster size is fixed at creation; validating an input index must not
  // run the native describe() walk once per input packet.
  const counts = new Map()
  const playerCount = (match_id, battle) => {
    if (!counts.has(match_id)) counts.set(match_id, battle.describe().players.length)
    return counts.get(match_id)
  }
  const inputBytes = value => {
    if (typeof value !== 'string' || !(value.length > 0 && value.length <= 16384) || value.length % 2 || !/^[0-9a-fA-F]+$/.test(value)) throw new ValueError('Invalid input bytes')
    return Buffer.from(value, 'hex')
  }
  const frame = (match_id, battle) => {
    const snapshots = battle.frame(); const state = battle.describe()
    if (placements.has(match_id)) {
      const observer = placements.get(match_id); observer.observe(state)
      for (const player of state.players) player.rank = observer.ranks.has(player.index) ? observer.ranks.get(player.index) : null
    }
    return { state, vision: snapshots }
  }

  const handle = raw => {
    let request_id = null
    try {
      n.setTimeoutReport(dumps({ requestId: null, error: 'Native execution stopped before return: call timeout exceeded', fatal: true }) + '\n')
      if (raw.length > MAX_LINE) throw new ValueError('IPC request too large')
      const request = loads(raw); request_id = integer(getitem(request, 'requestId'), 1, 2147483647)
      n.setTimeoutReport(dumps({ requestId: request_id, error: 'Native execution stopped before return: call timeout exceeded', fatal: true }) + '\n')
      const command = getitem(request, 'command')
      if (command === 'shutdown') {
        for (const observer of placements.values()) observer.close()
        for (const battle of matches.values()) battle.close()
        send({ requestId: request_id, result: true }); return 'break'
      }
      const match_id = identity(getitem(request, 'matchId'))
      let result
      if (command === 'create') {
        if (matches.has(match_id)) throw new ValueError('Duplicate match ID')
        const location = getitem(request, 'location'); let players = getitem(request, 'players'); const seed = integer(getitem(request, 'seed'), 0, 2147483647)
        if (!contains(data.entries.get(15), location)) throw new ValueError('Unknown native location')
        const table = data.csv.get(15); const row = table.records[indexOfKey(data.entries.get(15), location)]
        const definition = rowDefinition(table, row); const mode = getitem(definition, 'GameMode')
        if (getitem(definition, 'Disabled') === 'true' || (!getitem(definition, 'AllowedMaps') && mode !== 'Tutorial')) throw new ValueError('Disabled native location')
        const kinds = { BattleRoyale: 0, BattleRoyaleTeam: 6, Survival: 3, Raid: 7, Tutorial: 5 }
        const kind = Object.prototype.hasOwnProperty.call(kinds, mode) ? kinds[mode] : 1
        const capacity = kind === 5 ? 1 : [0, 6].includes(kind) ? 10 : [3, 7].includes(kind) ? 3 : 6
        if (!Array.isArray(players) || !(players.length >= 1 && players.length <= capacity)) throw new ValueError('Invalid human roster')
        const teams = kind === 5 ? [1] : kind === 0 ? Array(10).fill(1) : kind === 6 ? Array(5).fill(2) : [3, 7].includes(kind) ? [3] : mode === 'BossFight' ? [5, 1] : [3, 3]
        const occupied = Array(teams.length).fill(0)
        // Validate all external values before invoking constructors.
        for (const player of players) {
          if (!contains(data.entries.get(16), getitem(player, 'hero'))) throw new ValueError('Unknown native hero')
          const team = integer(getitem(player, 'team'), 0, teams.length - 1); occupied[team] += 1
          if (occupied[team] > teams[team]) throw new ValueError('Native team capacity exceeded')
          integer(getitem(player, 'accountId'), 1, 2147483647)
          integer(dictGet(player, 'powerLevel', 1), 1, 9)
          const name = getitem(player, 'name')
          if (typeof name !== 'string' || !(encodeUtf8(name).length >= 1 && encodeUtf8(name).length <= 128)) throw new ValueError('Invalid player name')
          for (const [key, type_id, target_column] of [['skin', 29, 'Character'], ['starCard', 23, 'Target']]) {
            const value = dictGet(player, key)
            if (truthy(value)) {
              if (!contains(data.entries.get(type_id), value)) throw new ValueError('Unknown ' + key)
              const source = data.csv.get(type_id); const values = rowDefinition(source, source.records[indexOfKey(data.entries.get(type_id), value)])
              if (getitem(values, target_column) !== getitem(player, 'hero') || (key === 'starCard' && getitem(values, 'MetaType') !== '4')) throw new ValueError('Invalid hero ' + key)
            }
          }
        }
        // The original Solo filler assigns each appended bot its roster
        // index as team ID. Human Solo teams must use the same canonical
        // IDs, including private rooms whose original seats have gaps.
        if (kind === 0) players = players.map((player, index) => Object.assign(Object.create(null), player, { team: index }))
        const battle = new NativeBattle(data, location, kind, seed)
        // Native functions own registered objects; destruction releases them.
        try {
          for (const player of players) {
            battle.add_player(getitem(player, 'hero'), getitem(player, 'team'), { name: getitem(player, 'name'), account_id: getitem(player, 'accountId'), power_level: dictGet(player, 'powerLevel', 1), star_card: dictGet(player, 'starCard'), skin: dictGet(player, 'skin') })
          }
          battle.setup(); matches.set(match_id, battle)
          if (mode === 'BattleRoyale' || mode === 'BattleRoyaleTeam') placements.set(match_id, new NativePlacements(battle))
          result = { kind, state: battle.describe() }
          counts.set(match_id, result.state.players.length)
        } catch (error) {
          battle.close(); throw error
        }
      } else {
        if (!matches.has(match_id)) throw new ValueError('Unknown native match')
        const battle = matches.get(match_id)
        if (command === 'frame') {
          result = frame(match_id, battle)
        } else if (command === 'input') {
          const index = integer(getitem(request, 'playerIndex'), 0, playerCount(match_id, battle) - 1)
          battle.input_packet(index, inputBytes(getitem(request, 'hex'))); result = true
        } else if (command === 'step') {
          // One round trip per tick: the tick's input packets in arrival
          // order, then the frame. Identical to N 'input' + one 'frame'.
          const inputs = getitem(request, 'inputs')
          if (!Array.isArray(inputs) || inputs.length > 256) throw new ValueError('Invalid step inputs')
          const count = playerCount(match_id, battle)
          const decoded = inputs.map(item => {
            if (!Array.isArray(item) || item.length !== 2) throw new ValueError('Invalid step inputs')
            return [integer(item[0], 0, count - 1), inputBytes(item[1])]
          })
          for (const [index, bytes] of decoded) battle.input_packet(index, bytes)
          result = frame(match_id, battle)
        } else if (command === 'destroy') {
          if (placements.has(match_id)) { placements.get(match_id).close(); placements.delete(match_id) }
          battle.close(); matches.delete(match_id); counts.delete(match_id); result = true
        } else throw new ValueError('Unknown native command')
      }
      send({ requestId: request_id, result })
    } catch (error) {
      if (isNonFatal(error)) {
        send({ requestId: request_id, error: String(error.message) })
      } else {
        exiting = true
        send({ requestId: request_id, error: String(error && error.message !== undefined ? error.message : error), fatal: true }, () => process.exit(1))
        return 'exit'
      }
    }
    return null
  }

  let pending = Buffer.alloc(0)
  const drain = final => {
    for (;;) {
      if (exiting) return
      let end = pending.indexOf(0x0a)
      if (end < 0) {
        if (!final || !pending.length) return
        end = pending.length - 1
      }
      const raw = pending.subarray(0, end + 1); pending = pending.subarray(end + 1)
      const outcome = handle(raw)
      if (outcome === 'break') { exiting = true; process.stdin.pause(); process.stdout.write('', () => process.exit(0)); return }
      if (outcome === 'exit') { process.stdin.pause(); return }
    }
  }
  process.stdin.on('data', chunk => { pending = pending.length ? Buffer.concat([pending, chunk]) : chunk; drain(false) })
  process.stdin.on('end', () => { drain(true); if (!exiting) process.stdout.write('', () => process.exit(0)) })
}

main().catch(error => {
  process.stderr.write((error && error.stack) ? error.stack + '\n' : String(error) + '\n')
  process.exit(1)
})
