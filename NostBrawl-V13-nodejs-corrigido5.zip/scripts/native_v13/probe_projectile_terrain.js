'use strict'
// Port of probe_projectile_terrain.py.
// Execute original projectile collision on controlled terrain.
// No gameplay hooks. No characters are registered in the object manager.
// Native terrain destruction executes; fine movement-grid rebuilding is outside this fixture.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { NativeOpenMap } = require('./native_open_map')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root)
  // Native global is looked up by the literal Open at 0x45ac54..0x45ac84.
  terrain.csv.ptr(0xab42d0, terrain.metadata.get('Open'))
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const battle = t.alloc(0x400); p(battle + 0x70, terrain.pointer); w(battle + 0x18, 100); w(battle + 0x20, 17)
  const manager = t.alloc(0x80); p(manager + 0x50, battle); p(battle, manager)
  const table = t.alloc(0x40); w(table + 0x28, 6)
  const origin = t.alloc(0x400)
  // Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
  p(origin, 0x74e558); w(origin + 0x30, 3000); w(origin + 0x34, 4500)
  w(origin + 0x3c, 1); w(origin + 0x40, 2)
  const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row)
    if (d.Indirect === 'true') return
    const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); p(meta + 0x10, table)
    w(meta + 0x94, R.int0(d.Speed)); w(meta + 0x98, R.int0(d.Radius)); w(meta + 0xa0, R.int0(d.Gravity))
    for (const tileName of ['Open', 'Indestructible', 'Water', 'Blocking1', 'Forest']) {
      for (const [previous, current] of [[[2500, 4650], [3500, 4650]], [[3500, 4650], [2500, 4650]], [[3150, 4000], [3150, 5200]], [[2500, 4000], [3500, 5200]]]) {
        const tile = terrain.set_tile(10, 15, tileName)
        const obj = t.alloc(0x120); n.call(0x4d30d0, obj, meta); p(obj + 0x18, manager)
        w(obj + 0x90, previous[0]); w(obj + 0x94, previous[1]); w(obj + 0x30, current[0]); w(obj + 0x34, current[1]); w(obj + 0x3c, 1)
        const result = n.call(0x373994, obj)
        const properties = {}
        for (const k of ['PassesEnvironment', 'PiercesEnvironment', 'PiercesEnvironmentLikeButter', 'Radius']) properties[k] = d[k]
        records.push({
          name: d.Name, tile: tileName, previous, current, result,
          position: [get(obj + 0x30), get(obj + 0x34)], contact: [get(obj + 0x58), get(obj + 0x5c)], tileIndex: get(obj + 0xc4), side: get(obj + 0xc0), destroyed: m.u64(tile) === terrain.metadata.get('Open') && tileName !== 'Open', properties
        })
      }
    }
  })
  R.writeJson('projectile-terrain-vectors.json', records)
  R.print('Original projectile terrain collision:', records.length, 'cases; no gameplay hooks')
})
