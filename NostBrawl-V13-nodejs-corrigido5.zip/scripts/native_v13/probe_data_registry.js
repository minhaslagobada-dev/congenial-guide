'use strict'
// Port of probe_data_registry.py.
// Construct actual metadata from client CSVs, not numeric metadata fixtures.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const records = []
  for (const [name, meta] of data.entries.get(16)) {
    const obj = n.alloc(0x400); n.call(0x14de30, obj, meta)
    records.push({
      name, dataId: data.word(meta + 0x20), hp: data.word(obj + 0xb0), maxHp: data.word(obj + 0xb4), state: data.word(obj + 0x78),
      radius: n.call(0x3305dc, obj), projectileStartZ: data.word(meta + 0x118), speed: data.word(meta + 0x128), type: data.word(meta + 0x184), skills: data.word(obj + 0x13c)
    })
  }
  R.writeJson('data-registry-vectors.json', records)
  R.print('Original data tables + gameplay references + character constructors:', records.length, 'client characters;', data.tables.size, 'tables; no gameplay substitutions or character CSV hooks')
})
