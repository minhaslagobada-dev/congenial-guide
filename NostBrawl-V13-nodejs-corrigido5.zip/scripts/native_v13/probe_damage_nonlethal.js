'use strict'
// Port of probe_damage_nonlethal.py.
// Original applyDamage under controlled nonlethal LootBox metadata.
// This does not validate hero passives, death effects, rewards or HP asset values.
const { NativeV13 } = require('./emulate_v13')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const m = R.memory(n)
  const w = m.put32; const p = m.put64; const get = m.i32
  const manager = n.alloc(0x100); const battle = n.alloc(0x400); p(manager + 0x50, battle); w(battle + 0x18, 100)
  const meta = n.alloc(0x200); w(meta + 0x184, 10)
  const records = []
  for (const damage of [0, 1, 300, 999]) {
    const actor = n.alloc(0x400); p(actor, 0x72dc10); p(actor + 0x10, meta); p(actor + 0x18, manager); w(actor + 0xb0, 1000); w(actor + 0xb4, 1000); w(actor + 0x3c, -1); w(actor + 0x338, -1)
    n.uc.mem_write(0x201ff000, R.pack('Q', 0, 0, 0, 0, 1))
    const result = n.call(0x1df258, actor, 0, damage, 0, 0, 0, 3000, 4500)
    records.push({ damage, result, hp: get(actor + 0xb0), lastDamageTick: get(actor + 0x2b8) })
  }
  R.writeJson('damage-nonlethal-vectors.json', records)
  R.print('Original applyDamage nonlethal controlled input:', records)
})
