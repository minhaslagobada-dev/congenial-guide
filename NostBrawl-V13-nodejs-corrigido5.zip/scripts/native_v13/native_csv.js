'use strict'
// Port of native_csv.py.
// CSV memory adapter for v13's actual table/row/column readers.
//
// This provides asset data, not gameplay callbacks. Native schema
// initializers, column lookup, type checks and value readers execute inside
// the supplied ELF.
const fs = require('node:fs')
const { csvRead, pyInt, encodeUtf8, KeyError, IndexError, StopIteration } = require('./lib/pycompat')

const TYPES = { string: 0, int: 1, boolean: 2 }

class NativeCsv {
  constructor (native, filename, excluded_rows = [], grouped_rows = false) {
    this.native = native
    const raw = csvRead(fs.readFileSync(String(filename), 'utf8'))
    this.names = raw[0]; this.types = raw[1]
    const first = row => { if (!row.length) throw new IndexError('list index out of range'); return row[0] }
    const excluded = new Set(excluded_rows)
    this.records = raw.slice(2).filter(row => !excluded.has(first(row)))
    const entry_indices = []
    this.records.forEach((row, i) => { if (!grouped_rows || row[0]) entry_indices.push(i) })
    this.rows = []
    this.table = this.alloc(0x40)
    const headers = this.alloc(this.names.length * 24)
    const columns = this.alloc(this.names.length * 8)
    const row_array = this.alloc(this.records.length * 8)
    this.ptr(this.table, headers)
    this.word(this.table + 8, this.names.length)
    this.word(this.table + 12, this.names.length)
    this.ptr(this.table + 16, columns)
    this.ptr(this.table + 32, row_array)
    this.word(this.table + 40, entry_indices.length)
    this.word(this.table + 44, entry_indices.length)
    this.names.forEach((name, i) => {
      this.string(headers + i * 24, name)
      const column = this.alloc(0x60)
      this.ptr(columns + i * 8, column)
      const typeName = this.types[i].toLowerCase()
      if (!(typeName in TYPES)) throw new KeyError(typeName)
      const kind = TYPES[typeName]
      this.word(column, kind)
      this.word(column + 0x10, this.records.length)
      this.word(column + 0x14, this.records.length)
      let array
      if (kind === 0) {
        array = this.alloc(this.records.length * 24)
        this.ptr(column + 8, array)
      } else if (kind === 1) {
        array = this.alloc(this.records.length * 4)
        this.ptr(column + 24, array)
        this.word(column + 32, this.records.length)
        this.word(column + 36, this.records.length)
      } else {
        array = this.alloc(this.records.length)
        this.ptr(column + 40, array)
        this.word(column + 48, this.records.length)
        this.word(column + 52, this.records.length)
      }
      this.records.forEach((record, j) => {
        const value = i < record.length ? record[i] : ''
        if (kind === 0) this.string(array + j * 24, value)
        else if (kind === 1) this.word(array + j * 4, value ? pyInt(value) : 0x7fffffff)
        else native.uc.mem_write(array + j, Buffer.from([value.toLowerCase() === 'true' ? 1 : value ? 0 : 2]))
      })
    })
    entry_indices.forEach((i, entry_index) => {
      const row = this.alloc(16)
      this.ptr(row, this.table); this.word(row + 8, i)
      this.ptr(row_array + entry_index * 8, row); this.rows.push(row)
    })
    this.physical_records = this.records
    this.records = entry_indices.map(i => this.physical_records[i])
  }

  alloc (size) {
    size = Math.max(1, size)
    const address = this.native.alloc(size)
    this.native.uc.mem_write(address, Buffer.alloc(size))
    return address
  }

  ptr (address, value) { const b = Buffer.alloc(8); b.writeBigUInt64LE(BigInt.asUintN(64, BigInt(value))); this.native.uc.mem_write(address, b) }
  word (address, value) { const b = Buffer.alloc(4); b.writeUInt32LE(Number(BigInt.asUintN(32, BigInt(value)))); this.native.uc.mem_write(address, b) }

  string (address, value) {
    if (!value) return
    const raw = Buffer.concat([encodeUtf8(value), Buffer.from([0])]); const memory = this.alloc(raw.length)
    this.native.uc.mem_write(memory, raw)
    this.native.call(0x12d868, address, memory)
    this.native.free(memory)
  }

  initialize_schema (fn) {
    this.native.call(fn, this.table, { count: 3000000 })
  }

  find (name) {
    const index = this.records.findIndex(row => row[0] === name)
    if (index < 0) throw new StopIteration()
    return this.rows[index]
  }
}

module.exports = { NativeCsv }
