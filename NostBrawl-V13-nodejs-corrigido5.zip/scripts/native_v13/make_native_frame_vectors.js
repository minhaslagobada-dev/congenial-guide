'use strict'
// Only package original frame bytes and observed object positions for the
// original client reader. This does not run BattleWorld or encode game state.
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR || !process.env.V13_VECTOR_DIR) throw new Error('Set V13_RESEARCH_DIR and V13_VECTOR_DIR')
const assets = new BattleAssets()
const result = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, process.env.V13_FRAME_FILE || 'battle-frame-vectors.json')))
if (result.error) throw new Error(JSON.stringify(result.error))
const grid = result.grid || assets.map(process.env.V13_FRAME_MAP || 'Gemgrab_1')
const vectors = result.frames.map(frame => ({
  name: 'original-frame/' + frame.tick, nativeSnapshot: true, mode: frame.nativeMode,
  capacity: frame.players.length, ownIndex: 0, grid,
  hex: frame.vision[0].hex,
  objects: frame.objects.map(object => ({ nativeId: object.id, fullDataId: object.dataId, x: object.x, y: object.y }))
}))
fs.mkdirSync(process.env.V13_VECTOR_DIR, { recursive: true })
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'world-vectors.json'), JSON.stringify({ tables: assets.tables, vectors }))
console.log('Packaged original native frames:', vectors.length)
