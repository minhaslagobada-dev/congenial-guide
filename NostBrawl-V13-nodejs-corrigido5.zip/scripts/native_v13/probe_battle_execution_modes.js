'use strict'
// Port of probe_battle_execution_modes.py.
// Compare complete original frames with instruction budgets and wall time budgets.
//
// Only the execution watchdog changes. Both runs use original constructors, bot AI,
// physics, encoders and destructors. No gameplay state is replaced by JavaScript.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 })
  n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const results = []; let reference = null
  for (const counted of [true, false]) {
    n.instruction_counting = false
    const battle = new NativeBattle(data, 'Gemgrab1'); battle.add_player('ShotgunGirl', 0); battle.setup()
    data.csv.get(15).word(battle.pointer + 0x18, 300)
    const frames = []; const start = performance.now(); n.instruction_counting = counted
    n.call_timeout_us = counted ? 0 : 2000000
    for (let index = 0; index < 40; index++) {
      const snapshots = battle.frame(); const state = battle.describe()
      frames.push({ state, vision: snapshots })
    }
    const elapsed = (performance.now() - start) / 1000; n.instruction_counting = false; n.call_timeout_us = 2000000
    battle.close()
    if (reference === null) reference = frames
    else {
      const count = Math.min(reference.length, frames.length)
      for (let index = 0; index < count; index++) R.assert(R.deepEqual(frames[index], reference[index]), `Execution watchdog changed native frame ${index}`)
    }
    results.push({ instructionCounting: counted, frames: frames.length, elapsedSeconds: elapsed })
    R.print('Execution mode', results[results.length - 1])
  }
  R.writeJson('battle-execution-modes.json', { identical: true, runs: results })
  R.print('Original complete frames and vision bytes identical with both execution watchdogs')
})
