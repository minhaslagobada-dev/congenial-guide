'use strict'
// Port of probe_angle.py.
// Original v13 angle lookup, with original decrypted arctangent table.
const { NativeV13 } = require('./emulate_v13')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const records = []; const m = R.memory(n)
  const table = Array.from({ length: 129 }, (_, i) => m.i32(0x9aadfc + 4 * i))
  const run = (x, y) => records.push({ x, y, angle: n.call(0x1cd630, R.u32(x), R.u32(y)) })
  const values = [-65535, -10000, -300, -1, 0, 1, 300, 10000, 65535]
  for (const x of values) for (const y of values) run(x, y)
  let seed = 17
  for (let i = 0; i < 6000; i++) {
    seed = (seed * 1664525 + 1013904223) % 4294967296; const x = seed % 131071 - 65535
    seed = (seed * 1664525 + 1013904223) % 4294967296; const y = seed % 131071 - 65535
    run(x, y)
  }
  R.writeJson('angle-table.json', table)
  R.writeJson('angle-vectors.json', records)
  R.print('Original v13 integer angle:', records.length, 'cases; original 129-entry table')
})
