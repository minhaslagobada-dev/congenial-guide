'use strict'
// Port of probe_tile_map.py.
// Original full map construction and movement-grid setup from client CSVs.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { RuntimeError, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  // This sweep retains all allocations; free() is a no-op in the harness.
  const n = await NativeV13.create({ heap_bytes: 0x4000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const t = data.csv.get(19); const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v)
  // Global Open tile lookup is initialized by the client's data-table registry.
  p(0xab42d0, data.named(27, 'Open'))
  const records = []
  const names = []
  for (const row of t.physical_records) if (row[1] && row[1] !== 'end' && !names.includes(row[1])) names.push(row[1])
  for (const name of names) {
    if (process.env.V13_MAP && name !== process.env.V13_MAP) continue
    const mapName = t.alloc(24); t.string(mapName, name)
    const rng = t.alloc(16); w(rng, 17)
    const map = t.alloc(0x100)
    try { n.call(0xf1f88, map, rng, 0, mapName, 0, { count: 20000000 }) } catch (e) {
      const error = new RuntimeError(pyRepr(tuple(name, R.errorMessage(e), m.pc(), m.lr()))); error.cause = e; throw error
    }
    const record = { name, width: data.word(map + 0x40), height: data.word(map + 0x44), logicWidth: data.word(map + 0x48), logicHeight: data.word(map + 0x4c), fineWidth: data.word(map + 0x50), fineHeight: data.word(map + 0x54), tiles: data.word(map + 0x58), respawningTiles: data.word(map + 0x60) }
    R.assert(record.width > 0 && record.height > 0)
    const source = data.ptr(map + 0x20); const cells = data.ptr(source + 0x10)
    record.grid = []
    for (let y = 0; y < record.height; y++) {
      let line = ''
      for (let x = 0; x < record.width; x++) line += String.fromCodePoint(data.word(cells + (y * record.width + x) * 4))
      record.grid.push(line)
    }
    records.push(record)
    R.print('map', name, record.width, record.height, 'heap', n.heap - 0x10000000)
  }
  R.writeJson('tile-map-vectors.json', records)
  R.print('Original full tile maps:', records.length, 'groups; native layout and movement-grid setup')
})
