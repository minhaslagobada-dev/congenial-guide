'use strict'
// Port of probe_skill_idle.py.
// Oracle for the actual v13 SkillServer::tick idle branch (0xeca90).
// The complete function at 0xec2a8 is invoked. No gameplay function is hooked.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const m = R.memory(n)
  const alloc = s => { const p = n.alloc(s); n.uc.mem_write(p, Buffer.alloc(s)); return p }
  const w = m.put32; const p = m.put64; const get = m.i32
  const root = R.ROOT
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  const manager = alloc(0x100); const battle = alloc(0x400); const owner = alloc(0x400); const globals = alloc(0x200)
  p(owner + 0x18, manager); p(manager + 0x50, battle); p(0xabb9b8, globals); w(globals + 0xb4, 20)
  const result = []
  const behaviors = { Attack: 0, Blink: 1, Charge: 2, Invisibility: 3, TransformMinion: 4, BuffMinion: 5, Rage: 6, Shield: 7 }
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = alloc(0x200); p(meta + 8, t.rows[i])
    const behavior = behaviors[d.BehaviorType]
    if (behavior === undefined) throw new Error('KeyError: ' + d.BehaviorType)
    w(meta + 0xb8, behavior)
    for (const [active, cooldown, ammo] of [[0, 0, 0], [0, 25, 0], [0, 50, 0], [0, 51, 0], [25, 100, 2990], [50, 50, 0], [51, 0, 0], [100, 0, 0]]) {
      for (const berserk of [false, true]) {
        for (const [mode, team] of [[0, 0], [7, 0], [7, 1]]) {
          const state = alloc(0x30); n.call(0x248d70, state, meta)
          w(state + 0xc, active); w(state + 0x10, cooldown); w(state + 0x14, ammo)
          n.uc.mem_write(state + 0x21, Buffer.from([1]))
          n.uc.mem_write(owner + 0x205, Buffer.from([berserk ? 1 : 0])); n.uc.mem_write(owner + 0x188, Buffer.from([1])); w(owner + 0x2fc, 1)
          w(battle + 0xe8, mode); w(owner + 0x40, team)
          n.call(0xec2a8, state, owner, 50)
          result.push({
            skill: d.Name,
            definition: { maxCharge: R.int0(d.MaxCharge), rechargeTime: R.int0(d.RechargeTime), behavior },
            before: { activeMs: active, cooldownMs: cooldown, ammo, berserk, mode, team },
            after: { activeMs: get(state + 0xc), cooldownMs: get(state + 0x10), ammo: get(state + 0x14), pending: m.u8(state + 0x21), ownerAttack: m.u8(owner + 0x188), ownerSlot: get(owner + 0x2fc) }
          })
        }
      }
    }
  })
  R.writeJson('skill-idle-vectors.json', result)
  R.print('Original v13 SkillServer::tick idle oracle:', result.length, 'cases; native schema/readers; no gameplay substitutions')
})
