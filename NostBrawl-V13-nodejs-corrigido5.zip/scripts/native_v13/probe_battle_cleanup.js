'use strict'
// Port of probe_battle_cleanup.py.
// Original match destruction with a reclaiming guest heap and shared metadata.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const liveBytes = () => { let sum = 0; for (const [, capacity] of n.guest_heap.live.values()) sum += capacity; return sum }
  const result = { baselineBytes: liveBytes(), matches: [] }
  n.guest_heap.trace_allocations = true
  try {
    for (let index = 0; index < 5; index++) {
      const previous = new Set(n.guest_heap.live.keys())
      const battle = new NativeBattle(data, 'Gemgrab1', 1, 17 + index)
      battle.add_player('ShotgunGirl', 0, { power_level: 9, star_card: 'ShotgunGirl_unique', skin: 'BanditGirlPrereg' })
      battle.setup()
      for (let tick = 0; tick < 40; tick++) {
        if (tick === 2 || tick === 20) {
          const command = tick === 2 ? { code: 100, x: 3150, y: 6150 } : { code: 0, targetId: 1000003, flag: true }
          battle.input_packet(0, battle.encode_input_packet([command], tick + 1))
        }
        battle.frame()
      }
      battle.close(); battle.close()
      const outstanding = [...n.guest_heap.live.keys()].filter(address => !previous.has(address)).map(address => ({ address: R.hex(address), size: n.guest_heap.live.get(address)[0], capacity: n.guest_heap.live.get(address)[1], origin: (n.guest_heap.origins.get(address) || []).map(value => R.hex(value)) }))
      const record = { index, liveBytes: liveBytes(), peakBytes: n.guest_heap.peak, outstanding }
      result.matches.push(record); R.print('native match destroyed', record)
    }
  } catch (e) {
    result.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
    R.print('blocked', result.error)
  }
  R.writeJson('battle-cleanup-vectors.json', result)
  if ('error' in result) throw new R.SystemExit(1)
  R.print('Original match destruction completed:', result.matches.length, 'matches; measured live guest allocations')
})
