'use strict'
// Port of validate_native_csv.py.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { RuntimeError, decodeUtf8, pyInt, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const m = R.memory(n)
  let lastColumn = []
  const inspect = (uc, address, size, data) => {
    if (address === 0x3fd61c) {
      const p = Number(uc.reg_read(C.UC_ARM64_REG_X1))
      const length = m.u32(p + 4)
      const text = length < 8 ? p + 8 : m.u64(p + 8)
      lastColumn = [decodeUtf8(uc.mem_read(text, length))]
    } else if (!uc.reg_read(C.UC_ARM64_REG_X0)) {
      throw new RuntimeError(pyRepr(tuple('Original v13 schema assertion', lastColumn, R.hex(uc.reg_read(C.UC_ARM64_REG_LR)))))
    }
  }
  n.uc.hook_add(C.UC_HOOK_CODE, inspect, null, 0x3fd61c, 0x3fd61c)
  n.uc.hook_add(C.UC_HOOK_CODE, inspect, null, 0x1dca94, 0x1dca94)
  const root = R.ROOT
  const checks = []
  for (const [name, initializer] of [['characters', 0x1fbfa4], ['skills', 0x13da8c]]) {
    const filename = path.join(root, 'GameAssets/csv_logic', `${name}.csv`)
    const raw = R.csvRows(filename)
    const rejected = []
    for (const row of raw.slice(2)) {
      raw[1].forEach((kind, i) => {
        const value = i < row.length ? row[i] : ''
        if (kind.toLowerCase() === 'int' && value) {
          try { pyInt(value) } catch (_) { rejected.push({ row: row[0], column: raw[0][i], value }) }
        }
      })
    }
    const excluded = [...new Set(rejected.map(r => r.row))].sort()
    const table = new NativeCsv(n, filename, excluded)
    try { table.initialize_schema(initializer) } catch (error) {
      if (!(error instanceof RuntimeError)) throw error
      if (!String(error.message).includes('Original v13 schema assertion')) throw error
      checks.push({ table: name, schema: 'rejected by original v13', firstFailedColumn: lastColumn[0], rejected })
      continue
    }
    table.records.forEach((row, index) => {
      table.types.forEach((kind, column) => {
        const value = column < row.length ? row[column] : ''
        if (kind.toLowerCase() === 'int') {
          const actual = n.call(0x469228, table.rows[index], column)
          const expected = BigInt.asUintN(64, value ? pyInt(value) : 0n)
          // X0 returns a 32-bit result; compare the exact 32 bits.
          R.assert((actual & 0xffffffffn) === (expected & 0xffffffffn), tuple(name, index, column, value, actual))
        } else if (kind.toLowerCase() === 'boolean') {
          const actual = n.call(0x24f974, table.rows[index], column)
          R.assert(actual === BigInt(value.toLowerCase() === 'true' ? 1 : 0), tuple(name, index, column, value, actual))
        }
      })
    })
    checks.push({ table: name, rows: table.rows.length, columns: table.names.length, rejected })
  }
  R.writeJson('csv-validation.json', checks, 2)
  R.print('Native CSV audit completed:', R.toJson(checks))
})
