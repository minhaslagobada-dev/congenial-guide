'use strict'
const path = require('node:path')
const fs = require('node:fs')
process.chdir(path.resolve(__dirname, '../..'))
const StartLoading = require('../../Packets/Messages/Server/Battle/StartLoadingMessage')
const { battleAssets } = require('../../Logic/Battle/World/BattleAssets')
const { rules } = require('../../Logic/Battle/World/GameModes')
const { BattleParticipants } = require('../../Logic/Battle/BattleParticipants')
const Skins = require('../../Files/CsvLogic/Skins')
const assets = battleAssets()
const out = []
function vector (location, hero, bots, ownIndex) {
  const mode = rules(location.GameMode)
  const capacities = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
  const teams = capacities.flatMap((capacity, team) => Array(capacity).fill(team))
  const entries = teams.map((team, index) => {
    const brawler = assets.heroes[(hero + index) % assets.heroes.length]
    const bot = bots && index !== ownIndex
    return { index, team, bot, low_id: bot ? 0 : 123000 + index, high_id: bot ? 0 : index + 1,
      name: index === 0 ? 'Player 1' : index === ownIndex ? 'Jogador 🦁' : bot ? 'Bot ' + index : 'Amigo ' + index,
      brawler_id: brawler.id, skin_id: Skins.get_default_skin(brawler.id) }
  })
  const own = entries[ownIndex]
  const message = new StartLoading(null, { low_id: own.low_id, map_id: location.id }, { map_id: location.id }, entries)
  message.encode()
  return { name: `${location.Name}/${hero}/${bots ? 'bots' : 'humans'}/${ownIndex}`, mapId: location.id, variation: mode.variation,
    loadingType: BattleParticipants.loading_game_type(entries), ownIndex, ownTeam: own.team, entries, hex: message.buffer.toString('hex') }
}
for (const location of assets.tables.locations.filter(l => l.AllowedMaps && l.Disabled !== 'true' && l.GameMode !== 'Tutorial')) {
  out.push(vector(location, 0, true, 0))
  out.push(vector(location, 1, false, rules(location.GameMode).capacity - 1))
}
for (let hero = 0; hero < assets.heroes.length; hero++) out.push(vector(assets.tables.locations[7], hero, true, 3))
// Regression specimen: recreate the missing LogicLong prefix from the released
// packet, rather than accepting a JS parser that shares the encoder's mistake.
const first = out[0]; const good = Buffer.from(first.hex, 'hex')
out.push({ ...first, name: 'legacy-missing-account-id', invalid: true, hex: Buffer.concat([good.subarray(0, 16), good.subarray(24)]).toString('hex') })
out.push({ ...first, name: 'truncated-loading', invalid: true, hex: good.subarray(0, good.length - 1).toString('hex') })
const oldCategory = Buffer.from(out.find(v => v.mapId === 7).hex, 'hex')
// Locate category immediately before the fixed suffix: category,1,3,false,0,19,15,map.
oldCategory[oldCategory.length - 8] = 0
out.push({ ...out.find(v => v.mapId === 7), name: 'legacy-location-mode-as-loading-category', invalid: true, loadingType: 0, hex: oldCategory.toString('hex') })
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'loading-vectors.json'), JSON.stringify(out))
