'use strict'
// Port of probe_projectile_shoot.py.
// Execute original shoot routine including factory and manager registration, with a non-character origin fixture.
// No gameplay hooks. Hero muzzle offsets are excluded by the controlled origin type.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { NativeOpenMap } = require('./native_open_map')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const battle = t.alloc(0x400); p(battle + 0x70, terrain.pointer); w(battle + 0x18, 100); w(battle + 0x20, 17)
  const manager = t.alloc(0x80); p(manager + 0x50, battle); p(battle, manager)
  const table = t.alloc(0x40); w(table + 0x28, 6)
  const origin = t.alloc(0x400)
  // Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
  p(origin, 0x74e558); w(origin + 0x30, 3000); w(origin + 0x34, 4500)
  w(origin + 0x3c, 1); w(origin + 0x40, 2)
  const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); p(meta + 0x10, table)
    n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0, d.ConstantFlyTime === 'true' ? 1 : 0]))
    w(meta + 0x94, R.int0(d.Speed)); w(meta + 0xa0, R.int0(d.Gravity))
    for (const target of [[5317, 8429], [3100, 4500], [3000, 4500], [6200, 9800]]) {
      for (const spread of [0, 30, -30, 100]) {
        for (const deterministic of [0, 1]) {
          for (let pattern = 0; pattern < 6; pattern++) {
            const stack = 0x201ff000
            n.uc.mem_write(stack, R.pack('Q', 456, R.u32(spread), deterministic, 0, battle, pattern, 0))
            const before = get(manager + 0xc); const rngBefore = get(battle + 0x20)
            const obj = Number(n.call(0x4a0228, 3000, 4500, 0, origin, meta, target[0], target[1], 123))
            R.assert(get(manager + 0xc) === before + 1)
            R.assert(m.u64(obj + 0x18) === manager)
            R.assert(get(obj + 0x3c) === 1 && get(obj + 0x40) === 2)
            R.assert(get(obj + 0x74) === 123 && get(obj + 0x78) === 456)
            const points = []; const point = t.alloc(8)
            for (const tick of [100, Math.floor((100 + get(obj + 0x24)) / 2), get(obj + 0x24)]) {
              const z = n.call(0x350c04, obj, tick, point)
              points.push({ tick, output: { x: get(point), y: get(point + 4), z } })
            }
            records.push({
              name: d.Name, aim: target, spread, deterministic, pattern,
              launch: get(obj + 0x20), finish: get(obj + 0x24), target: [get(obj + 0x68), get(obj + 0x6c)],
              start: [get(obj + 0x60), get(obj + 0x64)], rngState: get(battle + 0x20), rngBefore,
              progressStep: get(obj + 0xcc), z: get(obj + 0x70), points,
              data: { indirect: d.Indirect === 'true', speed: R.int0(d.Speed), constantFlyTime: d.ConstantFlyTime === 'true', gravity: R.int0(d.Gravity), bounce: R.int0(d.BouncePercent) }
            })
          }
        }
      }
    }
  })
  R.writeJson('projectile-shoot-vectors.json', records)
  R.print('Original projectile creation + spread + launch:', records.length, 'cases; controlled non-character origin; no gameplay hooks')
})
