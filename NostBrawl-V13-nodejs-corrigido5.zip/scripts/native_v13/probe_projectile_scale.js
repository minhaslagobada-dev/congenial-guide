'use strict'
// Port of probe_projectile_scale.py.
// Original projectile scale and flight-dependent damage, no gameplay hooks.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); const obj = t.alloc(0x120); n.call(0x4d30d0, obj, meta)
    for (const progress of [-1, 0, 1, 149, 150, 499, 500, 850, 999, 1000, 1001]) {
      w(obj + 0xc8, progress)
      const scale = R.signed32(n.call(0x3009c8, obj, R.u32(progress)))
      const damages = []
      for (const damage of [0, 1, 300, 999, 50000]) damages.push({ input: damage, output: R.signed32(n.call(0x474ed4, obj, damage)) })
      records.push({ definition: d, progress, scale, damages })
    }
  })
  R.writeJson('projectile-scale-vectors.json', records)
  R.print('Original projectile scale/damage:', records.length, 'scale cases;', records.reduce((s, r) => s + r.damages.length, 0), 'damage cases')
})
