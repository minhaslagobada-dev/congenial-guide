'use strict'
// Port of probe_hero_skills.py.
// Exercise original hero skill activation and character updates with client data.
//
// This is a controlled world, with full ammo/charge as explicit input. By default
// other objects are counted but not ticked. V13_ADVANCE_OBJECTS=1 invokes the
// original manager update as well. A complete game mode and networking are not
// certified here. Failures are reported, never replaced by game hooks.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeTileMap } = require('./native_tile_map')
const { ValueError, pyInt } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const advanceObjects = process.env.V13_ADVANCE_OBJECTS === '1'
  const enemyName = process.env.V13_ENEMY
  const enemyHp = process.env.V13_ENEMY_HP ? Number(pyInt(process.env.V13_ENEMY_HP)) : null
  if (enemyName && !advanceObjects) throw new ValueError('Enemy collision exercise requires original manager updates')
  if (enemyHp !== null && !enemyName) throw new ValueError('Injured target input requires V13_ENEMY')
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const terrain = new NativeTileMap(data, 'Tutorial'); const t = data.csv.get(16); const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const records = []
  for (const row of t.records) {
    const hero = R.zipDict(t.names, row)
    if (hero.Type !== 'Hero' || hero.Disabled === 'true' || hero.LockedForChronos === 'true') continue
    for (const [slot, key] of [[0, 'WeaponSkill'], [1, 'UltimateSkill']]) {
      const manager = t.alloc(0x100); const battle = t.alloc(0x400); p(manager + 0x50, battle); p(battle, manager); p(battle + 0x70, terrain.pointer)
      const players = t.alloc(6 * 8); p(battle + 0x78, players)
      for (let i = 0; i < 6; i++) { const player = t.alloc(0x200); p(players + i * 8, player); w(player + 0x60, 1000) }
      const playerList = t.alloc(16); p(playerList, players); w(playerList + 8, 6); w(playerList + 12, 6)
      const obj = t.alloc(0x400); n.call(0x14de30, obj, data.named(16, hero.Name)); w(obj + 0x3c, 0); w(obj + 0x40, 0); n.call(0x253b18, manager, obj); n.call(0x465f38, obj, 2550, 3450, 0)
      let enemy = 0
      if (enemyName) {
        enemy = t.alloc(0x400); n.call(0x14de30, enemy, data.named(16, enemyName)); w(enemy + 0x3c, -1); w(enemy + 0x40, 1); n.call(0x253b18, manager, enemy); n.call(0x465f38, enemy, 3150, 3450, 0)
        if (enemyHp !== null) {
          R.assert(enemyHp > 0 && enemyHp <= data.word(enemy + 0xb0), 'Injured target input must be within native maximum HP')
          w(enemy + 0xb0, enemyHp)
        }
      }
      w(battle + 0x18, 150); n.call(0x18ff68, obj, { count: 3000000 })
      const state = data.ptr(data.ptr(obj + 0x130) + slot * 8); w(state + 0x14, 3000); w(state + 0x10, 0)
      const record = { hero: hero.Name, skill: hero[key], slot, frames: [] }
      try {
        n.call(0x4a3f3c, state, obj, 3150, 3450, terrain.pointer, 150, { count: 3000000 })
        for (let tick = 150; tick < 190; tick++) {
          w(battle + 0x18, tick)
          if (advanceObjects) n.call(0x18572c, manager, playerList, { count: 10000000 })
          else n.call(0x18ff68, obj, { count: 3000000 })
          const objectIds = []
          for (let index = 0; index < data.word(manager + 0xc); index++) {
            const current = data.ptr(data.ptr(manager) + index * 8); const metadata = data.ptr(current + 0x10)
            objectIds.push(metadata ? data.word(metadata + 0x20) : null)
          }
          record.frames.push({ tick, x: data.word(obj + 0x30), y: data.word(obj + 0x34), hp: data.word(obj + 0xb0), objects: data.word(manager + 0xc), objectDataIds: objectIds, activeMs: data.word(state + 0xc), ammo: data.word(state + 0x14), enemyHp: enemy ? data.word(enemy + 0xb0) : null })
        }
        R.print('skill', hero.Name, hero[key], 'objects', record.frames[record.frames.length - 1].objects)
      } catch (e) {
        record.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
        R.print('blocked', hero.Name, hero[key], record.error)
      }
      records.push(record)
    }
  }
  const filename = enemyHp !== null ? 'hero-death-vectors.json' : enemyName ? 'hero-enemy-vectors.json' : advanceObjects ? 'hero-world-vectors.json' : 'hero-skills-vectors.json'
  R.writeJson(filename, records)
  const failed = records.filter(r => 'error' in r)
  const scope = advanceObjects ? 'native manager updates' : 'other objects not advanced'
  R.print('Original hero skill exercise:', records.length, 'skills;', failed.length, 'blocked; controlled input;', scope)
  if (failed.length) throw new R.SystemExit(1)
})
