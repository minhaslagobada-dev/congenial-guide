'use strict'
// Port of native.py: loads the v13 libg.so, verifies its identity and offers
// the same static helpers (read/ptr/dump/calls/adrrefs) used by the tools.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { ELFFile, SHT_NOBITS, SHT_RELA } = require('./lib/elf')

const libraryPath = process.env.LIBG_V13 || path.resolve(__dirname, '../../Native/V13/libg.so')
const fileBytes = fs.readFileSync(libraryPath)
const elf_sha256 = crypto.createHash('sha256').update(fileBytes).digest('hex')
const KNOWN_LIBRARIES = {
  '782ca3ed0a404cb1a28a9b65808c5ef5a40e57d5ada5ead54ae01540bbeb87db': 'reference-v13',
  '8d7a7f463f68edb6f4618c706670477ea18730eacfd788ebd17f9734b5f8c578': 'supplied-client-apk'
}
if (!(elf_sha256 in KNOWN_LIBRARIES)) throw new Error('Unexpected v13 library: offsets are specific to the supplied reference/client libg.so')
const elf = new ELFFile(fileBytes)
const secs = elf.iter_sections().filter(s => s.sh_type !== SHT_NOBITS && (s.sh_flags & 2)).map(s => [s.sh_addr, s.data()])
const t = elf.get_section_by_name('.text'); const code = t.data(); const base = t.sh_addr
// r_offset -> r_addend (BigInt) for every RELA section, later entries win (dict semantics).
const relocs = new Map()
for (const s of elf.iter_sections()) {
  if (s.sh_type !== SHT_RELA) continue
  for (const r of elf.iter_relocations(s)) relocs.set(r.r_offset, r.r_addend)
}

function read (a, n) {
  for (const [st, d] of secs) {
    if (st <= a && a + n <= st + d.length) return d.subarray(a - st, a - st + n)
  }
  return Buffer.alloc(0)
}
function ptr (a) {
  if (relocs.has(a)) return relocs.get(a)
  const b = read(a, 8)
  if (b.length !== 8) throw new Error('unpack requires a buffer of 8 bytes')
  return b.readBigUInt64LE(0)
}

let capstone = null
async function disassembler () {
  if (capstone) return capstone
  let factory
  try { factory = require('@alexaltea/capstone-js') } catch (_) {
    throw new Error('Disassembly requires the optional dependency @alexaltea/capstone-js@5.0.9 (npm install @alexaltea/capstone-js)')
  }
  const cs = await factory()
  capstone = new cs.Capstone(cs.ARCH_ARM64, cs.MODE_LITTLE_ENDIAN)
  return capstone
}
async function dump (a, n = 256) {
  const md = await disassembler()
  for (const i of md.disasm(Array.from(read(a, n)), a)) {
    console.log(`0x${BigInt(i.address).toString(16)}: ${i.mnemonic.padEnd(8)} ${i.op_str}`)
  }
}
function calls (target) {
  const out = []
  for (let offset = 0; offset < code.length; offset += 4) {
    const word = code.readUInt32LE(offset)
    if (((word & 0x7c000000) >>> 0) === 0x14000000) {
      let imm = word & 0x3ffffff; if (imm & 0x2000000) imm = imm - 0x4000000
      if (base + offset + imm * 4 === target) out.push(base + offset)
    }
  }
  return out
}
function adrrefs (target) {
  const page = target - (target % 4096); const out = []
  for (let off = 0; off < code.length - 32; off += 4) {
    const w = code.readUInt32LE(off)
    if (((w & 0x9f000000) >>> 0) !== 0x90000000) continue
    let imm = ((w >>> 29) & 3) | (((w >>> 5) & 0x7ffff) << 2)
    if (imm & 0x100000) imm -= 0x200000
    const pc = base + off
    if ((pc - (pc % 4096)) + imm * 4096 !== page) continue
    const reg = w & 31
    for (let j = 4; j < 32; j += 4) {
      const ins = code.readUInt32LE(off + j)
      if (((ins & 0xffc00000) >>> 0) === 0x91000000 && ((ins >>> 5) & 31) === reg && ((ins >>> 10) & 0xfff) === target % 4096) {
        out.push(base + off); break
      }
    }
  }
  return out
}

module.exports = { elf, elf_sha256, KNOWN_LIBRARIES, secs, code, base, relocs, read, ptr, dump, calls, adrrefs, libraryPath, disassembler }

if (require.main === module) {
  (async () => {
    const hex = v => '0x' + BigInt(v).toString(16)
    const parse = s => Number(BigInt(s))
    const mode = process.argv[2]; const a = parse(process.argv[3])
    if (mode === 'dump') await dump(a, process.argv.length > 4 ? parse(process.argv[4]) : 256)
    else if (mode === 'calls') console.log('[' + calls(a).map(x => `'${hex(x)}'`).join(', ') + ']')
    else if (mode === 'refs') {
      console.log('[' + adrrefs(a).map(x => `'${hex(x)}'`).join(', ') + ']')
      const matches = [...relocs.entries()].filter(([, v]) => v === BigInt(a)).map(([k, v]) => `('${hex(k)}', '${hex(v)}')`)
      console.log('relocs [' + matches.join(', ') + ']')
    } else if (mode === 'ptr') {
      const count = parseInt(process.argv[4], 10)
      console.log('[' + Array.from({ length: count }, (_, i) => `'${hex(ptr(a + i * 8))}'`).join(', ') + ']')
    }
  })().catch(error => { console.error(error); process.exit(1) })
}
