'use strict'
const fs = require('node:fs')
const path = require('node:path')
const Writer = require('../../Utils/Writer')
const { BattleAssets } = require('../../Logic/Battle/World/BattleAssets')
const { BattleParticipant, BattleEndData } = require('../../Logic/BattleEnd')
const { encode_battle_result } = require('../../Logic/BattleResultPayload')
const Skins = require('../../Files/CsvLogic/Skins')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const assets = new BattleAssets(); const vectors = []
for (let mode = 0; mode <= 6; mode++) {
  const count = [2, 5].includes(mode) ? 10 : [1, 3, 6].includes(mode) ? 3 : 6
  for (let local = 0; local < count; local++) for (const localMvp of mode === 0 ? [false, true] : [false]) {
    const mvp = mode === 0 ? (localMvp ? local : (local + 1) % count) : -1
    const participants = Array.from({ length: count }, (_, index) => {
      const hero = assets.heroes[index % assets.heroes.length]
      return new BattleParticipant({ brawlerId: hero.id, skinId: Skins.get_default_skin(hero.id), team: [3, 6].includes(mode) ? 0 : mode === 2 ? index : mode === 5 ? Math.floor(index / 2) : mode === 4 ? (index === 5 ? 1 : 0) : Math.floor(index / (count / 2)), isPlayer: index === local || index % 2 === 0, name: 'P' + index + '–é', lowId: 100 + index, highId: 0, powerLevel: 1 + index % 9 })
    })
    const data = new BattleEndData({ participants, localIndex: local }); data.mvp_index = mvp
    const participant = participants[local]
    const player = { battle_end: data, authoritativeBattleResult: data, low_id: participant.low_id, high_id: 0, name: participant.name, rank: 1 + local % 5, battle_result: local % 3, tutorial: 2, Brawler_level: { [participant.brawler_id]: 8 }, profile_icon: local % 8, player_experience: 1000 }
    const rewards = { token: 20, gainedtrophies: local % 2 ? -3 : 8, doubledtokens: 5, remainingtokens: 95, experience: 8, mvpexperience: localMvp ? 10 : 0, brawler_trophies: 250, brawler_trophies_for_rank: 260, starplayer: localMvp, rewards: { old_battle_tokens: 200, battle_tokens: 180, old_experience: 982, hasStarKey: true, exp_rewards_array: localMvp ? { 0: 8, 8: 10 } : { 0: 8 } } }
    const writer = new Writer(); writer.enable_native_v13(); writer.player = player
    encode_battle_result(writer, rewards, mode)
    vectors.push({ mode, localIndex: local, mvpIndex: mvp, result: [2, 5].includes(mode) ? player.rank : player.battle_result, profile: player.profile_icon, participants, hex: writer.buffer.toString('hex') })
  }
}
fs.mkdirSync(process.env.V13_RESEARCH_DIR, { recursive: true })
fs.writeFileSync(path.join(process.env.V13_RESEARCH_DIR, 'result-vectors.json'), JSON.stringify(vectors))
console.log('Result packets:', vectors.length, 'all seven result kinds, every local position, mixed humans/bots and MVP flags')
