'use strict'
// Port of probe_earned_supers.py.
// Earn and cast each enabled hero's Super via original encoded human inputs.
//
// The driver chooses destinations/targets only. Native AI, damage, charge, death,
// respawn, cooldowns, skill execution and game-over rules are never overwritten.
// Unfinished scenarios are recorded as such, not counted as a working Super.
const fs = require('node:fs')
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { pyInt, StopIteration } = require('./lib/pycompat')
const { minBy, hypot } = require('./lib/battle_probe')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 })
  n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const out = R.outDir()
  const skills = {}; for (const row of data.csv.get(20).records) skills[row[0]] = R.zipDict(data.csv.get(20).names, row)
  const locRow = data.csv.get(15).records.find(row => R.zipDict(data.csv.get(15).names, row).GameMode === 'BountyHunter')
  if (!locRow) throw new StopIteration()
  const location = locRow[0]
  const records = []
  const observing = {}
  const activated = (uc, address, size, unused) => {
    const skill = Number(uc.reg_read(C.UC_ARM64_REG_X0)); const character = Number(uc.reg_read(C.UC_ARM64_REG_X1))
    if (data.ptr(skill) === observing.super && data.word(character + 0x3c) === 0) {
      observing.record.activations.push({ tick: data.word(observing.battle.pointer + 0x18), characterId: data.word(character + 8) })
    }
  }
  n.uc.hook_add(C.UC_HOOK_CODE, activated, null, 0x4a3f3c, 0x4a3f3c)
  for (const row of data.csv.get(16).records) {
    const hero = R.zipDict(data.csv.get(16).names, row)
    if (hero.Type !== 'Hero' || hero.Disabled === 'true' || hero.LockedForChronos === 'true') continue
    const record = { hero: hero.Name, earned: false, cast: false, checkpoints: [], superCommands: [], activations: [] }; let battle = null; const start = performance.now()
    const weapon = skills[hero.WeaponSkill]; const reach = Number(pyInt(weapon.CastingRange || '10')) * 100
    const desired = Math.max(250, Math.min(1400, Math.trunc(reach * 0.6)))
    const weaponCode = data.word(data.named(20, hero.WeaponSkill) + 0x20) - 20000000
    const superCode = data.word(data.named(20, hero.UltimateSkill) + 0x20) - 20000000
    let index; let afterCast
    try {
      battle = new NativeBattle(data, location); battle.add_player(hero.Name, 0); battle.setup(); let counter = 1
      Object.assign(observing, { record, battle, super: data.named(20, hero.UltimateSkill) })
      const limit = Number(pyInt(process.env.V13_EARNED_SUPER_TICKS || '3121'))
      let broke = false
      for (index = 0; index < limit; index++) {
        let state = battle.describe(); const human = state.players[0]
        const own = state.objects.find(obj => obj.id === human.characterId) || null
        if (human.superCharge === 4000) record.earned = true
        if (index % 10 === 2 && !record.cast && own && (own.hp ?? 0) > 0) {
          const enemies = state.objects.filter(obj => (obj.hp ?? 0) > 0 && state.players.some(p => p.team !== human.team && p.characterId === obj.id))
          if (enemies.length) {
            const target = minBy(enemies, obj => (obj.x - own.x) ** 2 + (obj.y - own.y) ** 2)
            const dx = own.x - target.x; const dy = own.y - target.y; const distance = Math.max(1, hypot(dx, dy)); const commands = []
            if (distance > desired * 1.15) {
              commands.push({ code: 100, x: Math.trunc(target.x + dx * desired / distance), y: Math.trunc(target.y + dy * desired / distance) })
            }
            if (distance <= Math.max(desired * 1.5, reach)) {
              if (human.superCharge === 4000) {
                commands.push({ code: 107 }, { code: superCode, targetId: target.id, flag: true })
                record.superCommands.push({ tick: state.tick, charge: 4000 })
              } else commands.push({ code: 108 }, { code: weaponCode, targetId: target.id, flag: true })
            }
            if (commands.length) {
              const packet = battle.encode_input_packet(commands, counter); counter += commands.length; battle.input_packet(0, packet)
            }
          }
        }
        const vision = battle.frame(); state = battle.describe()
        if (record.superCommands.length && record.activations.length && state.players[0].superCharge < 4000) {
          if (!record.cast) record.castTick = state.tick
          record.cast = true
        }
        afterCast = state.tick - ('castTick' in record ? record.castTick : state.tick)
        if ((index + 1) % 200 === 0 || (record.cast && [0, 20, 40].includes(afterCast)) || state.ended) {
          state.vision = vision; record.checkpoints.push(state)
        }
        if ((record.cast && afterCast >= 40) || state.ended) { broke = true; break }
      }
      if (!broke) index = limit - 1
      record.framesProcessed = index + 1
      record.postCastFrames = afterCast
    } catch (error) {
      record.error = { message: R.errorMessage(error), pc: m.pc(), lr: m.lr() }
    } finally {
      if (battle) {
        try { battle.close() } catch (error) { record.cleanupError = R.errorMessage(error) }
      }
    }
    record.elapsedSeconds = (performance.now() - start) / 1000; records.push(record)
    fs.writeFileSync(path.join(out, 'earned-supers.json'), R.toJson(records))
    R.print('Original earned Super', record.hero, 'earned', record.earned, 'cast', record.cast, 'ticks', record.framesProcessed ?? null, 'error', record.error ?? null)
  }
  if (records.some(record => !record.cast || 'error' in record || 'cleanupError' in record)) throw new R.SystemExit(1)
  R.print('All enabled heroes earned and cast Supers through original inputs')
})
