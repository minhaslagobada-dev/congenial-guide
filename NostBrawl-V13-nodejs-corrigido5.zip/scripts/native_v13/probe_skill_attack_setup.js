'use strict'
// Port of probe_skill_attack_setup.py.
// Execute full native Skill::tick for Attack setup without attached spawns.
// Controlled character memory; no character CSV/constructor claim and no hooks.
// This measures attack scheduling, not projectile damage or complete hero combat.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { disassembler, read } = require('./native')
const { NativeOpenMap } = require('./native_open_map')
const { RuntimeError, StopIteration, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
const int0x = text => { text = text.trim(); const negative = text.startsWith('-'); const v = Number(BigInt(negative ? text.slice(1) : text)); return negative ? -v : v }
function findIndex (records, name) { const i = records.findIndex(row => row[0] === name); if (i < 0) throw new StopIteration(); return i }
R.main(async () => {
  const md = await disassembler()
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  const proj = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); proj.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root); const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v)
  const getters = {}
  for (const address of [0x287418, 0xc0178, 0x2a545c, 0x1f1e5c, 0x428410, 0x4cb730, 0x161534, 0x2820dc, 0x350abc, 0x2ea740, 0x4f0ed0, 0x28f610]) {
    let page = null
    for (const ins of md.disasm(Array.from(read(address, 48)), address)) {
      if (ins.mnemonic === 'adrp' && ins.op_str.startsWith('x8, ')) page = int0x(ins.op_str.split('#')[1])
      if (page !== null && ins.mnemonic === 'ldr' && ins.op_str.startsWith('w1, [x8, #')) {
        const offset = int0x(ins.op_str.split('#')[1].split(']')[0])
        const index = m.i32(page + offset)
        getters[R.hex(address)] = t.names.at(index); break
      }
    }
  }
  const projectiles = {}
  proj.records.forEach((row, i) => {
    const d = R.zipDict(proj.names, row); const meta = t.alloc(0x200); p(meta + 8, proj.rows[i]); w(meta + 0x94, R.int0(d.Speed)); w(meta + 0x98, R.int0(d.Radius)); w(meta + 0xa0, R.int0(d.Gravity))
    n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0, d.ConstantFlyTime === 'true' ? 1 : 0]))
    projectiles[d.Name] = meta
  })
  const manager = t.alloc(0x100); const battle = t.alloc(0x400); p(manager + 0x50, battle); p(battle, manager); p(battle + 0x70, terrain.pointer); w(battle + 0x18, 100)
  const records = []
  const get = m.i32
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row)
    if (d.BehaviorType !== 'Attack' || ['SummonedCharacter', 'AreaEffectObject', 'AreaEffectObject2', 'SpawnedItem'].some(k => d[k])) return
    const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); p(meta + 0x68, d.Projectile ? projectiles[d.Projectile] : 0); w(meta + 0xb8, 0)
    for (const role of ['main', 'super']) {
      for (const casting of [0, 50]) {
        for (const level of [0, 9]) {
          for (const consumed of [1, 2]) {
            for (const ammo of [1000, 3000]) {
              for (const aimTicks of (d.Name === 'Bow' ? [-1, 0, 20, 40, 80] : [-1])) {
                for (const hasPlayer of [false, true]) {
                  const owner = t.alloc(0x400); const charmeta = t.alloc(0x200); p(owner, 0x72dc10); p(owner + 0x10, charmeta); p(owner + 0x18, manager)
                  const otherMeta = t.alloc(0x200); p(otherMeta + 8, t.find('ShotgunGirlWeapon'))
                  p(charmeta + 0x198, role === 'main' ? meta : otherMeta); p(charmeta + 0x1a0, role === 'super' ? meta : otherMeta)
                  w(owner + 0x30, 3000); w(owner + 0x34, 4500); w(owner + 0x3c, hasPlayer ? 0 : -1); w(owner + 0x2fc, aimTicks < 0 ? -1 : 100 - aimTicks)
                  const player = t.alloc(0x100); const players = t.alloc(8); p(players, player); p(battle + 0x78, players); w(player + 0x60, 1000); n.uc.mem_write(owner + 0x2f9, Buffer.from([1]))
                  const state = t.alloc(0x30); n.call(0x248d70, state, meta); w(state + 0x14, ammo); w(state + 0xc, Math.max(1, R.int0(d.ActiveTime))); w(state + 0x18, 3500); w(state + 0x1c, 5000); w(state + 0x28, consumed); w(state + 0x24, level)
                  const other = t.alloc(0x30); n.call(0x248d70, other, otherMeta)
                  n.uc.mem_write(state + 0x20, Buffer.from([1, 1])); w(owner + 0x198, casting)
                  const skills = t.alloc(16); p(skills, role === 'main' ? state : other); p(skills + 8, role === 'super' ? state : other); p(owner + 0x130, skills); w(owner + 0x13c, 2)
                  try { n.call(0xec2a8, state, owner, 50, { count: 3000000 }) } catch (e) {
                    const error = new RuntimeError(pyRepr(tuple(d.Name, role, casting, level, consumed, ammo, R.errorMessage(e)))); error.cause = e; throw error
                  }
                  const i32 = {}; for (const off of [0xbc, 0xc0, 0xc4, 0xc8, 0xcc, 0xd0, 0xd4, 0xe0, 0xe4, 0xe8, 0xf0, 0xf4, 0xf8, 0x180, 0x184, 0x1dc, 0x2fc]) i32[R.hex(off)] = get(owner + off)
                  const u8 = {}; for (const off of [0x140, 0x188, 0x1d5, 0x206, 0x2f9, 0x2fb]) u8[R.hex(off)] = m.u8(owner + off)
                  records.push({
                    name: d.Name,
                    definition: d,
                    otherDefinition: R.zipDict(t.names, t.records[findIndex(t.records, 'ShotgunGirlWeapon')]),
                    projectile: d.Projectile ? R.zipDict(proj.names, proj.records[findIndex(proj.records, d.Projectile)]) : null,
                    role,
                    hasPlayer,
                    playerCharge: get(player + 0x60),
                    aimTicks,
                    casting,
                    level,
                    consumed,
                    ammo,
                    skill: { activeMs: get(state + 0xc), cooldownMs: get(state + 0x10), ammo: get(state + 0x14), executing: m.u8(state + 0x20), pending: m.u8(state + 0x21) },
                    otherCooldownMs: get(other + 0x10),
                    attack: { target: [get(owner + 0x180), get(owner + 0x184)], delta: [get(owner + 0xf0), get(owner + 0xf4)], active: m.u8(owner + 0x188), damage: get(owner + 0xcc), spread: get(owner + 0xe0), pattern: get(owner + 0xd0), bullets: get(owner + 0xd4), attackIntervalMs: get(owner + 0xe4), range: get(owner + 0xe8), i32, u8, attackAngle: get(owner + 0x4c), moveAngle: get(owner + 0x48) }
                  })
                }
              }
            }
          }
        }
      }
    }
  })
  R.writeJson('skill-getters.json', getters, 2)
  R.writeJson('skill-attack-setup-vectors.json', records)
  R.print('Original active skill attack setup:', records.length, 'cases; controlled owner; full native Skill::tick; no gameplay hooks')
})
