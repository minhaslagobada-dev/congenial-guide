'use strict'
// Port of probe_projectile_hit.py.
// Execute original projectile collision and damage, controlled LootBox target.
// No gameplay hooks. One controlled non-hero target is registered using the original manager.
// Native terrain destruction executes; fine movement-grid rebuilding is outside this fixture.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { NativeOpenMap } = require('./native_open_map')
const { RuntimeError, StopIteration, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root)
  // Native global is looked up by the literal Open at 0x45ac54..0x45ac84.
  terrain.csv.ptr(0xab42d0, terrain.metadata.get('Open'))
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const battle = t.alloc(0x400); p(battle + 0x70, terrain.pointer); w(battle + 0x18, 100); w(battle + 0x20, 17)
  let manager = t.alloc(0x80); p(manager + 0x50, battle); p(battle, manager)
  const player = t.alloc(0x100); const players = t.alloc(8); p(players, player); p(battle + 0x78, players)
  const table = t.alloc(0x40); w(table + 0x28, 6)
  const origin = t.alloc(0x400)
  // Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
  p(origin, 0x74e558); w(origin + 0x30, 3000); w(origin + 0x34, 4500)
  w(origin + 0x3c, 1); w(origin + 0x40, 2)
  const records = []
  for (const name of ['ShotgunGirlProjectile', 'ShotgunGirlUltiProjectile', 'SniperProjectile', 'CrowProjectile', 'UndertakerUltiProjectile', 'DeadMariachiUltiProjectile']) {
    const source = t.records.find(row => row[0] === name)
    if (!source) throw new StopIteration()
    const d = R.zipDict(t.names, source)
    const meta = t.alloc(0x200); p(meta + 8, t.find(d.Name)); p(meta + 0x10, table); w(meta + 0x94, R.int0(d.Speed)); w(meta + 0x98, R.int0(d.Radius))
    for (const progress of [0, 500, 1000]) {
      for (const team of [0, 1]) {
        for (const alive of [false, true]) {
          for (const targetY of [4650, 4900]) {
            manager = t.alloc(0x100); p(manager + 0x50, battle); p(battle, manager)
            const target = t.alloc(0x400); const targetMeta = t.alloc(0x200); p(target, 0x72dc10); p(target + 0x10, targetMeta); w(targetMeta + 0x184, 10); w(targetMeta + 0x14c, 150)
            w(target + 0xb0, alive ? 10000 : 0); w(target + 0xb4, 10000); w(target + 0x3c, -1); w(target + 0x40, team); w(target + 0x30, 3150); w(target + 0x34, targetY); w(target + 0x338, -1)
            n.call(0x253b18, manager, target)
            const obj = t.alloc(0x120); n.call(0x4d30d0, obj, meta); p(obj + 0x18, manager)
            w(obj + 0x90, 2500); w(obj + 0x94, 4650); w(obj + 0x30, 3500); w(obj + 0x34, 4650); w(obj + 0x3c, 0); w(obj + 0x40, 0); w(obj + 0x74, 300); w(obj + 0x78, 300); w(obj + 0xc8, progress)
            let result
            try { result = n.call(0x373994, obj) } catch (e) {
              const error = new RuntimeError(pyRepr(tuple(name, progress, team, alive, targetY, m.pc(), m.lr(), R.errorMessage(e)))); error.cause = e; throw error
            }
            records.push({ name, definition: d, progress, team, alive, targetY, result, hp: get(target + 0xb0), projectilePosition: [get(obj + 0x30), get(obj + 0x34)], lastDamageTick: get(target + 0x2b8) })
          }
        }
      }
    }
  }
  R.writeJson('projectile-hit-vectors.json', records)
  R.print('Original projectile collision + applyDamage:', records.length, 'cases; controlled non-hero target, no gameplay substitutions')
})
