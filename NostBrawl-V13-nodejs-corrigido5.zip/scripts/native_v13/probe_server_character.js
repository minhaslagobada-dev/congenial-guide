'use strict'
// Port of probe_server_character.py.
// Run v13 character construction and event reset, not a JS simulation.
//
// Only CSV row access and libc imports are supplied by the harness. Entity
// constructors and all server encoding instructions are the original ARM64.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { RuntimeError, KeyError, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const rows = new Map(); const m = R.memory(n)
  const reg = i => Number(m.reg(i))
  const word = m.u32; const ptr = m.u64; const put = m.put32; const pp = m.put64
  const alloc = size => { const p = n.alloc(size); n.uc.mem_write(p, Buffer.alloc(size)); return p }
  const rowValue = () => {
    const row = rows.get(reg(0))
    if (row === undefined) throw new KeyError(reg(0))
    if (!row.has(reg(1))) throw new RuntimeError(pyRepr(tuple('Unknown fixture column', reg(0), reg(1))))
    return row.get(reg(1))
  }
  n.hooks.set(0x469228, rowValue)
  n.hooks.set(0x24f974, n.hooks.get(0x469228))
  n.hooks.set(0x1dca94, () => { if (reg(0)) return 0; throw new RuntimeError('Native assertion') })
  for (const [a, col] of [[0x82675c, 1], [0x8112a4, 2], [0xa9d214, 3], [0x945404, 4], [0xaa77d4, 5]]) put(a, col)
  const root = R.ROOT
  const table = name => R.dictReader(path.join(root, 'GameAssets/csv_logic', `${name}.csv`)).slice(1)
  const characters = table('characters'); const skills = {}
  for (const s of table('skills')) skills[s.Name] = s
  const types = { Hero: 0, Npc_Boss: 1, Minion_FollowOwner: 2, Minion_FindEnemies: 3, Minion_Building: 4, Campaign_DefendTarget: 5, Pvp_Base: 6, Minion_Building_charges_ulti: 7, Minion_Dog: 8, LaserBall: 9, LootBox: 10, Minion_FindEnemies2: 11 }
  const records = []
  characters.forEach((data, idx) => {
    if (!(data.Type in types)) return
    const meta = alloc(0x200); const row = alloc(16); pp(meta + 8, row)
    put(meta + 0x128, R.int0(data.Speed)); put(meta + 0x184, types[data.Type])
    rows.set(row, new Map([[4, R.int0(data.Hitpoints)], [5, R.int0(data.AutoAttackDamage)]]))
    for (const [off, key] of [[0x198, 'WeaponSkill'], [0x1a0, 'UltimateSkill']]) {
      if (!data[key]) continue
      const s = skills[data[key]]; if (!s) throw new KeyError(data[key])
      const mm = alloc(0x200); const r = alloc(16); pp(mm + 8, r)
      rows.set(r, new Map([[1, R.int0(s.ActiveTime)], [2, R.int0(s.MaxCharge)], [3, s.SkillCanChange === 'true' ? 1 : 0]]))
      const behavior = { Attack: 0, Blink: 1, Charge: 2, Invisibility: 3, TransformMinion: 4, BuffMinion: 5, Rage: 6, Shield: 7 }
      put(mm + 0xb8, behavior[s.BehaviorType]); pp(meta + off, mm)
    }
    const obj = alloc(0x400)
    n.call(0x14de30, obj, meta)
    R.assert(ptr(obj) === 0x72dc10)
    R.assert(word(obj + 0xb0) === R.int0(data.Hitpoints))
    R.assert(word(obj + 0xb4) === R.int0(data.Hitpoints))
    const record = { id: idx, name: data.Name, constructor: { state: word(obj + 0x78), hp: word(obj + 0xb0), maxHp: word(obj + 0xb4), attackAngle: word(obj + 0x4c), moveAngle: word(obj + 0x48), attackingTicks: m.i32(obj + 0x12c) }, skillCount: word(obj + 0x13c) }
    // Verify genuine resetEventsOnTick with two controlled timer entries.
    for (const [off, values] of [[0x270, [70, 71]], [0x280, [0, 1]], [0x290, [0, 3]]]) {
      const a = alloc(8); n.uc.mem_write(a, R.pack('i', ...values)); pp(obj + off, a); put(obj + off + 12, 2)
    }
    n.call(0x39c038, obj)
    record.eventTick = {}
    for (const off of [0x270, 0x280, 0x290]) record.eventTick[R.hex(off)] = { count: word(obj + off + 12), values: [m.i32(ptr(obj + off)), m.i32(ptr(obj + off) + 4)] }
    R.assert([0x270, 0x280, 0x290].every(off => record.eventTick[R.hex(off)].count === 1))
    R.assert(record.eventTick['0x290'].values[0] === 2)
    records.push(record)
  })
  R.writeJson('character-constructor.json', records, 2)
  R.print('Native server construction + event reset passed:', records.length, 'character definitions; no JS engine invoked')
})
