'use strict'
// Port of native_data.py.
// Original v13 data-table construction and gameplay reference resolution.
//
// CSV bytes are inputs. Native table/metadata constructors, lookups and all
// reference-initialization instructions execute unchanged inside the ELF.
// Client visual tables are constructed for named references, not rendered.
const path = require('node:path')
const { NativeCsv } = require('./native_csv')
const C = require('./lib/unicorn_const')
const { ValueError, RuntimeError, AssertionError, KeyError, decodeUtf8, tuple, pyRepr } = require('./lib/pycompat')
const hex = v => '0x' + BigInt(v).toString(16)

class NativeDataRegistry {
  constructor (native, assets, progress = null, extra_references = []) {
    this.native = native; this.tables = new Map(); this.csv = new Map(); this.entries = new Map()
    // The library provides its own disabled live-tuning service for normal
    // gameplay. Skin references register texture strings through it even
    // when no editor/tuning UI is active. Execute that initializer intact.
    native.call(0x3f991c, 0)
    this._diagnostics = []
    native.uc.hook_add(C.UC_HOOK_CODE, (uc, address, size, data) => this._reference_check(uc, address, size, data), null, 0x435bbc, 0x435bbc)
    // 0x1dca94 is the original assertion helper: `tbz w0,#0,0x1dca9c; ret`.
    // It runs thousands of times per battle frame, so trapping its entry cost
    // a JS round trip per call (most of a frame's time). Trap only the failing
    // branch target instead; X0 is unchanged there, so the check is identical.
    native.uc.hook_add(C.UC_HOOK_CODE, (uc, address, size, data) => this._assertion_check(uc, address, size, data), null, 0x1dca9c, 0x1dca9c)
    for (const [type_id, filename] of NativeDataRegistry.SPECS) {
      const source = new NativeCsv(native, path.join(String(assets), filename), [], true)
      const table = source.alloc(type_id === 3 ? 0x108 : 0x40)
      native.call(type_id === 3 ? 0x295a64 : 0x3b1b68, table, source.table, type_id, { count: 5000000 })
      this.tables.set(type_id, table); this.csv.set(type_id, source)
      source.ptr(0xabb9a0 + type_id * 8, table)
      const size = this.word(table + 0x14)
      if (size !== source.records.length) throw new AssertionError(tuple(filename, size, source.records.length))
      const array = this.ptr(table + 8)
      const entries = new Map()
      source.records.forEach((row, i) => entries.set(row[0], this.ptr(array + i * 8)))
      this.entries.set(type_id, entries)
      source.records.forEach((row, i) => {
        if (this.word(entries.get(row[0]) + 0x20) !== type_id * 1000000 + i) throw new AssertionError(tuple(filename, row[0]))
      })
      if (progress) progress('constructed', type_id, source.records.length)
    }
    const ordered = [...new Set([...NativeDataRegistry.GAMEPLAY, ...extra_references])]
    for (const type_id of ordered) {
      if (!this.tables.has(type_id)) throw new ValueError('Native reference table is not loaded: ' + String(type_id))
      try {
        native.call(type_id === 3 ? 0x2245e4 : 0x1ee9e4, this.tables.get(type_id), { count: 12000000 })
      } catch (e) {
        const error = new RuntimeError(pyRepr(tuple('Native gameplay reference initialization', type_id, hex(native.uc.reg_read(C.UC_ARM64_REG_PC)), hex(native.uc.reg_read(C.UC_ARM64_REG_LR)), String(e.message))))
        error.cause = e
        throw error
      }
      if (progress) progress('references', type_id, this.entries.get(type_id).size)
    }
  }

  ptr (address) { return Number(this.native.uc.mem_read(Number(address), 8).readBigUInt64LE(0)) }
  word (address) { return this.native.uc.mem_read(Number(address), 4).readInt32LE(0) }
  string (address) {
    const length = this.word(address + 4); const data = length < 8 ? address + 8 : this.ptr(address + 8)
    return decodeUtf8(this.native.uc.mem_read(data, length))
  }

  _reference_check (uc, address, size, data) {
    if (uc.reg_read(C.UC_ARM64_REG_X0) === 0n && uc.reg_read(C.UC_ARM64_REG_X19)) {
      const table = Number(uc.reg_read(C.UC_ARM64_REG_X21)); const name = this.string(Number(uc.reg_read(C.UC_ARM64_REG_X20)))
      throw new RuntimeError(pyRepr(tuple('Missing native data reference', this.word(table + 0x28), name, hex(uc.reg_read(C.UC_ARM64_REG_LR)))))
    }
  }

  _assertion_check (uc, address, size, data) {
    if (uc.reg_read(C.UC_ARM64_REG_X0) === 0n) {
      throw new RuntimeError(pyRepr(tuple('Native data assertion', hex(uc.reg_read(C.UC_ARM64_REG_LR)))))
    }
  }

  named (type_id, name) {
    const entries = this.entries.get(type_id)
    if (!entries) throw new KeyError(type_id)
    if (!entries.has(name)) throw new KeyError(name)
    return entries.get(name)
  }
}

NativeDataRegistry.SPECS = [[3, 'csv_logic/globals.csv'], [4, 'csv_client/sounds.csv'], [5, 'csv_logic/resources.csv'], [6, 'csv_logic/projectiles.csv'], [7, 'csv_client/effects.csv'],
  [11, 'csv_client/health_bars.csv'], [12, 'csv_client/music.csv'], [15, 'csv_logic/locations.csv'], [16, 'csv_logic/characters.csv'], [17, 'csv_logic/area_effects.csv'],
  [18, 'csv_logic/items.csv'], [19, 'csv_logic/maps.csv'], [23, 'csv_logic/cards.csv'], [37, 'csv_logic/map_blocks.csv'], [20, 'csv_logic/skills.csv'],
  [27, 'csv_logic/tiles.csv'], [29, 'csv_logic/skins.csv'], [28, 'csv_logic/player_thumbnails.csv']]
NativeDataRegistry.GAMEPLAY = [3, 6, 15, 16, 17, 18, 20, 27, 23, 29]

module.exports = { NativeDataRegistry }
