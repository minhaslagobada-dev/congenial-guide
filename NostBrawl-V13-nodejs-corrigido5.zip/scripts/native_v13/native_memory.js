'use strict'
// Port of native_memory.py.
// Single-thread guest heap for original C/C++ allocation imports.
//
// The guest never observes allocator headers. Allocations are aligned to 16
// bytes, freed intervals coalesce, and realloc preserves bytes before
// releasing a block.
const { RuntimeError } = require('./lib/pycompat')
const C = require('./lib/unicorn_const')
const hex = v => '0x' + BigInt(v).toString(16)

class GuestHeap {
  constructor (native) {
    this.native = native; this.live = new Map(); this.free_ranges = []; this.peak = 0
    this.trace_allocations = false; this.origins = new Map()
  }

  allocate (size) {
    const requested = Math.max(1, Math.trunc(Number(size))); const capacity = (Math.max(16, requested) + 15) - ((Math.max(16, requested) + 15) % 16)
    let address = null
    for (let index = 0; index < this.free_ranges.length; index++) {
      const [start, length] = this.free_ranges[index]
      if (length < capacity) continue
      if (length === capacity) this.free_ranges.splice(index, 1)
      else this.free_ranges[index] = [start + capacity, length - capacity]
      address = start
      break
    }
    if (address === null) {
      address = this.native.heap
      if (address + capacity > this.native.heap_limit) throw new RuntimeError('Guest heap exhausted')
      this.native.heap += capacity
      this.peak = Math.max(this.peak, this.native.heap - 0x10000000)
    }
    if (this.live.has(address)) throw new RuntimeError('Overlapping live guest allocation')
    this.live.set(address, [requested, capacity])
    if (this.trace_allocations) {
      this.origins.set(address, [this.native.uc.reg_read(C.UC_ARM64_REG_PC), this.native.uc.reg_read(C.UC_ARM64_REG_LR)])
    }
    return address
  }

  release (address) {
    address = Number(address)
    if (!address) return
    const allocation = this.live.get(address)
    if (allocation === undefined) throw new RuntimeError('Invalid or repeated guest free: ' + hex(address))
    this.live.delete(address)
    this.origins.delete(address)
    this.free_ranges.push([address, allocation[1]]); this.free_ranges.sort((x, y) => x[0] - y[0] || x[1] - y[1])
    const merged = []
    for (const [pointer, length] of this.free_ranges) {
      if (merged.length && merged[merged.length - 1][0] + merged[merged.length - 1][1] === pointer) {
        const [previous, previousLength] = merged[merged.length - 1]; merged[merged.length - 1] = [previous, previousLength + length]
      } else merged.push([pointer, length])
    }
    this.free_ranges = merged
  }

  resize (address, size) {
    address = Number(address); size = Number(size)
    if (!address) return this.allocate(size)
    if (!this.live.has(address)) throw new RuntimeError('Unknown guest realloc pointer: ' + hex(address))
    if (!size) { this.release(address); return 0 }
    const previousSize = this.live.get(address)[0]
    const replacement = this.allocate(size)
    this.native.uc.mem_write(replacement, this.native.uc.mem_read(address, Math.min(previousSize, size)))
    this.release(address)
    return replacement
  }
}

module.exports = { GuestHeap }
