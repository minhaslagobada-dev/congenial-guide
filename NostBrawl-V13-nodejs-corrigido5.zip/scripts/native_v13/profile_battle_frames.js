'use strict'
// Port of profile_battle_frames.py.
// Measure native-frame CPU cost and imported runtime callback overhead.
// cProfile/pstats are replaced by the V8 inspector CPU profiler: the profile is
// written as native-frame-profile.cpuprofile (open it in Chrome DevTools) and
// the 12 most expensive functions are printed like pstats' cumulative listing.
const fs = require('node:fs')
const path = require('node:path')
const inspector = require('node:inspector')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const R = require('./lib/research')

function post (session, method, params) {
  return new Promise((resolve, reject) => session.post(method, params || {}, (err, result) => (err ? reject(err) : resolve(result))))
}
const cpuSeconds = () => { const u = process.cpuUsage(); return (u.user + u.system) / 1e6 }

function cumulative (profile) {
  const nodes = new Map(profile.nodes.map(node => [node.id, node]))
  const interval = profile.samples.length ? (profile.endTime - profile.startTime) / profile.samples.length / 1e6 : 0
  const self = new Map(); for (const id of profile.samples) self.set(id, (self.get(id) || 0) + 1)
  const parent = new Map(); for (const node of profile.nodes) for (const child of node.children || []) parent.set(child, node.id)
  const stats = new Map()
  const key = node => `${node.callFrame.url || '~'}:${node.callFrame.lineNumber + 1}(${node.callFrame.functionName || '<anonymous>'})`
  for (const [id, count] of self) {
    const seen = new Set(); let current = id; let first = true
    while (current !== undefined) {
      const node = nodes.get(current); const k = key(node)
      if (!stats.has(k)) stats.set(k, { tottime: 0, cumtime: 0 })
      const s = stats.get(k)
      if (first) s.tottime += count * interval
      if (!seen.has(k)) { s.cumtime += count * interval; seen.add(k) }
      first = false; current = parent.get(current)
    }
  }
  return [...stats].sort((a, b) => b[1].cumtime - a[1].cumtime)
}

R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000, reclaim_memory: true }); n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const battle = new NativeBattle(data, 'Gemgrab1'); battle.add_player('ShotgunGirl', 0); battle.setup()
  data.csv.get(15).word(battle.pointer + 0x18, 300)
  const session = new inspector.Session(); session.connect()
  await post(session, 'Profiler.enable'); await post(session, 'Profiler.start')
  let start = performance.now(); let cpu = cpuSeconds()
  for (let i = 0; i < 20; i++) battle.frame()
  const { profile } = await post(session, 'Profiler.stop')
  const result = { frames: 20, wallSeconds: (performance.now() - start) / 1000, cpuSeconds: cpuSeconds() - cpu }
  n.instruction_counting = false; n.call_timeout_us = 2000000
  start = performance.now(); cpu = cpuSeconds()
  for (let i = 0; i < 20; i++) battle.frame()
  result.withoutInstructionCounter = { frames: 20, wallSeconds: (performance.now() - start) / 1000, cpuSeconds: cpuSeconds() - cpu }
  const out = R.outDir()
  fs.writeFileSync(path.join(out, 'native-frame-profile.cpuprofile'), JSON.stringify(profile))
  fs.writeFileSync(path.join(out, 'native-frame-profile.json'), R.toJson(result))
  R.print('Native frame cost:', result)
  const rows = cumulative(profile).slice(0, 12)
  console.log('   Ordered by: cumulative time\n   List reduced to 12 due to restriction\n\n   tottime   cumtime filename:lineno(function)')
  for (const [k, s] of rows) console.log(s.tottime.toFixed(3).padStart(10) + s.cumtime.toFixed(3).padStart(10) + ' ' + k)
  session.disconnect()
})
