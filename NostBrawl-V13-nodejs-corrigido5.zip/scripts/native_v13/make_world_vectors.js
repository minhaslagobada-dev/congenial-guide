'use strict'
const fs = require('node:fs'), path = require('node:path')
process.chdir(path.resolve(__dirname, '../..'))
const { battleAssets } = require('../../Logic/Battle/World/BattleAssets')
const { BattleWorld } = require('../../Logic/Battle/Game/BattleWorld')
const { rules } = require('../../Logic/Battle/World/GameModes')
const { encodeWorld } = require('../../Logic/Battle/Game/V13WorldCodec')
const assets = battleAssets(), vectors = []
for (const location of assets.tables.locations.filter(l => l.AllowedMaps && l.Disabled !== 'true' && l.GameMode !== 'Tutorial')) {
  const mode = rules(location.GameMode)
  const caps = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
  const entries = caps.flatMap((count, team) => Array.from({ length: count }, () => ({ team })))
  entries.forEach((entry, index) => Object.assign(entry, { index, player: { low_id: index + 1, brawler_id: assets.heroes[(location.id + index) % assets.heroes.length].id } }))
  const world = new BattleWorld('native-world', assets, location.id, entries)
  entries.forEach(p => { p.ready = true }); world.step()
  for (const ticks of [0, 2, 5, 20, 80]) {
    while (world.tick < ticks && world.phase !== 'finished') world.step()
    for (const viewer of [entries[0], entries.at(-1)]) {
      const objects = world.visibleObjects(viewer).map(o => ({ id: o.id, dataClass: o.dataClass, dataId: o.dataId, x: Math.trunc(o.x), y: Math.trunc(o.y) }))
      vectors.push({ name: location.Name + '/' + ticks + '/' + viewer.index, mode: mode.variation, capacity: mode.capacity, ownIndex: viewer.index,
        grid: assets.locationMap(location.id).grid, objects, hex: encodeWorld(world, viewer, assets).toString('hex') })
    }
    for (const char of world.characters.values()) {
      const enemy = world.nearestEnemy(char)
      if (enemy) { world.activate(char, 0, enemy.x, enemy.y); char.superCharge = 4000; world.activate(char, 1, enemy.x, enemy.y) }
    }
  }
}
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'world-vectors.json'), JSON.stringify({ tables: assets.tables, vectors }))
