'use strict'
// Port of native_libc.py.
// Marshal ARM64 va_list arguments and format them with C (glibc-compatible)
// printf semantics. Only the ABI/formatting is adapted; game routines stay
// native. The Python version delegated the formatting to the host's
// snprintf; this module reproduces glibc's output for the same conversions.
const C = require('./lib/unicorn_const')
const { RuntimeError, pyRepr } = require('./lib/pycompat')

const TOKEN = /%([-+ #0]*)(\*|[0-9]*)(?:\.(\*|[0-9]*))?(hh|ll|[hljztL])?([diuoxXfFeEgGaAcspn%])/y
const LONG = new Set(['ll', 'j', 'z', 't', 'l'])

// ------------------------------------------------------------ float helpers
function decompose (x) {
  const view = new DataView(new ArrayBuffer(8)); view.setFloat64(0, x)
  const bits = view.getBigUint64(0)
  const negative = (bits >> 63n) === 1n
  const exponentBits = Number((bits >> 52n) & 0x7ffn)
  const fraction = bits & ((1n << 52n) - 1n)
  return { negative, exponentBits, fraction }
}
// |x| = m * 2^e
function exact (x) {
  const { exponentBits, fraction } = decompose(x)
  if (exponentBits === 0) return { m: fraction, e: -1074 }
  return { m: fraction | (1n << 52n), e: exponentBits - 1075 }
}
const pow10 = n => 10n ** BigInt(n)
// round(m*2^e*10^k) with ties-to-even (k may be negative)
function scaledRound (m, e, k) {
  let num = m; let den = 1n
  if (e >= 0) num <<= BigInt(e); else den <<= BigInt(-e)
  if (k >= 0) num *= pow10(k); else den *= pow10(-k)
  const q = num / den; const r = num % den
  if (2n * r > den || (2n * r === den && (q & 1n))) return q + 1n
  return q
}
function fixedDigits (x, precision) {
  const { m, e } = exact(x)
  let s = scaledRound(m, e, precision).toString()
  if (precision > 0) {
    s = s.padStart(precision + 1, '0')
    return s.slice(0, s.length - precision) + '.' + s.slice(s.length - precision)
  }
  return s
}
// returns { digits: string of precision+1 digits, exponent }
function expDigits (x, precision) {
  const { m, e } = exact(x)
  if (m === 0n) return { digits: '0'.repeat(precision + 1), exponent: 0 }
  let X = Math.floor(Math.log10(Math.abs(x)))
  for (let guard = 0; guard < 4; guard++) {
    const q = scaledRound(m, e, precision - X)
    if (q >= pow10(precision + 1)) { X++; continue }
    if (q < pow10(precision)) { X--; continue }
    return { digits: q.toString(), exponent: X }
  }
  throw new Error('float formatting did not converge')
}
function expString (exponent, upper) {
  return (upper ? 'E' : 'e') + (exponent < 0 ? '-' : '+') + String(Math.abs(exponent)).padStart(2, '0')
}
function formatFloat (x, spec, flags, precision) {
  const upper = spec === spec.toUpperCase()
  const lower = spec.toLowerCase()
  const { negative } = decompose(x)
  let sign = negative ? '-' : flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : ''
  if (!Number.isFinite(x)) {
    const body = Number.isNaN(x) ? 'nan' : 'inf'
    return { sign, body: upper ? body.toUpperCase() : body, special: true }
  }
  const alt = flags.includes('#')
  const ax = Math.abs(x)
  if (lower === 'f') {
    const p = precision < 0 ? 6 : precision
    let body = fixedDigits(ax, p)
    if (alt && p === 0) body += '.'
    return { sign, body }
  }
  if (lower === 'e') {
    const p = precision < 0 ? 6 : precision
    const { digits, exponent } = expDigits(ax, p)
    let body = digits[0] + (p > 0 || alt ? '.' : '') + digits.slice(1)
    body += expString(exponent, upper)
    return { sign, body }
  }
  if (lower === 'g') {
    let P = precision < 0 ? 6 : precision; if (P === 0) P = 1
    const { exponent } = expDigits(ax, P - 1)
    let body
    if (P > exponent && exponent >= -4) {
      body = fixedDigits(ax, P - 1 - exponent)
      if (alt && !body.includes('.')) body += '.'
      if (!alt && body.includes('.')) body = body.replace(/0+$/, '').replace(/\.$/, '')
    } else {
      const { digits, exponent: X } = expDigits(ax, P - 1)
      let mantissa = digits[0] + (P - 1 > 0 || alt ? '.' : '') + digits.slice(1)
      if (!alt && mantissa.includes('.')) mantissa = mantissa.replace(/0+$/, '').replace(/\.$/, '')
      body = mantissa + expString(X, upper)
    }
    return { sign, body }
  }
  // %a / %A (glibc layout: leading digit 1 for normals, 0 for subnormals/zero)
  const { exponentBits, fraction } = decompose(x)
  let lead; let exp2; let frac = fraction
  if (exponentBits === 0 && fraction === 0n) { lead = 0n; exp2 = 0 } else if (exponentBits === 0) { lead = 0n; exp2 = -1022 } else { lead = 1n; exp2 = exponentBits - 1023 }
  let hexDigits = frac.toString(16).padStart(13, '0')
  if (precision < 0) {
    hexDigits = hexDigits.replace(/0+$/, '')
  } else if (precision < 13) {
    const keep = BigInt(precision * 4); const dropBits = 52n - keep
    let kept = frac >> dropBits; const rest = frac & ((1n << dropBits) - 1n); const half = 1n << (dropBits - 1n)
    if (rest > half || (rest === half && ((kept & 1n) || (precision === 0 && (lead & 1n))))) {
      kept += 1n
      if (kept >> keep) { kept &= (1n << keep) - 1n; lead += 1n }
    }
    hexDigits = precision ? kept.toString(16).padStart(precision, '0') : ''
  } else hexDigits = hexDigits.padEnd(precision, '0')
  // glibc pads with '0' between the 0x prefix and the digits, so the prefix
  // travels with the sign.
  let body = lead.toString(16) + (hexDigits.length || alt ? '.' : '') + hexDigits + 'p' + (exp2 < 0 ? '-' : '+') + Math.abs(exp2)
  if (upper) body = body.toUpperCase()
  return { sign: sign + (upper ? '0X' : '0x'), body }
}

// ------------------------------------------------------------ integer helpers
function integerBody (value, spec, flags, precision) {
  // value: BigInt already normalised (signed for d/i, unsigned otherwise)
  let sign = ''; let digits
  const negative = value < 0n
  const magnitude = negative ? -value : value
  if (spec === 'd' || spec === 'i') {
    sign = negative ? '-' : flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : ''
    digits = magnitude.toString(10)
  } else if (spec === 'u') digits = magnitude.toString(10)
  else if (spec === 'o') digits = magnitude.toString(8)
  else digits = magnitude.toString(16)
  if (spec === 'X') digits = digits.toUpperCase()
  if (precision === 0 && magnitude === 0n) digits = ''
  if (precision > digits.length) digits = digits.padStart(precision, '0')
  let prefix = ''
  if (flags.includes('#')) {
    if (spec === 'o' && !digits.startsWith('0')) digits = '0' + digits
    if ((spec === 'x' || spec === 'X') && magnitude !== 0n) prefix = spec === 'x' ? '0x' : '0X'
  }
  return { sign: sign + prefix, digits }
}
function pad (sign, body, width, flags, zeroAllowed) {
  const total = sign.length + body.length
  if (width <= total) return sign + body
  if (flags.includes('-')) return sign + body + ' '.repeat(width - total)
  if (zeroAllowed && flags.includes('0')) return sign + '0'.repeat(width - total) + body
  return ' '.repeat(width - total) + sign + body
}

function vsnprintf (native, destination, size, format_pointer) {
  const uc = native.uc; const va = Number(uc.reg_read(C.UC_ARM64_REG_X3)); const fmt = native.string(format_pointer)
  const ptr = a => Number(uc.mem_read(a, 8).readBigUInt64LE(0))
  const offset = a => uc.mem_read(a, 4).readInt32LE(0)
  const take = (fp = false) => {
    const address = va + (fp ? 28 : 24); const off = offset(address)
    let location
    if (off < 0) {
      location = ptr(va + (fp ? 16 : 8)) + off
      const b = Buffer.alloc(4); b.writeInt32LE(off + (fp ? 16 : 8)); uc.mem_write(address, b)
    } else {
      location = ptr(va); const b = Buffer.alloc(8); b.writeBigUInt64LE(BigInt(location + 8)); uc.mem_write(va, b)
    }
    return uc.mem_read(location, 8)
  }
  const text = fmt.toString('latin1')
  const out = []; let produced = 0
  const emit = chunk => { const b = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, 'latin1'); out.push(b); produced += b.length }
  const writebacks = []
  let position = 0
  // Arguments are consumed in the same order as the Python marshaller.
  while (position < text.length) {
    const next = text.indexOf('%', position)
    if (next < 0) { emit(fmt.subarray(position)); break }
    if (next > position) emit(fmt.subarray(position, next))
    TOKEN.lastIndex = next
    const match = TOKEN.exec(text)
    if (!match) throw new RuntimeError('Unsupported native printf format: ' + pyRepr(new Uint8Array(fmt)))
    position = TOKEN.lastIndex
    let [, flags, width, precision, length, spec] = match
    length = length || ''
    let widthValue = 0; let precisionValue = -1
    if (width === '*') {
      widthValue = take().readInt32LE(0)
      if (widthValue < 0) { flags += '-'; widthValue = -widthValue }
    } else if (width) widthValue = parseInt(width, 10)
    if (precision === '*') {
      const p = take().readInt32LE(0); precisionValue = p < 0 ? -1 : p
    } else if (precision !== undefined) precisionValue = precision ? parseInt(precision, 10) : 0
    if (spec === '%') { emit('%'); continue }
    if ('fFeEgGaA'.includes(spec)) {
      if (length === 'L') throw new RuntimeError('Native long-double formatting requires an ARM64 long-double adapter')
      const value = take(true).readDoubleLE(0)
      const { sign, body, special } = formatFloat(value, spec, flags, precisionValue)
      emit(pad(sign, body, widthValue, flags, !special))
      continue
    }
    const rawBuffer = take(); const raw = rawBuffer.readBigUInt64LE(0)
    if (spec === 's') {
      if (length) throw new RuntimeError('Native wide-string formatting is not implemented')
      let bytes
      if (raw) bytes = native.string(raw)
      else bytes = Buffer.from(precisionValue === -1 || precisionValue >= 6 ? '(null)' : '', 'latin1')
      if (precisionValue >= 0 && bytes.length > precisionValue) bytes = bytes.subarray(0, precisionValue)
      const fill = Math.max(0, widthValue - bytes.length)
      if (flags.includes('-')) { emit(bytes); emit(' '.repeat(fill)) } else { emit(' '.repeat(fill)); emit(bytes) }
      continue
    }
    if (spec === 'p') {
      if (raw === 0n) emit(pad('', '(nil)', widthValue, flags, false))
      else {
        // glibc formats %p as %#lx and honours the '+' / ' ' sign flags.
        const { sign, digits } = integerBody(raw, 'x', flags.includes('#') ? flags : flags + '#', precisionValue)
        const signChar = flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : ''
        emit(pad(signChar + sign, digits, widthValue, flags, precisionValue < 0))
      }
      continue
    }
    if (spec === 'n') {
      const size = LONG.has(length) ? 8 : length === 'h' ? 2 : length === 'hh' ? 1 : 4
      writebacks.push([Number(raw), size, produced])
      continue
    }
    if (spec === 'c') {
      const byte = Number(raw & 0xffn)
      const fill = Math.max(0, widthValue - 1)
      if (flags.includes('-')) { emit(Buffer.from([byte])); emit(' '.repeat(fill)) } else { emit(' '.repeat(fill)); emit(Buffer.from([byte])) }
      continue
    }
    let value
    if (spec === 'd' || spec === 'i') {
      value = LONG.has(length) ? BigInt.asIntN(64, raw) : BigInt.asIntN(32, raw & 0xffffffffn)
      if (length === 'h') value = BigInt.asIntN(16, value)
      else if (length === 'hh') value = BigInt.asIntN(8, value)
    } else {
      value = LONG.has(length) ? raw : raw & 0xffffffffn
      if (length === 'h') value = BigInt.asUintN(16, value)
      else if (length === 'hh') value = BigInt.asUintN(8, value)
    }
    const { sign, digits } = integerBody(value, spec, flags, precisionValue)
    emit(pad(sign, digits, widthValue, flags, precisionValue < 0))
  }
  if (size > 1048576) throw new RuntimeError('Native formatting buffer exceeds harness limit')
  const result = produced
  if (size) {
    const formatted = Buffer.concat(out)
    const buffer = Buffer.alloc(size)
    formatted.copy(buffer, 0, 0, Math.min(formatted.length, size - 1))
    uc.mem_write(destination, buffer.subarray(0, Math.min(size, Math.max(0, result) + 1)))
  }
  for (const [guest, width, count] of writebacks) {
    const b = Buffer.alloc(width)
    if (width === 8) b.writeBigInt64LE(BigInt(count)); else if (width === 2) b.writeInt16LE(Number(BigInt.asIntN(16, BigInt(count)))); else if (width === 1) b.writeInt8(Number(BigInt.asIntN(8, BigInt(count)))); else b.writeInt32LE(count | 0)
    uc.mem_write(guest, b)
  }
  return result
}

module.exports = { vsnprintf, formatFloat, integerBody }
