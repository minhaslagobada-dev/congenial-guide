'use strict'
// Port of inspect_native_schema.py.
// Recover CSV column requirements from the v13 initializers themselves.
const path = require('node:path')
const { disassembler, read } = require('./native')
const { NativeV13 } = require('./emulate_v13')
const { decodeUtf8, pyInt } = require('./lib/pycompat')
const R = require('./lib/research')
const SCHEMAS = { characters: [0x1fbfa4, 0x1fda2c], skills: [0x13da8c, 0x13e5e0], projectiles: [0x449b0c, 0x44ae40], area_effects: [0x370430, 0x3709e4], tiles: [0x4478e4, 0x448000] }
// int(text, 0)
const int0x = text => { text = text.trim(); const negative = text.startsWith('-'); const v = Number(BigInt(negative ? text.slice(1) : text)); return negative ? -v : v }
function recover (md, native, start, end) {
  const records = []; let page = null; let target = null; let recent = null
  for (const instruction of md.disasm(Array.from(read(start, end - start)), start)) {
    const m = instruction.mnemonic; const o = instruction.op_str
    if (m === 'adrp' && o.startsWith('x1, #')) page = parseInt(o.split('#')[1], 16)
    else if (m === 'add' && o.startsWith('x1, x1, #') && page !== null) target = page + parseInt(o.split('#')[1], 16)
    else if (m === 'bl' && o === '#0x12d868' && target !== null) {
      recent = { name: decodeUtf8(native.string(target)), stringRva: R.hex(target), callRva: R.hex(instruction.address) }
      records.push(recent); target = null
    } else if (m === 'bl' && o === '#0x1f2eac' && recent && Object.keys(recent).length) recent.typeCheckRva = R.hex(instruction.address)
    else if (m === 'cmp' && o.startsWith('w0, #') && recent && Object.keys(recent).length && 'typeCheckRva' in recent && !('nativeType' in recent)) {
      recent.nativeType = int0x(o.split('#')[1])
    }
  }
  return records
}
R.main(async () => {
  const md = await disassembler()
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const report = {}
  for (const [name, [start, end]] of Object.entries(SCHEMAS)) {
    const raw = R.csvRows(path.join(root, 'GameAssets/csv_logic', `${name}.csv`))
    const required = recover(md, n, start, end); const missing = required.map(r => r.name).filter(x => !raw[0].includes(x))
    const invalid = []
    for (const row of raw.slice(2)) {
      raw[1].forEach((kind, index) => {
        const value = index < row.length ? row[index] : ''
        if (kind.toLowerCase() === 'int' && value) {
          try { pyInt(value) } catch (_) { invalid.push({ row: row[0], column: raw[0][index], value }) }
        }
      })
    }
    report[name] = { initializer: R.hex(start), required, missing, invalidIntegers: invalid }
    R.print(name + ':', required.length, 'native columns;', missing.length, 'missing;', invalid.length, 'invalid integer cells')
  }
  R.writeJson('required-csv-schema.json', report, 2)
})
