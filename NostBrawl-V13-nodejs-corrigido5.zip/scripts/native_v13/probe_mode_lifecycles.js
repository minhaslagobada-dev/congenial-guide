'use strict'
// Port of probe_mode_lifecycles.py.
// Natural original-mode endings, including native AI, objectives and clocks.
//
// One idle human per match, no assignment to HP, scores, positions, clocks, ranks
// or end flags. A cap is reported as incomplete, never converted into a victory.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { pyInt } = require('./lib/pycompat')
const { kindOf } = require('./lib/battle_probe')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 })
  n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const records = []; const seen = new Set(); const table = data.csv.get(15)
  for (const row of table.records) {
    const location = R.zipDict(table.names, row); const mode = location.GameMode
    if (!location.AllowedMaps || location.Disabled === 'true' || seen.has(mode)) continue
    seen.add(mode); const kind = kindOf(mode)
    const record = { location: location.Name, gameMode: mode, kind, checkpoints: [], finished: false }
    let battle = null; const start = performance.now()
    try {
      battle = new NativeBattle(data, location.Name, kind); battle.add_player('ShotgunGirl', 0); battle.setup()
      record.initial = battle.describe()
      const limit = Number(pyInt(process.env.V13_LIFECYCLE_TICKS || '6500'))
      let index
      for (index = 0; index < limit; index++) {
        const vision = battle.frame(); const ended = Boolean(m.u8(battle.pointer + 0xa3))
        if ((index + 1) % 100 === 0 || ended) { const state = battle.describe(); state.vision = vision; record.checkpoints.push(state) }
        if (ended) { record.finished = true; break }
      }
      if (index === limit) index = limit - 1
      record.framesProcessed = index + 1
    } catch (error) {
      record.error = { message: R.errorMessage(error), pc: m.pc(), lr: m.lr() }
    } finally {
      if (battle !== null) {
        try { battle.close() } catch (error) { record.cleanupError = R.errorMessage(error) }
      }
    }
    record.elapsedSeconds = (performance.now() - start) / 1000; records.push(record)
    R.writeJson('mode-lifecycles.json', records)
    R.print('Original lifecycle', mode, 'finished', record.finished, 'frames', record.framesProcessed, 'error', record.error)
  }
  if (records.some(r => !r.finished || 'error' in r || 'cleanupError' in r)) throw new R.SystemExit(1)
  R.print('All original mode lifecycles ended naturally')
})
