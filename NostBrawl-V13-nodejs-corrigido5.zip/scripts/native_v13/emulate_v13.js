'use strict'
// Port of emulate_v13.py: executes original v13 ARM64 functions inside Unicorn
// (WebAssembly build of Unicorn 2.1.4, same engine version as the Python tools).
const { elf, relocs } = require('./native')
const { loadUnicorn, Uc } = require('./lib/unicorn')
const C = require('./lib/unicorn_const')
const { ValueError, RuntimeError } = require('./lib/pycompat')

const STOP = 0x40000000
const hex = v => '0x' + BigInt(v).toString(16)

// Out-of-thread watchdog for per-call deadlines (timeout_us). An expired
// native call is fatal (the original tools also abandon the process), so the
// watchdog writes the configured report and ends the process.
//
// Performance: arm()/disarm() run around every guest call (thousands per
// second in a live battle). They only store a deadline and bump a generation
// counter in shared memory - no thread wake-up, no syscall. The watchdog
// thread polls every POLL_MS. (Unicorn's own uc_emu_start timeout creates and
// joins a timer thread on EVERY call, ~0.13 ms each; that dominated the cost of
// small calls such as input decoding and score queries.)
const WATCHDOG_POLL_MS = 50
class CallWatchdog {
  constructor () {
    const { Worker } = require('node:worker_threads')
    this.sab = new SharedArrayBuffer(32 + 65536)
    this.ctl = new Int32Array(this.sab, 0, 4) // [generation, active, reportLength, stop]
    this.deadline = new Float64Array(this.sab, 16, 1)
    this.report = new Uint8Array(this.sab, 32)
    const source = `
      const { workerData } = require('node:worker_threads'); const fs = require('node:fs')
      const sab = workerData.sab; const ctl = new Int32Array(sab, 0, 4); const deadline = new Float64Array(sab, 16, 1); const report = new Uint8Array(sab, 32)
      for (;;) {
        Atomics.wait(ctl, 3, 0, ${WATCHDOG_POLL_MS})
        if (Atomics.load(ctl, 3)) break
        if (!Atomics.load(ctl, 1)) continue
        const generation = Atomics.load(ctl, 0); const limit = deadline[0]
        if (Date.now() < limit) continue
        if (Atomics.load(ctl, 0) !== generation || !Atomics.load(ctl, 1)) continue
        const length = Atomics.load(ctl, 2)
        try { if (length) fs.writeSync(1, Buffer.from(report.slice(0, length))) } catch (_) {}
        try { fs.writeSync(2, 'Native execution stopped before return: call timeout of ' + workerData.label + ' exceeded\\\\n') } catch (_) {}
        process.kill(process.pid, 'SIGKILL')
      }`
    this.worker = new Worker(source, { eval: true, workerData: { sab: this.sab, label: 'the configured limit' } })
    this.worker.unref()
  }

  arm (timeoutUs) {
    this.deadline[0] = Date.now() + timeoutUs / 1000
    Atomics.add(this.ctl, 0, 1)
    Atomics.store(this.ctl, 1, 1)
  }

  disarm () {
    Atomics.store(this.ctl, 1, 0)
    Atomics.add(this.ctl, 0, 1)
  }

  setReport (text) {
    const bytes = Buffer.from(text || '', 'utf8')
    if (bytes.length > this.report.length) throw new Error('Watchdog report too large')
    Atomics.store(this.ctl, 2, 0)
    this.report.set(bytes)
    Atomics.store(this.ctl, 2, bytes.length)
  }
}

class NativeV13 {
  // Unicorn's Wasm module must be loaded once before construction.
  static async ready () { await loadUnicorn() }
  static async create (options) { await loadUnicorn(); return new NativeV13(options) }

  constructor ({ heap_bytes = 0x1000000, reclaim_memory = false, instruction_counting = true, timeout_us = 0 } = {}) {
    this.instruction_counting = instruction_counting; this.call_timeout_us = timeout_us
    this.uc = new Uc(C.UC_ARCH_ARM64, C.UC_MODE_ARM)
    // Guest memory layout. LEGACY maps everything RWX and traps invalid
    // accesses with one global hook, exactly like the original research tools.
    // That forces Unicorn's slow path for EVERY guest store: a TLB entry is
    // only marked dirty when it is not executable and no memory hook covers it
    // (qemu/accel/tcg/cputlb.c notdirty_write()). The default layout mirrors
    // the device loader instead - code segment R-X, data/bss/heap/stack/TLS
    // RW- - bounds the invalid-access hook to the unmapped gaps and, on the
    // native backend, uses a region-permission TLB (the CPU TLB with the MMU
    // off makes every entry executable). Valid programs execute identically;
    // stores become ~7x cheaper. UNICORN_LEGACY_MEMORY=1 restores the old
    // layout, UNICORN_CPU_TLB=1 only the default TLB, for diagnosis.
    this.legacy_memory = process.env.UNICORN_LEGACY_MEMORY === '1'
    const RW = C.UC_PROT_READ | C.UC_PROT_WRITE; const RX = C.UC_PROT_READ | C.UC_PROT_EXEC
    this._mapped = []
    const map = (address, size, perms = C.UC_PROT_ALL) => {
      this.uc.mem_map(address, size, this.legacy_memory ? C.UC_PROT_ALL : perms)
      this._mapped.push([address, address + size, perms])
    }
    let codeEnd = 0
    for (const seg of elf.iter_segments()) if (seg.p_type === 1 && (seg.p_flags & 1)) codeEnd = Math.max(codeEnd, seg.p_vaddr + seg.p_memsz)
    codeEnd = Math.min(0xc00000, (codeEnd + 0xfff) & ~0xfff)
    for (const seg of elf.iter_segments()) {
      if (seg.p_type === 1 && !(seg.p_flags & 1) && seg.p_vaddr < codeEnd) codeEnd = 0 // overlapping layout: keep one RWX image
    }
    if (codeEnd) { map(0, codeEnd, RX); map(codeEnd, 0xc00000 - codeEnd, RW) } else map(0, 0xc00000)
    for (const seg of elf.iter_segments()) {
      if (seg.p_type === 1) this.uc.mem_write(seg.p_vaddr, seg.data())
    }
    const packed = Buffer.alloc(8)
    for (const [address, value] of relocs) { packed.writeBigUInt64LE(BigInt.asUintN(64, value)); this.uc.mem_write(address, packed) }
    if (heap_bytes < 0x1000000 || heap_bytes % 4096 || heap_bytes > 0x10000000) throw new ValueError('Invalid research heap size')
    this.heap_limit = 0x10000000 + heap_bytes
    map(0x10000000, heap_bytes, RW); this.heap = 0x10000000
    this.guest_heap = null
    if (reclaim_memory) {
      const { GuestHeap } = require('./native_memory')
      this.guest_heap = new GuestHeap(this)
    }
    map(0x20000000, 0x200000, RW); map(0x30000000, 0x1000, RW)
    map(0x40000000, 0x1000) // return trampoline (STOP); executable
    this.uc.reg_write(C.UC_ARM64_REG_TPIDR_EL0, 0x30000000)
    this.hooks = new Map(); this.calls = []; this.trace = []
    const sym = elf.get_section_by_name('.dynsym'); const plt = elf.get_section_by_name('.plt')
    elf.iter_relocations(elf.get_section_by_name('.rela.plt')).forEach((r, i) => {
      const name = elf.symbolName(sym, r.r_info_sym)
      const address = plt.sh_addr + 32 + i * 16
      this.hooks.set(address, () => this.external(name))
    })
    // Trap only registered external/fixture addresses. A global instruction
    // callback needlessly returns to JavaScript for every original instruction.
    this._hooked_addresses = new Set()
    this._onCode = (uc, address, size, data) => this.on_code(uc, address, size, data)
    this.uc.hook_add(C.UC_HOOK_CODE, this._onCode, null, STOP, STOP)
    const invalid = (uc, access, address, size, value, data) => this.invalid(uc, access, address, size, value, data)
    if (this.legacy_memory) this.uc.hook_add(C.UC_HOOK_MEM_INVALID, invalid)
    else {
      // Same diagnostics for unmapped accesses, without covering mapped pages.
      const regions = [...this._mapped].sort((a, b) => a[0] - b[0]); let cursor = 0n
      for (const [start, end] of regions) {
        if (BigInt(start) > cursor) this.uc.hook_add(C.UC_HOOK_MEM_UNMAPPED, invalid, null, cursor, BigInt(start) - 1n)
        if (BigInt(end) > cursor) cursor = BigInt(end)
      }
      this.uc.hook_add(C.UC_HOOK_MEM_UNMAPPED, invalid, null, cursor, 0xffffffffffffffffn)
      if (typeof this.uc.enable_region_tlb === 'function' && process.env.UNICORN_CPU_TLB !== '1') {
        this.uc.enable_region_tlb(regions)
        this.region_tlb = true
      }
    }
    this._watchdog = null
  }

  alloc (n) {
    if (this.guest_heap !== null) return this.guest_heap.allocate(n)
    n = Math.max(16, Math.trunc(Number(n))); const out = this.heap; this.heap += (n + 15) & ~15
    if (this.heap > this.heap_limit) throw new RuntimeError('Emulation heap exhausted')
    return out
  }

  free (pointer) {
    if (this.guest_heap !== null) this.guest_heap.release(pointer)
  }

  string (a) {
    a = Number(a)
    const parts = []; let total = 0
    for (;;) {
      const b = this.uc.mem_read(a, 256); const i = b.indexOf(0)
      if (i >= 0) { parts.push(b.subarray(0, i)); return Buffer.concat(parts) }
      parts.push(b); total += 256; a += 256
      if (total > 1000000) throw new RuntimeError('Invalid native string')
    }
  }

  external (name) {
    const [ra, rb, rc] = [C.UC_ARM64_REG_X0, C.UC_ARM64_REG_X1, C.UC_ARM64_REG_X2].map(x => this.uc.reg_read(x))
    const a = Number(ra); const b = Number(rb); const c = Number(rc)
    const uc = this.uc
    if (name === 'realloc' && this.guest_heap !== null) return this.guest_heap.resize(a, b)
    if (['malloc', 'calloc', '_Znwm', '_Znam', 'realloc'].includes(name)) {
      const length = name === 'calloc' ? Number(ra * rb) : name === 'realloc' ? b : a
      const pointer = this.alloc(length)
      if (name === 'calloc') uc.mem_write(pointer, Buffer.alloc(length))
      return pointer
    }
    if (['free', '_ZdlPv', '_ZdaPv'].includes(name)) { this.free(a); return 0 }
    if (['__cxa_atexit', '__cxa_finalize', 'pthread_mutex_lock', 'pthread_mutex_unlock', '__android_log_print'].includes(name)) return 0
    if (name === '__cxa_guard_acquire') return uc.mem_read(a, 1)[0] === 0 ? 1 : 0
    if (name === '__cxa_guard_release') { uc.mem_write(a, Buffer.from([1])); return 0 }
    if (name === '__cxa_guard_abort') { uc.mem_write(a, Buffer.from([0])); return 0 }
    if (name === 'strlen') return this.string(a).length
    if (name === 'strnlen') {
      const data = uc.mem_read(a, b); const end = data.indexOf(0); return end < 0 ? data.length : end
    }
    if (name === 'strcpy' || name === '__strcpy_chk') { uc.mem_write(a, Buffer.concat([this.string(b), Buffer.from([0])])); return a }
    if (name === 'strncpy' || name === '__strncpy_chk') {
      let data = uc.mem_read(b, c); const end = data.indexOf(0)
      if (end >= 0) data = Buffer.concat([data.subarray(0, end), Buffer.alloc(c - end)])
      uc.mem_write(a, data); return a
    }
    if (['memcpy', 'memmove', '__memcpy_chk', '__memmove_chk'].includes(name)) { uc.mem_write(a, uc.mem_read(b, c)); return a }
    if (name === 'memset' || name === '__memset_chk') { uc.mem_write(a, Buffer.alloc(c, b & 255)); return a }
    if (name === 'memcmp') return Math.sign(Buffer.compare(uc.mem_read(a, c), uc.mem_read(b, c)))
    if (name === 'strcmp') return Math.sign(Buffer.compare(this.string(a), this.string(b)))
    if (name === 'strcasecmp' || name === 'strncasecmp') {
      const lower = buf => Buffer.from(buf.map(x => (x >= 0x41 && x <= 0x5a ? x + 32 : x)))
      let left = lower(this.string(a)); let right = lower(this.string(b))
      if (name === 'strncasecmp') { left = left.subarray(0, c); right = right.subarray(0, c) }
      return Math.sign(Buffer.compare(left, right))
    }
    if (name === 'vsnprintf') {
      const { vsnprintf } = require('./native_libc')
      return vsnprintf(this, a, b, c)
    }
    throw new RuntimeError('Unimplemented native import ' + name)
  }

  ret (value) {
    if (value !== null && value !== undefined) this.uc.reg_write(C.UC_ARM64_REG_X0, BigInt.asUintN(64, BigInt(value)))
    this.uc.reg_write(C.UC_ARM64_REG_PC, this.uc.reg_read(C.UC_ARM64_REG_LR))
  }

  on_code (uc, address, size, data) {
    if (address === STOP) { uc.emu_stop(); return }
    const hook = this.hooks.get(address)
    if (hook) this.ret(hook())
  }

  invalid (uc, access, address, size, value, data) {
    throw new RuntimeError(`Unmapped memory ${hex(address)} pc=${hex(uc.reg_read(C.UC_ARM64_REG_PC))} lr=${hex(uc.reg_read(C.UC_ARM64_REG_LR))}`)
  }

  prepare_hooks () {
    for (const address of this.hooks.keys()) {
      if (this._hooked_addresses.has(address)) continue
      this.uc.hook_add(C.UC_HOOK_CODE, this._onCode, null, address, address)
      this._hooked_addresses.add(address)
    }
  }

  // Report written to stdout by the watchdog if a timed call expires (IPC worker).
  // Unicorn's built-in uc_emu_start timeout spawns a timer thread per call;
  // only use it when explicitly requested (UNICORN_ENGINE_TIMEOUT=1).
  get engine_timeout () { return Boolean(this.uc.supportsTimeout) && process.env.UNICORN_ENGINE_TIMEOUT === '1' }

  setTimeoutReport (text) {
    if (this.engine_timeout || !this.call_timeout_us) return
    if (!this._watchdog) this._watchdog = new CallWatchdog()
    this._watchdog.setReport(text)
  }

  // Returns X0 as an unsigned 64-bit BigInt (Python returns an int).
  call (addr, ...args) {
    let count = 1000000
    if (args.length && args[args.length - 1] !== null && typeof args[args.length - 1] === 'object' && !(typeof args[args.length - 1] === 'bigint')) {
      const options = args.pop(); if (options.count !== undefined) count = options.count
    }
    this.prepare_hooks()
    this.uc.reg_write(C.UC_ARM64_REG_SP, 0x201ff000); this.uc.reg_write(C.UC_ARM64_REG_LR, STOP)
    args.forEach((v, i) => this.uc.reg_write(C.UC_ARM64_REG_X0 + i, typeof v === 'boolean' ? Number(v) : v))
    const timeout = this.call_timeout_us
    // Deadlines use the shared-memory watchdog (cheap on every call); the
    // engine's per-call timer thread is opt-in (see engine_timeout).
    const engineTimeout = this.engine_timeout
    const watched = Boolean(timeout) && !engineTimeout
    if (watched) { if (!this._watchdog) this._watchdog = new CallWatchdog(); this._watchdog.arm(timeout) }
    try {
      this.uc.emu_start(addr, STOP, engineTimeout ? timeout : 0, this.instruction_counting ? count : 0)
    } finally {
      if (watched) this._watchdog.disarm()
    }
    const pc = this.uc.reg_read(C.UC_ARM64_REG_PC)
    if (pc !== BigInt(STOP)) throw new RuntimeError(`Native execution stopped before return at ${hex(pc)}`)
    return this.uc.reg_read(C.UC_ARM64_REG_X0)
  }

  decrypt () { this.call(0x104518, { count: 30000000 }) }
}

module.exports = { NativeV13 }

if (require.main === module) {
  NativeV13.create().then(n => {
    n.decrypt()
    console.log('column', require('./lib/pycompat').pyRepr(new Uint8Array(n.string(0x97478b))))
  }).catch(error => { console.error(error); process.exit(1) })
}
