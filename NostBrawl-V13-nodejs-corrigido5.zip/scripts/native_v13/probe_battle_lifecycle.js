'use strict'
// Port of probe_battle_lifecycle.py.
// Run original populated frames until natural completion or an explicit cap.
//
// No score, timer, position, health or end flag is forced. One human is idle;
// the remaining players use the original bot AI. This is not a UDP load test.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { pyInt } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const location = process.env.V13_LOCATION || 'Gemgrab1'; const kind = Number(pyInt(process.env.V13_BATTLE_KIND || '1'))
  const limit = Number(pyInt(process.env.V13_LIFECYCLE_TICKS || '6000')); const result = { location, kind, limit, checkpoints: [] }
  try {
    const battle = new NativeBattle(data, location, kind); battle.add_player('ShotgunGirl', 0); battle.setup()
    result.initial = battle.describe(); const started = performance.now()
    let index; let ended
    for (index = 0; index < limit; index++) {
      const vision = battle.frame()
      ended = Boolean(m.u8(battle.pointer + 0xa3))
      if ((index + 1) % 100 === 0 || ended) {
        const frame = battle.describe(); frame.vision = vision; result.checkpoints.push(frame)
        R.print('lifecycle', location, 'tick', frame.tick, 'score', frame.teamScores, 'countdown', frame.countdown, 'objects', frame.objects.length, 'ended', ended)
      }
      if (ended) break
    }
    if (index === limit) index = limit - 1
    Object.assign(result, { framesProcessed: index + 1, finished: ended, elapsedSeconds: (performance.now() - started) / 1000, heapBytes: n.heap - 0x10000000 })
    R.print('Original lifecycle result:', result.framesProcessed, 'frames; natural completion', ended)
  } catch (e) {
    result.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
    R.print('blocked', result.error)
  }
  R.writeJson('battle-lifecycle-' + location + '.json', result)
  if ('error' in result) throw new R.SystemExit(1)
})
