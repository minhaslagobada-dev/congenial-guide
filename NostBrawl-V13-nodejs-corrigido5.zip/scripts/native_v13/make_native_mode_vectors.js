'use strict'
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR || !process.env.V13_VECTOR_DIR) throw new Error('Set V13_RESEARCH_DIR and V13_VECTOR_DIR')
const assets = new BattleAssets()
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'battle-modes-vectors.json')))
const vectors = []
for (const record of records) {
  if (record.error) throw new Error(JSON.stringify(record.error))
  const location = assets.named('locations', record.location)
  const grid = assets.map(location.AllowedMaps)
  for (const frame of record.frames) vectors.push({
    name: `${record.gameMode}/${frame.tick}`, nativeSnapshot: true, mode: frame.nativeMode,
    capacity: frame.players.length, ownIndex: 0, grid, hex: frame.vision[0].hex,
    objects: frame.objects.map(object => ({ nativeId: object.id, fullDataId: object.dataId, x: object.x, y: object.y }))
  })
}
fs.mkdirSync(process.env.V13_VECTOR_DIR, { recursive: true })
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'world-vectors.json'), JSON.stringify({ tables: assets.tables, vectors }))
console.log('Packaged original mode snapshots:', vectors.length, 'across', records.length, 'modes')
