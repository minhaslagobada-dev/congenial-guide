'use strict'
// Port of test_native_memory.py.
// Check guest allocator/libc lifetime semantics without running game logic.
const { NativeV13 } = require('./emulate_v13')
const { RuntimeError } = require('./lib/pycompat')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create({ reclaim_memory: true }); const heap = n.guest_heap
  const bytes = (a, size) => n.uc.mem_read(a, size)
  const a = n.alloc(32); const b = n.alloc(48); n.uc.mem_write(b, Buffer.alloc(48, 'B'))
  heap.release(a); const small = n.alloc(16); R.assert(small === a)
  n.uc.mem_write(small, Buffer.alloc(16, 'A')); R.assert(bytes(b, 48).equals(Buffer.alloc(48, 'B')))
  heap.release(small); heap.release(b); const merged = n.alloc(80); R.assert(merged === a)
  const sequence = Buffer.from(Array.from({ length: 80 }, (_, i) => i))
  n.uc.mem_write(merged, sequence); const grown = heap.resize(merged, 160)
  R.assert(bytes(grown, 80).equals(sequence))
  let rejected = false
  try { heap.release(merged) } catch (error) { if (!(error instanceof RuntimeError)) throw error; rejected = true }
  if (!rejected) throw new Error('AssertionError: Repeated free was not rejected')
  heap.release(grown)
  const external = (name, ...args) => {
    [C.UC_ARM64_REG_X0, C.UC_ARM64_REG_X1, C.UC_ARM64_REG_X2].slice(0, args.length).forEach((register, i) => n.uc.reg_write(register, args[i]))
    return Number(n.external(name))
  }
  const dirty = n.alloc(64); n.uc.mem_write(dirty, Buffer.alloc(64, 0xff)); heap.release(dirty)
  const zeroed = external('calloc', 4, 16); R.assert(bytes(zeroed, 64).equals(Buffer.alloc(64)))
  const replacement = external('realloc', zeroed, 128); R.assert(bytes(replacement, 64).equals(Buffer.alloc(64)))
  R.assert(external('realloc', replacement, 0) === 0)
  const guard = n.alloc(8); n.uc.mem_write(guard, Buffer.alloc(8))
  R.assert(external('__cxa_guard_acquire', guard) === 1)
  external('__cxa_guard_release', guard)
  R.assert(external('__cxa_guard_acquire', guard) === 0)
  external('__cxa_guard_abort', guard)
  R.assert(external('__cxa_guard_acquire', guard) === 1)
  R.assert(heap.peak < 1024)
  R.print('Guest heap: reuse/coalescing, realloc preservation, calloc zeroing, repeated-free rejection and single-thread C++ guards passed')
})
