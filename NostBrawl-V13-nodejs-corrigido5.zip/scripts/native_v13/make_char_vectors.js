process.chdir(require('path').resolve(__dirname, '../..'))
const fs=require('fs')
const {battleAssets}=require('../../Logic/Battle/World/BattleAssets')
const {V13BitStream}=require('../../Logic/Battle/Game/V13BitStream')
const {encodeCharacter,CHARACTER_TYPES}=require('../../Logic/Battle/Game/V13WorldCodec')
const assets=battleAssets(), out=[]
for(const data of assets.tables.characters) for(const mode of [0,2,3,5,6,7,8,9,10,11]) for(const own of [false,true]) for(const variant of [0,1]){
 // Keep cross-mode fixture inputs representable. Raid bosses use their full
 // native health only in Raid mode, where the client reads the 21-bit field.
 const maxHp=mode===10&&data.Type==='Npc_Boss'?Number(data.Hitpoints):Math.min(Number(data.Hitpoints),6399)
 const stream=new V13BitStream(),object={dataId:data.id,x:3100,y:5100,index:17,hp:Math.max(1,maxHp-100),maxHp,score:2,speed:Number(data.Speed),attackAngle:90,moveAngle:180,powerLevel:2,skills:[{ammo:2500},{ammo:0}]}
 object.statuses=variant?[{kind:'poison',remaining:4}]:[];object.invisible=Boolean(variant);object.carryingBall=Boolean(variant&&mode===5&&data.Type==='Hero')
 encodeCharacter(stream,object,own,mode,false,assets)
 out.push({hero:data.id,name:data.Name,mode,own,large:false,type:CHARACTER_TYPES[data.Type],object,skills:[data.WeaponSkill,data.UltimateSkill].filter(Boolean).map(n=>assets.named('skills',n)),hp:Number(data.Hitpoints),speed:Number(data.Speed),autoDamage:Number(data.AutoAttackDamage)||0,area:data.AreaEffect,bits:stream.position,hex:stream.bytes().toString('hex')})
}
fs.writeFileSync(require('path').join(process.env.V13_VECTOR_DIR, 'char-vectors.json'),JSON.stringify(out))
