'use strict'
// Port of probe_upgrade_skin_data.py.
// Original card/skin metadata reference initialization from client assets.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts), [23, 29])
  const records = {}
  for (const kind of [23, 29]) records[String(kind)] = [...data.entries.get(kind)].map(([name, pointer]) => ({ name, id: data.word(pointer + 0x20) }))
  for (const record of records['29']) {
    const pointer = data.named(29, record.name)
    for (const [key, offset] of [['mainProjectile', 0xd8], ['superProjectile', 0xe0]]) {
      const projectile = data.ptr(pointer + offset); record[key] = projectile ? data.word(projectile + 0x20) : null
    }
  }
  R.writeJson('upgrade-skin-data-vectors.json', records)
  R.print('Original card and skin references:', records['23'].length, 'cards;', records['29'].length, 'skins; rendering and upgraded combat excluded')
})
