'use strict'
// Port of probe_tile_state.py.
// Original tile constructor, destruction and isolated respawn update.
// The update caller's eligibility filter is separately identified, not invented.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { StopIteration } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/tiles.csv')); t.initialize_schema(0x4478e4)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const metaByName = new Map()
  t.records.forEach((row, i) => { const meta = t.alloc(0x100); p(meta + 8, t.rows[i]); metaByName.set(row[0], meta) })
  p(0xab42d0, metaByName.get('Open'))
  const manager = t.alloc(0x80); const array = t.alloc(8); p(manager, array)
  const actor = t.alloc(0x400); p(actor, 0x72dc10); p(array, actor)
  const pathx = t.alloc(4); const pathy = t.alloc(4); p(actor + 0x90, pathx); p(actor + 0xa0, pathy)
  const records = []
  const u64 = a => n.uc.mem_read(a, 8).readBigUInt64LE(0)
  const state = obj => {
    const data = m.u64(obj)
    let name; for (const [k, v] of metaByName) if (v === data) { name = k; break }
    if (name === undefined) throw new StopIteration()
    return { data: name, timer: get(obj + 0x20), seconds: new R.PyFloat(n.uc.mem_read(obj + 0x24, 4).readFloatLE(0)), movementMask: u64(obj + 0x10), projectileMask: u64(obj + 0x18) }
  }
  for (const row of t.records) {
    const d = R.zipDict(t.names, row); const name = d.Name
    for (const timer of [-1, 0, 1, 2, 700]) {
      for (const scenario of ['none', 'near', 'far', 'dead', 'flag148far', 'flag149far', 'pathNear', 'pathFar', 'at300', 'at301', 'diagonal300', 'diagonal301', 'projectileNear']) {
        const obj = t.alloc(0x40); n.call(0x39f9bc, obj, metaByName.get(name), 10, 15)
        const constructed = state(obj)
        n.call(0x39a128, obj); const destroyed = state(obj)
        w(obj + 0x20, timer)
        w(manager + 0xc, scenario === 'none' ? 0 : 1)
        p(actor, scenario === 'projectileNear' ? 0x74e558 : 0x72dc10)
        w(actor + 0xb0, scenario === 'dead' ? 0 : 100)
        w(actor + 0x30, ['near', 'dead'].includes(scenario) ? 3150 : 5000); w(actor + 0x34, ['near', 'dead'].includes(scenario) ? 4650 : 8000)
        if (['at300', 'at301', 'diagonal300', 'diagonal301', 'projectileNear'].includes(scenario)) {
          const [dx, dy] = { at300: [300, 0], at301: [301, 0], diagonal300: [180, 240], diagonal301: [180, 241], projectileNear: [0, 0] }[scenario]
          w(actor + 0x30, 3150 + dx); w(actor + 0x34, 4650 + dy)
        }
        n.uc.mem_write(actor + 0x148, Buffer.from([scenario === 'flag148far' ? 1 : 0, scenario === 'flag149far' ? 1 : 0]))
        w(actor + 0x9c, ['pathNear', 'pathFar'].includes(scenario) ? 1 : 0)
        w(pathx, scenario === 'pathNear' ? 3150 : 5000); w(pathy, scenario === 'pathNear' ? 4650 : 8000)
        n.call(0x12fa44, obj, manager)
        records.push({
          name, definition: d, timer, scenario, constructed, destroyed, after: state(obj),
          actors: scenario === 'none' ? [] : [{ type: scenario === 'projectileNear' ? 1 : 0, hp: get(actor + 0xb0), x: get(actor + 0x30), y: get(actor + 0x34), byte148: scenario === 'flag148far', byte149: scenario === 'flag149far', path: ['pathNear', 'pathFar'].includes(scenario) ? [get(pathx), get(pathy)] : null }]
        })
      }
    }
  }
  R.writeJson('tile-state-vectors.json', records)
  R.print('Original tile state:', records.length, 'constructor/destruction/isolated respawn cases')
})
