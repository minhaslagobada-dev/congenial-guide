'use strict'
const fs = require('node:fs'), path = require('node:path')
process.chdir(path.resolve(__dirname, '../..'))
const { battleAssets } = require('../../Logic/Battle/World/BattleAssets')
const { worldCommand } = require('../../Logic/Battle/Game/V13Commands')
const { encodeInput } = require('../../Logic/Battle/Network/V13BattleCodec')
const a = battleAssets(), vectors = []
for (const hero of a.heroes) for (const automatic of [false, true]) {
  const skills = [hero.WeaponSkill, hero.UltimateSkill].map(name => ({ definition: a.named('skills', name) }))
  for (const slot of [0, 1]) {
    const own = { x: 3100, y: 5100, dataId: hero.id, skills }
    const target = { dataClass: 16, hp: 3000, x: 5300, y: 5800 }
    const world = { assets: a, characters: new Map([[1, own]]), objects: new Map([[2, target]]), nearestEnemy: () => target }
    const input = { counter: 1, category: 1, code: skills[slot].definition.id, x: 1000, y: 1500, targetId: 1000002, flag: automatic }
    const output = worldCommand(world, { player: { low_id: 1 } }, input)
    vectors.push({ input, output, skills: skills.map(s => s.definition), slot, projectile: skills[slot].definition.Projectile ? a.named('projectiles', skills[slot].definition.Projectile) : null,
      packet: encodeInput({ inputs: [input] }).toString('hex') })
  }
}
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'command-vectors.json'), JSON.stringify(vectors))
