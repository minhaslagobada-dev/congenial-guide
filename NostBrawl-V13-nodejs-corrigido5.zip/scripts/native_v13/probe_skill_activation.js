'use strict'
// Port of probe_skill_activation.py.
// Execute the original v13 activation + terrain target resolver.
//
// CSV/cache references are input data. No native gameplay function is replaced.
// This measures activation only; it does not claim that attacks have simulated.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { NativeOpenMap } = require('./native_open_map')
const { RuntimeError, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  const terrain = new NativeOpenMap(n, root)
  const alloc = s => t.alloc(s); const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const behavior = { Attack: 0, Blink: 1, Charge: 2, Invisibility: 3, TransformMinion: 4, BuffMinion: 5, Rage: 6, Shield: 7 }
  const manager = alloc(0x100); const battle = alloc(0x400); p(manager + 0x50, battle); w(battle + 0x18, 150)
  const records = []
  const chars = R.dictReader(path.join(root, 'GameAssets/csv_logic/characters.csv')).slice(1)
  const selected = new Set()
  for (const char of chars) if (char.Type === 'Hero' && char.Disabled !== 'true') { selected.add(char.WeaponSkill); selected.add(char.UltimateSkill) }
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row)
    if (!selected.has(d.Name)) return
    const meta = alloc(0x200); p(meta + 8, t.rows[i]); w(meta + 0xb8, behavior[d.BehaviorType]); w(meta + 0x20, 20000000 + i)
    // Target resolver tests only the existence of these resolved references.
    for (const [field, key] of [[0x70, 'SummonedCharacter'], [0x88, 'SpawnedItem']]) if (d[key]) p(meta + field, alloc(0x200))
    for (const [x, y] of [[3500, 5000], [3000, 4500], [-1000, -1000], [20000, 20000]]) {
      for (const [cooldown, ammo] of [[0, 3000], [50, 3000], [0, 999]]) {
        const owner = alloc(0x400); p(owner + 0x18, manager); w(owner + 0x30, 3000); w(owner + 0x34, 4500); w(owner + 0x2fc, -1)
        const state = alloc(0x30); n.call(0x248d70, state, meta); w(state + 0x10, cooldown); w(state + 0x14, ammo)
        try { n.call(0x4a3f3c, state, owner, x, y, terrain.pointer, 150, { count: 3000000 }) } catch (e) {
          const error = new RuntimeError(pyRepr(tuple(d.Name, x, y, cooldown, ammo, R.errorMessage(e)))); error.cause = e; throw error
        }
        const result = {
          skill: d.Name,
          input: { x, y, cooldown, ammo },
          after: { activeMs: get(state + 0xc), cooldownMs: get(state + 0x10), ammo: get(state + 0x14), target: [get(state + 0x18), get(state + 0x1c)], executing: m.u8(state + 0x20), pending: m.u8(state + 0x21), castingMs: get(owner + 0x198) }
        }
        const after = result.after
        if (cooldown || ammo < 1000) {
          R.assert(after.executing === 0 && after.activeMs === 0)
          R.assert(after.cooldownMs === cooldown && after.ammo === ammo)
        } else {
          R.assert(after.executing === 1 && after.pending === 1 && after.activeMs >= 1)
          R.assert(after.cooldownMs === 0 && after.ammo === ammo, 'The native activation does not spend ammo or start cooldown here')
          R.assert(after.castingMs === R.int0(d.CastingTime))
          R.assert(after.target[0] >= 1 && after.target[0] <= 6298 && after.target[1] >= 1 && after.target[1] <= 9898)
        }
        records.push(result)
      }
    }
  })
  R.writeJson('skill-activation-vectors.json', records)
  R.print('Original v13 activation + target/terrain resolver:', records.length, 'cases;', new Set(records.map(r => r.skill)).size, 'hero skills; no gameplay hooks')
})
