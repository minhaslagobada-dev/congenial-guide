'use strict'
// Port of probe_collision_geometry.py.
// Original v13 segment intersection and rectangle contact, no gameplay hooks.
const { NativeV13 } = require('./emulate_v13')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); const point = n.alloc(8); const records = []; const m = R.memory(n)
  let state = 17
  const random = limit => { state = (state * 1664525 + 1013904223) % 4294967296; return state % limit }
  const run = (kind, values) => {
    n.uc.mem_write(point, R.pack('i', -12345, -12345))
    n.uc.mem_write(0x201ff000, R.pack('Q', point))
    const args = values.map(R.u32)
    const result = kind === 'circle' ? n.call(0x462288, ...args, point) : n.call(kind === 'segment' ? 0x2ea134 : 0x4413ac, ...args)
    records.push({ kind, input: values, result, point: [m.i32(point), m.i32(point + 4)] })
  }
  for (const values of [[0, 0, 100, 100, 0, 100, 100, 0], [0, 0, 100, 0, 50, -50, 50, 50], [0, 0, 100, 0, 50, 0, 150, 0],
    [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 100, 100, 100, 100, 200, 0], [3500, 4650, 2500, 4650, 3000, 4500, 3300, 4800]]) run('segment', values)
  for (const [start, end] of [[[2500, 4650], [3500, 4650]], [[3500, 4650], [2500, 4650]], [[3150, 4000], [3150, 5200]], [[2500, 4000], [3500, 5200]], [[3150, 4650], [3150, 4650]], [[3000, 4500], [3300, 4800]]]) {
    run('rectangle', [...start, ...end, 3000, 4500, 3300, 4800])
  }
  for (const values of [[0, 0, 1000, 0, 500, 0, 100], [0, 0, 50, 0, 0, 0, 100], [0, 0, 0, 0, 0, 0, 100], [0, 0, 100, 0, 50, 100, 100], [1000, 1000, 10000, 10000, 5000, 5000, 0]]) run('circle', values)
  for (let i = 0; i < 4000; i++) {
    run('circle', [...Array.from({ length: 6 }, () => random(20001) - 10000), random(1000)])
    run('segment', Array.from({ length: 8 }, () => random(20001) - 10000))
    const x = random(9000); const y = random(9000)
    run('rectangle', [random(10000), random(10000), random(10000), random(10000), x, y, x + random(1000), y + random(1000)])
  }
  R.writeJson('collision-geometry-vectors.json', records)
  R.print('Original v13 collision geometry:', records.length, 'segment/rectangle cases')
})
