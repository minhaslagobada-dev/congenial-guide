'use strict'
const fs = require('node:fs')
const path = require('node:path')
const { encodeInput } = require('../../Logic/Battle/Network/V13BattleCodec')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const commands = [
  { step: 2, code: 100, x: 3150, y: 6150 },
  { step: 215, code: 0, x: 0, y: -1800, targetId: 1000003, flag: true },
  { step: 230, code: 0, x: 0, y: -1800, targetId: 1000003, flag: true },
  { step: 245, code: 0, x: 0, y: -1800, targetId: 1000003, flag: true },
  { step: 280, code: 107, x: 0, y: 0 },
  { step: 281, code: 1, x: 0, y: -1800, targetId: 1000003, flag: true }
]
const records = commands.map((command, i) => ({
  step: command.step, player: 0, command,
  packet: encodeInput({ tick: command.step, sequence: i + 1, inputs: [{ counter: i + 1, category: 1, ...command }] }).toString('hex')
}))
fs.mkdirSync(process.env.V13_RESEARCH_DIR, { recursive: true })
fs.writeFileSync(path.join(process.env.V13_RESEARCH_DIR, 'battle-input-schedule.json'), JSON.stringify(records))
console.log('Generated native input schedule:', records.length, 'original v13 packets')
