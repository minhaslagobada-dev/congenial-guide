'use strict'
// Port of validate_command_native.py.
const { NativeV13 } = require('./emulate_v13')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const m = R.memory(n)
  const put = m.put32; const pp = m.put64; const word = m.i32
  const reg = i => n.uc.reg_read(C.UC_ARM64_REG_X0 + i)
  const state = {}
  // These hooks supply actor/CSV lookups and capture the final activation. The
  // original v13 input-entry decoder and action/coordinate consumer execute.
  n.uc.mem_map(0x40001000, 4096)
  n.hooks.set(0x40001000, () => 1)
  n.hooks.set(0x40001004, () => 0)
  n.hooks.set(0x3afbc8, () => (reg(1) === 1000001n ? state.own : reg(1) === 1000002n ? state.target : 0))
  n.hooks.set(0x31cde4, () => state.skill)
  n.hooks.set(0x469228, () => R.int0(state.v.skills[state.v.slot].ChargeType))
  n.hooks.set(0x3ec52c, () => ((state.v.projectile || {}).AttractsPet === 'true' ? 1 : 0))
  n.hooks.set(0x4bd7ac, () => 3100)
  n.hooks.set(0x2599ec, () => 5100)
  n.hooks.set(0x4dff44, () => 5300)
  n.hooks.set(0x4ff8f4, () => 5800)
  for (const [address, value] of [[0x1f2a54, 3100], [0x4ee3f0, 5100], [0x1f1d14, 26900], [0x33ff28, 24900]]) n.hooks.set(address, () => value)
  n.hooks.set(0x3b7d84, () => state.ulti)
  n.hooks.set(0x36f164, () => state.weapon)
  n.hooks.set(0x11bdc4, () => state.v.skills[reg(0) === BigInt(state.ulti) ? 1 : 0].id)
  n.hooks.set(0x16c94c, () => 1)
  for (const address of [0x38fec4, 0x19292c, 0x13b0b4]) n.hooks.set(address, () => 0)
  const activate = () => { state.actual = [reg(1), reg(2), reg(3)]; return 0 }
  n.hooks.set(0x267b98, activate)
  if (process.env.V13_TRACE) {
    const trace = (uc, address, size, data) => {
      if ([0xcd75c, 0xcd7dc, 0xcd8e0, 0xcd900, 0xcd99c].includes(address)) R.print(R.hex(address), [0, 20, 21, 24, 25].map(i => uc.reg_read(C.UC_ARM64_REG_W0 + i)))
    }
    n.uc.hook_add(C.UC_HOOK_CODE, trace)
  }
  const vectors = R.vectors('command-vectors.json')
  for (const v of vectors) {
    for (const key of Object.keys(state)) delete state[key]
    n.heap = 0x10000000
    const owner = n.alloc(0x400); const target = n.alloc(0x400); const world = n.alloc(0x200); const vt = n.alloc(0x100); const skill = n.alloc(0x200); const projectile = n.alloc(0x200); const weapon = n.alloc(16); const ulti = n.alloc(16)
    for (const [a, size] of [[owner, 0x400], [target, 0x400], [world, 0x200], [vt, 0x100], [skill, 0x200], [projectile, 0x200]]) n.uc.mem_write(a, Buffer.alloc(size))
    pp(owner, vt); pp(target, vt); pp(vt + 0x58, 0x40001000); pp(vt + 0x38, 0x40001004)
    Object.assign(state, { v, own: owner, target, skill, weapon, ulti })
    const sk = v.skills[v.slot]; const pr = v.projectile
    put(skill + 0xb8, sk.BehaviorType === 'Charge' ? 2 : 0)
    if (pr) {
      pp(skill + 0x68, projectile); n.uc.mem_write(projectile + 0x90, Buffer.from([pr.Indirect === 'true' ? 1 : 0]))
      pp(projectile + 0xa8, pr.SpawnAreaEffectObject ? 1 : 0)
    }
    pp(skill + 0x88, sk.SpawnedItem ? 1 : 0); pp(skill + 0x70, sk.SummonedCharacter ? 1 : 0)
    const message = n.alloc(0x98); n.uc.mem_write(message, Buffer.alloc(0x98)); n.call(0x18efc4, message)
    const stream = message + 16; const raw = Buffer.from(v.packet, 'hex'); const buf = n.alloc(raw.length); n.uc.mem_write(buf, raw); pp(stream + 0x20, buf); put(stream + 0x14, 4); put(stream + 0x18, raw.length)
    const command = n.alloc(32); n.call(0x3f9fcc, command, stream)
    const expected = v.input
    const decoded = [0, 1, 2, 3, 4, 5].map(i => word(command + i * 4)); const wanted = ['counter', 'category', 'code', 'x', 'y', 'targetId'].map(k => expected[k])
    R.assert(R.deepEqual(decoded, wanted))
    R.assert(Boolean(m.u8(command + 24)) === expected.flag)
    n.call(0xcd610, world, command, 1000001)
    const out = v.output
    const actual = state.actual
    R.assert(actual !== undefined && actual[0] === BigInt(expected.code) && actual[1] === BigInt(out.x) && actual[2] === BigInt(out.y), [sk.Name, expected, actual === undefined ? null : actual, out])
  }
  R.print('Native v13 command entry + action/aim handler passed:', vectors.length, 'cases')
})
