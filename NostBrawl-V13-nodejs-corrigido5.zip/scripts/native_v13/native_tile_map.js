'use strict'
// Port of native_tile_map.py.
// Execute the client's complete map constructor on registered client CSV data.
class NativeTileMap {
  constructor (data, name, seed = 17, mode = 0) {
    this.data = data
    const t = data.csv.get(19)
    t.ptr(0xab42d0, data.named(27, 'Open'))
    const native_name = t.alloc(24); t.string(native_name, name)
    const rng = t.alloc(16); t.word(rng, seed)
    this.pointer = t.alloc(0x100)
    data.native.call(0xf1f88, this.pointer, rng, 0, native_name, mode, { count: 20000000 })
  }

  describe () {
    const d = this.data; const p = this.pointer
    const result = {}
    for (const [name, offset] of [['width', 0x40], ['height', 0x44], ['logicWidth', 0x48], ['logicHeight', 0x4c], ['fineWidth', 0x50], ['fineHeight', 0x54], ['tiles', 0x58], ['respawningTiles', 0x60]]) result[name] = d.word(p + offset)
    const cells = d.ptr(d.ptr(p + 0x20) + 0x10)
    result.grid = []
    for (let y = 0; y < result.height; y++) {
      let row = ''
      for (let x = 0; x < result.width; x++) row += String.fromCodePoint(d.word(cells + (y * result.width + x) * 4))
      result.grid.push(row)
    }
    return result
  }
}

module.exports = { NativeTileMap }
