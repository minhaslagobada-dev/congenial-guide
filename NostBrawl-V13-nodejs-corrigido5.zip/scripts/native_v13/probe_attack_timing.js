'use strict'
// Port of probe_attack_timing.py.
// Original attack interval function, native skill readers, controlled cache.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const records = []
  const behaviors = { Attack: 0, Blink: 1, Charge: 2, Invisibility: 3, TransformMinion: 4, BuffMinion: 5, Rage: 6, Shield: 7 }
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); w(meta + 0xb8, behaviors[d.BehaviorType])
    for (const active of [0, 150]) {
      for (const executing of [0, 1]) {
        for (const casting of [0, 50]) {
          for (const characterType of [0, 1]) {
            for (const cached of [0, 3, 40]) {
              const actor = t.alloc(0x400); const data = t.alloc(0x200); p(actor + 0x10, data); w(data + 0x184, characterType); w(data + 0x130, cached); p(data + 0x198, meta)
              w(actor + 0x198, casting); w(actor + 0xe4, R.int0(d.MsBetweenAttacks))
              const skill = t.alloc(0x30); p(skill, meta); w(skill + 0xc, active); n.uc.mem_write(skill + 0x20, Buffer.from([executing]))
              const skills = t.alloc(8); p(skills, skill); p(actor + 0x130, skills); w(actor + 0x13c, 1)
              const result = R.signed32(n.call(0x14ad30, actor))
              records.push({ definition: d, activeMs: active, executing, castingMs: casting, characterType, cachedInterval: cached, result })
            }
          }
        }
      }
    }
  })
  R.writeJson('attack-timing-vectors.json', records)
  R.print('Original attack timing:', records.length, 'cases; no gameplay hooks')
})
