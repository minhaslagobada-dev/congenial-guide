'use strict'
// Port of probe_character_movement.py.
// Original moveTo, pathfinder and character updates on a real client map.
//
// Battle/player structures remain controlled input. No movement, terrain, metadata
// reader or character update function is replaced.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeTileMap } = require('./native_tile_map')
const { RuntimeError, ValueError, StopIteration, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const terrain = new NativeTileMap(data, 'Tutorial'); const description = terrain.describe()
  const t = data.csv.get(19); const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const records = []
  // Select a four-tile unobstructed corridor from the actual native source grid.
  const tiles = data.csv.get(27); const openRow = tiles.records.find(row => row[0] === 'Open')
  if (!openRow) throw new StopIteration()
  const openCode = openRow[tiles.names.indexOf('TileCode')]
  const corridors = []
  description.grid.forEach((text, y) => {
    const line = [...text]
    for (let x = 1; x < line.length - 4; x++) if (line.slice(x, x + 4).join('') === openCode.repeat(4)) corridors.push([x, y])
  })
  R.assert(corridors.length, 'No open test corridor in Tutorial')
  const [x, y] = corridors[Math.floor(corridors.length / 2)]
  let origin = [x * 300 + 150, y * 300 + 150]; let target = [origin[0] + 600, origin[1]]
  const scenario = process.env.V13_MOVEMENT_SCENARIO || 'corridor'
  if (!['corridor', 'obstacle'].includes(scenario)) throw new ValueError('Unknown movement scenario')
  if (scenario === 'obstacle') {
    origin = [2550, 6450]; target = [2550, 7050]
    R.assert([...description.grid[22]].slice(8, 11).join('') === 'YYY')
  }
  const ticks = scenario === 'obstacle' ? 100 : 30
  const characters = data.csv.get(16)
  for (const row of characters.records) {
    const d = R.zipDict(characters.names, row)
    if (d.Type !== 'Hero' || d.Disabled === 'true' || d.LockedForChronos === 'true') continue
    const manager = t.alloc(0x100); const battle = t.alloc(0x400); p(manager + 0x50, battle); p(battle, manager); p(battle + 0x70, terrain.pointer)
    const players = t.alloc(6 * 8); p(battle + 0x78, players)
    for (let i = 0; i < 6; i++) p(players + i * 8, t.alloc(0x200))
    const obj = t.alloc(0x400); n.call(0x14de30, obj, data.named(16, d.Name)); w(obj + 0x3c, 0); w(obj + 0x40, 0); n.call(0x253b18, manager, obj); n.call(0x465f38, obj, ...origin, 0)
    w(battle + 0x18, 150)
    try {
      n.call(0x3921f4, obj, ...target, 0, 0, { count: 3000000 })
      for (let tick = 150; tick < 150 + ticks; tick++) {
        w(battle + 0x18, tick); n.call(0x18ff68, obj, { count: 3000000 })
        records.push({ name: d.Name, tick, x: data.word(obj + 0x30), y: data.word(obj + 0x34), origin, target, hp: data.word(obj + 0xb0) })
      }
    } catch (e) {
      if (e instanceof Error && e.name === 'AssertionError') throw e
      const error = new RuntimeError(pyRepr(tuple(d.Name, R.errorMessage(e)))); error.cause = e; throw error
    }
    R.print('moved', d.Name, records[records.length - 1].x, records[records.length - 1].y)
  }
  R.writeJson(scenario === 'obstacle' ? 'character-obstacle-vectors.json' : 'character-movement-vectors.json', records)
  R.print('Original character movement:', records.length, 'frames; real native map/pathfinder and controlled battle/player structures')
})
