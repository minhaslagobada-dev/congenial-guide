'use strict'
// Runs the ORIGINAL v13 client decoder for 23458 BattleLogMessage
// (factory case 0x474c68, decode 0x3fb954 -> LogicBattleLogEntry 0x47f288 ->
// LogicBattleLogPlayer 0x21b324) on payloads produced by the server's
// BattleLogMessage and checks every field the client stores plus full
// consumption of the stream. No hooks: pure libg code under emulation.
//   node scripts/native_v13/validate_battle_log_native.js
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const R = require('./lib/research')
const BattleLogMessage = require('../../Packets/Messages/Server/Battle/BattleLogMessage')

function payloadOf (entries, replace, now) {
  const message = new BattleLogMessage({ player: null }, null, entries, replace, now)
  message.encode()
  return Buffer.from(message.buffer)
}

const NOW = 1_800_000_000_000
const people = (n, own) => Array.from({ length: n }, (_, i) => ({
  kind: i === own ? 1 : 3, high_id: 0, low_id: i === own ? 20650220 : i + 1, team: n === 6 ? (i < 3 ? 0 : 1) : (n === 10 && i % 2 ? i : i), mvp: i === 2,
  name: i === own ? 'Jogador ção ★' : '', brawler_id: (i * 3) % 24, trophies: 100 + i * 7, power_level: 1 + (i % 9), rank: n === 6 ? 0 : i + 1
}))
const VECTORS = [
  { replace: true, entries: [] },
  {
    replace: true,
    entries: [
      { created_at: NOW - 65_000, entry_type: 1, trophy_change: 10, duration: 134, practice: false, map_id: 7, result: 0, participants: people(6, 0) },
      { created_at: NOW - 3_600_000, entry_type: 1, trophy_change: -2, duration: 90, practice: false, map_id: 17, result: 1, participants: people(6, 4) },
      { created_at: NOW - 86_400_000 * 3, entry_type: 2, trophy_change: 3, duration: 200, practice: false, map_id: 48, result: 2, participants: people(10, 3) },
      { created_at: NOW - 5_000, entry_type: 5, trophy_change: 15, duration: 300, practice: false, map_id: 34, result: 0, participants: people(10, 0) },
      { created_at: NOW - 1_000, entry_type: 1, trophy_change: 8, duration: 60, practice: true, map_id: 0, result: 2, participants: people(6, 1) }
    ]
  },
  { replace: false, entries: [{ created_at: NOW, entry_type: 1, trophy_change: 0, duration: 0, practice: false, map_id: 24, result: 0, participants: people(6, 5) }] }
]
// 25 entries = the default client page
VECTORS.push({ replace: true, entries: Array.from({ length: 25 }, (_, i) => ({ ...VECTORS[1].entries[i % 4], created_at: NOW - i * 60_000 })) })

R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000, reclaim_memory: true, instruction_counting: false, timeout_us: 4000000 }); n.decrypt()
  const data = new NativeDataRegistry(n, path.join(R.ROOT, 'GameAssets'))
  const t = data.csv.get(15)
  let checked = 0
  VECTORS.forEach((vector, index) => {
    // Same construction as the client's message factory case 23458
    // (libg 0x474c68): new(0x58), PiranhaMessage ctor 0x3cfa18(msg, 0),
    // vtable 0x731188+0x10, replace=false, entries=null.
    const message = Number(n.call(0x5d1b08, 0x58))
    n.call(0x3cfa18, message, 0)
    t.ptr(message, 0x731198); n.uc.mem_write(message + 0x4c, Buffer.from([0])); t.ptr(message + 0x50, 0)
    R.assert(data.ptr(message) === 0x731198 && data.ptr(0x731198 + 0x18) === 0x3fb954, ['vtable/decode slot', index])
    const payload = payloadOf(vector.entries, vector.replace, NOW)
    const buffer = t.alloc(Math.max(1, payload.length)); n.uc.mem_write(buffer, payload)
    const stream = message + 0x10; const previous = data.ptr(stream + 0x20)
    if (previous) n.free(previous)
    t.ptr(stream + 0x20, buffer); t.word(stream + 0x10, payload.length); t.word(stream + 0x14, 0); t.word(stream + 0x18, payload.length)
    n.call(0x3fb954, message, { count: 20000000 })
    R.assert(data.word(stream + 0x14) === payload.length, ['23458 not fully consumed', index, data.word(stream + 0x14), payload.length])
    R.assert(Boolean(n.uc.mem_read(message + 0x4c, 1)[0]) === vector.replace, ['replace flag', index])
    const list = data.ptr(message + 0x50)
    R.assert(data.word(list + 0xc) === vector.entries.length, ['entry count', index, data.word(list + 0xc)])
    vector.entries.forEach((expected, i) => {
      const e = data.ptr(data.ptr(list) + i * 8)
      R.assert(data.word(e + 0x24) === Math.floor((NOW - expected.created_at) / 1000), ['age', index, i])
      R.assert(data.word(e + 4) === expected.entry_type, ['type', index, i])
      R.assert(data.word(e + 8) === (expected.practice ? 0 : expected.trophy_change), ['trophies', index, i, data.word(e + 8)])
      R.assert(data.word(e + 0xc) === expected.duration, ['duration', index, i])
      R.assert(Boolean(n.uc.mem_read(e + 0x10, 1)[0]) === expected.practice, ['friendly', index, i])
      R.assert(data.word(data.ptr(e + 0x18) + 0x20) === 15000000 + expected.map_id, ['location', index, i])
      R.assert(data.word(e + 0x20) === expected.result, ['result', index, i])
      R.assert(data.word(e + 0x28) === -1, ['replay', index, i])
      R.assert(data.word(e + 0x4c) === expected.participants.length, ['player count', index, i, data.word(e + 0x4c)])
      expected.participants.forEach((p, j) => {
        const q = data.ptr(data.ptr(e + 0x40) + j * 8)
        R.assert(data.word(q) === p.kind, ['kind', index, i, j])
        const id = n.uc.mem_read(q + 8, 8)
        R.assert(id.readInt32LE(0) === p.low_id || id.readInt32LE(4) === p.low_id || data.word(data.ptr(q + 8) + 4) === p.low_id, ['account id', index, i, j])
        R.assert(data.word(q + 0x10) === p.team, ['team', index, i, j])
        R.assert(Boolean(n.uc.mem_read(q + 0x14, 1)[0]) === p.mvp, ['mvp', index, i, j])
        R.assert(data.string(data.ptr(q + 0x18)) === p.name, ['name', index, i, j, data.string(data.ptr(q + 0x18))])
        R.assert(data.word(data.ptr(q + 0x20) + 0x20) === 16000000 + p.brawler_id, ['hero', index, i, j])
        R.assert(data.word(q + 0x28) === p.trophies && data.word(q + 0x2c) === p.power_level && data.word(q + 0x30) === p.rank, ['trophies/level/rank', index, i, j])
        checked++
      })
    })
  })
  R.print('Original v13 BattleLog decode passed:', VECTORS.length, 'packets,', checked, 'participants; every field, replace flag and full consumption')
})
