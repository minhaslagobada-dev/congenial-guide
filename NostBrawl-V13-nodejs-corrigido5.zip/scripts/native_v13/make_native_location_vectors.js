'use strict'
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR || !process.env.V13_VECTOR_DIR) throw new Error('Set V13_RESEARCH_DIR and V13_VECTOR_DIR')
const assets = new BattleAssets()
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'native-locations.json')))
const vectors = records.map(record => {
  if (record.error || record.cleanupError) throw new Error(record.error || record.cleanupError)
  const frame = record.final
  return { name: record.location, nativeSnapshot: true, mode: frame.nativeMode, capacity: frame.players.length,
    ownIndex: 0, grid: record.terrain.grid, hex: frame.vision[0].hex,
    objects: frame.objects.map(object => ({ nativeId: object.id, fullDataId: object.dataId, x: object.x, y: object.y })) }
})
fs.mkdirSync(process.env.V13_VECTOR_DIR, { recursive: true })
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'world-vectors.json'), JSON.stringify({ tables: assets.tables, vectors }))
console.log('Original populated location snapshots:', vectors.length)
