'use strict'
// Port of validate_world_native.py.
// The complete native world reader plus actual entity/skill bit readers run.
// Client CSV metadata/readers are original; entity allocation and graphical
// callbacks remain controlled inputs because Android rendering is not running.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { RuntimeError } = require('./lib/pycompat')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const state = {}; const definitions = new Map(); const m = R.memory(n)
  const registry = new NativeDataRegistry(n, path.join(R.ROOT, 'GameAssets'))
  const vectorHeap = n.heap
  const w = m.u32; const p = m.u64; const put = m.put32; const pp = m.put64
  const alloc = size => { const a = n.alloc(size); n.uc.mem_write(a, Buffer.alloc(size)); return a }
  const reg = i => Number(n.uc.reg_read(C.UC_ARM64_REG_X0 + i))
  n.uc.mem_map(0x40001000, 4096); n.hooks.set(0x40001000, () => 0)
  n.hooks.set(0x2966c8, () => state.tileMap)
  n.hooks.set(0x3226e8, () => state.v.ownIndex)
  n.hooks.set(0x11997c, () => (state.tile.IsDestructible === 'true' ? 1 : 0))
  n.hooks.set(0x53de84, () => (state.tile.IsDestructibleNormalWeapon === 'true' && (state.tile.BlocksMovement === 'true' || state.tile.BlocksProjectiles === 'true') ? 1 : 0))
  const tile = () => {
    const x = reg(1); const y = reg(2); const code = [...state.v.grid[y]][x]
    state.tile = Object.prototype.hasOwnProperty.call(state.tileDefs, code) ? state.tileDefs[code] : state.tileDefs['.']; return state.tilePtr
  }
  n.hooks.set(0x14c61c, tile)
  n.hooks.set(0x433050, () => 0)

  const classes = { 16: ['characters', 0x75e938], 6: ['projectiles', 0x746260], 17: ['area_effects', 0x750f78], 18: ['items', 0x737da8] }
  for (const cls of Object.keys(classes).map(Number)) {
    const table = registry.csv.get(cls)
    for (const row of table.records) definitions.set(registry.named(cls, row[0]), [cls, R.zipDict(table.names, row)])
  }

  const initObject = (obj, meta) => {
    const definition = definitions.get(meta)
    if (!definition) throw new Error('KeyError: ' + meta)
    const [cls] = definition; const vt = alloc(0x60); const base = classes[cls][1]
    for (let offset = 0; offset < 0x60; offset += 8) pp(vt + offset, p(base + offset))
    pp(vt + 0x10, 0x40001000); pp(obj, vt); pp(obj + 0x10, meta)
    if (cls === 16) {
      const skills = [0x198, 0x1a0].map(off => p(meta + off)).filter(Boolean)
      const array = alloc(16); pp(obj + 0x68, array); put(obj + 0x74, skills.length)
      skills.forEach((definitionPointer, i) => { const skill = alloc(0x30); pp(skill, definitionPointer); pp(array + i * 8, skill) })
    }
    return obj
  }
  n.hooks.set(0x2dd210, () => initObject(alloc(0x200), reg(0)))
  n.hooks.set(0x380970, () => initObject(reg(0), reg(1)))

  const stop = (uc, a, size, data) => uc.emu_stop()
  n.uc.hook_add(C.UC_HOOK_CODE, stop, null, 0x139db8, 0x139db8)
  const bounds = (uc, a, size, data) => {
    const stream = reg(0); const bits = reg(1); const position = w(stream + 8) * 8 + w(stream + 16)
    if (position + bits > state.maxBits) throw new RuntimeError('Native world bit overread')
  }
  n.uc.hook_add(C.UC_HOOK_CODE, bounds, null, 0x4f4518, 0x4f4518)
  n.prepare_hooks()
  const fixture = R.vectors('world-vectors.json')
  for (const v of fixture.vectors) {
    for (const key of Object.keys(state)) delete state[key]
    n.heap = vectorHeap
    const manager = alloc(0x100); const battle = alloc(0x200); const mapMeta = alloc(0x100); const tiles = alloc(0x80); const tilePtr = alloc(0x80); const stream = alloc(0x30); const players = alloc(16); const parray = alloc(v.capacity * 8); const extra = alloc(16); const root = alloc(0x100); const rootvt = alloc(0x100)
    pp(root, rootvt); pp(rootvt + 0x18, 0x40001000); pp(manager + 0x10, root)
    pp(battle + 0xc8, mapMeta); put(battle + 0xfc, v.mode); put(mapMeta + 0x40, [...v.grid[0]].length); pp(tilePtr + 8, mapMeta)
    pp(players, parray); put(players + 12, v.capacity)
    for (let i = 0; i < v.capacity; i++) { const player = alloc(0x100); put(player + 0x20, i); pp(parray + i * 8, player) }
    const raw = Buffer.from(v.hex, 'hex'); const payload = alloc(raw.length); n.uc.mem_write(payload, raw); pp(stream + 24, payload); put(stream + 12, raw.length)
    const names = {}
    for (const [key, table] of Object.entries(fixture.tables)) { names[key] = {}; for (const d of table) names[key][d.Name] = d }
    const tileDefs = {}; for (const d of fixture.tables.tiles) tileDefs[d.TileCode] = d
    Object.assign(state, { v, tables: fixture.tables, names, tileMap: tiles, tilePtr, tileDefs, maxBits: raw.length * 8 })
    n.uc.reg_write(C.UC_ARM64_REG_SP, 0x201ff000); n.uc.reg_write(C.UC_ARM64_REG_LR, 0x40000000)
    ;[manager, stream, players, 0, battle, extra].forEach((arg, i) => n.uc.reg_write(C.UC_ARM64_REG_X0 + i, arg))
    try {
      n.uc.emu_start(0x139398, 0x40000000, 0, 3000000)
      R.assert(Number(n.uc.reg_read(C.UC_ARM64_REG_PC)) === 0x139db8)
      const consumed = w(stream + 8) * 8 + w(stream + 16)
      R.assert(raw.length * 8 - consumed >= 0 && raw.length * 8 - consumed <= 7, ['Trailing bits', consumed, raw.length * 8])
      let pairs
      if (v.nativeSnapshot) {
        // Original vision may omit objects outside this player's visibility.
        const expectedById = new Map(v.objects.map(o => [o.nativeId, o]))
        R.assert(w(manager + 12) > 0 && w(manager + 12) <= expectedById.size)
        pairs = []
        for (let i = 0; i < w(manager + 12); i++) {
          const obj = p(p(manager) + i * 8); const gid = w(obj + 8)
          R.assert(expectedById.has(gid), ['Unknown original object', gid])
          const expected = expectedById.get(gid); R.assert(w(p(obj + 0x10) + 0x20) === expected.fullDataId)
          pairs.push([obj, expected])
        }
      } else {
        R.assert(w(manager + 12) === v.objects.length)
        pairs = v.objects.map((expected, i) => [p(p(manager) + i * 8), expected])
      }
      for (const [obj, expected] of pairs) {
        if (!v.nativeSnapshot) R.assert(w(obj + 8) === ({ 16: 1, 6: 2, 17: 3, 18: 4 })[expected.dataClass] * 1000000 + expected.id)
        R.assert(w(obj + 0x30) === expected.x && w(obj + 0x34) === expected.y, [expected, w(obj + 0x30), w(obj + 0x34)])
      }
    } catch (error) { R.print('FULL WORLD FAILED:', v.name, R.errorMessage(error)); throw error }
  }
  R.print('Native complete-world decode passed:', fixture.vectors.length, 'initial/combat map views')
})
