'use strict'
process.chdir(require('path').resolve(__dirname, '../..'))
const fs = require('fs')
const { battleAssets } = require('../../Logic/Battle/World/BattleAssets')
const { V13BitStream } = require('../../Logic/Battle/Game/V13BitStream')
const codec = require('../../Logic/Battle/Game/V13WorldCodec')
const a = battleAssets(), out = []
for (const [table, cls, fn] of [['projectiles', 6, 'encodeProjectile'], ['area_effects', 17, 'encodeArea'], ['items', 18, 'encodeItem']]) {
  for (const data of a.tables[table]) for (const mode of [0, 6]) for (const large of [false, true]) for (const variant of cls === 6 ? [0, 1, 2] : [0]) {
    const s = new V13BitStream()
    const object = { dataId: data.id, x: 3100, y: 5100, index: 17, z: 30, state: variant === 2 ? 4 : 0,
      fuseTick: 411, startX: 2900, startY: 4900, angle: 90, age: 3, targetX: 3100, targetY: 5100,
      deploymentMs: 650, triggerMs: 300, totalRange: 2000, remaining: 750,
      indirect: variant === 1, target: { x: 3500, y: 5700 }, bounceTileIndex: variant === 1 ? 718 : null }
    codec[fn](s, object, mode, large, a)
    out.push({ table, cls, data, mode, large, object, bits: s.position, hex: s.bytes().toString('hex') })
  }
}
fs.writeFileSync(require('path').join(process.env.V13_VECTOR_DIR, 'object-vectors.json'), JSON.stringify(out))
