'use strict'
// Port of validate_objects_native.py.
const { NativeV13 } = require('./emulate_v13')
const { RuntimeError } = require('./lib/pycompat')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create(); const rows = new Map(); const m = R.memory(n)
  const rowValue = () => {
    const row = rows.get(Number(n.uc.reg_read(C.UC_ARM64_REG_X0)))
    if (row === undefined) throw new Error('KeyError: ' + n.uc.reg_read(C.UC_ARM64_REG_X0))
    const value = row.get(Number(n.uc.reg_read(C.UC_ARM64_REG_W1)))
    return value === undefined ? 0 : value
  }
  n.hooks.set(0x469228, rowValue)
  n.hooks.set(0x24f974, rowValue)
  n.hooks.set(0x1dca94, () => { if (n.uc.reg_read(C.UC_ARM64_REG_X0)) return 0; throw new RuntimeError('Native assertion failed') })
  for (const [addr, col] of [[0x9778d8, 1], [0x9a9644, 2], [0x91bc30, 3], [0x94cbdc, 4]]) n.uc.mem_write(addr, R.pack('I', col))
  const put = m.put32; const pp = m.put64; const word = m.u32
  const state = {}
  const bounds = (uc, a, size, d) => {
    const p = Number(uc.reg_read(C.UC_ARM64_REG_X0)); const bits = Number(uc.reg_read(C.UC_ARM64_REG_W1)); const pos = word(p + 8) * 8 + word(p + 16)
    if (pos + bits > state.bits) throw new RuntimeError(`Native overread ${pos}+${bits}>${state.bits}, lr=${R.hex(uc.reg_read(C.UC_ARM64_REG_LR))}`)
  }
  n.uc.hook_add(C.UC_HOOK_CODE, bounds, null, 0x4f4518, 0x4f4518)
  const vectors = R.vectors('object-vectors.json')
  for (const v of vectors) {
    n.heap = 0x10000000
    const obj = n.alloc(0x200); const meta = n.alloc(0x200); const row = n.alloc(16); const stream = n.alloc(0x30); const payload = n.alloc(512)
    for (const [a, size] of [[obj, 0x200], [meta, 0x200], [stream, 0x30]]) n.uc.mem_write(a, Buffer.alloc(size))
    const d = v.data; rows.set(row, new Map([[1, d.IsBouncing === 'true' ? 1 : 0], [2, R.int0(d.TriggerWithDelayMs)], [3, R.int0(d.PreExplosionTimeMs)], [4, d.SyncAnimWithServer === 'true' ? 1 : 0]]))
    pp(meta + 8, row); pp(obj + 0x10, meta)
    let fn
    if (v.cls === 6) {
      pp(obj, 0x746260); put(meta + 0x9c, ({ Use360Frames: 1, UseZFrames: 2, DoNotRotateClip: 3 })[d.Rendering] || 0); fn = 0x387814
    } else if (v.cls === 17) { pp(obj, 0x750f78); put(meta + 0x80, d.Type === 'DelayedDamage' ? 8 : 0); fn = 0x469f7c } else { pp(obj, 0x737da8); put(meta + 0x64, d.id); fn = 0x41c734 }
    const data = Buffer.from(v.hex, 'hex'); n.uc.mem_write(payload, data); pp(stream + 24, payload); put(stream + 12, data.length); state.bits = v.bits
    try {
      n.call(fn, obj, stream, v.mode, v.large ? 1 : 0)
      const consumed = word(stream + 8) * 8 + word(stream + 16)
      R.assert(consumed === v.bits, [consumed, v.bits])
      R.assert(word(obj + 0x30) === v.object.x)
      R.assert(word(obj + 0x34) === v.object.y)
      if (v.cls === 6) {
        const source = v.object
        R.assert(word(obj + 0x48) === source.state)
        R.assert(word(obj + 0x64) === 625)
        if (d.TriggerWithDelayMs || d.PreExplosionTimeMs) R.assert(word(obj + 0x60) === 411)
        if (R.int0(d.PreExplosionTimeMs)) R.assert(word(obj + 0x58) === 3500 && word(obj + 0x5c) === 5700)
        if (source.indirect) {
          R.assert(m.u8(obj + 0x69) === 1)
          R.assert(word(obj + 0x74) === 3500 && word(obj + 0x78) === 5700)
        }
        if (d.IsBouncing === 'true' && source.bounceTileIndex !== null && source.bounceTileIndex !== undefined) R.assert(word(obj + 0x6c) === 718)
      }
    } catch (e) { R.print(v.table, d.Name, v.mode, v.large, 'FAIL', R.errorMessage(e)); throw e }
  }
  R.print('Native v13 projectile/area/item decode passed:', vectors.length, 'vectors')
})
