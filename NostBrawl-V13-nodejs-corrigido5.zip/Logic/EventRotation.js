'use strict'

const path = require('path')

const DataBase = require('../Database/DatabaseManager')
const Config = require('../Utils/Config')
const { readDictRows } = require('../Files/CsvLogic/CsvRows')
const { ValueError } = require('../Utils/Errors')

class EventError extends ValueError {
  constructor (message) {
    super(message)
    this.name = 'EventError'
  }
}

function toInteger (value) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return null
  }
  return Math.trunc(parsed)
}

function dayOrdinal (year, month, day) {
  return Math.floor(Date.UTC(year, month - 1, day) / 86400000) + 719162
}

function localIsoDay (date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

class EventRotation {
  static get SLOT_POOLS () {
    return [
      ['CoinRush', [7, 8, 9, 10, 11, 12, 40, 48]],
      ['BattleRoyale', [13, 14, 15, 16, 32, 43]],
      ['BountyHunter', [0, 4, 22]],
      ['LaserBall', [24, 25, 26, 50, 51]],
      ['BattleRoyaleTeam', [34, 35, 36, 37, 38, 28]]
    ]
  }

  static get CLAIMS_KEY () { return 'eventClaims' }
  static get STATES_KEY () { return 'eventStates' }
  static get CLAIM_HISTORY_DAYS () { return 64 }
  static get TOKEN_WALLET_CAP () { return 999900 }
  static get PROJECT_ROOT () { return path.resolve(__dirname, '..') }
  static get LOCATIONS_PATH () {
    return path.join(EventRotation.PROJECT_ROOT, 'GameAssets', 'csv_logic', 'locations.csv')
  }

  static _now (value = null) {
    return value !== null && value !== undefined ? value : new Date()
  }

  static _location_rows () {
    const rows = readDictRows(EventRotation.LOCATIONS_PATH)
    if (rows.length && rows[0].Name === 'string') {
      return rows.slice(1)
    }
    return rows
  }

  static locations () {
    const rows = EventRotation._location_rows()
    const result = []
    for (let locationId = 0; locationId < rows.length; locationId++) {
      const row = rows[locationId]
      const disabled = String(row.Disabled !== undefined ? row.Disabled : '').trim().toLowerCase()
      result.push({
        id: locationId,
        name: row.Name || '',
        game_mode: row.GameMode || '',
        enabled: !['1', 'true', 'yes'].includes(disabled)
      })
    }
    return result
  }

  static enabled_pools () {
    const locations = EventRotation.locations()
    const pools = []
    for (const [gameMode, candidates] of EventRotation.SLOT_POOLS) {
      const enabled = candidates.filter(
        (locationId) =>
          locationId < locations.length &&
          locations[locationId].enabled &&
          locations[locationId].game_mode === gameMode
      )
      if (!enabled.length) {
        throw new EventError('Slot sem mapa habilitado: ' + gameMode)
      }
      pools.push([gameMode, enabled])
    }
    return pools
  }

  static enabled_modifiers () {
    const configured = Config.GetValue().MapModifiers || {}
    if (typeof configured !== 'object' || configured === null || Array.isArray(configured)) {
      throw new EventError('MapModifiers deve ser um objeto de booleanos')
    }
    const result = []
    for (let modifier = 1; modifier < 6; modifier++) {
      const enabled = configured[String(modifier)] !== undefined
        ? configured[String(modifier)]
        : (configured[modifier] !== undefined ? configured[modifier] : false)
      if (typeof enabled !== 'boolean') {
        throw new EventError(
          `MapModifiers.${modifier} deve ser true ou false`
        )
      }
      if (enabled) {
        result.push(modifier)
      }
    }
    return result
  }

  static events (now = null) {
    const moment = EventRotation._now(now)
    const day = dayOrdinal(moment.getFullYear(), moment.getMonth() + 1, moment.getDate())
    const modifiers = EventRotation.enabled_modifiers()
    const result = []
    let slot = 0
    for (const [gameMode, pool] of EventRotation.enabled_pools()) {
      slot += 1
      const mapId = pool[(day + slot - 1) % pool.length]
      result.push({
        slot,
        map_id: mapId,
        game_mode: gameMode,
        tokens: 10,
        modifier: modifiers.length ? modifiers[0] : 0,
        modifiers,
        date: localIsoDay(moment)
      })
    }
    return result
  }

  static battle_event (mapId, mapSlot = 0, now = null) {
    mapId = toInteger(mapId)
    mapSlot = toInteger(mapSlot)
    if (mapId === null || mapSlot === null) {
      return null
    }
    let moment
    if (typeof now === 'number') {
      moment = new Date(now * 1000)
    } else {
      moment = EventRotation._now(now)
    }
    const locations = EventRotation.locations()
    if (!(mapId >= 0 && mapId < locations.length) || !locations[mapId].enabled) {
      return null
    }
    if (mapSlot === 0) {
      return {
        slot: 0,
        map_id: mapId,
        game_mode: locations[mapId].game_mode,
        date: localIsoDay(moment)
      }
    }
    if (!(mapSlot >= 1 && mapSlot <= EventRotation.SLOT_POOLS.length)) {
      return null
    }
    const event = EventRotation.events(moment)[mapSlot - 1]
    if (event.map_id !== mapId) {
      return null
    }
    return event
  }

  static claimed_slots (player, now = null) {
    const moment = EventRotation._now(now)
    const progression = player.progression
    if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
      return new Set()
    }
    const claims = progression[EventRotation.CLAIMS_KEY] || {}
    if (typeof claims !== 'object' || claims === null || Array.isArray(claims)) {
      return new Set()
    }
    const values = claims[localIsoDay(moment)] || []
    if (!Array.isArray(values)) {
      return new Set()
    }
    const result = new Set()
    for (const value of values) {
      const parsed = toInteger(value)
      if (parsed !== null) {
        result.add(parsed)
      }
    }
    return result
  }

  static _stored_state (progression, event) {
    if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
      return 1
    }
    const states = progression[EventRotation.STATES_KEY] || {}
    if (typeof states !== 'object' || states === null || Array.isArray(states)) {
      return 1
    }
    const daily = states[event.date] || {}
    if (typeof daily !== 'object' || daily === null || Array.isArray(daily)) {
      return 1
    }
    const record = daily[String(event.slot)]
    if (typeof record !== 'object' || record === null || Array.isArray(record)) {
      return 1
    }
    if (
      record.mapID !== event.map_id ||
      record.gameMode !== event.game_mode ||
      record.modifier !== event.modifier ||
      !arraysEqual(record.modifiers, Array.from(event.modifiers)) ||
      record.tokens !== event.tokens
    ) {
      return 1
    }
    let state
    try {
      state = toInteger(record.state)
      if (state === null) {
        return 1
      }
    } catch (error) {
      return 1
    }
    return [1, 2, 3].includes(state) ? state : 1
  }

  static _store_state (progression, event, state, moment) {
    let states = progression[EventRotation.STATES_KEY] || {}
    states = (typeof states === 'object' && states !== null && !Array.isArray(states))
      ? structuredClone(states)
      : {}
    const cutoff = cutoffDate(moment, EventRotation.CLAIM_HISTORY_DAYS)
    states = Object.fromEntries(
      Object.entries(states).filter(
        ([key]) => EventRotation._claim_date_after_cutoff(key, cutoff)
      )
    )
    let daily = states[event.date] || {}
    daily = (typeof daily === 'object' && daily !== null && !Array.isArray(daily))
      ? structuredClone(daily)
      : {}
    daily[String(event.slot)] = {
      state: Math.trunc(state),
      mapID: event.map_id,
      gameMode: event.game_mode,
      modifier: event.modifier,
      modifiers: Array.from(event.modifiers),
      tokens: event.tokens
    }
    states[event.date] = daily
    progression[EventRotation.STATES_KEY] = states
  }

  static snapshot (player, now = null) {
    const moment = EventRotation._now(now)
    const claimed = EventRotation.claimed_slots(player, moment)
    const progression = player.progression || {}
    const result = []
    for (const event of EventRotation.events(moment)) {
      const item = structuredClone(event)
      item.claimed = claimed.has(item.slot)
      item.status = EventRotation._stored_state(progression, item)
      result.push(item)
    }
    return result
  }

  static resolve_slot (player, slot, now = null) {
    slot = toInteger(slot)
    if (slot === null) {
      throw new EventError('Slot de evento inválido')
    }
    const events = EventRotation.snapshot(player, now)
    if (slot === 0) {
      return structuredClone(events[0])
    }
    for (const event of events) {
      if (event.slot === slot) {
        return event
      }
    }
    throw new EventError('Slot de evento inexistente')
  }

  static seconds_to_next_day (now = null) {
    const moment = EventRotation._now(now)
    const following = new Date(
      moment.getFullYear(), moment.getMonth(), moment.getDate() + 1, 0, 0, 0, 0
    )
    return Math.max(0, Math.trunc((following.getTime() - moment.getTime()) / 1000))
  }

  static legacy_events (player = null, now = null) {
    const events = player !== null ? EventRotation.snapshot(player, now) : EventRotation.events(now)
    const result = {}
    for (const event of events) {
      let collected = []
      if (event.claimed && player !== null) {
        collected = [player.low_id !== undefined ? player.low_id : 0]
      }
      result[String(event.slot - 1)] = {
        ID: event.map_id,
        Modifier: event.modifier,
        Tokens: event.tokens,
        Collected: collected
      }
    }
    return result
  }

  static _claim_locked (connection, lowId, event, moment, progression, balance) {
    const dateKey = localIsoDay(moment)
    const cutoff = cutoffDate(moment, EventRotation.CLAIM_HISTORY_DAYS)
    let claims = progression[EventRotation.CLAIMS_KEY] || {}
    if (typeof claims !== 'object' || claims === null || Array.isArray(claims)) {
      claims = {}
    }
    claims = Object.fromEntries(
      Object.entries(claims).filter(
        ([key]) => EventRotation._claim_date_after_cutoff(key, cutoff)
      )
    )
    let current = claims[dateKey] || []
    if (!Array.isArray(current)) {
      current = []
    }
    current = new Set(
      current
        .filter((value) => /^-?\d+$/.test(String(value)))
        .map((value) => Math.trunc(Number(value)))
    )
    progression[EventRotation.CLAIMS_KEY] = claims
    if (current.has(event.slot)) {
      return [false, balance, 0]
    }
    current.add(event.slot)
    claims[dateKey] = Array.from(current).sort((a, b) => a - b)
    const granted = Math.min(Math.max(0, Math.trunc(event.tokens)), Math.max(0, EventRotation.TOKEN_WALLET_CAP - balance))
    balance += granted
    const info = connection.prepare(
      'UPDATE players SET brawlBoxes = ? WHERE lowID = ?'
    ).run(balance, lowId)
    if (info.changes !== 1) {
      throw new EventError('Falha ao persistir a coleta')
    }
    return [true, balance, granted]
  }

  static _persist (player, slot, now, state) {
    const moment = EventRotation._now(now)
    const event = EventRotation.resolve_slot(player, slot, moment)
    if (state !== null && ![1, 2, 3].includes(state)) {
      throw new EventError('Estado de evento inválido')
    }
    const lowId = toInteger(player.low_id || 0) || 0
    if (lowId <= 0) {
      throw new EventError('Conta inválida para atualizar o evento')
    }
    let progression
    let balance
    let claimed = false
    let granted = 0
    DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const row = connection.prepare(
        'SELECT brawlBoxes FROM players WHERE lowID = ?'
      ).get(lowId)
      if (row === undefined) {
        throw new EventError('Conta não encontrada para atualizar o evento')
      }
      progression = DataBase._read_state(connection, lowId, 'progression')
      if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
        progression = {}
      } else {
        progression = structuredClone(progression)
      }
      if (state !== null) {
        EventRotation._store_state(progression, event, state, moment)
      }
      balance = toInteger(row.brawlBoxes || 0) || 0
      if (state === null || state === 2) {
        ;[claimed, balance, granted] = EventRotation._claim_locked(
          connection, lowId, event, moment, progression, balance
        )
      }
      DataBase._write_state(connection, lowId, 'progression', progression)
    }, true)
    player.brawl_boxes = balance
    player.progression = progression
    event.claimed = EventRotation.claimed_slots(player, moment).has(event.slot)
    event.status = EventRotation._stored_state(progression, event)
    const result = {
      claimed,
      event,
      balance,
      granted
    }
    if (state !== null) {
      result.state = state
    }
    return result
  }

  static claim (player, slot, now = null) {
    return EventRotation._persist(player, slot, now, null)
  }

  static apply_state (player, slot, state, now = null) {
    slot = toInteger(slot)
    state = toInteger(state)
    if (slot === null || state === null) {
      throw new EventError('Slot ou estado de evento inválido')
    }
    if (slot < 1) {
      throw new EventError('Slot de evento inexistente')
    }
    return EventRotation._persist(player, slot, now, state)
  }

  static _claim_date_after_cutoff (value, cutoff) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value))
    if (!match) {
      return false
    }
    const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
    if (
      date.getFullYear() !== Number(match[1]) ||
      date.getMonth() !== Number(match[2]) - 1 ||
      date.getDate() !== Number(match[3])
    ) {
      return false
    }
    return date.getTime() >= cutoff.getTime()
  }
}

function arraysEqual (a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
    return false
  }
  return a.every((value, index) => value === b[index])
}

function cutoffDate (moment, days) {
  return new Date(
    moment.getFullYear(), moment.getMonth(), moment.getDate() - days
  )
}

module.exports = { EventRotation, EventError }
