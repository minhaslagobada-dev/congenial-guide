'use strict'

const { BattleRewardsManager } = require('./BattleRewardsManager')

function apply_battle_result_rewards (player, gameMode, battleId = null, now = null) {
  const baseResult = Math.trunc(player.result !== undefined ? player.result : 16) || 0
  const battleResult = Math.trunc(player.battle_result || 0)
  const brawler = Math.trunc(player.brawler_id || 0)
  const fields = {
    Practice: Boolean(player.authoritativeBattleResult && player.authoritativeBattleResult.practice),
    GameMode: gameMode,
    MapID: Math.trunc(player.map_id || 0),
    MapSlot: Math.trunc(player.locationID || 0),
    Rank: Math.trunc(player.rank !== undefined ? player.rank : 1) || 0,
    Victory: battleResult,
    result: baseResult,
    Heroes: [{
      IsPlayer: true,
      Brawler: { ID: [16, brawler] }
    }]
  }
  const authoritative = player.authoritativeBattleResult
  if (authoritative && Number.isInteger(authoritative.mvp_index)) fields.IsMvp = authoritative.mvp_index === authoritative.local_index
  const rewards = new BattleRewardsManager(player).process_rewards(fields, battleId, now)
  return {
    brawler_trophies: rewards.brawler_trophies,
    brawler_trophies_for_rank: rewards.brawler_trophies_for_rank,
    token: rewards.tokens_gain,
    gainedtrophies: rewards.trophies_gain,
    trophies: rewards.trophies_gain,
    doubledtokens: rewards.doubled_tokens,
    remainingtokens: rewards.remaining_tokens,
    totaltokens: rewards.total_tokens,
    experience: rewards.experience,
    mvpexperience: rewards.star_player_exp,
    result: rewards.result,
    starplayer: rewards.starplayer,
    rewards
  }
}

module.exports = { apply_battle_result_rewards }
