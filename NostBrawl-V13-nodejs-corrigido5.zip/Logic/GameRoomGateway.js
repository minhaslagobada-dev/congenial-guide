'use strict'

const TeamGameroomDataMessage = require('../Packets/Messages/Server/Gameroom/TeamGameroomDataMessage')
const TeamGameStartingMessage = require('../Packets/Messages/Server/Gameroom/TeamGameStartingMessage')
const TeamLeaveOkMessage = require('../Packets/Messages/Server/Gameroom/TeamLeaveOkMessage')
const TeamLeftMessage = require('../Packets/Messages/Server/Gameroom/TeamLeftMessage')
const TeamStreamMessage = require('../Packets/Messages/Server/Gameroom/TeamStreamMessage')

class GameRoomGateway {
  static _stream_entries (room, lowId) {
    const { GameRoomService } = require('./GameRoomService')
    return GameRoomService.stream_for(room, Math.trunc(lowId))
  }

  static deliver_data (client, player, room) {
    if (room !== null && room !== undefined) {
      new TeamGameroomDataMessage(client, player, room).send()
    }
  }

  static send_data_to (lowId, player, room) {
    if (room === null || room === undefined) {
      return false
    }
    return new TeamGameroomDataMessage(
      null, player, room
    ).sendWithLowID(Math.trunc(lowId))
  }

  static broadcast_data (player, room, client = null) {
    if (room === null || room === undefined) {
      return
    }
    const currentId = Math.trunc(player !== null && player !== undefined ? (player.low_id || 0) : 0)
    if (client !== null && client !== undefined) {
      new TeamGameroomDataMessage(client, player, room).send()
    }
    for (const member of room.members) {
      const lowId = Math.trunc(member.low_id)
      if (client !== null && client !== undefined && lowId === currentId) {
        continue
      }
      new TeamGameroomDataMessage(null, player, room).sendWithLowID(lowId)
    }
  }

  static broadcast_data_and_stream (player, room, client = null, streamFirst = false) {
    if (room === null || room === undefined) {
      return
    }
    const currentId = Math.trunc(player !== null && player !== undefined ? (player.low_id || 0) : 0)
    if (client !== null && client !== undefined) {
      if (streamFirst) {
        new TeamStreamMessage(
          client, player, room,
          GameRoomGateway._stream_entries(room, currentId)
        ).send()
        new TeamGameroomDataMessage(client, player, room).send()
      } else {
        new TeamGameroomDataMessage(client, player, room).send()
        new TeamStreamMessage(
          client, player, room,
          GameRoomGateway._stream_entries(room, currentId)
        ).send()
      }
    }
    for (const member of room.members) {
      const lowId = Math.trunc(member.low_id)
      if (client !== null && client !== undefined && lowId === currentId) {
        continue
      }
      const entries = GameRoomGateway._stream_entries(room, lowId)
      if (streamFirst) {
        new TeamStreamMessage(null, player, room, entries).sendWithLowID(lowId)
        new TeamGameroomDataMessage(null, player, room).sendWithLowID(lowId)
      } else {
        new TeamGameroomDataMessage(null, player, room).sendWithLowID(lowId)
        new TeamStreamMessage(null, player, room, entries).sendWithLowID(lowId)
      }
    }
  }

  static send_starting (player, room) {
    if (room === null || room === undefined) {
      return 0
    }
    let delivered = 0
    for (const member of room.members) {
      const message = new TeamGameStartingMessage(null, player, room)
      if (message.sendWithLowID(Math.trunc(member.low_id))) {
        delivered += 1
      }
    }
    return delivered
  }

  static send_left (player, lowId, reason = 0, client = null) {
    const message = new TeamLeftMessage(client, player, reason)
    if (client !== null && client !== undefined) {
      message.send()
    } else {
      message.sendWithLowID(lowId)
    }
  }

  static send_leave_ok (player, lowId) {
    new TeamLeaveOkMessage(null, player).sendWithLowID(lowId)
  }
}

module.exports = { GameRoomGateway }
module.exports.default = GameRoomGateway
