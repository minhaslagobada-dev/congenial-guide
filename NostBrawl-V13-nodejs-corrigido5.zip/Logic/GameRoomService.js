'use strict'

const DataBase = require('../Database/DatabaseManager')
const Skins = require('../Files/CsvLogic/Skins')
const { EventRotation } = require('./EventRotation')
const { ValueError } = require('../Utils/Errors')

function deepCopy (value) {
  if (value === null || value === undefined) return value
  return JSON.parse(JSON.stringify(value))
}

class GameRoomFullError extends ValueError {
  constructor (message) {
    super(message)
    this.name = 'GameRoomFullError'
  }
}

class GameRoomInviteError extends ValueError {
  static get NO_FRIEND () { return 24 }
  static get REJECTED () { return 26 }
  static get BLOCKED () { return 27 }
  static get OFFLINE () { return 28 }
  static get ALREADY_IN_TEAM () { return 29 }

  constructor (code) {
    super(`Convite de equipe recusado (${Math.trunc(code)})`)
    this.name = 'GameRoomInviteError'
    this.code = Math.trunc(code)
  }
}

class GameRoomService {
  static get INVITE_MUTE_SECONDS () { return 600 }
  static get INVITE_MUTES_KEY () { return 'mutedTeamInviters' }
  static get STREAM_LIMIT () { return 64 }
  static get INVITE_PENDING () { return 1 }
  static get INVITE_DECLINED () { return 2 }
  static get INVITE_OFFLINE () { return 3 }
  static get TEAM_PRESENCE () { return 3 }
  static get HOME_PRESENCE () { return 2 }
  static get DISBAND_REASON () { return 3 }
  // The v13 client shows a team code as 'X' + base31(roomId * 256 + high)
  // (TeamCode, client converter 0x4e2418). Room ids in [117, 3607] with
  // high 0 give exactly four code characters after the client's fixed 'X'.
  static get CODE_ROOM_MIN () { return 117 }
  static get CODE_ROOM_MAX () { return 3607 }
  static get OFFLINE_STATUS () { return 0 }
  static get DEFAULT_OFFLINE_EXPIRY_SECONDS () { return 600 }

  static _allocate_room_id () {
    const min = GameRoomService.CODE_ROOM_MIN
    const span = GameRoomService.CODE_ROOM_MAX - min + 1
    const entries = GameRoomService._entries
    const crypto = require('node:crypto')
    for (let attempt = 0; attempt < 32; attempt++) {
      const candidate = min + crypto.randomInt(span)
      if (!(candidate in entries)) return candidate
    }
    const start = crypto.randomInt(span)
    for (let offset = 0; offset < span; offset++) {
      const candidate = min + ((start + offset) % span)
      if (!(candidate in entries)) return candidate
    }
    // More than 3491 simultaneous rooms: keep working with longer codes.
    let candidate = Math.max(GameRoomService.CODE_ROOM_MAX + 1, Math.trunc(GameRoomService._next_room_id))
    while (candidate in entries) candidate += 1
    GameRoomService._next_room_id = candidate + 1
    return candidate
  }

  static _offline_expiry_ms () {
    let seconds = GameRoomService.DEFAULT_OFFLINE_EXPIRY_SECONDS
    try {
      const settings = require('../Utils/Config').GetValue() || {}
      const team = settings.Team || {}
      const configured = Number(team.OfflineRoomExpirySeconds)
      if (Number.isFinite(configured) && configured >= 0) seconds = configured
    } catch (error) {}
    return Math.trunc(seconds * 1000)
  }

  static _is_offline (member) {
    return member !== null && member !== undefined && member._offline_since !== undefined && member._offline_since !== null
  }

  static _drop_room_timer (room) {
    if (room && room._expiry_timer) {
      clearTimeout(room._expiry_timer)
      room._expiry_timer = null
    }
  }

  // Every member closed the game: the room (code, members, host) is kept for
  // Team.OfflineRoomExpirySeconds, then retired like an explicit disband.
  static _schedule_expiry (room) {
    GameRoomService._drop_room_timer(room)
    if (!room.members.length || !room.members.every((member) => GameRoomService._is_offline(member))) return
    const roomId = Math.trunc(room.id)
    const timer = setTimeout(() => {
      GameRoomService._lock.run(() => {
        const current = GameRoomService._entries[roomId]
        if (current !== room) return
        room._expiry_timer = null
        if (!room.members.every((member) => GameRoomService._is_offline(member))) return
        delete GameRoomService._entries[roomId]
        for (const member of room.members) {
          try { GameRoomService._clear_room_id(member.low_id) } catch (error) {}
        }
        room.members = []
        room.stream = []
      })
    }, GameRoomService._offline_expiry_ms())
    if (timer.unref) timer.unref()
    room._expiry_timer = timer
  }

  // Brawler that the member will actually play: the live session value when
  // the member is online (it is what matchmaking uses), else the room copy.
  static _effective_brawler (member) {
    const player = member._player
    if (!GameRoomService._is_offline(member) && player && player.brawler_id !== undefined && player.brawler_id !== null) {
      return Math.trunc(Number(player.brawler_id) || 0)
    }
    return Math.trunc(Number(member.brawler_id) || 0)
  }

  static _duplicate_of (room, member) {
    const brawler = GameRoomService._effective_brawler(member)
    return room.members.find((other) => other !== member &&
      Math.trunc(other.team || 0) === Math.trunc(member.team || 0) &&
      GameRoomService._effective_brawler(other) === brawler) || null
  }

  // True when another member of the same side uses the player's brawler.
  static has_duplicate_brawler (player) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) return false
      const member = GameRoomService._member(room, lowId)
      if (member === null) return false
      member._player = player
      return GameRoomService._duplicate_of(room, member) !== null
    })
  }

  // Server-side guard used before any team search: no two members of the
  // same side may enter a match with the same brawler.
  static duplicate_brawler_members (room) {
    const internal = GameRoomService._room(room && room.id)
    if (internal === null) return []
    return internal.members.filter((member) => !GameRoomService._is_offline(member) && GameRoomService._duplicate_of(internal, member) !== null)
  }

  static _now () {
    return Math.floor(Date.now() / 1000)
  }

  static init () {
    const lock = GameRoomService._lock
    return lock.run(() => {
      GameRoomService._entries = {}
      GameRoomService._next_room_id = 1
      GameRoomService._next_request_key = 1
    })
  }

  static count () {
    return Object.keys(GameRoomService._entries).length
  }

  static _account_id (player) {
    let lowId = 0
    try {
      lowId = Math.trunc(Number(player.low_id ?? 0)) || 0
    } catch (error) {
      lowId = 0
    }
    if (lowId <= 0) {
      throw new ValueError('Conta inválida para GameRoom')
    }
    return lowId
  }

  static _mapping_value (mapping, key, defaultValue = 0) {
    if (typeof mapping !== 'object' || mapping === null) {
      return defaultValue
    }
    const raw = mapping[String(key)] !== undefined ? mapping[String(key)] : mapping[key]
    try {
      const value = Math.trunc(Number(raw || 0))
      return Number.isNaN(value) ? defaultValue : value
    } catch (error) {
      return defaultValue
    }
  }

  static _capacity (mapId) {
    let location = null
    try {
      location = EventRotation.locations()[Math.trunc(Number(mapId))]
    } catch (error) {
      return 6
    }
    if (!location) {
      return 6
    }
    if (location.game_mode === 'Tutorial') return 1
    if (location.game_mode === 'BattleRoyale' || location.game_mode === 'BattleRoyaleTeam') {
      return 10
    }
    if (location.game_mode === 'Survival') {
      return 3
    }
    if (location.game_mode === 'Raid') {
      return 3
    }
    return 6
  }

  static _location (mapId) {
    mapId = Math.trunc(Number(mapId))
    if (Number.isNaN(mapId)) {
      throw new ValueError('Mapa inválido')
    }
    const locations = EventRotation.locations()
    if (!(mapId >= 0 && mapId < locations.length) || !locations[mapId].enabled) {
      throw new ValueError('Mapa não habilitado')
    }
    return locations[mapId]
  }

  static _map_for_create (player, slot, requestedMap) {
    slot = Math.trunc(Number(slot))
    requestedMap = Math.trunc(Number(requestedMap))
    if (Number.isNaN(slot) || Number.isNaN(requestedMap)) {
      throw new ValueError('Slot ou mapa inválido')
    }
    if (slot >= 1 && slot <= EventRotation.SLOT_POOLS.length) {
      const event = EventRotation.resolve_slot(player, slot)
      return [Math.trunc(event.map_id), slot]
    }
    if (requestedMap === -64) {
      const event = EventRotation.resolve_slot(player, 0)
      return [Math.trunc(event.map_id), 0]
    }
    return [Math.trunc(GameRoomService._location(requestedMap).id), 0]
  }

  static _selected_skin (player, brawler) {
    const selected = player.brawlers_skins
    const stored = typeof selected === 'object' && selected !== null &&
      (String(brawler) in selected || brawler in selected)
    let skin
    if (stored) {
      skin = GameRoomService._mapping_value(selected, brawler, 0)
    } else if (Math.trunc(player.brawler_id || 0) === brawler) {
      skin = Math.trunc(player.skin_id || 0)
    } else {
      skin = 0
    }
    return Skins.resolve_skin(brawler, skin)
  }

  static _new_member (player, owner) {
    const lowId = GameRoomService._account_id(player)
    const brawler = Math.trunc(player.brawler_id || 0)
    return {
      low_id: lowId,
      high_id: Math.trunc(player.high_id || 0),
      host: Boolean(owner),
      ready: false,
      team: 0,
      status: 3,
      brawler_id: brawler,
      skin_id: GameRoomService._selected_skin(player, brawler),
      trophies: GameRoomService._mapping_value(player.brawlers_trophies, brawler),
      highest_trophies: GameRoomService._mapping_value(player.brawlers_trophies, brawler),
      power_level: GameRoomService._mapping_value(player.Brawler_level, brawler, 0),
      name: String(player.name !== undefined && player.name !== null ? player.name : ''),
      profile_icon: Math.trunc(player.profile_icon || 0),
      name_color: Math.trunc(player.name_color || 0),
      stream_from: 0,
      _player: player
    }
  }

  static _public_member (member) {
    const result = {}
    for (const [key, value] of Object.entries(member)) {
      if (!key.startsWith('_') && key !== 'stream_from') {
        result[key] = deepCopy(value)
      }
    }
    return result
  }

  static _public_invite (invite) {
    return {
      room_id: Math.trunc(invite.room_id),
      sender_id: Math.trunc(invite.sender_id),
      recipient_id: Math.trunc(invite.recipient_id),
      name: String(invite.name),
      invite_type: Math.trunc(invite.invite_type),
      status: Math.trunc(invite.status !== undefined ? invite.status : GameRoomService.INVITE_PENDING),
      entry: deepCopy(invite.entry)
    }
  }

  static _public_request (request) {
    return {
      key: Math.trunc(request.key),
      recipient_id: Math.trunc(request.recipient_id),
      requester_id: Math.trunc(request.requester_id),
      entry: deepCopy(request.entry)
    }
  }

  // Trophies and power shown above each brawler in TeamGameroomData (24124)
  // come from the server's live player, never from the copy taken when the
  // member joined or last changed brawler. That copy was what kept the menu
  // showing the pre-battle trophies until the brawler was selected again
  // (14354 was the only path that refreshed it).
  static _refresh_member_stats (member) {
    const player = member._player
    if (player === undefined || player === null) return
    const brawler = Math.trunc(member.brawler_id || 0)
    member.trophies = GameRoomService._mapping_value(player.brawlers_trophies, brawler)
    member.highest_trophies = GameRoomService._mapping_value(player.brawlers_trophies, brawler)
    member.power_level = GameRoomService._mapping_value(player.Brawler_level, brawler, 0)
  }

  static _snapshot (room) {
    if (room === null || room === undefined) {
      return null
    }
    for (const member of room.members) GameRoomService._refresh_member_stats(member)
    const members = room.members.map((member) => GameRoomService._public_member(member))
    const host = members.find((member) => member.host)
    const owner = host !== undefined ? host.low_id : 0
    return {
      id: Math.trunc(room.id),
      type: Math.trunc(room.type),
      map_id: Math.trunc(room.map_id),
      slot_index: Math.trunc(room.slot_index),
      map_slot: Math.trunc(room.map_slot !== undefined ? room.map_slot : 0),
      practice: Boolean(room.practice),
      advertise_band: Boolean(room.advertise_band !== undefined ? room.advertise_band : false),
      advertise_friends: Boolean(room.advertise_friends !== undefined ? room.advertise_friends : true),
      capacity: GameRoomService._capacity(room.map_id),
      owner_id: owner,
      player_count: members.length,
      members,
      invites: (room.invites || []).map((invite) => GameRoomService._public_invite(invite)),
      join_requests: (room.join_requests || []).map((item) => GameRoomService._public_request(item))
    }
  }

  static apply (fn) {
    return GameRoomService._lock.run(fn)
  }

  static _member (room, lowId) {
    return room.members.find((member) => member.low_id === Math.trunc(lowId)) || null
  }

  static _remove_member (room, lowId) {
    lowId = Math.trunc(lowId)
    const member = GameRoomService._member(room, lowId)
    if (member === null || member === undefined) {
      return false
    }
    room.members = room.members.filter((item) => item !== member)
    if (!room.members.length) {
      GameRoomService._drop_room_timer(room)
      const roomId = Math.trunc(room.id)
      if (roomId in GameRoomService._entries) {
        delete GameRoomService._entries[roomId]
      }
      return true
    }
    if (!room.members.some((item) => item.host)) {
      room.members[0].host = true
    }
    for (const item of room.members) {
      item.ready = false
    }
    GameRoomService._prune_stream(room)
    return true
  }

  static _prune_stream (room) {
    const members = room.members || []
    if (!members.length) {
      room.stream = []
      return
    }
    const floor = Math.min(...members.map((member) => Math.trunc(member.stream_from || 0)))
    if (floor > 0) {
      room.stream = room.stream.filter((entry) => Math.trunc(entry.id) > floor)
    }
    if (room.stream.length <= GameRoomService.STREAM_LIMIT) {
      return
    }
    const excess = room.stream.length - GameRoomService.STREAM_LIMIT
    const newFloor = Math.trunc(room.stream[excess].id) - 1
    room.stream = room.stream.slice(excess)
    for (const member of members) {
      if (Math.trunc(member.stream_from || 0) < newFloor) {
        member.stream_from = newFloor
      }
    }
  }

  static _session_player (sample, lowId) {
    const clients = sample && sample.ClientDict !== undefined ? sample.ClientDict : null
    if (typeof clients !== 'object' || clients === null) {
      return null
    }
    const entry = (clients.Clients || {})[String(Math.trunc(lowId))]
    if (!entry) {
      return null
    }
    const player = entry.Player
    if (!player || Math.trunc(player.low_id || 0) !== Math.trunc(lowId)) {
      return null
    }
    return player
  }

  static _member_for_join (request, requesterId) {
    let member = request.member !== undefined ? request.member : null
    const sample = request.player !== undefined && request.player !== null
      ? request.player
      : (member && member._player !== undefined ? member._player : null)
    const session = sample !== null ? GameRoomService._session_player(sample, requesterId) : null
    let player = session
    if (player === null && member !== null && member !== undefined) {
      player = member._player !== undefined ? member._player : null
    }
    if (player === null || player === undefined) {
      return null
    }
    request.player = player
    if (member === null || member === undefined) {
      member = GameRoomService._new_member(player, false)
      request.member = member
    }
    member._player = player
    return member
  }

  static _attach_member (room, member, event = 102) {
    member.stream_from = Math.trunc(room.entry_counter)
    room.members.push(member)
    GameRoomService._append_event(room, event, member)
    return member
  }

  static _drop_invites_of (room, lowId) {
    lowId = Math.trunc(lowId)
    const invites = room.invites || []
    const kept = invites.filter(
      (invite) => ![Math.trunc(invite.sender_id), Math.trunc(invite.recipient_id)].includes(lowId)
    )
    const removed = kept.length !== invites.length
    room.invites = kept
    return removed
  }

  static _purge_player_references (lowId) {
    lowId = Math.trunc(lowId)
    const affected = []
    for (const room of Object.values(GameRoomService._entries)) {
      let changed = GameRoomService._drop_invites_of(room, lowId)
      const requests = room.join_requests || []
      const pending = requests.filter((request) => Math.trunc(request.requester_id) === lowId)
      if (pending.length) {
        room.join_requests = requests.filter((request) => Math.trunc(request.requester_id) !== lowId)
        changed = true
      }
      if (changed) {
        affected.push(GameRoomService._snapshot(room))
      }
    }
    return affected
  }

  static stream_for (room, lowId) {
    if (room === null || room === undefined) {
      return []
    }
    const roomId = Math.trunc(typeof room === 'object' ? room.id : Number(room))
    return GameRoomService._lock.run(() => {
      const internal = GameRoomService._room(roomId)
      if (internal === null || internal === undefined) {
        return []
      }
      const member = lowId ? GameRoomService._member(internal, Math.trunc(lowId)) : null
      const after = member !== null && member !== undefined ? Math.trunc(member.stream_from || 0) : 0
      return deepCopy(internal.stream.filter((entry) => Math.trunc(entry.id) > after))
    })
  }

  static _room (roomId) {
    try {
      const room = GameRoomService._entries[Math.trunc(Number(roomId))]
      return room !== undefined ? room : null
    } catch (error) {
      return null
    }
  }

  static _room_for_player (player) {
    const lowId = GameRoomService._account_id(player)
    let roomId = 0
    try {
      roomId = Math.trunc(player.room_id || 0)
    } catch (error) {
      roomId = 0
    }
    const room = roomId > 0 ? GameRoomService._room(roomId) : null
    if (room !== null && GameRoomService._member(room, lowId) !== null) {
      return room
    }
    for (const candidate of Object.values(GameRoomService._entries)) {
      if (GameRoomService._member(candidate, lowId) !== null) {
        return candidate
      }
    }
    return null
  }

  static _set_room_id (player, roomId) {
    const lowId = GameRoomService._account_id(player)
    roomId = Math.trunc(roomId)
    const previous = Math.trunc(player.room_id || 0)
    const token = player.token
    if (previous !== roomId && token !== null && token !== undefined && token !== '' && token !== 'None') {
      if (!DataBase._update_value('lowID', lowId, 'roomID', roomId)) {
        throw new ValueError('Conta não encontrada ao atualizar equipe')
      }
    }
    player.room_id = roomId
  }

  static _bind_player (player, room) {
    GameRoomService._set_room_id(player, room !== null && room !== undefined ? Math.trunc(room.id) : 0)
    if (room !== null && room !== undefined) {
      player.map_id = Math.trunc(room.map_id)
      player.slot_index = Math.trunc(room.slot_index)
    }
  }

  static _clear_room_id (lowId) {
    if (!DataBase._update_value('lowID', Math.trunc(lowId), 'roomID', 0)) {
      throw new ValueError('Conta não encontrada ao sair da equipe')
    }
  }

  static sync_presence (player, status) {
    const PresenceService = require('./PresenceService')
    if (player === null || player === undefined) {
      return false
    }
    if (!PresenceService.set_status(player, Math.trunc(status))) {
      return false
    }
    PresenceService.publish(player)
    return true
  }

  static _bind_room_members (room, mapId, slotIndex) {
    const participants = room.members
      .map((member) => (member._player !== undefined ? member._player : null))
      .filter((participant) => participant !== null)
    const roomId = Math.trunc(room.id)
    mapId = Math.trunc(mapId)
    slotIndex = Math.trunc(slotIndex)
    const updates = []
    for (const participant of participants) {
      const lowId = GameRoomService._account_id(participant)
      const previous = Math.trunc(participant.room_id || 0)
      const token = participant.token
      if (previous !== roomId && token !== null && token !== undefined && token !== '' && token !== 'None') {
        updates.push(lowId)
      }
    }
    if (updates.length) {
      DataBase._connection((connection) => {
        connection.exec('BEGIN IMMEDIATE')
        for (const lowId of updates) {
          const info = connection.prepare('UPDATE players SET roomID = ? WHERE lowID = ?').run(roomId, lowId)
          if (info.changes !== 1) {
            throw new ValueError('Conta não encontrada ao atualizar equipe')
          }
        }
      }, true)
    }
    for (const participant of participants) {
      participant.room_id = roomId
      participant.map_id = mapId
      participant.slot_index = slotIndex
    }
  }

  static _append_event (room, event, actor, target = null, swapNames = false) {
    target = target === null || target === undefined ? actor : target
    room.entry_counter += 1
    const entry = {
      kind: 4,
      event: Math.trunc(event),
      id: Math.trunc(room.entry_counter),
      room_id: Math.trunc(room.id),
      player_id: Math.trunc(actor.low_id),
      player_name: String(swapNames ? target.name : actor.name),
      player_role: 0,
      target_id: Math.trunc(target.low_id),
      target_name: String(swapNames ? actor.name : target.name),
      created_at: Math.floor(Date.now() / 1000)
    }
    room.stream.push(entry)
    GameRoomService._prune_stream(room)
    return entry
  }

  static get (roomId) {
    return GameRoomService._lock.run(() => GameRoomService._snapshot(GameRoomService._room(roomId)))
  }

  static get_room_id (roomId) {
    return GameRoomService.get(roomId)
  }

  static get_rooms () {
    return GameRoomService._lock.run(() =>
      Object.values(GameRoomService._entries).map((room) => GameRoomService._snapshot(room))
    )
  }

  static for_player (player) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        GameRoomService._bind_player(player, null)
        return null
      }
      const member = GameRoomService._member(room, lowId)
      GameRoomService._bind_player(player, room)
      if (member !== null && member !== undefined) {
        member._player = player
      }
      return GameRoomService._snapshot(room)
    })
  }

  static clear_offline_invites (player, clients = null) {
    const lowId = GameRoomService._account_id(player)
    const registry = clients !== null ? clients : (player.ClientDict !== undefined ? player.ClientDict : null)
    const removed = []
    for (const room of Object.values(GameRoomService._entries)) {
      const invites = room.invites || []
      const doomed = invites.filter(
        (invite) => Math.trunc(invite.recipient_id) === lowId &&
          Math.trunc(invite.status !== undefined ? invite.status : GameRoomService.INVITE_PENDING) === GameRoomService.INVITE_OFFLINE
      )
      if (!doomed.length) {
        continue
      }
      room.invites = invites.filter((invite) => !doomed.includes(invite))
      removed.push(GameRoomService._snapshot(room))
    }
    if (registry !== null && registry !== undefined) {
      for (const snapshot of removed) {
        GameRoomService._notify_room(snapshot)
      }
    }
    return removed
  }

  static _notify_room (snapshot) {
    const { GameRoomGateway } = require('./GameRoomGateway')
    if (snapshot === null || snapshot === undefined) {
      return
    }
    GameRoomGateway.broadcast_data(null, snapshot)
  }

  // Login of an account that is still a member of a room (it closed the game
  // or lost the connection): it returns to the same room, same code and host
  // flag. Ready is never restored; the brawler is re-read from the account.
  static resume (player) {
    const lowId = GameRoomService._account_id(player)
    const room = GameRoomService._lock.run(() => {
      const internal = GameRoomService._room_for_player(player)
      if (internal === null) {
        GameRoomService._bind_player(player, null)
        return null
      }
      const member = GameRoomService._member(internal, lowId)
      GameRoomService._bind_player(player, internal)
      member._player = player
      member._offline_since = null
      member.ready = false
      member.status = internal.battle_started ? member.status : 3
      if (member.status === GameRoomService.OFFLINE_STATUS) member.status = 3
      const brawler = Math.trunc(player.brawler_id || 0)
      member.brawler_id = brawler
      member.skin_id = GameRoomService._selected_skin(player, brawler)
      member.trophies = GameRoomService._mapping_value(player.brawlers_trophies, brawler)
      member.highest_trophies = GameRoomService._mapping_value(player.brawlers_trophies, brawler)
      member.power_level = GameRoomService._mapping_value(player.Brawler_level, brawler, 0)
      member.name = String(player.name !== undefined && player.name !== null ? player.name : member.name)
      GameRoomService._drop_room_timer(internal)
      return GameRoomService._snapshot(internal)
    })
    if (room !== null) {
      GameRoomService.sync_presence(player, GameRoomService.TEAM_PRESENCE)
    }
    return room
  }

  // A closed game / lost connection is NOT a leave: the member stays in the
  // room as OFFLINE (status 0), un-ready, and the room keeps its id (code),
  // host and members. Only an explicit leave/kick/disband removes it, or the
  // offline expiry once every member is offline.
  static disconnect (player) {
    let result = { room: null, departed: false, disbanded: [], host: false, offline: false }
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room !== null) {
        const member = GameRoomService._member(room, lowId)
        if (member !== null && member._player === player) {
          member.ready = false
          member.status = GameRoomService.OFFLINE_STATUS
          member._offline_since = GameRoomService._now()
          member._player = null
          for (const item of room.members) item.ready = false
          result = { room: GameRoomService._snapshot(room), departed: false, disbanded: [], host: Boolean(member.host), offline: true }
          GameRoomService._schedule_expiry(room)
        }
      }
      GameRoomService._purge_player_references(lowId)
      return result
    })
  }

  static create_transition (player, slot = 0, requestedMap = 0, roomType = 0, practice = false) {
    const lowId = GameRoomService._account_id(player)
    const [mapId, resolvedSlot] = GameRoomService._map_for_create(player, slot, requestedMap)
    return GameRoomService._lock.run(() => {
      const current = GameRoomService._room_for_player(player)
      const roomId = GameRoomService._allocate_room_id()
      const room = {
        id: roomId,
        type: Math.trunc(roomType),
        practice: Boolean(practice),
        advertise_band: false,
        advertise_friends: true,
        map_id: mapId,
        slot_index: Math.trunc(resolvedSlot),
        map_slot: Math.trunc(resolvedSlot),
        members: [GameRoomService._new_member(player, true)],
        invites: [],
        join_requests: [],
        stream: [],
        entry_counter: 0
      }
      GameRoomService._append_event(room, 101, room.members[0])
      GameRoomService._bind_player(player, room)
      let previous = null
      if (current !== null) {
        const previousMember = GameRoomService._member(current, lowId)
        GameRoomService._append_event(current, 103, previousMember)
        GameRoomService._remove_member(current, lowId)
        if (current.members.length) {
          previous = GameRoomService._snapshot(current)
        }
      }
      GameRoomService._entries[roomId] = room
      return [GameRoomService._snapshot(room), previous, current !== null]
    })
  }

  static create (player, slot = 0, requestedMap = 0, roomType = 0, practice = false) {
    const [room, ,] = GameRoomService.create_transition(player, slot, requestedMap, roomType, practice)
    return room
  }

  static request_join_transition (player, roomId) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const target = GameRoomService._room(roomId)
      if (target === null) {
        return [null, null, false]
      }
      let previous = null
      let departed = false
      const current = GameRoomService._room_for_player(player)
      if (current !== null && current.id === target.id) {
        GameRoomService._bind_player(player, target)
        return [GameRoomService._snapshot(target), null, false]
      }
      if (target.members.length >= GameRoomService._capacity(target.map_id)) {
        throw new GameRoomFullError('Equipe cheia')
      }
      const member = GameRoomService._new_member(player, false)
      GameRoomService._bind_player(player, target)
      if (current !== null) {
        const previousMember = GameRoomService._member(current, lowId)
        GameRoomService._append_event(current, 103, previousMember)
        GameRoomService._remove_member(current, lowId)
        departed = true
        if (current.members.length) {
          previous = GameRoomService._snapshot(current)
        }
      }
      target.invites = (target.invites || []).filter(
        (invite) => Math.trunc(invite.recipient_id) !== lowId
      )
      GameRoomService._attach_member(target, member)
      return [GameRoomService._snapshot(target), previous, departed]
    })
  }

  static request_join (player, roomId) {
    const [room, ,] = GameRoomService.request_join_transition(player, roomId)
    return room
  }

  static join (player, roomId) {
    return GameRoomService.request_join(player, roomId)
  }

  static _find_request (lowId, key) {
    for (const room of Object.values(GameRoomService._entries)) {
      for (const item of room.join_requests || []) {
        if (Math.trunc(item.key) === key && Math.trunc(item.recipient_id) === lowId) {
          return [room, item]
        }
      }
    }
    return [null, null]
  }

  static _requests_from (player) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const affected = []
      for (const room of Object.values(GameRoomService._entries)) {
        const requests = room.join_requests || []
        const removed = requests.filter((item) => Math.trunc(item.requester_id) === lowId)
        if (!removed.length) {
          continue
        }
        room.join_requests = requests.filter((item) => Math.trunc(item.requester_id) !== lowId)
        affected.push([
          GameRoomService._snapshot(room),
          removed.map((item) => GameRoomService._public_request(item))
        ])
      }
      return affected
    })
  }

  static request_join_request (player, recipientId, roomId) {
    const lowId = GameRoomService._account_id(player)
    try {
      recipientId = Math.trunc(Number(recipientId))
      roomId = Math.trunc(Number(roomId))
    } catch (error) {
      return [null, null]
    }
    if (Number.isNaN(recipientId) || Number.isNaN(roomId)) {
      return [null, null]
    }
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room(roomId)
      if (room === null) {
        return [null, null]
      }
      if (GameRoomService._member(room, recipientId) === null) {
        return [null, null]
      }
      if (GameRoomService._member(room, lowId) !== null) {
        return [null, null]
      }
      let pending = (room.join_requests || []).filter((item) => Math.trunc(item.requester_id) !== lowId)
      if (room.members.length + (room.invites || []).length + pending.length >= GameRoomService._capacity(room.map_id)) {
        throw new GameRoomFullError('Equipe cheia')
      }
      const { FriendService } = require('./FriendService')
      const entry = DataBase._connection((connection) => {
        const progression = DataBase._read_state(connection, recipientId, 'progression')
        const mutes = progression[GameRoomService.INVITE_MUTES_KEY] || {}
        if (typeof mutes !== 'object' || mutes === null || Array.isArray(mutes)) {
          throw new ValueError('Silenciamentos de convites inválidos')
        }
        if (Math.trunc(mutes[String(lowId)] || 0) > GameRoomService._now()) {
          return null
        }
        return FriendService._entry(connection, recipientId, lowId)
      })
      if (entry === null || entry === undefined) {
        return [null, null]
      }
      pending = pending.filter((item) => Math.trunc(item.recipient_id) !== recipientId)
      const request = {
        player,
        key: Math.trunc(GameRoomService._next_request_key),
        room_id: Math.trunc(room.id),
        recipient_id: recipientId,
        requester_id: lowId,
        entry,
        member: GameRoomService._new_member(player, false)
      }
      GameRoomService._next_request_key += 1
      pending.push(request)
      room.join_requests = pending
      return [GameRoomService._snapshot(room), GameRoomService._public_request(request)]
    })
  }

  static cancel_join_requests (player) {
    return GameRoomService._requests_from(player)
  }

  static respond_join_request (player, key, accepted, muteRequester = false) {
    const lowId = GameRoomService._account_id(player)
    try {
      key = Math.trunc(Number(key))
    } catch (error) {
      return null
    }
    if (Number.isNaN(key)) {
      return null
    }
    accepted = Boolean(accepted)
    return GameRoomService._lock.run(() => {
      const [room, request] = GameRoomService._find_request(lowId, key)
      if (room === null) {
        return null
      }
      let mutes = null
      if (muteRequester) {
        mutes = GameRoomService._mute_inviter(player, Math.trunc(request.requester_id))
      }
      room.join_requests = room.join_requests.filter((item) => item !== request)
      const outcome = {
        room: null,
        previous: null,
        request: GameRoomService._public_request(request),
        accepted,
        joined: false,
        mutes
      }
      if (!accepted) {
        outcome.room = GameRoomService._snapshot(room)
        return outcome
      }
      const requesterId = Math.trunc(request.requester_id)
      const member = GameRoomService._member(room, requesterId)
      if (member === null) {
        if (room.members.length >= GameRoomService._capacity(room.map_id)) {
          room.join_requests.push(request)
          throw new GameRoomFullError('Equipe cheia')
        }
        let current = null
        for (const candidate of Object.values(GameRoomService._entries)) {
          if (candidate.id !== room.id && GameRoomService._member(candidate, requesterId) !== null) {
            current = candidate
            break
          }
        }
        const joinMember = GameRoomService._member_for_join(request, requesterId)
        if (joinMember === null) {
          outcome.room = GameRoomService._snapshot(room)
          return outcome
        }
        if (current !== null) {
          const previousMember = GameRoomService._member(current, requesterId)
          GameRoomService._append_event(current, 103, previousMember)
          GameRoomService._remove_member(current, requesterId)
          if (current.members.length) {
            outcome.previous = GameRoomService._snapshot(current)
          }
        }
        GameRoomService._attach_member(room, joinMember)
        if (!DataBase._update_value('lowID', requesterId, 'roomID', Math.trunc(room.id))) {
          room.members = room.members.filter((item) => item !== joinMember)
          room.stream.pop()
          room.join_requests.push(request)
          throw new ValueError('Conta não encontrada ao entrar na equipe')
        }
        const requester = joinMember._player !== undefined ? joinMember._player : null
        if (requester !== null) {
          requester.room_id = Math.trunc(room.id)
          requester.map_id = Math.trunc(room.map_id)
          requester.slot_index = Math.trunc(room.slot_index)
        }
        outcome.joined = true
      }
      outcome.room = GameRoomService._snapshot(room)
      return outcome
    })
  }

  static _exit_locked (player, room, member) {
    const lowId = GameRoomService._account_id(player)
    const result = { room: null, departed: false, disbanded: [], host: false }
    const host = Boolean(member.host)
    GameRoomService._bind_player(player, null)
    GameRoomService._append_event(room, 103, member)
    GameRoomService._drop_invites_of(room, lowId)
    if (host && room.members.length > 1) {
      const remaining = room.members.filter((item) => item !== member)
      room.members = room.members.filter((item) => item !== member)
      GameRoomService._drop_room_timer(room)
      const roomId = Math.trunc(room.id)
      if (roomId in GameRoomService._entries) {
        delete GameRoomService._entries[roomId]
      }
      for (const item of remaining) {
        const participant = item._player !== undefined ? item._player : null
        if (participant !== null) {
          GameRoomService._set_room_id(participant, 0)
        } else {
          GameRoomService._clear_room_id(item.low_id)
        }
        item.stream_from = 0
      }
      room.members = []
      room.stream = []
      result.departed = true
      result.host = true
      result.disbanded = remaining
      return result
    }
    GameRoomService._remove_member(room, lowId)
    result.departed = true
    result.host = host
    if (room.members.length) {
      result.room = GameRoomService._snapshot(room)
    }
    return result
  }

  static leave_transition (player) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      let result = { room: null, departed: false, disbanded: [], host: false }
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        GameRoomService._bind_player(player, null)
        GameRoomService._purge_player_references(lowId)
        return result
      }
      const member = GameRoomService._member(room, lowId)
      if (member === null) {
        GameRoomService._bind_player(player, null)
        GameRoomService._purge_player_references(lowId)
        return result
      }
      result = GameRoomService._exit_locked(player, room, member)
      GameRoomService._purge_player_references(lowId)
      return result
    })
  }

  static leave (player) {
    const result = GameRoomService.leave_transition(player)
    return [result.room, result.departed]
  }

  static kick_transition (player, targetId) {
    const result = { room: null, target_id: 0, target: null }
    GameRoomService._account_id(player)
    try {
      targetId = Math.trunc(Number(targetId))
    } catch (error) {
      return result
    }
    if (Number.isNaN(targetId)) {
      return result
    }
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return result
      }
      const actor = GameRoomService._member(room, Math.trunc(player.low_id))
      const target = GameRoomService._member(room, targetId)
      if (actor === null || !actor.host || target === null) {
        return result
      }
      const targetPlayer = target._player !== undefined ? target._player : null
      if (targetPlayer !== null) {
        GameRoomService._bind_player(targetPlayer, null)
      }
      GameRoomService._append_event(room, 104, actor, target, true)
      GameRoomService._remove_member(room, targetId)
      result.room = room.members.length ? GameRoomService._snapshot(room) : null
      result.target_id = targetId
      result.target = targetPlayer
      return result
    })
  }

  static kick (player, targetId) {
    const result = GameRoomService.kick_transition(player, targetId)
    return [result.room, result.target_id]
  }

  static set_ranked_location (player, mapId, slot) {
    try {
      mapId = Math.trunc(Number(mapId))
      slot = Math.trunc(Number(slot))
    } catch (error) {
      throw new ValueError('Mapa ou slot de evento inválido')
    }
    if (Number.isNaN(mapId) || Number.isNaN(slot)) {
      throw new ValueError('Mapa ou slot de evento inválido')
    }
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      const event = EventRotation.resolve_slot(player, slot)
      if (Math.trunc(event.slot) !== slot) {
        throw new Error('Slot de evento inexistente')
      }
      if (Math.trunc(event.map_id) !== mapId) {
        throw new ValueError('Mapa divergente para o slot do evento')
      }
      GameRoomService._bind_room_members(room, event.map_id, event.slot)
      room.slot_index = Math.trunc(event.slot)
      room.map_slot = Math.trunc(event.slot)
      room.map_id = Math.trunc(event.map_id)
      room.type = 0
      return GameRoomService._snapshot(room)
    })
  }

  static set_location (player, mapId) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      const location = GameRoomService._location(mapId)
      GameRoomService._bind_room_members(room, location.id, 0)
      room.map_id = Math.trunc(location.id)
      room.slot_index = 0
      room.map_slot = 0
      room.type = 1
      return GameRoomService._snapshot(room)
    })
  }

  static toggle_practice (player) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      room.practice = !room.practice
      return GameRoomService._snapshot(room)
    })
  }

  static toggle_advertise_band (player) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      room.advertise_band = !room.advertise_band
      return GameRoomService._snapshot(room)
    })
  }

  static set_ready (player, ready) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      const member = GameRoomService._member(room, lowId)
      if (member !== null) {
        member.ready = Boolean(ready)
      }
      return GameRoomService._snapshot(room)
    })
  }

  static begin_battle (player) {
    GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      // A room whose previous match ended while all of its members had
      // already gone home never saw end_battle(); that stale flag must not
      // keep the next match from resetting ready/status.
      if (room === null) {
        return null
      }
      room.battle_started = true
      const participants = []
      for (const member of room.members) {
        member.ready = false
        if (member.status !== 0) {
          member.status = 5
        }
        const participant = member._player !== undefined ? member._player : null
        if (participant !== null) {
          participants.push(participant)
        }
      }
      return [GameRoomService._snapshot(room), participants]
    })
  }

  // Battle -> lobby: snapshot with the rewards already committed (trophies
  // are read live by _snapshot), or null when the player has no room.
  static lobby_snapshot (player) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      return room ? GameRoomService._snapshot(room) : null
    })
  }

  static end_battle (player) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (!room) return null
      room.battle_started = false
      for (const member of room.members) {
        member.ready = false
        if (member.status !== 0) member.status = 2
      }
      return GameRoomService._snapshot(room)
    })
  }

  static set_status (player, status) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      const member = GameRoomService._member(room, lowId)
      if (member !== null) {
        member.status = Math.trunc(status)
        member._player = player
      }
      return GameRoomService._snapshot(room)
    })
  }

  static set_teams (player, targets, team) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null || !targets || !targets.length) {
        return null
      }
      const members = []
      for (const [highId, targetId] of targets) {
        const member = GameRoomService._member(room, Math.trunc(targetId))
        if (member !== null && Math.trunc(member.high_id) === Math.trunc(highId)) {
          members.push(member)
        }
      }
      if (!members.length) {
        return null
      }
      const side = Math.trunc(team) >= 3 ? 1 : 0
      for (const member of members) {
        member.team = side
      }
      return GameRoomService._snapshot(room)
    })
  }

  static set_member_settings (player, brawlerId = 0, skinId = 0) {
    const lowId = GameRoomService._account_id(player)
    const brawler = Math.trunc(brawlerId)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return null
      }
      const member = GameRoomService._member(room, lowId)
      if (member === null) {
        return GameRoomService._snapshot(room)
      }
      member._player = player
      member.brawler_id = brawler
      member.skin_id = Math.trunc(skinId)
      member.trophies = GameRoomService._mapping_value(player.brawlers_trophies, brawler)
      member.highest_trophies = GameRoomService._mapping_value(player.brawlers_trophies, brawler)
      member.power_level = GameRoomService._mapping_value(player.Brawler_level, brawler, 0)
      return GameRoomService._snapshot(room)
    })
  }

  static pending_invites (room) {
    return (room.invites || []).filter(
      (invite) => Math.trunc(invite.status !== undefined ? invite.status : GameRoomService.INVITE_PENDING) === GameRoomService.INVITE_PENDING
    )
  }

  static _room_for_account (lowId) {
    for (const room of Object.values(GameRoomService._entries)) {
      if (GameRoomService._member(room, Math.trunc(lowId)) !== null) {
        return room
      }
    }
    return null
  }

  static _invite_room (recipientId, senderId) {
    const found = []
    for (const room of Object.values(GameRoomService._entries)) {
      for (const invite of GameRoomService.pending_invites(room)) {
        if (Math.trunc(invite.recipient_id) !== Math.trunc(recipientId)) {
          continue
        }
        if (Math.trunc(invite.sender_id) !== Math.trunc(senderId)) {
          continue
        }
        found.push(room)
        break
      }
    }
    return found.length ? found[found.length - 1] : null
  }

  static _invite_of (room, recipientId, senderId) {
    for (const invite of GameRoomService.pending_invites(room)) {
      if (Math.trunc(invite.recipient_id) !== Math.trunc(recipientId)) {
        continue
      }
      if (Math.trunc(invite.sender_id) !== Math.trunc(senderId)) {
        continue
      }
      return invite
    }
    return null
  }

  static invite (player, recipientId, inviteType = 0) {
    const senderId = GameRoomService._account_id(player)
    recipientId = Math.trunc(recipientId)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null || recipientId === senderId) {
        return [null, null]
      }
      if (GameRoomService._member(room, recipientId) !== null) {
        throw new GameRoomInviteError(GameRoomInviteError.ALREADY_IN_TEAM)
      }
      if (GameRoomService.pending_invites(room).some(
        (invite) => Math.trunc(invite.recipient_id) === recipientId
      )) {
        return [null, null]
      }
      if (room.members.length + GameRoomService.pending_invites(room).length >= GameRoomService._capacity(room.map_id)) {
        throw new GameRoomFullError('Equipe cheia')
      }
      if (GameRoomService._room_for_account(recipientId) !== null) {
        throw new GameRoomInviteError(GameRoomInviteError.ALREADY_IN_TEAM)
      }
      const { FriendService } = require('./FriendService')
      const { accountName, entry } = DataBase._connection((connection) => {
        const account = connection.prepare('SELECT name, DoNotDistrub FROM players WHERE lowID = ?').get(recipientId)
        if (account === undefined) {
          throw new GameRoomInviteError(GameRoomInviteError.NO_FRIEND)
        }
        const progression = DataBase._read_state(connection, recipientId, 'progression')
        const mutes = progression[GameRoomService.INVITE_MUTES_KEY] || {}
        if (typeof mutes !== 'object' || mutes === null || Array.isArray(mutes)) {
          throw new ValueError('Silenciamentos de convites inválidos')
        }
        const until = Math.trunc(mutes[String(senderId)] || 0)
        if (Math.trunc(account.DoNotDistrub || 0) === 1 || until > GameRoomService._now()) {
          throw new GameRoomInviteError(GameRoomInviteError.BLOCKED)
        }
        const entry = FriendService._entry(connection, recipientId, senderId)
        return { accountName: String(account.name || ''), entry }
      })
      if (entry === null || entry === undefined) {
        throw new GameRoomInviteError(GameRoomInviteError.NO_FRIEND)
      }
      room.invites = (room.invites || []).filter(
        (invite) => Math.trunc(invite.recipient_id) !== recipientId
      )
      const invite = {
        room_id: Math.trunc(room.id),
        sender_id: senderId,
        recipient_id: recipientId,
        name: accountName,
        invite_type: Math.trunc(inviteType),
        status: GameRoomService.INVITE_PENDING,
        entry
      }
      room.invites.push(invite)
      return [GameRoomService._snapshot(room), GameRoomService._public_invite(invite)]
    })
  }

  static mark_invite (player, recipientId, status) {
    const senderId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return [null, null]
      }
      for (const invite of room.invites || []) {
        if (Math.trunc(invite.recipient_id) !== Math.trunc(recipientId)) {
          continue
        }
        if (Math.trunc(invite.sender_id) !== senderId) {
          continue
        }
        invite.status = Math.trunc(status)
        return [GameRoomService._snapshot(room), GameRoomService._public_invite(invite)]
      }
      return [null, null]
    })
  }

  static decline_invite_from (player, senderId, muteSender = false) {
    const lowId = GameRoomService._account_id(player)
    senderId = Math.trunc(senderId)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._invite_room(lowId, senderId)
      if (room === null) {
        return [null, null]
      }
      const invite = GameRoomService._invite_of(room, lowId, senderId)
      if (invite === null || invite === undefined) {
        return [null, null]
      }
      if (GameRoomService._member(room, senderId) === null) {
        room.invites = room.invites.filter((item) => item !== invite)
        return [null, null]
      }
      if (muteSender) {
        GameRoomService._mute_inviter(player, senderId)
      }
      invite.status = GameRoomService.INVITE_DECLINED
      return [GameRoomService._snapshot(room), GameRoomService._public_invite(invite)]
    })
  }

  static cancel_invite (player, highId, lowId) {
    const actorId = GameRoomService._account_id(player)
    try {
      highId = Math.trunc(Number(highId))
      lowId = Math.trunc(Number(lowId))
    } catch (error) {
      return [null, null]
    }
    if (Number.isNaN(highId) || Number.isNaN(lowId)) {
      return [null, null]
    }
    if (highId !== 0) {
      return [null, null]
    }
    return GameRoomService._lock.run(() => {
      let room = GameRoomService._room_for_player(player)
      if (room !== null) {
        for (const invite of Array.from(room.invites || [])) {
          if (Math.trunc(invite.recipient_id) !== lowId) {
            continue
          }
          if (Math.trunc(invite.sender_id) !== actorId) {
            continue
          }
          room.invites = room.invites.filter((item) => item !== invite)
          return [GameRoomService._snapshot(room), GameRoomService._public_invite(invite)]
        }
        return [null, null]
      }
      room = GameRoomService._invite_room(actorId, lowId)
      if (room === null) {
        return [null, null]
      }
      const invite = GameRoomService._invite_of(room, actorId, lowId)
      if (invite === null || invite === undefined) {
        return [null, null]
      }
      room.invites = room.invites.filter((item) => item !== invite)
      return [GameRoomService._snapshot(room), GameRoomService._public_invite(invite)]
    })
  }

  static accept_invite_from (player, senderId, muteSender = false) {
    const lowId = GameRoomService._account_id(player)
    senderId = Math.trunc(senderId)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._invite_room(lowId, senderId)
      if (room === null) {
        return [null, null]
      }
      return GameRoomService.accept_invite(player, Math.trunc(room.id), muteSender)
    })
  }

  static _mute_inviter_locked (connection, lowId, senderId) {
    const progression = DataBase._read_state(connection, lowId, 'progression')
    let mutes = progression[GameRoomService.INVITE_MUTES_KEY] || {}
    if (typeof mutes !== 'object' || mutes === null || Array.isArray(mutes)) {
      throw new ValueError('Silenciamentos de convites inválidos')
    }
    const now = GameRoomService._now()
    const pruned = {}
    for (const [key, value] of Object.entries(mutes)) {
      if (Math.trunc(value) > now) {
        pruned[key] = Math.trunc(value)
      }
    }
    mutes = pruned
    mutes[String(Math.trunc(senderId))] = now + GameRoomService.INVITE_MUTE_SECONDS
    progression[GameRoomService.INVITE_MUTES_KEY] = mutes
    DataBase._write_state(connection, lowId, 'progression', progression)
    return mutes
  }

  static _mute_inviter (player, senderId) {
    const lowId = GameRoomService._account_id(player)
    const mutes = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const account = connection.prepare('SELECT token FROM players WHERE lowID = ?').get(lowId)
      if (account === undefined || String(account.token) !== String(player.token)) {
        throw new ValueError('Conta não encontrada ao silenciar convite')
      }
      return GameRoomService._mute_inviter_locked(connection, lowId, senderId)
    }, true)
    if (typeof player.progression !== 'object' || player.progression === null || Array.isArray(player.progression)) {
      player.progression = {}
    }
    player.progression[GameRoomService.INVITE_MUTES_KEY] = { ...mutes }
  }

  static _take_invite (player, roomId, muteSender = false) {
    const lowId = GameRoomService._account_id(player)
    const room = GameRoomService._room(roomId)
    if (room === null) {
      return [null, null, null]
    }
    let index = -1
    for (let candidate = 0; candidate < (room.invites || []).length; candidate++) {
      const invite = room.invites[candidate]
      if (
        Math.trunc(invite.recipient_id) === lowId &&
        Math.trunc(invite.status !== undefined ? invite.status : GameRoomService.INVITE_PENDING) === GameRoomService.INVITE_PENDING
      ) {
        index = candidate
        break
      }
    }
    if (index === -1) {
      return [room, null, null]
    }
    const invite = room.invites[index]
    if (GameRoomService._member(room, Math.trunc(invite.sender_id)) === null) {
      room.invites.splice(index, 1)
      return [room, null, null]
    }
    if (muteSender) {
      GameRoomService._mute_inviter(player, invite.sender_id)
    }
    room.invites.splice(index, 1)
    return [room, invite, GameRoomService._public_invite(invite)]
  }

  static clear_invite (player, roomId, muteSender = false) {
    return GameRoomService._lock.run(() => {
      const [room, , invite] = GameRoomService._take_invite(player, roomId, muteSender)
      if (room === null || invite === null) {
        return [null, null]
      }
      return [GameRoomService._snapshot(room), invite]
    })
  }

  static accept_invite (player, roomId, muteSender = false) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room(roomId)
      if (room === null) {
        return [null, null]
      }
      const rawInvite = GameRoomService.pending_invites(room).find(
        (item) => Math.trunc(item.recipient_id) === lowId
      )
      if (rawInvite === undefined || rawInvite === null) {
        return [null, null]
      }
      if (GameRoomService._member(room, Math.trunc(rawInvite.sender_id)) === null) {
        room.invites = room.invites.filter((item) => item !== rawInvite)
        return [null, null]
      }
      const invite = GameRoomService._public_invite(rawInvite)
      const existingMember = GameRoomService._member(room, lowId)
      const member = existingMember !== null ? null : GameRoomService._new_member(player, false)
      if (member !== null && room.members.length >= GameRoomService._capacity(room.map_id)) {
        throw new GameRoomFullError('Equipe cheia')
      }
      const current = member !== null ? GameRoomService._room_for_player(player) : null
      const token = player.token
      let mutes = null
      if (token !== null && token !== undefined && token !== '' && token !== 'None') {
        DataBase._connection((connection) => {
          connection.exec('BEGIN IMMEDIATE')
          const account = connection.prepare('SELECT token FROM players WHERE lowID = ?').get(lowId)
          if (account === undefined || String(account.token) !== String(token)) {
            throw new ValueError('Conta não encontrada ao aceitar convite')
          }
          if (muteSender) {
            mutes = GameRoomService._mute_inviter_locked(connection, lowId, rawInvite.sender_id)
          }
          const info = connection.prepare('UPDATE players SET roomID = ? WHERE lowID = ? AND token = ?').run(
            Math.trunc(room.id), lowId, token
          )
          if (info.changes !== 1) {
            throw new ValueError('Falha ao persistir entrada na equipe')
          }
        }, true)
      } else if (muteSender) {
        throw new ValueError('Conta não encontrada ao silenciar convite')
      }
      room.invites = room.invites.filter((item) => item !== rawInvite)
      if (member !== null) {
        if (current !== null && current.id !== room.id) {
          const previousMember = GameRoomService._member(current, lowId)
          GameRoomService._append_event(current, 103, previousMember)
          GameRoomService._remove_member(current, lowId)
        }
        GameRoomService._attach_member(room, member)
      }
      player.room_id = Math.trunc(room.id)
      player.map_id = Math.trunc(room.map_id)
      player.slot_index = Math.trunc(room.slot_index)
      if (mutes !== null) {
        if (typeof player.progression !== 'object' || player.progression === null || Array.isArray(player.progression)) {
          player.progression = {}
        }
        player.progression[GameRoomService.INVITE_MUTES_KEY] = { ...mutes }
      }
      return [GameRoomService._snapshot(room), invite]
    })
  }

  static add_chat (player, text) {
    const lowId = GameRoomService._account_id(player)
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room_for_player(player)
      if (room === null) {
        return [null, null]
      }
      room.entry_counter += 1
      const chat = {
        kind: 2,
        id: Math.trunc(room.entry_counter),
        room_id: Math.trunc(room.id),
        player_id: lowId,
        player_name: String(player.name !== undefined && player.name !== null ? player.name : ''),
        player_role: 0,
        message: String(text !== undefined && text !== null ? text : ''),
        created_at: Math.floor(Date.now() / 1000)
      }
      room.stream.push(chat)
      GameRoomService._prune_stream(room)
      return [GameRoomService._snapshot(room), deepCopy(chat)]
    })
  }

  static stream (roomId, afterId = 0) {
    return GameRoomService._lock.run(() => {
      const room = GameRoomService._room(roomId)
      if (room === null) {
        return []
      }
      return deepCopy(room.stream.filter((entry) => entry.id > Math.trunc(afterId)))
    })
  }

  static chats (roomId, afterId = 0) {
    return GameRoomService.stream(roomId, afterId).filter((entry) => entry.kind === 2)
  }
}

GameRoomService._entries = {}
GameRoomService._next_room_id = 1
GameRoomService._next_request_key = 1
// Synchronous guard: Node is single-threaded and all storage here is
// in-memory + better-sqlite3 (sync), so a plain passthrough keeps the
// Python `with cls._lock:` call-sites working unchanged.
GameRoomService._lock = { run: (fn) => fn() }

module.exports = { GameRoomService, GameRoomFullError, GameRoomInviteError }
module.exports.default = GameRoomService
