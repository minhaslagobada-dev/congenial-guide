'use strict'
const fs = require('fs')
const Config = require('../Utils/Config')
const Fingerprint = require('../Utils/Fingerprint')
const Characters = require('../Files/CsvLogic/Characters')
const Skins = require('../Files/CsvLogic/Skins')
const Cards = require('../Files/CsvLogic/Cards')
const { AsyncLock } = require('../Utils/AsyncLock')

let content
try {
  content = fs.readFileSync('config.json', 'utf-8')
} catch (error) {
  console.log('Creating config.json...')
  Config.create_config()
  content = fs.readFileSync('config.json', 'utf-8')
}

// Use the same defaults as the server. A new/minimal config must not crash
// while accessing UnlockedBrawler or initialize account fields as undefined.
const settings = Config.GetValue()

const skins_id = Skins.get_skins_id()
const brawlers_id = Characters.get_brawlers_id()
const card_skills_id = new Cards().get_spg_id()
const card_unlock_id = brawlers_id.map((brawler) => Cards.get_brawler_unlock_by_character(brawler))

const UnlockType = settings.UnlockedBrawlersOption
const BrawlersDict = structuredClone(settings.UnlockedBrawler[0])
const BrawlersUnlockedState = {}

if (UnlockType === 'All') {
  for (const i of brawlers_id) {
    BrawlersUnlockedState[String(i)] = 1
  }
} else if (UnlockType === 'SpecifiedOnly') {
  let index = 0
  for (const brawlersName of Object.keys(BrawlersDict)) {
    BrawlersUnlockedState[String(index)] = BrawlersDict[brawlersName]
    index += 1
  }
} else if (UnlockType === 'StarterOnly') {
  const starter = [0, 1, 2, 3, 7, 8, 9, 14, 22]
  for (const i of brawlers_id) {
    if (starter.includes(i)) {
      BrawlersUnlockedState[String(i)] = 1
    } else {
      BrawlersUnlockedState[String(i)] = 0
    }
  }
}

const brawler_power_level = Math.max(0, Number.parseInt(settings.BrawlerPowerLevel, 10) - 1)
const brawler_star_power = 0
const brawler_trophies_for_rank = settings.BrawlerTrophiesForRank
const brawler_trophies = settings.BrawlerTrophies
const brawler_upgrade_points = settings.BrawlerUpgradePoints

const brawlers_trophies = {}
for (const id of brawlers_id) {
  brawlers_trophies[`${id}`] = brawler_trophies_for_rank
}

const brawlers_skins = {}
for (const id of brawlers_id) {
  brawlers_skins[`${id}`] = 0
}

const rankKeys = [
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14',
  '15', '16', '17', '18', '19', '20', '21', '23', '24', '25'
]

const brawlers_trophies_in_rank = {}
for (const key of rankKeys) {
  brawlers_trophies_in_rank[key] = brawler_trophies_for_rank
}

const brawlers_upgradium = {}
for (const key of rankKeys) {
  brawlers_upgradium[key] = brawler_upgrade_points
}

const Brawler_level = {}
for (const key of rankKeys) {
  Brawler_level[key] = brawler_power_level
}

const Brawler_starPower = {}
for (const key of rankKeys) {
  Brawler_starPower[key] = brawler_star_power
}

const patch_sha = Fingerprint.loadFinger('GameAssets/fingerprint.json')

let patch = false
if (settings.Patch) {
  patch = true
}

let maintenance = false
let err_code = 7
let maintenance_time = 0
if (settings.Maintenance) {
  err_code = 10
  maintenance = true
  maintenance_time = settings.MaintenanceTime
}

class Players {
  static CreateNewBrawlersList () {
    const result = {}
    for (const id of brawlers_id) {
      result[String(id)] = id === 0 ? 1 : 0
    }
    return result
  }

  constructor (device) {
    this.device = device
    this.send_lock = new AsyncLock()

    this.high_id = 0
    this.low_id = 0
    this.token = 'None'
    this.IsFacebookLinked = 0
    this.FacebookID = 'None'
    this.FacebookToken = 'None'
    this.box_id = 0
    this.map_id = 7
    this.slot_index = 0
    this.room_id = 0
    this.brawler_id = 0
    this.skin_id = 0
    this.online = 0
    this.logged_in = false
    this.tgid = 0
    this.battleTick = 0

    this.message = 0
    this.brawlerstate = 3

    this.dudu = 0
    this.battleX = 3500
    this.battleY = 500

    this.ClientDict = {}

    this.skins_id = skins_id
    this.brawlers_id = brawlers_id
    this.card_skills_id = card_skills_id
    this.card_unlock_id = card_unlock_id

    this.UnlockType = UnlockType
    this.BrawlersDict = BrawlersDict
    this.BrawlersUnlockedState = structuredClone(BrawlersUnlockedState)

    this.brawler_power_level = brawler_power_level
    this.brawler_star_power = brawler_star_power
    this.brawler_trophies_for_rank = brawler_trophies_for_rank
    this.brawler_trophies = brawler_trophies
    this.brawler_upgrade_points = brawler_upgrade_points
    this.brawlers_spg_unlock = {}
    this.starpower = 76

    this.brawlers_trophies = structuredClone(brawlers_trophies)
    this.brawlers_skins = structuredClone(brawlers_skins)

    this.name = 'Guest'
    this.tutorial = 2
    this.trophy_road = 1
    this.player_experience = 99999
    this.profile_icon = 0
    this.name_color = 0
    this.do_not_distrub = 0
    this.brawl_boxes = settings.BrawlBoxTokens
    this.big_boxes = settings.BigBoxTokens
    this.star_points = settings.Starpoints
    this.highest_trophies = 0
    this.trophies = settings.Trophies
    this.solo_wins = 0
    this.duo_wins = 0
    this.ThreeVSThree_wins = 0
    this.tokensdoubler = 0
    this.battle_tokens = 700
    this.gems = settings.Gems
    this.gold = settings.Gold
    this.tickets = settings.Tickets
    this.exp_points = settings.ExperiencePoints
    this.region = settings.Region !== undefined ? settings.Region : 'BR'
    this.theme_id = 41000000 + settings.ThemeID
    this.content_creator = settings.SupportedContentCreator
    this.tokens = 0
    this.tokenevent = settings.TokenEvent
    this.coinevent = settings.CoinEvent
    this.trophiesAnim = 0
    this.tokensAnim = 0
    this.bigTokensAnim = 0
    this.max_experience = 145630
    this.UnlockedSkins = { Skins: [] }
    this.Friends = {}
    this.Notifications = {}
    this.progression = {
      unlockedEvents: 0,
      shop: {},
      keyReward: 0,
      trophyReward: 0,
      starKeyReward: 0,
      starPoints: this.star_points,
      brawlerNewTag: {}
    }

    this.club_high_id = 0
    this.club_low_id = 0
    this.club_role = 0

    this.update_url = settings.UpdateUrl
    this.patch_url = settings.PatchUrl
    this.patch_sha = patch_sha
    this.maintenance_time = maintenance_time

    this.err_code = err_code
    this.maintenance = maintenance
    this.patch = patch
    if (settings.Patch) {
      this.error_code = 7
    }

    this.message_tick = 0
    this.bot_message_tick = 0

    this.brawlers_trophies_in_rank = structuredClone(brawlers_trophies_in_rank)
    this.brawlers_upgradium = structuredClone(brawlers_upgradium)
    this.Brawler_level = structuredClone(Brawler_level)
    this.Brawler_starPower = structuredClone(Brawler_starPower)

    this.battle_result = 0
    this.game_type = 0
    this.use_gadget = 1
    this.rank = 0
    this.team = 0
    this.isReady = 0

    this.bot1 = 0
    this.bot1_n = null
    this.bot2 = 0
    this.bot2_n = null
    this.bot3 = 0
    this.bot3_n = null
    this.bot4 = 0
    this.bot4_n = null
    this.bot5 = 0
    this.bot5_n = null
  }
}

Players.skins_id = skins_id
Players.brawlers_id = brawlers_id
Players.card_skills_id = card_skills_id
Players.card_unlock_id = card_unlock_id
Players.BrawlersDict = BrawlersDict
Players.BrawlersUnlockedState = BrawlersUnlockedState
Players.Brawler_level = Brawler_level
Players.Brawler_starPower = Brawler_starPower
Players.brawlers_upgradium = brawlers_upgradium
Players.brawlers_trophies = brawlers_trophies
Players.brawlers_trophies_in_rank = brawlers_trophies_in_rank
Players.brawlers_skins = brawlers_skins

module.exports = { Players }
