'use strict'

const { ValueError } = require('../Utils/Errors')

class TeamCode {
  static get PREFIX () { return 'X' }
  static get ALPHABET () { return 'QWERTYUPASDFGHJKLZCVBNM23456789' }
  static get MAX_LOW_ID () { return 0x7fffffff }
  static get MAX_VALUE () { return TeamCode.MAX_LOW_ID * 256 + 0xff }

  static to_code (highId, lowId) {
    highId = Number(highId)
    lowId = Number(lowId)
    if (!Number.isInteger(highId) || !Number.isInteger(lowId)) {
      throw new ValueError('Código de equipe inválido')
    }
    if (!(highId >= 0 && highId < 256) || !(lowId >= 0 && lowId <= TeamCode.MAX_LOW_ID)) {
      throw new ValueError('Código de equipe inválido')
    }
    let value = lowId * 256 + highId
    let encoded = ''
    const base = TeamCode.ALPHABET.length
    while (value) {
      const index = value % base
      value = (value - index) / base
      encoded = TeamCode.ALPHABET[index] + encoded
    }
    return TeamCode.PREFIX + encoded
  }

  static to_id (code) {
    if (typeof code !== 'string' || !(code.length >= 1 && code.length < 14)) {
      throw new ValueError('Código de equipe inválido')
    }
    if (!code.startsWith(TeamCode.PREFIX)) {
      throw new ValueError('Código de equipe inválido')
    }
    let value = 0
    const base = TeamCode.ALPHABET.length
    for (const character of code.slice(1)) {
      const index = TeamCode.ALPHABET.indexOf(character)
      if (index < 0) {
        throw new ValueError('Código de equipe inválido')
      }
      value = value * base + index
      if (value > TeamCode.MAX_VALUE) {
        throw new ValueError('Código de equipe inválido')
      }
    }
    const highId = value & 0xff
    const lowId = Math.floor(value / 256)
    return [highId, lowId]
  }

  // Code typed by a player: the 4 characters shown after the client's fixed
  // 'X' (e.g. '2QKV') or the full client form ('X2QKV'); case, spaces and a
  // leading '#' are ignored. Returns [high, roomId] or throws ValueError.
  static parse_room_code (code) {
    if (typeof code !== 'string') {
      throw new ValueError('Código de equipe inválido')
    }
    let text = code.trim().toUpperCase().replace(/\s+/g, '')
    if (text.startsWith('#')) text = text.slice(1)
    if (!text.length || text.length > 13) {
      throw new ValueError('Código de equipe inválido')
    }
    if (!text.startsWith(TeamCode.PREFIX)) {
      // 'X' is not part of the alphabet, so a bare code is unambiguous.
      text = TeamCode.PREFIX + text
    }
    return TeamCode.to_id(text)
  }

  // Rooms that a v13 join-by-code request (14358: high, low) can refer to.
  // The client skips the FIRST typed character before converting, so:
  //  - 'X2QKV' (client form) arrives as high 0, low = room id;
  //  - '2QKV' (only the 4 characters) arrives without its first character.
  //    Room codes are multiples of 256 (high 0), so the dropped character c
  //    is the unique c in [0, 30] with (c * 31^3 + tail) % 256 == 0.
  static join_candidates (highId, lowId) {
    highId = Number(highId); lowId = Number(lowId)
    if (!Number.isInteger(highId) || !Number.isInteger(lowId) || highId < 0 || highId > 0xff || lowId < 0 || lowId > TeamCode.MAX_LOW_ID) {
      throw new ValueError('Código de equipe inválido')
    }
    const candidates = []
    if (highId === 0 && lowId > 0) candidates.push(lowId)
    const base = TeamCode.ALPHABET.length
    const weight = base * base * base
    const tail = lowId * 256 + highId
    if (tail < weight) {
      for (let first = 0; first < base; first++) {
        const value = first * weight + tail
        if (value % 256 === 0 && value > 0 && !candidates.includes(value / 256)) candidates.push(value / 256)
      }
    }
    return candidates
  }

  // Four characters shown to the players for a room id (the client prepends 'X').
  static short_code (roomId) {
    return TeamCode.to_code(0, roomId).slice(TeamCode.PREFIX.length)
  }
}

module.exports = TeamCode
