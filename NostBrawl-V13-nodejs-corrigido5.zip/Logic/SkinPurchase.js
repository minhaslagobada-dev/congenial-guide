'use strict'

const Skins = require('../Files/CsvLogic/Skins')
const { RewardError, RewardTransaction } = require('./Rewards')

function toInteger (value) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return null
  }
  return Math.trunc(parsed)
}

class SkinPurchase {
  static price_for (skin) {
    skin = Math.trunc(skin)
    return Math.trunc(Skins.getSkinPrice(skin))
  }

  static purchase (player, skin, brawler) {
    skin = toInteger(skin)
    brawler = toInteger(brawler)
    if (skin === null || brawler === null) {
      throw new RewardError('Skin inválida')
    }

    if (!Skins.get_skins_id().includes(skin)) {
      throw new RewardError('Skin inválida')
    }
    const actualBrawler = Skins.getBrawler(skin)
    if (brawler !== actualBrawler) {
      throw new RewardError('Skin e brawler não correspondem')
    }

    const states = player.BrawlersUnlockedState || {}
    const statesValue = states[String(brawler)] !== undefined ? states[String(brawler)] : states[brawler]
    const unlocked = statesValue === 1
    const isDefault = Skins.getIsDefaultSkin(skin)
    const unlockedSkins = player.UnlockedSkins || {}
    const owned = unlockedSkins.Skins || []
    const price = isDefault ? 0 : SkinPurchase.price_for(skin)

    const transaction = new RewardTransaction(player)
    if (isDefault) {
      if (unlocked) {
        throw new RewardError('Brawler já desbloqueado')
      }
      transaction.add_reward('Brawler', brawler)
    } else {
      if (!unlocked) {
        throw new RewardError('A skin exige um brawler desbloqueado')
      }
      if (owned.includes(skin)) {
        throw new RewardError('Skin já desbloqueada')
      }
      transaction.charge('gems', price)
      transaction.add_reward('Skin', skin, brawler)
    }

    if (isDefault) {
      transaction.set_value('skin_id', 'skinID', skin)
      transaction.set_value('brawler_id', 'brawlerID', brawler)
    }
    transaction.commit()
    const result = transaction.result(100, 100)
    Object.assign(result, {
      skin,
      brawler,
      price,
      isDefaultSkin: isDefault
    })
    return result
  }
}

module.exports = SkinPurchase
