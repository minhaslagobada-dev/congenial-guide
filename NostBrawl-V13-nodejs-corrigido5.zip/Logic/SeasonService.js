'use strict'

const DataBase = require('../Database/DatabaseManager')
const { readDictRows } = require('../Files/CsvLogic/CsvRows')
const NotificationFactory = require('./NotificationFactory')
const { RewardTransaction } = require('./Rewards')
const Config = require('../Utils/Config')
const { ValueError } = require('../Utils/Errors')

let milestonesCache = null

function toInteger (value, defaultValue = 0) {
  try {
    const parsed = Number(value)
    if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
      return defaultValue
    }
    return Math.trunc(parsed)
  } catch (error) {
    return defaultValue
  }
}

class SeasonService {
  static get STATE_KEY () { return 'season' }
  static get STATE_VERSION () { return 1 }
  static get DEFAULT_DURATION () { return '14d' }
  static get MINIMUM_TROPHIES () { return 500 }
  static get LOSS_PERCENTAGE () { return 50 }
  static get SEASON_BOX_REWARDS () { return { 6: 10, 10: 11, 14: 12 } }

  static _integer (value, defaultValue = 0) {
    return toInteger(value, defaultValue)
  }

  static _nonnegative (value, defaultValue = 0) {
    return Math.max(0, toInteger(value, defaultValue))
  }

  static parse_duration (value) {
    let seconds
    if (typeof value === 'boolean') {
      throw new ValueError('SeasonDuration deve usar dias, horas ou minutos')
    }
    if (typeof value === 'number' && Number.isInteger(value)) {
      seconds = value
    } else if (typeof value === 'string') {
      const match = /^(\d+)([dhm])?$/.exec(value.trim().toLowerCase())
      if (match === null) {
        throw new ValueError('SeasonDuration deve usar formatos como 70d, 12h ou 1m')
      }
      const amount = parseInt(match[1], 10)
      const unit = match[2]
      const multiplier = { undefined: 1, m: 60, h: 3600, d: 86400 }[unit]
      seconds = amount * multiplier
    } else {
      throw new ValueError('SeasonDuration deve usar dias, horas ou minutos')
    }
    if (seconds <= 0) {
      throw new ValueError('SeasonDuration deve ser maior que zero')
    }
    return seconds
  }

  static duration () {
    return SeasonService.parse_duration(
      Config.GetValue().SeasonDuration !== undefined
        ? Config.GetValue().SeasonDuration
        : SeasonService.DEFAULT_DURATION
    )
  }

  static milestones () {
    if (milestonesCache !== null) {
      return milestonesCache
    }
    const milestones = []
    for (const row of readDictRows('GameAssets/csv_logic/milestones.csv')) {
      if (row.Type !== '6') {
        continue
      }
      let milestone
      try {
        milestone = {
          Index: parseInt(row.Index, 10),
          Trophies: parseInt(row.ProgressStart || '0', 10),
          Keys: parseInt(row.SeasonEndRewardKeys || '0', 10),
          RewardType: parseInt(row.PrimaryLvlUpRewardType || '0', 10),
          RewardCount: parseInt(row.PrimaryLvlUpRewardCount || '0', 10)
        }
        if (
          Number.isNaN(milestone.Index) ||
          Number.isNaN(milestone.Trophies) ||
          Number.isNaN(milestone.Keys) ||
          Number.isNaN(milestone.RewardType) ||
          Number.isNaN(milestone.RewardCount)
        ) {
          throw new TypeError('invalid milestone value')
        }
      } catch (error) {
        const wrapped = new ValueError(
          `Marco de temporada inválido: ${row.Name || '?'}`
        )
        wrapped.cause = error
        throw wrapped
      }
      if (Math.min(...Object.values(milestone)) < 0) {
        throw new ValueError(
          `Marco de temporada negativo: ${row.Name || '?'}`
        )
      }
      milestones.push(milestone)
    }
    if (!milestones.length) {
      throw new ValueError('Nenhum marco de temporada foi encontrado')
    }
    milestones.sort((a, b) => (a.Trophies - b.Trophies) || (a.Index - b.Index))
    milestonesCache = milestones
    return milestonesCache
  }

  static milestone_for_trophies (trophies) {
    trophies = SeasonService._nonnegative(trophies)
    let selected = null
    for (const milestone of SeasonService.milestones()) {
      if (milestone.Trophies > trophies) {
        break
      }
      selected = milestone
    }
    if (selected === null) {
      return {
        Index: -1,
        Trophies: 0,
        Keys: 0,
        RewardType: 0,
        RewardCount: 0
      }
    }
    return structuredClone(selected)
  }

  static is_persistent (player) {
    const token = player.token
    const lowId = toInteger(player.low_id !== undefined ? player.low_id : 0)
    return (
      lowId > 0 &&
      typeof token === 'string' &&
      Boolean(token) &&
      token !== 'None'
    )
  }

  static _new_state (now, generation = 0) {
    return {
      version: SeasonService.STATE_VERSION,
      endsAt: Math.trunc(now) + SeasonService.duration(),
      generation: Math.max(0, toInteger(generation)),
      lastResetAt: 0
    }
  }

  static _ensure_state (player, now) {
    let current = player.progression
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      current = {}
    }
    const raw = current[SeasonService.STATE_KEY]
    if (
      typeof raw === 'object' && raw !== null && !Array.isArray(raw) &&
      toInteger(raw.endsAt) > 0
    ) {
      return {
        version: SeasonService.STATE_VERSION,
        endsAt: toInteger(raw.endsAt),
        generation: Math.max(0, toInteger(raw.generation)),
        lastResetAt: Math.max(0, toInteger(raw.lastResetAt))
      }
    }

    const state = SeasonService._new_state(now)
    const progression = structuredClone(current)
    progression[SeasonService.STATE_KEY] = state
    if (SeasonService.is_persistent(player)) {
      DataBase._update_value(
        'lowID',
        toInteger(player.low_id !== undefined ? player.low_id : 0),
        'progression',
        progression
      )
    }
    player.progression = progression
    return state
  }

  static _sorted_brawler_keys (mapping) {
    const sortKey = (value) => {
      const numeric = Number(value)
      if (!Number.isNaN(numeric) && Number.isFinite(numeric)) {
        return [0, Math.trunc(numeric), '']
      }
      return [1, 0, String(value)]
    }
    return Object.keys(mapping).sort((a, b) => {
      const ka = sortKey(a)
      const kb = sortKey(b)
      if (ka[0] !== kb[0]) return ka[0] - kb[0]
      if (ka[1] !== kb[1]) return ka[1] - kb[1]
      return ka[2] < kb[2] ? -1 : (ka[2] > kb[2] ? 1 : 0)
    })
  }

  static _reset_details (player, now) {
    let current = player.brawlers_trophies !== undefined ? player.brawlers_trophies : {}
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      current = {}
    }
    const updated = structuredClone(current)
    const changes = []
    let totalLoss = 0
    let bestBrawler = 0
    let bestLoss = 0

    for (const key of SeasonService._sorted_brawler_keys(current)) {
      const before = SeasonService._nonnegative(current[key])
      const excess = Math.max(0, before - SeasonService.MINIMUM_TROPHIES)
      const loss = Math.floor(excess * SeasonService.LOSS_PERCENTAGE / 100)
      const after = before - loss
      updated[key] = after
      if (loss <= 0) {
        continue
      }
      totalLoss += loss
      const change = {
        Brawler: toInteger(key),
        Before: before,
        After: after,
        Loss: loss
      }
      changes.push(change)
      if (loss > bestLoss) {
        bestLoss = loss
        bestBrawler = toInteger(key)
      }
    }

    const oldTotal = SeasonService._nonnegative(player.trophies !== undefined ? player.trophies : 0)
    const newTotal = Math.max(0, oldTotal - totalLoss)
    const milestone = SeasonService.milestone_for_trophies(oldTotal)
    const boxes = []
    if (milestone.Keys > 0) {
      const boxType = SeasonService.SEASON_BOX_REWARDS[milestone.RewardType] !== undefined
        ? SeasonService.SEASON_BOX_REWARDS[milestone.RewardType]
        : null
      if (boxType !== null && milestone.RewardCount > 0) {
        boxes.push({
          Type: boxType,
          Count: milestone.RewardCount
        })
      }
    }

    const bestAfter = SeasonService._nonnegative(updated[String(bestBrawler)] !== undefined ? updated[String(bestBrawler)] : 0)
    return {
      updatedTrophies: updated,
      newTotal,
      notification: {
        Best: {
          Trophies: bestAfter,
          Points: bestLoss,
          Coins: bestLoss,
          Bonus: 0
        },
        Total: {
          Trophies: newTotal,
          Points: totalLoss,
          Coins: totalLoss,
          Bonus: milestone.Keys
        },
        BestBrawler: bestBrawler,
        Boxes: boxes,
        Milestone: milestone,
        Changes: changes,
        OldTotalTrophies: oldTotal,
        NewTotalTrophies: newTotal
      }
    }
  }

  static _end_season (player, now, state) {
    const details = SeasonService._reset_details(player, now)
    const [notifications, notification] = NotificationFactory._prepare_season(
      player, details.notification, now
    )
    const nextState = {
      version: SeasonService.STATE_VERSION,
      endsAt: Math.trunc(now) + SeasonService.duration(),
      generation: Math.max(0, toInteger(state.generation)) + 1,
      lastResetAt: Math.trunc(now)
    }

    const transaction = new RewardTransaction(player)
    transaction.set_value(
      'brawlers_trophies',
      'brawlersTrophies',
      details.updatedTrophies
    )
    transaction.set_value('trophies', 'trophies', details.newTotal)
    transaction.set_value('Notifications', 'Notifications', notifications)
    transaction.set_progression_value(SeasonService.STATE_KEY, nextState)
    transaction.commit()
    return [notification, nextState]
  }

  static sync (player, now = null) {
    return SeasonService._sync_unlocked(player, now)
  }

  static _sync_unlocked (player, now = null) {
    now = Math.trunc(now === null || now === undefined ? Date.now() / 1000 : now)
    if (!SeasonService.is_persistent(player)) {
      return {
        enabled: false,
        reset: false,
        notification: null,
        endsAt: 0,
        remaining: 0
      }
    }

    let state = SeasonService._ensure_state(player, now)
    let notification = null
    let reset = false
    if (now >= state.endsAt) {
      ;[notification, state] = SeasonService._end_season(player, now, state)
      reset = true
    }
    return {
      enabled: true,
      reset,
      notification: notification === null || notification === undefined ? null : structuredClone(notification),
      endsAt: state.endsAt,
      remaining: Math.max(0, state.endsAt - now)
    }
  }

  static end_now (player, now = null, expectedEndsAt = null) {
    now = Math.trunc(now === null || now === undefined ? Date.now() / 1000 : now)
    const state = SeasonService._ensure_state(player, now)
    if (expectedEndsAt !== null && expectedEndsAt !== undefined && state.endsAt !== expectedEndsAt) {
      return null
    }
    const [notification, nextState] = SeasonService._end_season(player, now, state)
    return {
      notification,
      season: nextState
    }
  }
}

module.exports = SeasonService
