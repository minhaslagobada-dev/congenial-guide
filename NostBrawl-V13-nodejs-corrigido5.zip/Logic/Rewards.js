'use strict'

const DataBase = require('../Database/DatabaseManager')
const Cards = require('../Files/CsvLogic/Cards')
const Characters = require('../Files/CsvLogic/Characters')
const Skins = require('../Files/CsvLogic/Skins')
const { ValueError } = require('../Utils/Errors')

const MAX_POWER_POINTS = DataBase.MAX_POWER_POINTS

class RewardError extends ValueError {
  constructor (message) {
    super(message)
    this.name = 'RewardError'
  }
}

function toInteger (value) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return null
  }
  return Math.trunc(parsed)
}

class RewardTransaction {
  constructor (player) {
    this.player = player
    this.updates = {}
    this._values = {}
    this.reward_details = []
    const progression = player.progression
    this.progression = (typeof progression === 'object' && progression !== null && !Array.isArray(progression))
      ? structuredClone(progression)
      : {}
    if (this.progression.starPoints === undefined) {
      this.progression.starPoints = toInteger(player.star_points) || 0
    }
  }

  _value (attribute, defaultValue = 0) {
    if (attribute in this._values) {
      return this._values[attribute]
    }
    const value = this.player[attribute]
    return value !== undefined && value !== null ? value : defaultValue
  }

  _mapping (attribute, column) {
    if (!(attribute in this._values)) {
      const value = this.player[attribute]
      this._values[attribute] = (typeof value === 'object' && value !== null && !Array.isArray(value))
        ? structuredClone(value)
        : {}
      this.updates[column] = this._values[attribute]
    }
    return this._values[attribute]
  }

  generation_player () {
    const player = Object.assign(Object.create(Object.getPrototypeOf(this.player)), this.player)
    for (const [attribute, value] of Object.entries(this._values)) {
      player[attribute] = (typeof value === 'object' && value !== null) ? structuredClone(value) : value
    }
    return player
  }

  set_value (attribute, column, value) {
    this._values[attribute] = value
    this.updates[column] = value
  }

  set_progression_value (key, value) {
    this.progression[key] = value
    this._values.progression = this.progression
    this.updates.progression = this.progression
  }

  charge (currency, amount) {
    amount = toInteger(amount)
    if (amount === null || amount < 0) {
      throw new RewardError('Preço inválido')
    }

    const currencies = {
      gems: ['gems', 'gems'],
      gold: ['gold', 'gold'],
      brawlBoxes: ['brawl_boxes', 'brawlBoxes'],
      bigBoxes: ['big_boxes', 'bigBoxes']
    }
    if (currency === 'starpoints' || currency === 'starPoints') {
      let balance = toInteger(this._value('star_points', 0)) || 0
      if (balance < amount) {
        throw new RewardError('Star points insuficientes')
      }
      balance -= amount
      this._values.star_points = balance
      this.set_progression_value('starPoints', balance)
      return
    }

    if (!(currency in currencies)) {
      throw new RewardError(`Moeda não suportada: ${currency}`)
    }
    const [attribute, column] = currencies[currency]
    const balance = toInteger(this._value(attribute, 0)) || 0
    if (balance < amount) {
      throw new RewardError('Saldo insuficiente')
    }
    this.set_value(attribute, column, balance - amount)
  }

  static _brawler_id (value) {
    value = toInteger(value)
    if (value === null || !Characters.get_brawlers_id().includes(value)) {
      throw new RewardError('Brawler inválido')
    }
    return value
  }

  _is_unlocked (brawlerId) {
    const states = 'BrawlersUnlockedState' in this._values
      ? this._values.BrawlersUnlockedState
      : (this.player.BrawlersUnlockedState || {})
    const value = states[String(brawlerId)] !== undefined ? states[String(brawlerId)] : states[brawlerId]
    return value === 1
  }

  _unlock_brawler (brawlerId) {
    const states = this._mapping('BrawlersUnlockedState', 'UnlockedBrawlers')
    const key = String(brawlerId)
    if (states[key] !== 1) {
      states[key] = 1
      const defaults = [
        ['brawlers_trophies', 'brawlersTrophies', 0],
        ['brawlers_trophies_in_rank', 'brawlersTrophiesForRank', 0],
        ['brawlers_upgradium', 'brawlersUpgradePoints', 0],
        ['Brawler_level', 'brawlerPowerLevel', 0],
        ['Brawler_starPower', 'brawlerStarPower', 0],
        ['brawlers_skins', 'brawlersSkins', 0]
      ]
      for (const [attribute, column, defaultValue] of defaults) {
        const mapping = this._mapping(attribute, column)
        if (mapping[key] === undefined) {
          mapping[key] = defaultValue
        }
      }
      const levels = this._mapping('Brawler_level', 'brawlerPowerLevel')
      if ((toInteger(levels[key]) || 0) < 0) {
        levels[key] = 0
      }
      let tags = this.progression.brawlerNewTag
      if (typeof tags !== 'object' || tags === null || Array.isArray(tags)) {
        tags = {}
        this.progression.brawlerNewTag = tags
      }
      tags[key] = 1
      this.set_progression_value('brawlerNewTag', tags)
    }
  }

  add_reward (name, amount, target = 0, exact = false) {
    const aliases = {
      Golds: 'Coins',
      gold: 'Coins',
      coins: 'Coins',
      Coins: 'Coins',
      gems: 'gems',
      Gems: 'gems',
      tickets: 'tickets',
      Tickets: 'tickets',
      TokensDoubler: 'tokens_doubler',
      tokenDoublers: 'tokens_doubler',
      tokensdoubler: 'tokens_doubler',
      tokens_doubler: 'tokens_doubler',
      UpgradePoints: 'UpgradePoints',
      Brawler: 'Brawler',
      Skin: 'Skin',
      StarPower: 'StarPower'
    }
    if (!(name in aliases)) {
      throw new RewardError(`Recompensa não suportada: ${name}`)
    }
    name = aliases[name]
    try {
      amount = toInteger(amount)
      target = toInteger(target || 0)
      if (amount === null || target === null) {
        throw new TypeError()
      }
    } catch (error) {
      throw new RewardError('Recompensa inválida')
    }
    if (amount < 0) {
      throw new RewardError('Recompensa inválida')
    }

    if (name === 'Coins') {
      this.set_value('gold', 'gold', (toInteger(this._value('gold', 0)) || 0) + amount)
    } else if (name === 'gems') {
      this.set_value('gems', 'gems', (toInteger(this._value('gems', 0)) || 0) + amount)
    } else if (name === 'tickets') {
      this.set_value('tickets', 'tickets', (toInteger(this._value('tickets', 0)) || 0) + amount)
    } else if (name === 'tokens_doubler') {
      this.set_value('tokensdoubler', 'tokensdoubler', (toInteger(this._value('tokensdoubler', 0)) || 0) + amount)
    } else if (name === 'UpgradePoints') {
      target = RewardTransaction._brawler_id(target)
      if (!this._is_unlocked(target)) {
        throw new RewardError('Power points exigem um brawler desbloqueado')
      }
      const points = this._mapping('brawlers_upgradium', 'brawlersUpgradePoints')
      const key = String(target)
      const current = Math.max(0, toInteger(points[key]) || 0)
      const remaining = Math.max(0, MAX_POWER_POINTS - current)
      if (exact && amount > remaining) {
        throw new RewardError('O brawler não possui capacidade para todos os power points')
      }
      amount = Math.min(amount, remaining)
      points[key] = current + amount
    } else if (name === 'Brawler') {
      amount = RewardTransaction._brawler_id(amount)
      this._unlock_brawler(amount)
    } else if (name === 'StarPower') {
      target = RewardTransaction._brawler_id(target)
      if (!this._is_unlocked(target)) {
        throw new RewardError('Star power exige um brawler desbloqueado')
      }
      if (amount === 0 || Cards.get_brawler_star_power(target) !== amount) {
        throw new RewardError('Star power inválido')
      }
      const powers = this._mapping('Brawler_starPower', 'brawlerStarPower')
      powers[String(target)] = amount
    } else if (name === 'Skin') {
      if (!Skins.get_skins_id().includes(amount)) {
        throw new RewardError('Skin inválida')
      }
      target = Skins.getBrawler(amount)
      if (!this._is_unlocked(target)) {
        throw new RewardError('A skin exige um brawler desbloqueado')
      }
      const skins = this._mapping('UnlockedSkins', 'UnlockedSkins')
      if (!Array.isArray(skins.Skins)) {
        skins.Skins = []
      }
      const owned = skins.Skins
      if (owned.includes(amount)) {
        throw new RewardError('Skin já desbloqueada')
      }
      owned.push(amount)
    } else {
      throw new RewardError(`Recompensa não suportada: ${name}`)
    }

    this.reward_details.push({ name, amount, target })
    return amount
  }

  add_rewards (rewards) {
    for (const reward of rewards) {
      if (typeof reward === 'object' && !Array.isArray(reward)) {
        this.add_reward(
          reward.name,
          reward.amount,
          reward.target !== undefined ? reward.target : 0,
          reward.exact !== undefined ? reward.exact : false
        )
      } else {
        const [name, amount, target] = reward
        this.add_reward(name, amount, target)
      }
    }
  }

  commit (connection = null) {
    for (const attribute of [
      'gems', 'gold', 'tickets', 'brawl_boxes', 'big_boxes',
      'tokensdoubler', 'battle_tokens', 'star_points'
    ]) {
      if (attribute in this._values && toInteger(this._values[attribute]) < 0) {
        throw new RewardError(`Saldo negativo em ${attribute}`)
      }
    }

    if (connection === null) {
      if (!DataBase.replaceValues(this, this.updates)) {
        throw new RewardError('Conta não encontrada no SQLite')
      }
      this.finalize()
    } else if (
      !DataBase._write_values(
        connection, toInteger(this.player.low_id) || 0, this.updates
      )
    ) {
      throw new RewardError('Conta não encontrada no SQLite')
    }
    return this
  }

  finalize (player = null) {
    player = player === null ? this.player : player
    for (const [attribute, value] of Object.entries(this._values)) {
      player[attribute] = value
    }
    if ('progression' in this.updates) {
      player.progression = this.progression
      player.tokensAnim = toInteger(this.progression.keyReward) || 0
      player.trophiesAnim = toInteger(this.progression.trophyReward) || 0
      player.bigTokensAnim = toInteger(this.progression.starKeyReward) || 0
    }
    return this
  }

  result (boxId = 100, boxType = null, trophyRoad = 0) {
    return {
      boxID: boxId,
      boxType: boxType === null ? boxId : boxType,
      rewards: this.reward_details.map((reward) => reward.amount),
      rewardNames: this.reward_details.map((reward) => reward.name),
      rewardsTargetBrawler: this.reward_details.map((reward) => reward.target),
      rewardDetails: structuredClone(this.reward_details),
      trophyRoad
    }
  }
}

module.exports = { RewardError, RewardTransaction, MAX_POWER_POINTS }
