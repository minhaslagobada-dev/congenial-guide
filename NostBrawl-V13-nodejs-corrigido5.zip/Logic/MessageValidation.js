'use strict'

const { ValueError } = require('../Utils/Errors')

function read_data_reference (reader) {
  const csvId = reader.read_Vint()
  if (csvId === 0) {
    return [0, 0]
  }
  return [csvId, reader.read_Vint()]
}

function read_boolean (reader) {
  const value = reader.read_byte()
  if (value !== 0 && value !== 1) {
    throw new ValueError('Booleano inválido')
  }
  return Boolean(value)
}

function ensure_end (reader, label) {
  if (reader.read(1).length) {
    throw new ValueError(label + ' contém dados residuais')
  }
}

module.exports = { read_data_reference, read_boolean, ensure_end }
