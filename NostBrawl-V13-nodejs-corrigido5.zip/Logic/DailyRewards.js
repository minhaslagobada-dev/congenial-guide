'use strict'

const DataBase = require('../Database/DatabaseManager')

class DailyRewardError extends Error {
  constructor (message) {
    super(message)
    this.name = 'DailyRewardError'
  }
}

function localIsoDay (date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

class DailyRewards {
  static get TOKEN_LIMIT () { return 700 }
  static get TOKEN_REFILL_AMOUNT () { return 20 }
  static get TOKEN_REFILL_INTERVAL () { return 144 * 60 }
  static get STAR_AMOUNT () { return 1 }

  static _moment (now = null) {
    return now === null || now === undefined ? new Date() : now
  }

  static _day (now = null) {
    return localIsoDay(DailyRewards._moment(now))
  }

  static _player_id (player) {
    let lowId
    try {
      lowId = Math.trunc(Number(player.low_id || 0))
      if (Number.isNaN(lowId)) {
        lowId = 0
      }
    } catch (error) {
      lowId = 0
    }
    const token = player.token
    if (lowId <= 0 || typeof token !== 'string' || !token || token === 'None') {
      return 0
    }
    return lowId
  }

  static _timestamp (now = null) {
    return Math.floor(DailyRewards._moment(now).getTime() / 1000)
  }

  static _ensure_locked (connection, lowId, now = null) {
    const moment = DailyRewards._moment(now)
    const timestamp = DailyRewards._timestamp(moment)
    const account = connection.prepare(
      'SELECT battleTokens FROM players WHERE lowID = ?'
    ).get(lowId)
    if (account === undefined) {
      throw new DailyRewardError('Conta não encontrada para os tokens')
    }
    let balance = Math.max(0, Math.min(DailyRewards.TOKEN_LIMIT, Math.trunc(account.battleTokens || 0)))
    const row = connection.prepare(
      'SELECT next_refill_at FROM battle_token_refill WHERE player_id = ?'
    ).get(lowId)
    let nextAt
    if (row === undefined) {
      nextAt = balance < DailyRewards.TOKEN_LIMIT ? timestamp + DailyRewards.TOKEN_REFILL_INTERVAL : 0
      connection.prepare(
        'INSERT INTO battle_token_refill (player_id, next_refill_at) VALUES (?, ?)'
      ).run(lowId, nextAt)
    } else {
      nextAt = Math.trunc(row.next_refill_at)
      if (balance >= DailyRewards.TOKEN_LIMIT) {
        nextAt = 0
      } else if (nextAt <= 0) {
        nextAt = timestamp + DailyRewards.TOKEN_REFILL_INTERVAL
      } else if (timestamp >= nextAt) {
        const steps = 1 + Math.floor((timestamp - nextAt) / DailyRewards.TOKEN_REFILL_INTERVAL)
        balance = Math.min(DailyRewards.TOKEN_LIMIT, balance + steps * DailyRewards.TOKEN_REFILL_AMOUNT)
        nextAt = balance >= DailyRewards.TOKEN_LIMIT ? 0 : nextAt + steps * DailyRewards.TOKEN_REFILL_INTERVAL
      }
      connection.prepare(
        'UPDATE battle_token_refill SET next_refill_at = ? WHERE player_id = ?'
      ).run(nextAt, lowId)
    }
    const info = connection.prepare(
      'UPDATE players SET battleTokens = ? WHERE lowID = ?'
    ).run(balance, lowId)
    if (info.changes !== 1) {
      throw new DailyRewardError('Conta não encontrada para os tokens')
    }
    return {
      day: DailyRewards._day(moment),
      limit: DailyRewards.TOKEN_LIMIT,
      used: DailyRewards.TOKEN_LIMIT - balance,
      remaining: balance,
      old_battle_tokens: balance,
      next_refill_at: nextAt,
      next_refill_in: nextAt ? Math.max(0, nextAt - timestamp) : 0
    }
  }

  static sync_player (player, now = null) {
    const lowId = DailyRewards._player_id(player)
    if (lowId <= 0) {
      const remaining = Math.max(
        0, Math.min(DailyRewards.TOKEN_LIMIT, Math.trunc(Number(player.battle_tokens || 0)) || 0)
      )
      return {
        day: DailyRewards._day(now),
        limit: DailyRewards.TOKEN_LIMIT,
        used: DailyRewards.TOKEN_LIMIT - remaining,
        remaining,
        next_refill_at: 0,
        next_refill_in: 0,
        persisted: false
      }
    }
    const state = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      return DailyRewards._ensure_locked(connection, lowId, now)
    }, true)
    player.battle_tokens = state.remaining
    state.persisted = true
    return state
  }

  static consume (connection, lowId, requested, doubler = 0, now = null) {
    try {
      lowId = Math.trunc(lowId)
      requested = Math.trunc(requested)
      doubler = Math.max(0, Math.trunc(doubler))
      if (Number.isNaN(lowId) || Number.isNaN(requested) || Number.isNaN(doubler)) {
        throw new TypeError()
      }
    } catch (error) {
      throw new DailyRewardError('Recompensa diária inválida')
    }
    if (lowId <= 0 || requested < 0) {
      throw new DailyRewardError('Recompensa diária inválida')
    }
    const moment = DailyRewards._moment(now)
    const state = DailyRewards._ensure_locked(connection, lowId, moment)
    const base = Math.min(requested, state.remaining)
    const doubled = Math.min(base, doubler)
    const total = base + doubled
    if (base) {
      state.remaining -= base
      state.used = DailyRewards.TOKEN_LIMIT - state.remaining
      if (!state.next_refill_at) {
        state.next_refill_at = DailyRewards._timestamp(moment) + DailyRewards.TOKEN_REFILL_INTERVAL
        state.next_refill_in = DailyRewards.TOKEN_REFILL_INTERVAL
        connection.prepare(
          'UPDATE battle_token_refill SET next_refill_at = ? WHERE player_id = ?'
        ).run(state.next_refill_at, lowId)
      }
      const info = connection.prepare(
        'UPDATE players SET battleTokens = ? WHERE lowID = ?'
      ).run(state.remaining, lowId)
      if (info.changes !== 1) {
        throw new DailyRewardError('Falha ao atualizar os tokens')
      }
    }
    Object.assign(state, {
      requested_tokens: requested,
      tokens_gain: base,
      doubled_tokens: doubled,
      total_tokens: total,
      remaining_doubler: doubler - doubled,
      battle_tokens: state.remaining
    })
    return state
  }

  static claim_star (connection, lowId, mapId, battleId, eligible, now = null) {
    if (!eligible) {
      return false
    }
    try {
      lowId = Math.trunc(lowId)
      mapId = Math.trunc(mapId)
      if (Number.isNaN(lowId) || Number.isNaN(mapId)) {
        throw new TypeError()
      }
    } catch (error) {
      throw new DailyRewardError('Evento da ficha estrela inválido')
    }
    if (lowId <= 0 || mapId < 0 || !battleId) {
      throw new DailyRewardError('Ficha estrela exige partida e evento persistentes')
    }
    const day = DailyRewards._day(now)
    const existing = connection.prepare(
      'SELECT 1 FROM daily_star_rewards ' +
      'WHERE player_id = ? AND day = ? AND map_id = ?'
    ).get(lowId, day, mapId)
    if (existing !== undefined) {
      return false
    }
    connection.prepare(
      'INSERT INTO daily_star_rewards (' +
      'player_id, day, map_id, amount, battle_id, created_at' +
      ') VALUES (?, ?, ?, ?, ?, ?)'
    ).run(lowId, day, mapId, DailyRewards.STAR_AMOUNT, String(battleId), Math.floor(Date.now() / 1000))
    return true
  }
}

module.exports = { DailyRewards, DailyRewardError }
