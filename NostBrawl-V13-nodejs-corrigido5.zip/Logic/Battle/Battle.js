'use strict'

const { BattleParticipants } = require('./BattleParticipants')
const StartLoadingMessage = require('../../Packets/Messages/Server/Battle/StartLoadingMessage')
const VisionUpdateMessage = require('../../Packets/Messages/Server/Battle/VisionUpdateMessage')

class Battle {
  constructor (client, player, state, room = null, participants = null) {
    this.client = client
    this.player = player
    this.subTick = 0
    this.tick = 0
    this.started = 0
    this.state = state
    this.room = room
    this.participants = participants || BattleParticipants.build(room, player)
    this.player.battleTick = 0
    this.player.battle_room = room
    this.player.battle_participants = this.participants
    this._timer = null
  }

  startBattle () {
    this.started = 1
    try {
      new StartLoadingMessage(
        this.client, this.player, this.room, this.participants
      ).send()
      const step = () => {
        if (!this.started) {
          return
        }
        try {
          this.tick += 1
          this.subTick = 0
          this.player.battleTick = this.tick
          new VisionUpdateMessage(
            this.client, this.player, this.room, this.participants
          ).send()
        } catch (error) {
          if (error && (error.code === 'ECONNRESET' || error.code === 'EPIPE' || error.errno)) {
            this.started = 0
            this.stop()
            return
          }
          this.started = 0
          this.stop()
          return
        }
        this._timer = setTimeout(step, 52)
        if (this._timer.unref) this._timer.unref()
      }
      this._timer = setTimeout(step, 52)
      if (this._timer.unref) this._timer.unref()
    } catch (error) {
      this.started = 0
    }
  }

  start () {
    this.startBattle()
  }

  run () {
    this.startBattle()
  }

  stop () {
    this.started = 0
    if (this._timer !== null) {
      clearTimeout(this._timer)
      this._timer = null
    }
  }
}

module.exports = { Battle }
module.exports.default = Battle
