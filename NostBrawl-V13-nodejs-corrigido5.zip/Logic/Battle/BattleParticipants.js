'use strict'

const Characters = require('../../Files/CsvLogic/Characters')
const Skins = require('../../Files/CsvLogic/Skins')
const { EventRotation } = require('../EventRotation')
const { ValueError } = require('../../Utils/Errors')

class BattleParticipants {
  static get GAME_MODE_VARIATIONS () {
    return require('./World/GameModes').VARIATIONS
  }

  // 0xcf5c4 uses this category to allocate slots via 0xda014. The
  // location independently supplies the rules at 0x4796f8.
  static loading_game_type (entries) {
    const category = { 3: 3, 6: 1, 10: 6 }[entries.length]
    if (category === undefined) throw new ValueError('Quantidade de participantes sem categoria nativa online')
    return category
  }

  static location (mapId) {
    const locations = EventRotation.locations()
    const location = locations[Math.trunc(Number(mapId))]
    if (location === undefined) {
      throw new ValueError('Mapa de batalha inválido')
    }
    return location
  }

  static game_mode_variation (mapId) {
    const location = BattleParticipants.location(mapId)
    const variation = BattleParticipants.GAME_MODE_VARIATIONS[location.game_mode]
    return variation !== undefined ? variation : -1
  }

  static _skin (brawlerId, skinId = 0) {
    try {
      brawlerId = Math.trunc(Number(brawlerId))
      return [brawlerId, Skins.resolve_skin(brawlerId, skinId)]
    } catch (error) {
      brawlerId = 0
      return [brawlerId, Skins.get_default_skin(brawlerId)]
    }
  }

  static _entry (member, index, team, bot = false) {
    const [brawlerId, skinId] = BattleParticipants._skin(
      member.brawler_id !== undefined ? member.brawler_id : 0,
      member.skin_id !== undefined ? member.skin_id : 0
    )
    return {
      index,
      team,
      name: String(member.name !== undefined && member.name !== null && member.name ? member.name : 'Bot'),
      low_id: bot ? 0 : Math.trunc(member.low_id || 0),
      high_id: bot ? 0 : Math.trunc(member.high_id || 0),
      brawler_id: brawlerId,
      skin_id: skinId,
      bot
    }
  }

  static build (room, player = null) {
    room = room || {}
    const mapId = Math.trunc(
      room.map_id !== undefined && room.map_id
        ? room.map_id
        : (player !== null && player !== undefined ? (player.map_id || 7) : 7)
    ) || 0
    const gameMode = BattleParticipants.location(mapId).game_mode
    let members = Array.from(room.members || [])
    if (!members.length && player !== null && player !== undefined) {
      members = [{
        low_id: Math.trunc(player.low_id || 0),
        high_id: Math.trunc(player.high_id || 0),
        name: String(player.name || ''),
        brawler_id: Math.trunc(player.brawler_id || 0),
        skin_id: Math.trunc(player.skin_id || 0),
        team: 0
      }]
    }
    let capacity = Math.trunc(room.capacity || 0)
    if (capacity <= 0) {
      if (gameMode === 'BattleRoyale' || gameMode === 'BattleRoyaleTeam') {
        capacity = 10
      } else if (gameMode === 'Survival') {
        capacity = 3
      } else if (gameMode === 'Raid') {
        capacity = 3
      } else {
        capacity = 6
      }
    }
    capacity = Math.max(capacity, members.length)
    const entries = []

    if (gameMode === 'BattleRoyale') {
      for (const member of members) {
        entries.push(BattleParticipants._entry(member, entries.length, entries.length))
      }
    } else if (gameMode === 'BattleRoyaleTeam') {
      for (const member of members) {
        entries.push(BattleParticipants._entry(member, entries.length, Math.floor(entries.length / 2)))
      }
    } else if (['BossFight', 'Survival', 'Raid'].includes(gameMode)) {
      for (const member of members) {
        entries.push(BattleParticipants._entry(member, entries.length, 0))
      }
    } else {
      const sideCounts = [0, 0]
      for (const member of members) {
        let team
        try {
          team = Math.trunc(member.team || 0)
        } catch (error) {
          team = 0
        }
        if (![0, 1].includes(team) || sideCounts[team] >= 3) {
          team = sideCounts[0] <= sideCounts[1] ? 0 : 1
        }
        sideCounts[team] += 1
        entries.push(BattleParticipants._entry(member, entries.length, team))
      }
    }

    const brawlers = Characters.get_brawlers_id()
    if (!brawlers.length) {
      throw new ValueError('Nenhum brawler disponível para bots')
    }
    const roomId = Math.trunc(room.id || 0)
    while (entries.length < capacity) {
      const index = entries.length
      let team
      if (gameMode === 'BattleRoyale') {
        team = index
      } else if (gameMode === 'BattleRoyaleTeam') {
        team = Math.floor(index / 2)
      } else if (['BossFight', 'Survival', 'Raid'].includes(gameMode)) {
        team = 0
      } else {
        const counts = [0, 0]
        for (const entry of entries) {
          if ([0, 1].includes(entry.team)) {
            counts[entry.team] += 1
          }
        }
        team = counts[0] <= counts[1] ? 0 : 1
      }
      const brawlerId = brawlers[(roomId + index) % brawlers.length]
      const bot = {
        name: 'Bot',
        brawler_id: brawlerId,
        skin_id: Skins.get_default_skin(brawlerId)
      }
      entries.push(BattleParticipants._entry(bot, index, team, true))
    }
    return entries
  }

  static own_index (entries, player) {
    const lowId = Math.trunc(player.low_id || 0)
    for (const entry of entries) {
      if (!entry.bot && entry.low_id === lowId) {
        return Math.trunc(entry.index)
      }
    }
    return 0
  }
}

module.exports = { BattleParticipants }
module.exports.default = BattleParticipants
