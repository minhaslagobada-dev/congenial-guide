'use strict'
const { EventEmitter } = require('node:events')
const { Worker } = require('node:worker_threads')
const path = require('node:path')
const { decodeInput } = require('./Network/V13BattleCodec')

// Keep the coordinator's atomic matchmaking/tick API while the worker thread
// handles child-process IO. The original native frame runs in the Node.js engine worker.
class NativeBattleBridge extends EventEmitter {
  constructor (options = {}) {
    super(); this.closed = false; this.timeout = options.timeout || 5000
    this.control = new SharedArrayBuffer(8); this.buffer = new SharedArrayBuffer(2097152)
    this.signal = new Int32Array(this.control)
    this.worker = new Worker(path.join(__dirname, 'NativeBattleThread.js'), { workerData: { options, control: this.control, buffer: this.buffer } })
    this.worker.on('error', error => this.fail(error))
    this.pending = new Map(); this.nextAsync = 1
    this.worker.on('message', message => {
      if (message.engineFailure) { this.fail(new Error(message.engineFailure)); return }
      if (!message.asyncId) return
      const request = this.pending.get(message.asyncId)
      if (!request) return
      this.pending.delete(message.asyncId); clearTimeout(request.timer)
      if (message.error) {
        const error = new Error(message.error)
        request.reject(error)
        if (message.fatal) this.fail(error)
      } else request.resolve(message.result)
    })
    this.worker.on('exit', code => { if (!this.closed) this.fail(new Error(`Native bridge exited (${code})`)) })
    try { this.read(35000) } catch (error) { this.closed = true; this.worker.terminate(); throw error }
  }
  read (timeout) {
    if (Atomics.wait(this.signal, 0, 0, timeout) === 'timed-out') {
      this.fail(new Error('Native bridge timed out')); throw new Error('Native bridge timed out')
    }
    const state = Atomics.load(this.signal, 0); const length = Atomics.load(this.signal, 1)
    if (length <= 0 || length > this.buffer.byteLength) throw new Error('Invalid native bridge response size')
    const message = JSON.parse(Buffer.from(new Uint8Array(this.buffer, 0, length)).toString())
    if (state !== 1 || message.error) {
      const error = new Error(message.error || 'Native bridge failed')
      if (message.fatal) this.fail(error)
      throw error
    }
    return message.result
  }
  request (command, fields = {}) {
    if (this.closed) throw new Error('Native engine closed')
    Atomics.store(this.signal, 0, 0); Atomics.store(this.signal, 1, 0)
    this.worker.postMessage({ command, fields, control: this.control, buffer: this.buffer })
    return this.read(this.timeout)
  }
  // Non-blocking variant used by the tick loop. Requests share the worker's
  // FIFO with synchronous ones, so per-match ordering is preserved.
  requestAsync (command, fields = {}) {
    if (this.closed) return Promise.reject(new Error('Native engine closed'))
    const asyncId = this.nextAsync++
    if (this.nextAsync > 2147483647) this.nextAsync = 1
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(asyncId); const error = new Error(`Native ${command} timed out`); reject(error); this.fail(error) }, this.timeout)
      this.pending.set(asyncId, { resolve, reject, timer })
      this.worker.postMessage({ command, fields, async: asyncId })
    })
  }
  stepAsync (matchId, inputs) {
    for (const [, bytes] of inputs) decodeInput(bytes)
    return this.requestAsync('step', { matchId, inputs: inputs.map(([index, bytes]) => [index, bytes.toString('hex')]) })
  }
  step (matchId, inputs) {
    for (const [, bytes] of inputs) decodeInput(bytes)
    return this.request('step', { matchId, inputs: inputs.map(([index, bytes]) => [index, bytes.toString('hex')]) })
  }
  create (matchId, location, seed, players) { return this.request('create', { matchId, location, seed, players }) }
  frame (matchId) { return this.request('frame', { matchId }) }
  input (matchId, playerIndex, bytes) {
    decodeInput(bytes)
    return this.request('input', { matchId, playerIndex, hex: bytes.toString('hex') })
  }
  destroy (matchId) { return this.request('destroy', { matchId }) }
  fail (error) {
    if (this.closed) return
    this.closed = true; this.worker.terminate()
    for (const request of this.pending.values()) { clearTimeout(request.timer); request.reject(error) }
    this.pending.clear()
    this.emit('engineFailure', error)
  }
  close () {
    if (this.closed) return
    try { this.request('shutdown') } finally {
      this.closed = true; this.worker.terminate()
      for (const request of this.pending.values()) { clearTimeout(request.timer); request.reject(new Error('Native engine closed')) }
      this.pending.clear()
    }
  }
}
module.exports = { NativeBattleBridge }
