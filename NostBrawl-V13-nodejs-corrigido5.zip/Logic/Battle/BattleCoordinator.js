'use strict'
const crypto = require('node:crypto')
const { performance } = require('node:perf_hooks')
const { EventEmitter } = require('node:events')
const { battleAssets } = require('./World/BattleAssets')
const { Matchmaker } = require('./Matchmaker')
const { BattleWorld } = require('./Game/BattleWorld')
const { visionPayload } = require('./Game/V13WorldCodec')
const { BattleInstanceService } = require('../BattleInstances')
const UDPInfo = require('../../Packets/Messages/Server/Battle/UDPConnectionInfo')
const Vision = require('../../Packets/Messages/Server/Battle/AuthoritativeVisionUpdateMessage')
const StartLoading = require('../../Packets/Messages/Server/Battle/StartLoadingMessage')
const Status = require('../../Packets/Messages/Server/Battle/MatchMakingStatusMessage')
const Cancelled = require('../../Packets/Messages/Server/Battle/MatchMakingCancelledMessage')
const { ValueError } = require('../../Utils/Errors')

const TCP_VISION_BACKLOG_BYTES = 8192

class BattleCoordinator extends EventEmitter {
  constructor (transport, settings = {}) {
    super(); this.transport = transport; this.assets = battleAssets()
    this.nativeRuntime = settings.NativeRuntime || null
    // No artificial server-wide player cap (the old Battle.MaxPlayers = 200
    // refused every player above 200 in battle/queue). Each match is still
    // bounded by its mode capacity from the original location data.
    this.matchmaker = new Matchmaker(this.assets)
    this.worlds = new Map(); this.accounts = new Map(); this.closed = false
    this.privateRooms = new Map(); this.privatePlayers = new Map()
    this.metrics = { steps: 0, worldsStarted: 0, worldsFinished: 0, snapshots: 0, tcpSnapshots: 0, failures: 0,
      lateTicks: 0, catchUpTicks: 0, droppedTicks: 0, reconnects: 0, lastStepMs: 0, maxStepMs: 0 }
    this.tickMs = 50
    // A world whose engine call is still running when its next tick is due
    // owes at most MaxCatchUpTicks frames; older ticks are dropped instead of
    // queueing (a backlog only adds latency for every player).
    this.maxCatchUp = Number.isInteger(settings.MaxCatchUpTicks) ? settings.MaxCatchUpTicks : 2
    this.reconnectWindowMs = Number.isFinite(settings.ReconnectWindowSeconds) ? settings.ReconnectWindowSeconds * 1000 : 180000
    this.asyncSteps = settings.AsyncSteps !== false
    this.onNativeFailure = error => {
      this.engineFailed = true
      this.metrics.failures++; this.emit('battleError', error)
      this.matchmaker.close()
      for (const ticket of Array.from(this.privateRooms.values())) this.removePrivateRoom(ticket, true)
      for (const world of Array.from(this.worlds.values())) world.finish(null, 'server-error')
    }
    if (this.nativeRuntime) this.nativeRuntime.on('engineFailure', this.onNativeFailure)
    this.matchmaker.on('status', (ticket, found, seconds) => {
      for (const member of ticket.members) this.deliver(() => new Status(member.client, member.player, seconds, found, ticket.mode.capacity).send())
    })
    this.matchmaker.on('cancel', ticket => {
      let room = null
      if (ticket.roomId) for (const member of ticket.members) room = this.deliver(() => require('../GameRoomService').GameRoomService.set_ready(member.player, false)) || room
      for (const member of ticket.members) if (!member.client.destroyed) this.deliver(() => new Cancelled(member.client, member.player).send())
      // Members that stay in the room must see the cleared ready flags.
      if (room) this.deliver(() => require('../GameRoomGateway').GameRoomGateway.broadcast_data(ticket.members[0].player, room))
    })
    this.onInput = (session) => {
      const world = this.accounts.get(session.player.low_id)
      if (!world) return
      const entry = world.players.find(p => p.player === session.player && p.client === session.client)
      if (entry) { entry.session = session; entry.ready = true }
    }
    this.onRelease = (session, reason) => {
      if (reason === 'battle-start-failed' || (reason === 'timeout' && !this.accounts.has(session.player.low_id))) return
      this.disconnect(session.player, session.client, reason === 'home')
    }
    transport.on('input', this.onInput); transport.on('release', this.onRelease)
    // Drift-compensated 20 Hz clock: each tick is scheduled against the ideal
    // timeline, so timer jitter or a slow tick does not accumulate. After a
    // long stall (process suspended) the timeline restarts instead of firing
    // a burst of catch-up ticks.
    this.nextTickAt = performance.now() + this.tickMs
    const clock = () => {
      if (this.closed) return
      const now = performance.now()
      if (now - this.nextTickAt > this.tickMs * 5) this.nextTickAt = now
      this.nextTickAt += this.tickMs
      this.timer = setTimeout(clock, Math.max(0, this.nextTickAt - performance.now())); this.timer.unref()
      this.step()
    }
    this.timer = setTimeout(clock, this.tickMs); this.timer.unref()
  }

  deliver (action) {
    try { return action() } catch (error) { this.emit('battleError', error); return false }
  }

  enqueue (members, mapId) {
    if (this.engineFailed) {
      for (const member of members) if (!member.client.destroyed) this.deliver(() => new Cancelled(member.client, member.player).send())
      throw new ValueError('Motor nativo indisponível; verifique o erro de batalha no console')
    }
    if (this.closed) throw new ValueError('Servidor de batalhas encerrado')
    // A Play/ready request comes from the lobby, so any previous result screen
    // is over: retire it (rewards are already settled) instead of silently
    // swallowing the request, which left the search button dead.
    this.settleResults(members)
    for (const member of members) if (this.accounts.has(member.player.low_id) || this.privatePlayers.has(member.player.low_id)) throw new ValueError('Jogador já está em batalha ou sala privada')
    return this.matchmaker.enqueue(members, mapId)
  }

  readyRoom (player, room) {
    if (this.closed || this.engineFailed) throw new ValueError('Motor de batalhas indisponível')
    const registry = player.ClientDict && player.ClientDict.Clients
    const sessionOf = member => {
      const session = registry && registry[String(member.low_id)]
      return session && session.Player && session.SocketInfo && !session.SocketInfo.destroyed ? session : null
    }
    // Members that closed the game stay in the room as OFFLINE (status 0)
    // and never block the online ones; they are simply not part of this match.
    const online = room.members.filter(member => sessionOf(member))
    if (!online.length || !online.some(member => member.low_id === player.low_id) || !online.every(member => member.ready)) return null
    const { GameRoomService } = require('../GameRoomService')
    const duplicates = GameRoomService.duplicate_brawler_members(room)
    if (duplicates.length) {
      const error = new ValueError('Brawlers repetidos na mesma equipe')
      error.teamError = 17
      throw error
    }
    const members = online.map(member => {
      const session = sessionOf(member)
      return { player: session.Player, client: session.SocketInfo }
    })
    const mode = require('./World/GameModes').rules(this.assets.tables.locations[room.map_id].GameMode)
    if (room.practice) {
      return this.queuePrivateRoom(player, room, members, mode)
    }
    // Original flow: TeamGameStarting (24130, location of the room) opens the
    // client's matchmaking popup for EVERY member before the first
    // MatchMakingStatus (20405). The v13 client ignores 20405 while that
    // popup is closed, which is why a ready team only saw "Cancelar".
    const queued = this.matchmaker.players.get(player.low_id)
    if (!queued || queued.state !== 'queued') {
      const Starting = require('../../Packets/Messages/Server/Gameroom/TeamGameStartingMessage')
      for (const member of members) if (!member.client.destroyed) this.deliver(() => new Starting(member.client, member.player, room).send())
    }
    const ticket = this.enqueue(members, room.map_id)
    if (ticket) ticket.roomId = room.id
    return ticket
  }

  settleResults (members) {
    const { ResultOutbox } = require('./ResultOutbox')
    for (const member of members) if (member.player.pendingBattleResult) ResultOutbox.acknowledge(member.player)
  }

  // A refused Play/ready (busy account, capacity, member offline, engine
  // down...) must leave the lobby usable, never drop the connection: the
  // ready flags of the room are cleared and every connected member gets
  // MatchMakingCancelled, so the next press starts a new search.
  refuse (player, client, room, error) {
    this.emit('battleError', new Error(`Busca recusada para a conta ${player.low_id}: ${error && error.message ? error.message : error}`))
    const { GameRoomService } = require('../GameRoomService')
    const targets = [{ player, client }]
    const registry = player.ClientDict && player.ClientDict.Clients
    if (room && room.members) {
      for (const member of room.members) {
        const session = registry && registry[String(member.low_id)]
        const memberPlayer = member.low_id === player.low_id ? player : session && session.Player
        if (!memberPlayer) continue
        this.deliver(() => GameRoomService.set_ready(memberPlayer, false))
        if (memberPlayer !== player && session.SocketInfo && !session.SocketInfo.destroyed) targets.push({ player: memberPlayer, client: session.SocketInfo })
      }
    }
    for (const target of targets) if (target.client && !target.client.destroyed) this.deliver(() => new Cancelled(target.client, target.player).send())
    return targets
  }

  cancel (player, client) {
    if (this.accounts.has(player.low_id)) {
      const world = this.accounts.get(player.low_id)
      const entry = world.players.find(p => !p.bot && p.player.low_id === player.low_id)
      // Only a live, connected brawler blocks a cancel; anything else is stale.
      if (entry && !entry.left && entry.client === client && world.phase !== 'finished') return false
    }
    const privateRoom = this.privatePlayers.get(player.low_id)
    if (privateRoom && privateRoom.members.some(m => m.player === player && m.client === client)) { this.removePrivateRoom(privateRoom, true); return true }
    if (this.matchmaker.cancel(player, client)) return true
    if (!client.destroyed) this.deliver(() => new Cancelled(client, player).send())
    return false
  }

  start (selected, mapId) {
    let players = []
    for (const { ticket, team } of selected) for (const member of ticket.members) players.push({ ...member, team, index: players.length, session: null })
    const mode = require('./World/GameModes').rules(this.assets.tables.locations[mapId].GameMode)
    const capacities = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
    const humanCount = players.length
    if (!humanCount) throw new ValueError('A partida precisa de pelo menos um jogador conectado')
    const level = Math.round(players.reduce((sum, entry) => sum + (entry.powerLevel || 0), 0) / Math.max(1, humanCount))
    const Skins = require('../../Files/CsvLogic/Skins')
    for (let team = 0; team < capacities.length && !this.nativeRuntime; team++) {
      const present = players.filter(entry => entry.team === team).length
      if (present > capacities[team]) throw new ValueError('Equipe maior que a capacidade do modo')
      for (let slot = present; slot < capacities[team]; slot++) {
        const hero = this.assets.heroes[crypto.randomInt(this.assets.heroes.length)]
        const index = players.length
        players.push({ bot: true, team, index, session: null, client: null, brawlerId: hero.id,
          skinId: Skins.get_default_skin(hero.id), powerLevel: level,
          player: { low_id: -(index + 1), high_id: 0, name: 'Bot ' + (index - humanCount + 1), brawler_id: hero.id, Brawler_level: {} } })
      }
    }
    if (!this.nativeRuntime && players.length !== mode.capacity) throw new ValueError('Quantidade de participantes incompatível com o mapa')
    const id = crypto.randomBytes(16).toString('hex'); const seed = crypto.randomInt(2147483647)
    const world = this.nativeRuntime
      ? new (require('./Game/NativeBattleWorld').NativeBattleWorld)(id, this.assets, mapId, players, seed, this.nativeRuntime)
      : new BattleWorld(id, this.assets, mapId, players, seed)
    players = world.players
    const humans = players.filter(entry => !entry.bot)
    // Battle log: each brawler's trophies as the match starts (other players'
    // results may be committed before this player's own entry is written).
    for (const entry of humans) entry.historyTrophies = Math.trunc(Number((entry.player.brawlers_trophies || {})[entry.brawlerId]) || 0)
    world.on('cleanupError', error => { this.metrics.failures++; this.emit('battleError', error) })
    // Build world and validate the initial snapshots before consuming tickets.
    const begun = []
    try {
      for (const entry of humans) visionPayload(world, entry, this.assets)
      for (const entry of humans) {
        BattleInstanceService.begin(entry.player); begun.push(entry)
        entry.session = this.transport.attach(entry.player, entry.client)
      }
    } catch (error) {
      world.finish(null, 'server-error')
      for (const entry of begun) {
        this.deliver(() => BattleInstanceService.mark_home(entry.player))
        this.deliver(() => this.transport.release(entry.player, entry.client, 'battle-start-failed'))
      }
      throw error
    }
    world.on('finished', result => this.finished(world, result))
    const participants = players.map(entry => ({ index: entry.index, team: entry.team,
      name: entry.player.name, low_id: entry.bot ? 0 : entry.player.low_id, high_id: entry.bot ? 0 : entry.player.high_id || 0,
      brawler_id: entry.brawlerId, skin_id: entry.skinId, bot: Boolean(entry.bot) }))
    world.participants = participants
    this.worlds.set(world.id, world)
    for (const entry of humans) this.accounts.set(entry.player.low_id, world)
    for (const entry of humans) {
      entry.player.map_id = mapId; entry.player.onlineBattle = world; entry.player.authoritativeBattleResult = null
      this.deliver(() => {
        new StartLoading(entry.client, entry.player, { map_id: mapId, battle_seed: world.seed, loading_game_type: world.loadingGameType }, participants).send()
        new UDPInfo(entry.client, entry.player).send()
        this.sendTcpVision(world, entry, visionPayload(world, entry, this.assets))
      })
    }
    for (const { ticket } of selected) if (ticket.roomId) require('../GameRoomService').GameRoomService.begin_battle(ticket.members[0].player)
    this.metrics.worldsStarted++; return world
  }

  step () {
    if (this.closed || this.engineFailed) return
    this.metrics.steps++
    try { this.pollPrivateRooms() } catch (error) { this.metrics.failures++; this.emit('battleError', error) }
    try { this.matchmaker.poll((selected, mapId) => this.start(selected, mapId)) } catch (error) { this.metrics.failures++; this.emit('battleError', error) }
    const now = Date.now()
    for (const world of Array.from(this.worlds.values())) {
      if (world.allDisconnectedAt !== undefined && now - world.allDisconnectedAt >= this.reconnectWindowMs) { world.finish(null, 'abandoned'); continue }
      this.tickWorld(world)
    }
    if (this.metrics.steps % 20 === 0) for (const mapId of this.matchmaker.buckets.keys()) this.matchmaker.notify(mapId)
  }

  tickWorld (world) {
    if (world.phase === 'finished') return
    if (!this.asyncSteps || !world.stepAsync || !this.nativeRuntime || !this.nativeRuntime.stepAsync) {
      try {
        const started = performance.now()
        world.step(); this.recordStep(performance.now() - started)
        if (world.phase !== 'finished') this.broadcast(world)
      } catch (error) {
        this.metrics.failures++; this.emit('battleError', error); world.finish(null, 'server-error')
      }
      return
    }
    if (world.stepping) {
      this.metrics.lateTicks++
      if ((world.owedTicks || 0) < this.maxCatchUp) world.owedTicks = (world.owedTicks || 0) + 1
      else this.metrics.droppedTicks++
      return
    }
    world.stepping = true
    const started = performance.now()
    let request
    try { request = world.stepAsync() } catch (error) {
      world.stepping = false; this.metrics.failures++; this.emit('battleError', error); world.finish(null, 'server-error'); return
    }
    request.then(adopted => {
      world.stepping = false
      this.recordStep(performance.now() - started)
      if (this.closed || this.engineFailed || world.phase === 'finished') return
      if (adopted) this.broadcast(world)
      if (world.owedTicks > 0) { world.owedTicks--; this.metrics.catchUpTicks++; this.tickWorld(world) }
    }, error => {
      world.stepping = false
      if (this.closed || this.engineFailed || world.phase === 'finished') return
      this.metrics.failures++; this.emit('battleError', error); world.finish(null, 'server-error')
    }).catch(error => {
      this.metrics.failures++; this.emit('battleError', error)
      if (world.phase !== 'finished') world.finish(null, 'server-error')
    })
  }

  recordStep (ms) {
    this.metrics.lastStepMs = ms
    if (ms > this.metrics.maxStepMs) this.metrics.maxStepMs = ms
  }

  broadcast (world) {
    for (const entry of world.players) {
      if (entry.bot || !entry.session || entry.session.closed || entry.client.destroyed) continue
      try {
        const payload = visionPayload(world, entry, this.assets)
        // Bootstrap over encrypted TCP, independently of UDP reachability.
        // Oversized snapshots also use TCP instead of deleting live objects.
        if (!entry.session.endpoint || payload.length > 1370) this.sendTcpVision(world, entry, payload)
        else if (this.transport.send(entry.session, 24109, payload)) this.metrics.snapshots++
      } catch (error) {
        // One peer's socket failure must not stop the match for the others.
        this.metrics.failures++; this.emit('battleError', error)
      }
    }
  }

  // Login while the account still owns a live match: bind the new connection
  // to the same brawler and replay the battle bootstrap (20559 -> 24112 ->
  // TCP 24109 of the current tick). The v13 client rebuilds its battle from
  // StartLoading and continues from the authoritative snapshot; position, HP,
  // ammo, Super charge and cooldowns are the engine's own live state.
  reconnect (player, client) {
    if (this.closed || this.engineFailed) return false
    const world = this.accounts.get(player.low_id)
    if (!world || world.phase === 'finished' || !world.rejoin || !world.participants) return false
    const entry = world.players.find(other => !other.bot && other.player.low_id === player.low_id)
    if (!entry || entry.left) return false
    const previous = { player: entry.player, client: entry.client, session: entry.session, disconnected: entry.disconnected }
    entry.player = player; entry.client = client
    let session
    try { session = this.transport.attach(player, client) } catch (error) {
      Object.assign(entry, previous); this.emit('battleError', error); return false
    }
    entry.session = session; entry.ready = true
    world.rejoin(entry)
    if (previous.player !== player && previous.player.onlineBattle === world) previous.player.onlineBattle = null
    player.map_id = world.mapId; player.onlineBattle = world; player.authoritativeBattleResult = null
    this.deliver(() => BattleInstanceService.begin(player))
    this.deliver(() => {
      new StartLoading(client, player, { map_id: world.mapId, battle_seed: world.seed, loading_game_type: world.loadingGameType }, world.participants).send()
      new UDPInfo(client, player).send()
      this.sendTcpVision(world, entry, visionPayload(world, entry, this.assets))
    })
    this.metrics.reconnects++
    this.emit('reconnected', world, entry)
    return true
  }

  sendTcpVision (world, entry, payload, final = false) {
    // Bound socket buffering; the authoritative clock never waits for a peer.
    // Every 24109 is a complete snapshot of its tick, so when the kernel send
    // buffer is already full a stale frame is dropped and the next tick
    // replaces it. The old 256 KB bound let ~780 queued snapshots (tens of
    // seconds at 300-1300 B each) pile up in userland on a congested phone
    // link, which shows as commands/attacks landing seconds late.
    if (!final && entry.client.writableLength > TCP_VISION_BACKLOG_BYTES) return false
    new Vision(entry.client, entry.player, payload).send()
    this.metrics.tcpSnapshots++
    return true
  }

  finished (world, result) {
    // The native end flag must reach the client before its result packet.
    // Use one TCP channel for both so UDP/TCP reordering cannot invert them.
    if (world.nativeVisionPayload && result.reason === 'native-game-over') {
      for (const entry of world.players) {
        if (entry.bot || !entry.session || entry.session.closed || entry.client.destroyed) continue
        this.deliver(() => this.sendTcpVision(world, entry, visionPayload(world, entry, this.assets), true))
      }
    }
    this.worlds.delete(world.id); this.metrics.worldsFinished++
    for (const entry of world.players) {
      if (entry.bot) continue
      // A player who already went home may be queued or playing elsewhere:
      // never touch that newer state (account map, room, result screen).
      const moved = this.accounts.get(entry.player.low_id) !== world
      if (!moved) this.accounts.delete(entry.player.low_id)
      if (entry.player.onlineBattle === world) entry.player.onlineBattle = null
      if (entry.left || moved) {
        const id = entry.player.low_id
        const idle = !this.accounts.has(id) && !this.matchmaker.players.has(id) && !this.privatePlayers.has(id)
        if (idle && !['loading-timeout', 'server-error', 'shutdown', 'abandoned'].includes(result.reason)) this.deliver(() => this.result(world, entry, true))
        this.transport.release(entry.player, entry.client, 'battle-ended')
        continue
      }
      const { GameRoomService } = require('../GameRoomService')
      this.deliver(() => GameRoomService.end_battle(entry.player))
      // Abort paths cannot grant competitive rewards.
      if (!['loading-timeout', 'server-error', 'shutdown', 'abandoned'].includes(result.reason)) this.deliver(() => this.result(world, entry))
      else if (result.reason !== 'shutdown' && entry.player.token && !entry.client.destroyed && !entry.client.readableEnded) {
        this.deliver(() => {
          BattleInstanceService.mark_home(entry.player)
          const Home = require('../../Packets/Messages/Server/Home/OwnHomeDataMessage')
          new Home(entry.client, entry.player).send()
        })
      }
      this.transport.release(entry.player, entry.client, 'battle-ended')
    }
  }

  result (world, entry, silent = false) {
    const { BattleEndData, BattleEndService, BattleParticipant } = require('../BattleEnd')
    const [gameMode] = BattleEndService.game_mode(world.mapId)
    const ranked = [2, 5].includes(gameMode)
    const outcome = world.outcome.winner === null ? 2 : world.outcome.winner === entry.team ? 0 : 1
    const hash = crypto.createHash('sha256').update(world.id + ':' + entry.player.low_id + ':' + JSON.stringify(world.outcome)).digest('hex')
    const participants = world.players.map(other => new BattleParticipant({ brawlerId: other.brawlerId, skinId: other.skinId, team: other.team,
      isPlayer: !other.bot, name: other.player.name, lowId: other.bot ? 0 : other.player.low_id, highId: other.bot ? 0 : other.player.high_id || 0, powerLevel: other.powerLevel + 1 }))
    // Showdown placements come from the simulation. A missing placement must
    // never read as rank 1 (a win): only the winning side may take first,
    // anyone else gets the last place of the match.
    let rank = entry.rank
    if (!rank) {
      const sides = gameMode === 5 ? Math.max(1, Math.ceil(world.players.length / 2)) : Math.max(1, world.players.length)
      rank = ranked && world.outcome.winner !== entry.team ? sides : 1
    }
    const data = new BattleEndData({ battleResult: ranked ? rank : outcome, submittedResult: entry.team,
      rank, mapSlot: entry.player.map_slot || 0, mapId: world.mapId, gameMode,
      locationGameMode: world.mode.name, participants, battleId: hash, localIndex: entry.index })
    data.practice = Boolean(world.practice)
    if (world.nativeVisionPayload) data.mvp_index = Number.isInteger(world.state.mvpIndex) ? world.state.mvpIndex : -1
    const ledgerId = BattleInstanceService.resolve_result(entry.player, hash, gameMode)
    BattleEndService.apply_to_player(entry.player, data); entry.player.battle_end_id = ledgerId
    entry.player.authoritativeBattleResult = data
    const { BattleHistory } = require('../BattleHistory')
    // Battle log snapshot travels with the saved result, so a result restored
    // after a crash (ResultOutbox.restore) can still be written exactly once.
    data.history = BattleHistory.snapshot(world, entry, data, this.tickMs)
    if (silent) {
      // Left before the end and still idle in the lobby: settle the rewards
      // through the ledger only. No result screen or pending outbox entry is
      // created for a client that already returned home.
      const rewards = require('../BattleResultAdapter').apply_battle_result_rewards(entry.player, gameMode, ledgerId)
      this.recordHistory(entry, data, rewards)
      return
    }
    const { ResultOutbox } = require('./ResultOutbox')
    ResultOutbox.save(entry.player, data, ledgerId)
    const rewards = require('../BattleResultAdapter').apply_battle_result_rewards(entry.player, gameMode, ledgerId)
    ResultOutbox.send(entry.player, entry.client)
    this.recordHistory(entry, data, rewards)
  }

  // Queued outside the tick (setImmediate, one transaction per batch). The
  // (player, battle) key makes a repeated end/result a no-op.
  recordHistory (entry, data, rewards) {
    if (!data.history) return
    const { BattleHistory } = require('../BattleHistory')
    const player = entry.player
    BattleHistory.queue(player.low_id, BattleHistory.complete(data.history, rewards), record => {
      // Back in the lobby already (left early, or GoHome came first): push the
      // entry now; otherwise GoHome pushes it after OwnHomeData.
      BattleHistory.stored_for(player, record, !player.pendingBattleResult && !player.onlineBattle)
    })
  }

  disconnect (player, client, left = false) {
    const privateRoom = this.privatePlayers.get(player.low_id)
    if (privateRoom && privateRoom.members.some(m => m.player === player && m.client === client)) this.removePrivateRoom(privateRoom, true)
    this.matchmaker.cancel(player, client, 'disconnect')
    const world = this.accounts.get(player.low_id)
    if (!world) return
    const entry = world.players.find(p => p.player === player && p.client === client)
    if (!entry) return
    entry.disconnected = true
    if (world.disconnectPlayer) {
      world.disconnectPlayer(entry, left)
      // An explicit exit (GoHome) frees the account at once: the brawler can
      // never rejoin (reconnect rejects left entries), and keeping it mapped
      // to a match that other humans are still playing made every later Play
      // or team ready fail with "already in battle" until that match ended.
      if (left && this.accounts.get(player.low_id) === world) {
        this.accounts.delete(player.low_id)
        if (player.onlineBattle === world) player.onlineBattle = null
      }
      return
    }
    const char = world.characters.get(player.low_id)
    if (char && char.hp > 0) world.damage(char, char.hp, null)
    if (world.phase === 'loading' || world.players.filter(p => !p.bot).every(p => p.disconnected)) world.finish(null, 'abandoned')
  }

  close () {
    if (this.closed) return
    this.closed = true; clearTimeout(this.timer); this.matchmaker.close()
    try { require('../BattleHistory').BattleHistory.flush() } catch (_) {}
    for (const ticket of Array.from(this.privateRooms.values())) this.removePrivateRoom(ticket, true)
    for (const world of Array.from(this.worlds.values())) world.finish(null, 'shutdown')
    if (this.nativeRuntime) {
      this.nativeRuntime.off('engineFailure', this.onNativeFailure)
      this.nativeRuntime.close()
    }
    this.transport.off('input', this.onInput); this.transport.off('release', this.onRelease)
  }
}
Object.assign(BattleCoordinator.prototype, require('./PrivateRooms'))
module.exports = { BattleCoordinator }
