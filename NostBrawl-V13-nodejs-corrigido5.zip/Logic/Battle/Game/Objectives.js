'use strict'
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y)

module.exports = {
  kickBall (char, x, y, superShot = false) {
    if (!this.ball || this.ball.carrier !== char) return false
    if (superShot && char.superCharge < 4000) return false
    if (superShot) char.superCharge = 0
    const r = Math.atan2(y - char.y, x - char.x)
    char.carryingBall = false
    this.ball.carrier = null; this.ball.vx = Math.cos(r) * (superShot ? 210 : 150); this.ball.vy = Math.sin(r) * (superShot ? 210 : 150)
    this.ball.kicker = char; this.ball.pickupAfter = this.tick + 6
    return true
  },

  resetBall () {
    Object.assign(this.ball, this.freePoint(this.map.logicWidth / 2, this.map.logicHeight / 2, 100))
    this.ball.carrier = null; this.ball.vx = 0; this.ball.vy = 0; this.ball.pickupAfter = this.tick + 20
    for (const char of this.characters.values()) {
      char.carryingBall = false
      char.hp = char.maxHp; char.target = null; char.charging = false; char.statuses = []
      Object.assign(char, char.spawn)
    }
    for (const object of this.objects.values()) if (object.dataClass !== 16) this.objects.delete(object.id)
  },

  stepBall () {
    const ball = this.ball
    if (this.goalPauseUntil > this.tick) return
    this.goalTeam = undefined
    if (ball.carrier && ball.carrier.hp <= 0) { ball.carrier.carryingBall = false; ball.carrier = null; ball.pickupAfter = this.tick + 6 }
    if (ball.carrier) { ball.x = ball.carrier.x; ball.y = ball.carrier.y }
    else {
      if (ball.vx || ball.vy) {
        const wall = this.map.trace(ball.x, ball.y, ball.x + ball.vx, ball.y + ball.vy, 100)
        const fraction = wall ? Math.max(0, wall.t - 0.001) : 1
        ball.x += ball.vx * fraction; ball.y += ball.vy * fraction
        if (wall) { const dot = ball.vx * wall.nx + ball.vy * wall.ny; ball.vx -= 2 * dot * wall.nx; ball.vy -= 2 * dot * wall.ny }
        ball.vx *= 0.98; ball.vy *= 0.98
        if (Math.hypot(ball.vx, ball.vy) < 2) { ball.vx = 0; ball.vy = 0 }
      }
      if (!(ball.pickupAfter > this.tick)) for (const char of this.characters.values()) if (char.hp > 0 && !char.charging && distance(char, ball) <= char.radius + 120) {
        ball.carrier = char; char.carryingBall = true; ball.vx = 0; ball.vy = 0; break
      }
    }
    for (const [marker, scoredFor] of [['6', 1], ['7', 0]]) {
      const points = this.map.markers.get(marker) || []
      if (!points.length) continue
      const lowX = Math.min(...points.map(p => p.x)) - 150; const highX = Math.max(...points.map(p => p.x)) + 150
      if (ball.x >= lowX && ball.x <= highX && Math.abs(ball.y - points[0].y) < 180) {
        this.goalTeam = scoredFor; this.goalPauseUntil = this.tick + 40
        this.teamScores[scoredFor]++
        if (this.teamScores[scoredFor] >= 2 || this.overtime) this.finish(scoredFor, 'goals')
        else this.resetBall()
        break
      }
    }
    if (this.tick === 3000) {
      if (this.teamScores[0] !== this.teamScores[1]) this.finish(this.teamScores[0] > this.teamScores[1] ? 0 : 1, 'time-limit')
      else {
        this.overtime = true
        this.map.destroy(this.map.logicWidth / 2, this.map.logicHeight / 2, Math.hypot(this.map.logicWidth, this.map.logicHeight), this.tick)
      }
    }
    if (this.tick >= 4200) this.finish(null, 'time-limit')
  },

  stepCoop () {
    if (this.mode.variation === 8) {
      if (this.tick === 1 || this.tick % 240 === 0) {
        this.wave++
        const tier = Math.min(3, Math.floor((this.wave - 1) / 8))
        const points = this.map.markers.get('2') || this.map.markers.get('1') || []
        for (let i = 0; i < Math.min(10, 2 + Math.floor(this.wave / 3)); i++) {
          const point = points[(this.wave + i) % points.length]
          const families = ['CoopMeleeEnemy', 'CoopFastMeleeEnemy', 'CoopRangedEnemy']
          const data = this.assets.named('characters', families[i % families.length] + (tier + 1))
          this.character(data.id, 1, i % 16, this.freePoint(point.x, point.y, Number(data.CollisionRadius) || 120))
        }
      }
      if (this.tick >= 7500) this.finish(0, 'survived')
    } else if (this.mode.variation === 10) {
      if (this.tick % 1200 === 0 && this.boss && this.boss.hp > 0) { this.boss.scale += 0.5; this.boss.speed = Math.min(1000, this.boss.speed + 80) }
      if (!Array.from(this.characters.values()).some(c => c.hp > 0)) this.finish(1, 'team-eliminated')
      if (this.tick >= 12000) this.finish(1, 'time-limit')
    }
  }
}
