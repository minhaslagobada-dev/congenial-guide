'use strict'
// v13 LogicRandom::rand 0x2880b8: signed arithmetic right shift.
class V13Random {
  constructor (seed = 0) { this.seed = seed | 0 }
  rand (maximum) {
    if (!Number.isInteger(maximum) || maximum <= 0 || maximum > 2147483647) return 0
    let value = this.seed || -1
    value ^= value << 13; value ^= value >> 17; value ^= value << 5
    this.seed = value | 0
    return ((value < 0 ? -value : value) | 0) % maximum
  }
}
const sine = Array.from({ length: 91 }, (_, angle) => Math.round(Math.sin(angle * Math.PI / 180) * 1024))
function sin (angle) {
  angle = ((Math.trunc(angle) % 360) + 360) % 360
  return angle <= 90 ? sine[angle] : angle <= 180 ? sine[180 - angle] : angle <= 270 ? -sine[angle - 180] : -sine[360 - angle]
}
function rotate (x, y, angle) { const s = sin(angle); const c = sin(angle + 90); return { x: Math.trunc((x * c - y * s) / 1024), y: Math.trunc((y * c + x * s) / 1024) } }
module.exports = { V13Random, rotate }
