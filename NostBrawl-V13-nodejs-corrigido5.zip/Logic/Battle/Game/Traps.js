'use strict'
const { rotate } = require('./V13Math')
const number = (row, key, fallback = 0) => Number(row[key]) || fallback
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

module.exports = {
  deployTraps (box, definition) {
    const automatic = definition.Name !== 'BoxOfMines'
    const name = automatic ? definition.Name === 'BoxOfSelfDestructBombs' ? 'SelfDestructBomb' : 'Bomb' : 'Mine'
    if (!automatic) for (const item of this.objects.values()) if (item.dataClass === 18 && item.owner === box.owner && this.assets.tables.items[item.dataId].Name === name) this.objects.delete(item.id)
    const radius = number(definition, 'Value2', 8) * 100
    const count = number(definition, 'Value', 3); const goals = []
    this.random.rand(3)
    for (let ordinal = 0; ordinal < count; ordinal++) {
      this.random.rand(20)
      let goal = { x: Math.trunc(box.x), y: Math.trunc(box.y) }
      for (let attempt = 0; attempt < 200; attempt++) {
        const r = Math.trunc(radius / 2) + this.random.rand(Math.max(1, Math.trunc(radius / 2)))
        const delta = rotate(r, 0, this.random.rand(360))
        const candidate = { x: clamp(Math.trunc(box.x) + delta.x, 1, this.map.logicWidth - 2), y: clamp(Math.trunc(box.y) + delta.y, 1, this.map.logicHeight - 2) }
        if (!automatic && (!this.map.canOccupy(candidate.x, candidate.y, 0) || this.map.trace(box.x, box.y, candidate.x, candidate.y, 0))) continue
        if (goals.some(point => (point.x - candidate.x) ** 2 + (point.y - candidate.y) ** 2 < 360000)) continue
        goal = candidate; break
      }
      goals.push(goal)
      const item = this.spawnItem(name, box.x, box.y, box.owner, box.damage)
      Object.assign(item, { startX: Math.trunc(box.x), startY: Math.trunc(box.y), targetX: goal.x, targetY: goal.y,
        bornTick: this.tick + ordinal * 2, deploymentMs: 750, triggerMs: 0, triggered: false, automatic, z: automatic ? 1200 : 0 })
    }
    this.random.rand(360)
    this.objects.delete(box.id)
  },

  advanceTrap (item, definition) {
    if (this.tick <= item.created || this.tick < item.bornTick) return
    if (item.triggered) {
      item.triggerMs = Math.max(0, item.triggerMs - 50)
      if (item.triggerMs === 0) { this.area(definition.TriggerAreaEffect, item.owner, item.x, item.y, item.damage); this.objects.delete(item.id) }
      return
    }
    if (item.deploymentMs > 0) {
      item.deploymentMs = Math.max(0, item.deploymentMs - 50)
      const progress = 1000 - Math.trunc(item.deploymentMs * 1000 / 750)
      const gravity = item.automatic ? 10 : 6; const initialZ = item.automatic ? 1200000 : 0
      if (progress <= 700) {
        item.x = Math.trunc((item.startX * 1000 + (item.targetX - item.startX) * progress) / 1000)
        item.y = Math.trunc((item.startY * 1000 + (item.targetY - item.startY) * progress) / 1000)
        item.z = Math.trunc((initialZ + gravity * progress * (700 - progress) + Math.trunc(-initialZ * progress / 700)) / 1000)
      } else {
        const q = progress - 700
        for (const [axis, first, last] of [['x', 'startX', 'targetX'], ['y', 'startY', 'targetY']]) {
          const anchor = Math.trunc((item[first] * 300 + item[last] * 700) / 1000)
          const end = item[first] + Math.trunc((item[last] - item[first]) * 700 / 1000) + Math.trunc((item[last] - item[first]) * 300 / 2000)
          item[axis] = Math.trunc((anchor * (300 - q) + end * q) / 300)
        }
        item.z = Math.trunc(gravity * q * (300 - q) / 1000)
      }
      item.z = clamp(item.z, 0, 3000)
      if (item.deploymentMs > 0) return
    }
    if (item.automatic) { item.triggered = true; item.triggerMs = number(definition, 'Value2', 300); return }
    const radius = number(definition, 'TriggerRangeSubTiles', 3) * 100
    for (const char of this.objects.values()) {
      if (char.dataClass !== 16 || char.hp <= 0 || char === this.ball || this.airborne(char) || char.team === item.team) continue
      const type = this.assets.tables.characters[char.dataId].Type
      if (['Pvp_Base', 'LootBox'].includes(type)) continue
      if (Math.hypot(char.x - item.x, char.y - item.y) <= radius) {
        item.triggered = true; item.triggerMs = number(definition, 'Value2', 300); break
      }
    }
  }
}
