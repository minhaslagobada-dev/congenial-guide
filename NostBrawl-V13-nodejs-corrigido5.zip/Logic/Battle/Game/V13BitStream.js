'use strict'

// Native BitStream uses least-significant-bit order. Unlike ByteStream VInt,
// these fields have fixed widths chosen by the v13 decoder.
class V13BitStream {
  constructor (bytes = null) {
    this.reading = bytes !== null
    this.buffer = bytes === null ? Buffer.alloc(256) : Buffer.from(bytes)
    this.position = 0
  }
  ensure (bits) {
    const size = Math.ceil((this.position + bits) / 8)
    if (this.reading) { if (size > this.buffer.length) throw new RangeError('Truncated v13 world bitstream') } else if (size > this.buffer.length) {
      const grown = Buffer.alloc(Math.max(size, this.buffer.length * 2))
      this.buffer.copy(grown); this.buffer = grown
    }
  }
  uint (value, bits) {
    if (!Number.isInteger(bits) || bits < 1 || bits > 32 || !Number.isInteger(value) || value < 0 || value >= 2 ** bits) throw new RangeError(`Invalid v13 field ${value}/${bits}`)
    this.ensure(bits)
    let remaining = bits
    while (remaining) {
      const offset = this.position & 7
      const count = Math.min(remaining, 8 - offset)
      this.buffer[this.position >> 3] |= (value & ((1 << count) - 1)) << offset
      value >>>= count; this.position += count; remaining -= count
    }
    return this
  }
  append (bytes, bits = bytes.length * 8) {
    if (!Buffer.isBuffer(bytes) || !Number.isInteger(bits) || bits < 0 || bits > bytes.length * 8) throw new RangeError('Invalid bit append')
    this.ensure(bits)
    const offset = this.position & 7; const start = this.position >> 3
    if (offset === 0 && bits % 8 === 0) bytes.copy(this.buffer, start, 0, bits / 8)
    else for (let i = 0; i < Math.ceil(bits / 8); i++) {
      const count = Math.min(8, bits - i * 8); const byte = bytes[i] & ((1 << count) - 1)
      this.buffer[start + i] |= byte << offset
      if (offset + count > 8) this.buffer[start + i + 1] |= byte >>> (8 - offset)
    }
    this.position += bits; return this
  }
  sint (value, bits) { this.uint(value < 0 ? 0 : 1, 1); return this.uint(Math.abs(value), bits) }
  bool (value) { return this.uint(value ? 1 : 0, 1) }
  readUint (bits) {
    this.ensure(bits)
    let value = 0
    for (let i = 0; i < bits; i++, this.position++) value += ((this.buffer[this.position >> 3] >>> (this.position & 7)) & 1) * 2 ** i
    return value
  }
  readSint (bits) { const sign = this.readUint(1) ? 1 : -1; return sign * this.readUint(bits) }
  dataRef (classId, instanceId) {
    this.uint(classId, 5)
    if (classId) this.uint(instanceId, 7)
    return this
  }
  objectId (classId, instanceId) {
    this.uint(classId, 5)
    if (classId) this.uint(instanceId, 13)
    return this
  }
  bytes () { return this.buffer.subarray(0, Math.ceil(this.position / 8)) }
}

module.exports = { V13BitStream }
