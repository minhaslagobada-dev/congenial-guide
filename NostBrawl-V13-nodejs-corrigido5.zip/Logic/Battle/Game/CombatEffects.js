'use strict'
const { enabled } = require('../World/BattleAssets')
const n = (row, field, fallback = 0) => Number(row[field]) || fallback
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y)

module.exports = {
  airborne (char) { return Boolean(char.charging && [2, 3, 6].includes(char.chargeType)) },
  heal (target, amount) {
    if (target.hp <= 0 || ['Pvp_Base', 'LootBox', 'LaserBall'].includes(this.assets.tables.characters[target.dataId].Type)) return 0
    if (this.mode.variation === 7 && target === this.boss) amount *= this.assets.global('BOSS_HEAL_MUL', 25) / this.assets.global('BOSS_HEAL_DIV', 100)
    const healed = Math.max(0, Math.min(target.maxHp - target.hp, Math.trunc(amount)))
    target.hp += healed; return healed
  },

  push (target, origin, strength) {
    const length = distance(target, origin) || 1
    if (strength < 0) strength = -Math.min(-strength, distance(target, origin))
    const point = this.moveBody(target,
      target.x + (target.x - origin.x) / length * strength,
      target.y + (target.y - origin.y) / length * strength, target.radius)
    Object.assign(target, point); target.target = null
  },

  projectileHit (p, target) {
    const data = this.assets.tables.projectiles[p.dataId]
    const startPercent = n(data, 'DamagePercentStart', 100); const endPercent = n(data, 'DamagePercentEnd', startPercent)
    const progress = Math.min(1, distance(p, { x: p.startX, y: p.startY }) / Math.max(1, p.totalRange))
    const damage = p.damage * (startPercent + (endPercent - startPercent) * progress) / 100
    if (target.team === p.team) this.heal(target, damage * n(data, 'HealOwnPercent') / 100)
    else {
      const dealt = this.damage(target, damage, p.owner, p.slot)
      if (n(data, 'LifeStealPercent') && !['Pvp_Base', 'LootBox'].includes(this.assets.tables.characters[target.dataId].Type)) this.heal(p.owner, dealt * n(data, 'LifeStealPercent') / 100)
      if (n(data, 'StunLengthMS')) {
        target.stunUntil = this.tick + n(data, 'StunLengthMS') / 50
        target.target = null; target.charging = false; target.z = 0
        for (const skill of target.skills) { skill.activeMs = 0; skill.shotsLeft = 0 }
      }
      if (n(data, 'FreezeStrength')) { target.slowUntil = this.tick + 40; target.slowPercent = n(data, 'FreezeStrength') / 1000 }
      if (n(data, 'PushbackStrength')) this.push(target, p.owner, n(data, 'PushbackStrength') * 6)
      if (n(data, 'PoisonDamagePercent')) {
        target.statuses = target.statuses.filter(status => status.kind !== 'poison' || status.source !== p.owner)
        target.statuses.push({ kind: 'poison', source: p.owner, damage: p.damage * n(data, 'PoisonDamagePercent') / 400, due: this.tick + 20, remaining: 4, slot: p.slot })
      }
      if (data.ChainBullet && n(data, 'ChainsToEnemies')) {
        const candidates = Array.from(this.objects.values()).filter(c => c.dataClass === 16 && c.hp > 0 && c.team !== p.team && c !== target && !p.hit.has(c.id) && distance(c, target) <= n(data, 'ChainTravelDistance', 20) * 100)
        candidates.sort((a, b) => distance(a, target) - distance(b, target))
        for (const next of candidates.slice(0, n(data, 'ChainsToEnemies'))) {
          const state = { ...p.skill, target: { x: next.x, y: next.y }, definition: { ...p.skill.definition, CastingRange: n(data, 'ChainTravelDistance', 20) } }
          const child = this.projectile(data.ChainBullet, p.owner, Math.atan2(next.y - target.y, next.x - target.x), p.damage, state, target)
          child.hit = new Set(p.hit); child.hit.add(target.id)
        }
      }
    }
  },

  stepStatuses (char) {
    for (const status of char.statuses) if (status.remaining > 0 && status.due <= this.tick) {
      this.damage(char, status.damage, status.source, status.slot); status.remaining--; status.due += 20
    }
    char.statuses = char.statuses.filter(status => status.remaining > 0)
  },

  stepNpc (char) {
    const data = this.assets.tables.characters[char.dataId]
    if (char.entry || char === this.ball || char.team < 0) return
    if (data.AreaEffect && !char.aura) char.aura = this.area(data.AreaEffect, char, char.x, char.y, Math.abs(n(this.assets.named('area_effects', data.AreaEffect), 'Damage')) * char.scale)
    if (char.aura) { char.aura.x = char.x; char.aura.y = char.y }
    const enemy = this.nearestEnemy(char)
    if (!enemy) return
    const range = n(data, 'AutoAttackRange') * 100
    if (distance(char, enemy) <= range + enemy.radius && this.tick >= (char.nextAutoAttack || 0) && !this.map.trace(char.x, char.y, enemy.x, enemy.y, 0, true)) {
      char.nextAutoAttack = this.tick + Math.max(1, Math.ceil(n(data, 'AutoAttackSpeedMs', 1000) / 50))
      char.attackAngle = (Math.atan2(enemy.y - char.y, enemy.x - char.x) * 180 / Math.PI + 360) % 360
      const damage = n(data, 'AutoAttackDamage') * char.scale
      if (data.AutoAttackProjectile) this.projectile(data.AutoAttackProjectile, char, Math.atan2(enemy.y - char.y, enemy.x - char.x), damage,
        { slot: 0, target: { x: enemy.x, y: enemy.y }, definition: { CastingRange: n(data, 'AutoAttackRange', 30) } })
      else if (damage) this.damage(enemy, damage, char)
    }
    if (data.Type === 'Npc_Boss' && this.tick >= (char.npcNextSuper || 200) && char.skills[1]) {
      if (this.activate(char, 1, enemy.x, enemy.y)) char.npcNextSuper = this.tick + 200
    }
    if (char.skills.length && this.tick % 100 === 0) this.activate(char, 0, enemy.x, enemy.y)
    if (char.speed > 0 && distance(char, enemy) > Math.max(200, range * 0.8) && this.tick % 10 === 0) char.target = this.map.path(char.x, char.y, enemy.x, enemy.y, char.radius)[0]
  },

  stepArea (area) {
    const data = this.assets.tables.area_effects[area.dataId]; area.age++
    if (area.owner && area.owner.hp <= 0 && data.Type === 'Hot') { this.objects.delete(area.id); return }
    if (data.Type === 'BulletExplosion' && area.age === 1) {
      const count = n(data, 'CustomValue', 6)
      for (let i = 0; i < count; i++) this.projectile(data.BulletExplosionBullet, area.owner, i * Math.PI * 2 / count, area.damage,
        { slot: area.slot, target: { x: area.x + Math.cos(i * Math.PI * 2 / count) * 3000, y: area.y + Math.sin(i * Math.PI * 2 / count) * 3000 }, definition: { CastingRange: n(data, 'BulletExplosionBulletDistance', 30) } }, area)
    }
    const delay = data.Type === 'DelayedDamage' ? Math.ceil(n(data, 'CustomValue', 700) / 50) : 1
    const repeat = ['Hot', 'Dot', 'SmokeScreen'].includes(data.Type)
    if (area.age >= delay && (area.age === delay || (repeat && (area.age - delay) % 20 === 0))) {
      area.triggered = true
      for (const target of this.objects.values()) {
        if (target.dataClass !== 16 || target.hp <= 0 || target === this.ball || this.airborne(target) || distance(area, target) > area.radius + target.radius) continue
        if (['Heal', 'Hot'].includes(data.Type) && target.team === area.team) this.heal(target, Math.abs(area.damage))
        else if (data.Type === 'SmokeScreen' && target.team === area.team) { target.invisible = true; target.invisibleUntil = this.tick + 21 }
        else if (target.team !== area.team && ['Damage', 'DelayedDamage', 'Dot', 'Pushback'].includes(data.Type)) {
          if (data.Type !== 'Pushback') this.damage(target, area.damage, area.owner, area.slot)
          if (n(data, 'PushbackStrength')) this.push(target, area, n(data, 'PushbackStrength') * 6)
          if (n(data, 'FreezeStrength')) { target.slowUntil = this.tick + 21; target.slowPercent = n(data, 'FreezeStrength') / 1000 }
        }
      }
      if (enabled(data.DestroysEnvironment)) this.map.destroy(area.x, area.y, area.radius, this.tick)
    }
    if (area.age >= area.duration) this.objects.delete(area.id)
  },

  stepItem (item) {
    item.age++
    const data = this.assets.tables.items[item.dataId]; const name = data.Name
    if (['BoxOfMines', 'BoxOfBombs', 'BoxOfSelfDestructBombs'].includes(name) && item.age === 1) {
      this.deployTraps(item, data); return
    }
    if (data.TriggerAreaEffect) { this.advanceTrap(item, data); return }
    for (const char of this.characters.values()) if (char.hp > 0 && distance(item, char) < char.radius + 100) {
      if (name === 'Point') { char.score++; char.entry.score = char.score }
      else if (name === 'BattleRoyaleBuff') { char.maxHp += 400; char.hp += 400; char.scale += 0.1; char.score++ }
      else if (name === 'Health') this.heal(char, n(data, 'Value'))
      else continue
      this.objects.delete(item.id); break
    }
  }
}
