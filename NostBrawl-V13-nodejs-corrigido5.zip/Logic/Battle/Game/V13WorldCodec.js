'use strict'

const { V13BitStream } = require('./V13BitStream')
const { enabled } = require('../World/BattleAssets')
const { vint } = require('../Network/V13BattleCodec')
const CHARACTER_TYPES = Object.freeze({ Hero: 0, Npc_Boss: 1, Minion_FollowOwner: 2, Minion_FindEnemies: 3, Minion_Building: 4, Campaign_DefendTarget: 5, Pvp_Base: 6, Minion_Building_charges_ulti: 7, Minion_Dog: 8, LaserBall: 9, LootBox: 10, Minion_FindEnemies2: 11 })
const clamp = (v, min, max) => Math.max(min, Math.min(max, Math.trunc(v || 0)))

function encodeBase (stream, object, mode, large, projectile = false) {
  const wide = large || mode === 6 || mode === 9
  stream.uint(clamp(object.x, 0, wide ? 32767 : 8191), wide ? 15 : 13)
  stream.uint(clamp(object.y, 0, wide ? 65535 : 16383), wide ? 16 : 14)
  stream.uint(clamp(object.index, 0, mode === 6 || mode === 9 ? 255 : 127), mode === 6 || mode === 9 ? 8 : 7)
  stream.uint(clamp(object.z, 0, 4095), 12)
  if (!projectile) stream.uint(clamp(object.fade === undefined ? 10 : object.fade, 0, 15), 4)
}

function encodeSkill (stream, state, definition) {
  const maxTime = Math.max(1, Number(definition.ActiveTime) || 0)
  const bits = Math.max(8, Math.min(14, Math.ceil(Math.log2(maxTime + 1))))
  stream.uint(clamp(state.activeMs, 0, Math.min(maxTime, 2 ** bits - 1)), bits)
  stream.bool(state.onActivate)
  stream.uint(clamp(state.cooldownMs, 0, 4095), 12)
  if (Number(definition.MaxCharge) > 0) stream.uint(clamp(state.ammo, 0, 4095), 12)
  if (enabled(definition.SkillCanChange)) stream.uint(definition.id, 8)
}

function encodeCharacter (stream, object, own, mode, large, assets) {
  const data = assets.tables.characters[object.dataId]
  if (!data || CHARACTER_TYPES[data.Type] === undefined) throw new Error('Unknown native character type')
  const type = CHARACTER_TYPES[data.Type]
  encodeBase(stream, object, mode, large)
  const stationary = Number(data.Speed) === 0 && !Number(data.AutoAttackDamage)
  if (stationary) {
    stream.uint(clamp(object.state, 0, 7), 3)
    if (data.AreaEffect) stream.uint(clamp(object.attackAngle, 0, 359), 9)
  } else {
    if (own) stream.bool(true)
    stream.uint(clamp(object.attackAngle, 0, 359), 9)
    stream.uint(clamp(object.moveAngle, 0, 359), 9)
    stream.uint(clamp(object.state, 0, 7), 3)
    stream.bool(false).sint(-1, 6)
    stream.bool(false).bool(false).bool(false)
    stream.uint(0, 7).uint(0, 5)
  }
  const poisoned = (object.statuses || []).some(status => status.kind === 'poison' && status.remaining > 0)
  stream.bool(false).uint(poisoned ? 1 : 0, 2)
  if (poisoned) stream.bool(false)
  const hpBits = mode === 10 && type === 1 ? 21 : mode === 7 && Math.floor(object.index / 16) === 1 ? 18
    : [6, 9].includes(mode) || (mode === 10 && type === 0) || Number(data.Hitpoints) > 6399 ? 16 : 13
  stream.uint(clamp(object.hp, 0, 2 ** hpBits - 1), hpBits)
  stream.uint(clamp(object.maxHp, 0, 2 ** hpBits - 1), hpBits)
  if (type === 0) {
    stream.uint(clamp(object.score, 0, mode === 3 ? 127 : 63), mode === 3 ? 7 : 6)
    if (mode === 5) {
      stream.bool(Boolean(object.carryingBall))
      if (object.carryingBall) stream.uint(clamp(object.x, 0, 8191), 13).uint(clamp(object.y, 0, 16383), 14)
    }
    stream.uint(0, 13).uint(clamp(object.nativeExtra11, 0, 2047), 11)
    stream.bool(false).bool(Boolean(object.charging)).bool(false).bool(false)
    stream.bool(false).bool(Boolean(object.superSelected)).bool(false).bool(false).bool(false)
    if (own) stream.uint(clamp(object.powerLevel, 0, 15), 4)
    if (object.charging) stream.uint(clamp(object.chargeTotalTicks ? Math.trunc(1000 * (1 - object.chargeTicks / object.chargeTotalTicks)) : 0, 0, 1000), 10).uint(clamp(object.chargeType, 0, 15), 4)
  } else if (type === 9) stream.uint(object.carrier ? 1 : (object.vx || object.vy) ? 2 : 0, 2).uint(object.carrier ? object.carrier.team + 1 : 0, 2)
  else if (type === 8) stream.uint(0, 5)
  else {
    const chargeSkill = [data.WeaponSkill, data.UltimateSkill].filter(Boolean).some(name => assets.named('skills', name).BehaviorType === 'Charge')
    if (chargeSkill) {
      stream.bool(Boolean(object.charging))
      if (object.charging) stream.uint(clamp(object.chargeType, 0, 15), 4)
    }
  }
  if (mode === 10 && type === 1) stream.uint(0, 2)
  stream.uint(0, 2).bool(Boolean(object.invisible)).uint(0, 9)
  if (own) stream.sint(0, 9)
  stream.uint(0, 5) // Per-team revealed poison/buff instances.
  const skills = [data.WeaponSkill, data.UltimateSkill].filter(Boolean)
  for (let i = 0; i < skills.length; i++) encodeSkill(stream, (object.skills || [])[i] || {}, assets.named('skills', skills[i]))
}

function encodeProjectile (stream, object, mode, large, assets) {
  const data = assets.tables.projectiles[object.dataId]
  encodeBase(stream, object, mode, large, true)
  stream.uint(clamp(object.state, 0, 7), 3)
  if (object.state === 4) stream.bool(false).uint(0, large ? 14 : 10)
  else if (enabled(data.IsBouncing)) {
    stream.bool(object.bounceTileIndex !== null && object.bounceTileIndex !== undefined)
    if (object.bounceTileIndex !== null && object.bounceTileIndex !== undefined) stream.uint(clamp(object.bounceTileIndex, 0, large ? 16383 : 1023), large ? 14 : 10)
  }
  stream.bool(false)
  if (Number(data.TriggerWithDelayMs) || Number(data.PreExplosionTimeMs)) stream.uint(clamp(object.fuseTick, 0, 16383), 14)
  if (Number(data.PreExplosionTimeMs)) {
    stream.uint(clamp((object.target || {}).x, 0, large ? 32767 : 8191), large ? 15 : 13)
    stream.uint(clamp((object.target || {}).y, 0, large ? 65535 : 16383), large ? 16 : 14)
  }
  stream.uint(clamp(object.totalRange > 0 ? Math.round(1000 * (1 - object.remaining / object.totalRange)) : 0, 0, 1000), 10)
  if (data.Rendering !== 'DoNotRotateClip') stream.uint(clamp(object.angle, 0, 359), 9)
  stream.bool(Boolean(object.indirect))
  if (object.indirect) {
    stream.uint(clamp(object.target.x, 0, large ? 32767 : 8191), large ? 15 : 13)
    stream.uint(clamp(object.target.y, 0, large ? 65535 : 16383), large ? 16 : 14)
  }
}

function encodeArea (stream, object, mode, large, assets) {
  encodeBase(stream, object, mode, large)
  const data = assets.tables.area_effects[object.dataId]
  if (data.Type === 'DelayedDamage') stream.bool(Boolean(object.triggered))
  if (enabled(data.SyncAnimWithServer)) stream.uint(clamp(object.age, 0, 1023), 10)
}

function encodeItem (stream, object, mode, large) {
  encodeBase(stream, object, mode, large)
  if ([5, 7, 8, 11, 13].includes(object.dataId)) {
    stream.uint(clamp(object.valueA === undefined ? object.targetX === undefined ? object.x : object.targetX : object.valueA, 0, 16383), 14)
    stream.uint(clamp(object.valueB === undefined ? object.targetY === undefined ? object.y : object.targetY : object.valueB, 0, 16383), 14)
  } else if ([6, 12, 14].includes(object.dataId)) stream.uint(clamp(object.deploymentMs === undefined ? object.age : object.deploymentMs, 0, 2047), 11).uint(clamp(object.triggerMs === undefined ? object.remainingTicks : object.triggerMs, 0, 2047), 11)
}

function encodeHeader (stream, world, viewer) {
  const mode = world.mode.variation
  const own = world.characters.get(viewer.player.low_id)
  const ownId = own ? 1000000 + own.id : 0
  stream.uint(ownId, 21).uint(world.countdown ? clamp(world.countdown.due, 0, 32767) : 0, 15).bool(false).sint(-1, 4)
  stream.bool(false).bool(false).bool(false).bool(false)
  const map = world.map
  const wide = map.width >= 22
  if (!map.nativeHeader || map.nativeHeader.revision !== map.revision) {
    const tiles = new V13BitStream()
    tiles.uint(0, wide ? 6 : 5).uint(0, wide ? 7 : 6)
    tiles.uint(map.width - 1, wide ? 6 : 5).uint(map.height - 1, wide ? 7 : 6)
    for (let x = 0; x < map.width; x++) for (let y = 0; y < map.height; y++) {
      const tile = map.tile(x, y)
      if (enabled(tile.definition.IsDestructible) || (enabled(tile.definition.IsDestructibleNormalWeapon) && (enabled(tile.definition.BlocksMovement) || enabled(tile.definition.BlocksProjectiles)))) tiles.bool(map.destroyed.has(tile.index))
    }
    map.nativeHeader = { revision: map.revision, bytes: tiles.bytes(), bits: tiles.position }
  }
  stream.append(map.nativeHeader.bytes, map.nativeHeader.bits)
  for (const entry of world.players) {
    const character = world.characters.get(entry.player.low_id)
    stream.bool(character && character.hp > 0).bool(false)
    if (mode === 6) stream.uint(clamp(entry.rank, 0, 15), 4)
    if (entry.player.low_id === viewer.player.low_id) {
      stream.uint(clamp(character && character.superCharge, 0, 4095), 12)
      stream.bool(character && character.superSelected)
    }
  }
  if (mode === 6) stream.uint(clamp(world.alivePlayers, 0, 15), 4)
  if (mode === 9) stream.uint(clamp(world.aliveTeams, 0, 7), 3)
  if (mode === 5) stream.bool(!(world.goalPauseUntil > world.tick)).sint(world.goalTeam === undefined ? -1 : world.goalTeam, 1)
  if (mode === 2) stream.uint(clamp(world.baseHpPercent[0], 0, 127), 7).uint(clamp(world.baseHpPercent[1], 0, 127), 7)
  if (mode === 7 || mode === 10) stream.uint(clamp(world.bossHpPercent, 0, 127), 7)
  if (mode === 8) stream.uint(clamp(world.wave, 0, 127), 7).uint(clamp(world.baseHpPercent[0], 0, 127), 7).bool(false)
  for (const entry of world.players) {
    stream.uint(clamp(entry.score, 0, 255), 8)
    const kills = (entry.kills || []).slice(-15)
    stream.uint(kills.length, 4)
    for (const kill of kills) stream.uint(kill.victim, 4).sint(kill.value || 0, 3)
  }
  return stream
}

function encodeWorld (world, viewer, assets) {
  const stream = new V13BitStream()
  encodeHeader(stream, world, viewer)
  const mode = world.mode.variation
  const own = world.characters.get(viewer.player.low_id)
  const wide = world.map.width >= 22
  const objects = world.visibleObjects(viewer)
  if (objects.length > 127) throw new Error('v13 world view exceeds 127 objects')
  stream.uint(objects.length, 7)
  for (const object of objects) stream.dataRef(object.dataClass, object.dataId)
  for (const object of objects) stream.objectId(object.objectClass, object.id)
  for (const object of objects) {
    if (object.dataClass === 16) encodeCharacter(stream, object, object === own, mode, wide, assets)
    else if (object.dataClass === 6) encodeProjectile(stream, object, mode, wide, assets)
    else if (object.dataClass === 17) encodeArea(stream, object, mode, wide, assets)
    else if (object.dataClass === 18) encodeItem(stream, object, mode, wide)
    else throw new Error(`Unknown v13 data class ${object.dataClass}`)
  }
  if (mode === 7) stream.bool(false)
  return stream.bytes()
}

function visionPayload (world, viewer, assets) {
  if (world.nativeVisionPayload) return world.nativeVisionPayload(viewer)
  const bits = encodeWorld(world, viewer, assets)
  const length = Buffer.alloc(4); length.writeInt32BE(bits.length)
  const ack = viewer.session ? viewer.session.input.lastAcknowledged : 0
  return Buffer.concat([vint(world.tick), vint(ack), vint(0), vint(0), length, bits])
}
module.exports = { CHARACTER_TYPES, encodeBase, encodeSkill, encodeCharacter, encodeProjectile, encodeArea, encodeItem, encodeHeader, encodeWorld, visionPayload }
