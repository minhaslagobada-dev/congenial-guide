'use strict'
const { EventEmitter } = require('node:events')
const { rules } = require('../World/GameModes')
const { readDictRows } = require('../../../Files/CsvLogic/CsvRows')
const { encodeInput } = require('../Network/V13BattleCodec')
const { nativeVisionPayload } = require('../NativeVision')
const Skins = require('../../../Files/CsvLogic/Skins')
const path = require('node:path')

// A session adapter around original frames. It contains no movement, collision,
// attack, bot, Super, objective, spawn or game-over implementation.
class NativeBattleWorld extends EventEmitter {
  constructor (id, assets, mapId, humans, seed, runtime) {
    super(); this.id = id; this.assets = assets; this.mapId = mapId; this.seed = seed; this.runtime = runtime
    humans = humans.map((entry, index) => {
      const brawlerId = entry.brawlerId === undefined ? entry.player.brawler_id : entry.brawlerId
      let skinId = entry.skinId === undefined ? entry.player.skin_id || 0 : entry.skinId
      try { if (Skins.getBrawler(skinId) !== brawlerId) skinId = Skins.get_default_skin(brawlerId) } catch (_) { skinId = Skins.get_default_skin(brawlerId) }
      const level = entry.powerLevel === undefined ? Number((entry.player.Brawler_level || {})[brawlerId]) || 0 : entry.powerLevel
      return { ...entry, index, brawlerId, skinId, powerLevel: Math.max(0, Math.min(9, Math.trunc(level))) }
    })
    this.mode = rules(assets.tables.locations[mapId].GameMode)
    this.practice = this.mode.variation === 11
    this.phase = 'loading'; this.loadingTicks = 0; this.tick = 0; this.nativeActive = false
    const skins = readDictRows(path.resolve(__dirname, '../../../GameAssets/csv_logic/skins.csv')).slice(1)
    const cards = readDictRows(path.resolve(__dirname, '../../../GameAssets/csv_logic/cards.csv')).slice(1)
    const roster = humans.map(entry => {
      const hero = assets.hero(entry.brawlerId)
      const star = cards[Number((entry.player.Brawler_starPower || {})[entry.brawlerId])]
      const skin = skins[entry.skinId]
      return { hero: hero.Name, team: entry.team, accountId: entry.player.low_id, name: entry.player.name,
        powerLevel: Math.min(9, entry.powerLevel + 1),
        starCard: star && star.Target === hero.Name && star.MetaType === '4' ? star.Name : null,
        skin: skin && skin.Character === hero.Name ? skin.Name : null }
    })
    try {
      const prepared = runtime.create(id, assets.tables.locations[mapId].Name, seed, roster)
      this.nativeActive = true; this.loadingGameType = prepared.kind
      const byId = new Map(prepared.state.objects.map(object => [object.id, object]))
      this.players = prepared.state.players.map(native => {
        if (!native.bot) {
          const entry = humans[native.index]
          if (!entry || (this.mode.variation !== 6 && entry.team !== native.team)) throw new Error('Original human roster mismatch')
          return { ...entry, team: native.team, ready: false, rank: 0 }
        }
        const actor = byId.get(native.characterId)
        if (!actor) throw new Error('Original bot character missing')
        const brawlerId = actor.dataId - 16000000
        return { index: native.index, team: native.team, bot: true, ready: true, rank: 0, brawlerId,
          skinId: native.skinDataId === null ? Skins.get_default_skin(brawlerId) : native.skinDataId - 29000000,
          powerLevel: Math.max(0, (native.powerLevel || 1) - 1), session: null, client: null,
          player: { low_id: -(native.index + 1), high_id: 0, name: native.name, brawler_id: brawlerId } }
      })
      if (this.players.length !== this.mode.capacity) throw new Error('Original participant capacity mismatch')
      this.initialObjects = prepared.state.objects
      this.adopt(runtime.frame(id))
    } catch (error) {
      if (this.nativeActive) { try { runtime.destroy(id) } catch (_) {} }
      this.nativeActive = false; throw error
    }
  }

  adopt (frame) {
    this.state = frame.state; this.tick = frame.state.tick; this.snapshots = frame.vision
    for (const player of frame.state.players) if (player.rank) this.players[player.index].rank = player.rank
  }

  nativeVisionPayload (viewer) {
    const snapshot = this.snapshots[viewer.index]
    if (!snapshot || viewer.bot) throw new Error('Original human vision missing')
    return nativeVisionPayload(snapshot, viewer.session ? viewer.session.input.lastAcknowledged : 0)
  }

  // The original engine accepts commands from tick 1 and the v13 client only
  // leaves its intro once authoritative ticks advance: it does not send input
  // while the clock is frozen, so waiting for a first input deadlocks the
  // intro until the client's own retry. Clients that are still loading
  // receive the same full snapshots and join at the current tick.
  begin () {
    if (this.phase !== 'loading') return
    this.phase = 'running'; this.emit('started')
  }

  // Collect this tick's commands in arrival order (one packet per 30).
  collectInputs () {
    const packets = []
    for (const entry of this.players) {
      if (entry.bot || !entry.session || entry.session.closed) continue
      const inputs = entry.session.input.drain()
      for (let offset = 0; offset < inputs.length; offset += 30) {
        const commands = inputs.slice(offset, offset + 30)
        packets.push([entry.index, encodeInput({ tick: this.tick, sequence: commands.at(-1).counter, inputs: commands })])
      }
    }
    return packets
  }

  completeStep (frame) {
    if (this.phase === 'finished') return
    this.adopt(frame)
    if (this.state.ended) {
      if (this.mode.variation === 11) this.finish(null, 'abandoned')
      else this.finish(this.winner(), 'native-game-over')
    }
  }

  step () {
    if (this.phase === 'finished') return
    this.begin()
    const packets = this.collectInputs()
    if (this.runtime.step) { this.completeStep(this.runtime.step(this.id, packets)); return }
    for (const [index, bytes] of packets) this.runtime.input(this.id, index, bytes)
    this.completeStep(this.runtime.frame(this.id))
  }

  // Non-blocking tick: one engine round trip for inputs + frame while the
  // event loop keeps serving sockets. Resolves to true when a frame was adopted.
  stepAsync () {
    if (this.phase === 'finished') return Promise.resolve(false)
    this.begin()
    const packets = this.collectInputs()
    return this.runtime.stepAsync(this.id, packets).then(frame => {
      if (this.phase === 'finished') return false
      this.completeStep(frame); return true
    })
  }

  winner () {
    const variation = this.mode.variation
    if ([0, 2, 3, 5].includes(variation)) {
      const [first, second] = this.state.teamScores
      return first === second ? null : first > second ? 0 : 1
    }
    if ([6, 9].includes(variation)) {
      const winner = this.players.find(player => player.rank === 1)
      if (!winner || this.players.some(player => !player.rank)) throw new Error('Original placements incomplete at game over')
      return winner.team
    }
    if (variation === 7) {
      const boss = this.state.players.find(player => player.team === 1)
      const actor = boss && this.state.objects.find(object => object.id === boss.characterId)
      return actor && actor.hp > 0 ? 1 : 0
    }
    const type = variation === 8 ? 'Pvp_Base' : variation === 10 ? 'Npc_Boss' : null
    if (!type) throw new Error('Native result projection is unavailable for this mode')
    const objective = this.initialObjects.find(object => this.assets.tables.characters[object.dataId - 16000000]?.Type === type)
    if (!objective) throw new Error('Original mode objective missing')
    const current = this.state.objects.find(object => object.id === objective.id)
    const alive = Boolean(current && current.hp > 0)
    return variation === 8 ? (alive ? 0 : 1) : (alive ? 1 : 0)
  }

  // A dropped connection keeps the brawler in the original simulation so the
  // account can rejoin (BattleCoordinator.reconnect). Only an explicit exit by
  // every human, or no human connected for the whole reconnection window,
  // abandons the match.
  disconnectPlayer (entry, left = false) {
    entry.disconnected = true
    if (left) entry.left = true
    const humans = this.players.filter(player => !player.bot)
    if (humans.every(player => player.left)) { this.finish(null, 'abandoned'); return }
    if (humans.every(player => player.disconnected) && this.allDisconnectedAt === undefined) this.allDisconnectedAt = Date.now()
  }

  rejoin (entry) {
    entry.disconnected = false; entry.left = false
    this.allDisconnectedAt = undefined
  }

  finish (winner, reason) {
    if (this.phase === 'finished') return false
    this.phase = 'finished'; this.outcome = { winner, reason, tick: this.tick }
    try { this.emit('finished', this.outcome) } finally {
      if (this.nativeActive) {
        this.nativeActive = false
        if (!this.runtime.closed) {
          try { this.runtime.destroy(this.id) } catch (error) { this.emit('cleanupError', error) }
        }
      }
    }
    return true
  }
}
module.exports = { NativeBattleWorld }
