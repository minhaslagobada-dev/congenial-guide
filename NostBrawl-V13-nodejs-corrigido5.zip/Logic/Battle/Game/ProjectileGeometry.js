'use strict'
// CSV spread is an offset in native logic units, not an angle in degrees.
function spreadFor (spread, pattern, shot, shots, pellet, pellets) {
  if (!pattern) return pellets === 1 ? 0 : -spread + Math.trunc(2 * spread / (pellets - 1)) * pellet
  if (shots < 2) return 0
  if (pattern === 2) return Math.trunc(2 * spread * shot / (shots - 1)) - spread
  if (pattern === 3 || shots >= 5) {
    const degrees = Math.trunc((pattern === 3 ? 720 : 1080) * shot / (shots - 1))
    return Math.round(Math.sin(degrees * Math.PI / 180) * 1024) * spread >> 10
  }
  return [0, spread, -spread][shot % 3]
}
function direction (dx, dy, spread) {
  const distance = Math.hypot(dx, dy)
  if (!distance) return 0
  const offset = Math.trunc(Math.trunc(distance) * Math.abs(spread) / 300)
  if (offset >= 3) {
    const sx = dx; const sy = dy; const sign = Math.sign(spread)
    dx -= Math.trunc(sy * offset / distance) * sign
    dy += Math.trunc(sx * offset / distance) * sign
  }
  return Math.atan2(dy, dx)
}
function speedBonus (speed, count, pellet, shot) {
  return count < 4 ? 0 : [0, Math.trunc(Math.trunc(speed / 7) / 2), Math.trunc(speed / 7)][(pellet + shot) % (count === 5 ? 2 : 3)]
}
module.exports = { spreadFor, direction, speedBonus }
