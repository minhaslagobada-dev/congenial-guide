'use strict'
const { enabled } = require('../World/BattleAssets')
const number = (data, key, fallback = 0) => Number(data[key]) || fallback
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y)

module.exports = {
  // Bots use the same movement, ammo, collision, skills and damage routines as
  // connected players. Their decisions do not create client commands/sessions.
  stepBot (char) {
    if (this.goalPauseUntil > this.tick || char.hp <= 0 || char.stunUntil > this.tick || char.charging || this.tick % 5 !== char.entry.index % 5) return
    const visible = this.visibleObjects(char.entry)
    const enemies = visible.filter(object => object.dataClass === 16 && object.hp > 0 && object.team !== char.team && object !== this.ball &&
      (object.team >= 0 || this.assets.tables.characters[object.dataId].Type === 'LootBox'))
    enemies.sort((a, b) => distance(char, a) - distance(char, b))
    const enemy = enemies[0]
    const weapon = char.skills[0]
    const range = weapon ? number(weapon.definition, 'CastingRange') * 100 : 0
    let goal = enemy
    let collecting = false
    const mode = this.mode.variation

    if (this.ball && this.ball.carrier === char) {
      const goals = this.map.markers.get(char.team === 0 ? '7' : '6') || []
      if (goals.length) {
        goal = goals[Math.floor(goals.length / 2)]
        if (distance(char, goal) < 2200 && !this.map.trace(char.x, char.y, goal.x, goal.y, 100)) this.kickBall(char, goal.x, goal.y, char.superCharge >= 4000)
        else this.navigateBot(char, goal)
      }
      return
    }
    if (this.ball && !this.ball.carrier) { goal = this.ball; collecting = true }
    if ([0, 6, 9].includes(mode)) {
      const pickups = visible.filter(object => object.dataClass === 18 && ['Point', 'BattleRoyaleBuff'].includes(this.assets.tables.items[object.dataId].Name))
      pickups.sort((a, b) => distance(char, a) - distance(char, b))
      if (pickups[0] && (distance(char, pickups[0]) < 1800 || !enemy)) { goal = pickups[0]; collecting = true }
      if (!goal) goal = { x: this.map.logicWidth / 2, y: this.map.logicHeight / 2 }
    }
    if (mode === 2 && !enemy) goal = (this.bases || []).find(base => base.team !== char.team && base.hp > 0)
    if (!goal && this.mode.cooperative) goal = (this.bases || [])[0]

    if (enemy) {
      const indirect = weapon && weapon.definition.Projectile && enabled(this.assets.named('projectiles', weapon.definition.Projectile).Indirect)
      const clearShot = indirect || !this.map.trace(char.x, char.y, enemy.x, enemy.y, 0, true)
      const near = distance(char, enemy)
      if (weapon && near <= range + enemy.radius && clearShot) this.activate(char, 0, enemy.x, enemy.y)
      if (char.superCharge >= 4000 && char.skills[1]) {
        const superSkill = char.skills[1].definition
        const superRange = number(superSkill, 'CastingRange') * 100
        let target = enemy
        if (char.dataId === 13) {
          target = Array.from(this.characters.values()).filter(ally => ally.team === char.team && ally.hp > 0 && ally.hp < ally.maxHp * 0.7 && distance(char, ally) <= superRange)
            .sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0]
        } else if (char.dataId === 16) target = char
        if (target && (distance(char, target) <= superRange + (target.radius || 0) || superSkill.BehaviorType === 'Invisibility')) this.activate(char, 1, target.x, target.y)
      }
      if (!collecting && goal === enemy && near < range * 0.75 && clearShot) {
        char.target = null
        return
      }
    }
    if (goal) this.navigateBot(char, goal)
  },

  navigateBot (char, goal) {
    const moved = !char.botGoal || distance(char.botGoal, goal) > 300
    if (char.target && !moved && this.tick < char.botRepathAt && char.botMapRevision === this.map.revision) return
    const destination = this.freePoint(goal.x, goal.y, char.radius)
    char.botGoal = { x: goal.x, y: goal.y }; char.botRepathAt = this.tick + 20; char.botMapRevision = this.map.revision
    char.target = this.map.path(char.x, char.y, destination.x, destination.y, char.radius)[0] || null
  }
}
