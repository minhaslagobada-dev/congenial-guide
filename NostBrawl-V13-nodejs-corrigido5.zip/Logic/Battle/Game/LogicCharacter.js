'use strict'

class LogicCharacter {
  encode (stream, participants = null) {
    if (participants === null || participants === undefined) {
      participants = this.participants !== undefined ? this.participants : null
    }
    if (participants === null || participants === undefined) {
      const player = this.player
      participants = [{
        index: 0,
        brawler_id: Math.trunc(player.brawler_id || 0)
      }]
    }
    stream.writePositiveInt(participants.length, 7)
    for (const entry of participants) {
      stream.writePositiveInt(16, 5)
      stream.writePositiveInt(Math.trunc(entry.brawler_id), 8)
    }
    for (let index = 0; index < participants.length; index++) {
      stream.writePositiveInt(index, 14)
    }

    for (const entry of participants) {
      stream.writePositiveVInt(3125, 4)
      stream.writePositiveVInt(9500, 4)
      stream.writePositiveInt(0, 3)
      stream.writePositiveInt(0, 4)
      stream.writePositiveInt(10, 4)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 3)
      stream.writePositiveInt(0, 1)
      stream.writeInt(63, 6)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 2)
      stream.writePositiveInt(3600, 13)
      stream.writePositiveInt(3600, 13)
      stream.writePVIntMax255OZ(0)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 4)
      stream.writePositiveInt(0, 2)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 9)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 5)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(3000, 12)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(0, 8)
    }
  }
}

module.exports = { LogicCharacter }
module.exports.default = LogicCharacter
