'use strict'
const { vint } = require('./Network/V13BattleCodec')

// The bitstream comes directly from the original server frame encoder. Only
// the existing v13 transport header surrounds it here; no world fields are encoded.
function nativeVisionPayload (snapshot, acknowledged = 0) {
  if (!snapshot || !Number.isInteger(snapshot.tick) || snapshot.tick < 0 ||
      !Number.isInteger(snapshot.bits) || snapshot.bits <= 0 || snapshot.bits > 1000000 ||
      typeof snapshot.hex !== 'string' || !/^[0-9a-f]+$/i.test(snapshot.hex) ||
      snapshot.hex.length !== Math.ceil(snapshot.bits / 8) * 2) throw new Error('Invalid original native snapshot')
  const bits = Buffer.from(snapshot.hex, 'hex')
  const length = Buffer.alloc(4); length.writeInt32BE(bits.length)
  return Buffer.concat([vint(snapshot.tick), vint(acknowledged), vint(0), vint(0), length, bits])
}
module.exports = { nativeVisionPayload }
