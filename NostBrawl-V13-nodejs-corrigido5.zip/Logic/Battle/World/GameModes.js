'use strict'

// Recovered from v13 LogicLocationData::getGameModeVariation,
// libg.so 0x35adcc..0x35af7c. These are not the result-upload enums.
const VARIATIONS = Object.freeze({
  CoinRush: 0, AttackDefend: 2, BountyHunter: 3, LaserBall: 5,
  BattleRoyale: 6, BossFight: 7, Survival: 8,
  BattleRoyaleTeam: 9, Raid: 10, Tutorial: 11
})
function rules (name) {
  const variation = VARIATIONS[name]
  if (variation === undefined) throw new Error(`Unsupported v13 game mode: ${name}`)
  let capacity = 6; let teamSize = 3
  if (variation === 6) { capacity = 10; teamSize = 1 }
  if (variation === 9) { capacity = 10; teamSize = 2 }
  if (variation === 8 || variation === 10) { capacity = 3; teamSize = 3 }
  if (variation === 11) { capacity = 1; teamSize = 1 }
  return { name, variation, capacity, teamSize: variation === 7 ? 5 : teamSize, teamCapacities: variation === 7 ? [5, 1] : null, cooperative: variation === 8 || variation === 10 }
}
module.exports = { VARIATIONS, rules }
