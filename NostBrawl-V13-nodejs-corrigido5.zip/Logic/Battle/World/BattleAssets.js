'use strict'

const path = require('path')
const { readDictRows } = require('../../../Files/CsvLogic/CsvRows')
const { ValueError } = require('../../../Utils/Errors')

const ROOT = path.resolve(__dirname, '../../../GameAssets/csv_logic')
function rows (name) { return readDictRows(path.join(ROOT, name + '.csv')).slice(1) }
function enabled (value) { return String(value).toLowerCase() === 'true' }

class BattleAssets {
  constructor () {
    this.tables = {}
    this.names = {}
    for (const table of ['characters', 'skills', 'projectiles', 'area_effects', 'items', 'tiles', 'locations', 'globals']) {
      const entries = rows(table).map((row, id) => Object.freeze({ ...row, id }))
      this.tables[table] = Object.freeze(entries)
      this.names[table] = new Map(entries.map(row => [row.Name, row]))
    }
    this.tileCodes = new Map(this.tables.tiles.map(row => [row.TileCode, row]))
    this.maps = new Map()
    let group
    for (const row of rows('maps')) {
      if (row.Group) {
        group = { name: row.Group, fromBlocks: enabled(row.ConstructFromBlocks), rows: [] }
        this.maps.set(group.name, group)
      }
      if (group && row.Data) group.rows.push(row.Data)
    }
    this.maps.delete('end')
    this.blocks = new Map()
    let block
    for (const row of rows('map_blocks')) {
      if (row.Group && row.Group !== '****') {
        block = []
        if (!this.blocks.has(row.Group)) this.blocks.set(row.Group, [])
        this.blocks.get(row.Group).push(block)
      }
      if (block && row.Data) block.push(row.Data)
    }
    this.heroes = Object.freeze(this.tables.characters.filter(row => row.Type === 'Hero' && !enabled(row.Disabled) && !enabled(row.LockedForChronos)))
    for (const hero of this.heroes) {
      this.named('skills', hero.WeaponSkill)
      this.named('skills', hero.UltimateSkill)
    }
    for (const entry of this.maps.values()) {
      if (!entry.fromBlocks) this.validateGrid(entry.rows, entry.name)
    }
  }

  global (name, fallback = 0) {
    const row = this.names.globals.get(name)
    return row && row.NumberValue !== '' ? Number(row.NumberValue) : fallback
  }

  named (table, name) {
    const row = this.names[table] && this.names[table].get(name)
    if (!row) throw new ValueError(`Unknown ${table} entry: ${name}`)
    return row
  }

  hero (id) {
    const hero = this.tables.characters[id]
    if (!hero || !this.heroes.includes(hero)) throw new ValueError('Brawler unavailable in v13')
    return hero
  }

  validateGrid (grid, name) {
    if (!grid.length || !grid[0].length || grid.some(row => row.length !== grid[0].length)) throw new ValueError(`Invalid rectangular map: ${name}`)
    if (grid.length > 64 || grid[0].length > 64) throw new ValueError(`Map outside v13 tile limits: ${name}`)
    for (const row of grid) for (const code of row) {
      if (!this.tileCodes.has(code) && !/^[0-9]$/.test(code)) throw new ValueError(`Unknown tile ${code} in ${name}`)
    }
  }

  map (name, chooseBlock = () => 0) {
    const entry = this.maps.get(name)
    if (!entry) throw new ValueError(`Unknown v13 map: ${name}`)
    if (!entry.fromBlocks) return entry.rows.slice()
    const grid = []
    for (const row of entry.rows) {
      const fields = row.split(',')
      if (fields.length % 2) throw new ValueError('Invalid map block specification')
      const selected = []
      for (let col = 0; col < fields.length; col += 2) {
        const options = this.blocks.get(fields[col])
        if (!options || !options.length) throw new ValueError(`Missing map block: ${fields[col]}`)
        const choice = chooseBlock(options.length, fields[col])
        if (!Number.isInteger(choice) || choice < 0 || choice >= options.length) throw new ValueError('Invalid map block selection')
        const block = options[choice].slice()
        if (fields[col + 1] !== '0') throw new ValueError('Unsupported map block transform in v13 data')
        this.validateGrid(block, fields[col])
        selected.push(block)
      }
      if (selected.some(block => block.length !== selected[0].length)) throw new ValueError('Mismatched map block heights')
      for (let y = 0; y < selected[0].length; y++) grid.push(selected.map(block => block[y]).join(''))
    }
    this.validateGrid(grid, name)
    return grid
  }

  locationMap (locationId, chooseBlock) {
    const location = this.tables.locations[locationId]
    if (!location || !location.AllowedMaps) throw new ValueError('Invalid v13 location')
    return { location, grid: this.map(location.AllowedMaps, chooseBlock) }
  }
}

let shared
function battleAssets () { if (!shared) shared = new BattleAssets(); return shared }
module.exports = { BattleAssets, battleAssets, enabled }
