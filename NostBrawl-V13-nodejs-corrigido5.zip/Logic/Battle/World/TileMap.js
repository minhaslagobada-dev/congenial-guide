'use strict'

const { enabled } = require('./BattleAssets')
const TILE = 300
const EPS = 1e-7
const clamp = (v, low, high) => Math.max(low, Math.min(high, v))

// Exact segment/circle versus tile collision: straight faces plus rounded
// corners. Expanding to a square alone incorrectly blocks diagonal movement.
function hitRectangle (x, y, dx, dy, radius, left, top, right, bottom) {
  let best = null
  const offer = (t, nx, ny) => {
    if (t >= -EPS && t <= 1 + EPS && dx * nx + dy * ny < -EPS && (!best || t < best.t)) best = { t: clamp(t, 0, 1), nx, ny }
  }
  if (dx > 0) {
    const t = (left - radius - x) / dx; const yy = y + t * dy
    if (yy >= top - EPS && yy <= bottom + EPS) offer(t, -1, 0)
  } else if (dx < 0) {
    const t = (right + radius - x) / dx; const yy = y + t * dy
    if (yy >= top - EPS && yy <= bottom + EPS) offer(t, 1, 0)
  }
  if (dy > 0) {
    const t = (top - radius - y) / dy; const xx = x + t * dx
    if (xx >= left - EPS && xx <= right + EPS) offer(t, 0, -1)
  } else if (dy < 0) {
    const t = (bottom + radius - y) / dy; const xx = x + t * dx
    if (xx >= left - EPS && xx <= right + EPS) offer(t, 0, 1)
  }
  const a = dx * dx + dy * dy
  if (radius > 0 && a > EPS) {
    for (const [cx, cy, sx, sy] of [[left, top, -1, -1], [right, top, 1, -1], [left, bottom, -1, 1], [right, bottom, 1, 1]]) {
      const ox = x - cx; const oy = y - cy
      const b = ox * dx + oy * dy
      const discriminant = b * b - a * (ox * ox + oy * oy - radius * radius)
      if (discriminant < 0) continue
      const t = (-b - Math.sqrt(discriminant)) / a
      const nx = (x + t * dx - cx) / radius
      const ny = (y + t * dy - cy) / radius
      if (nx * sx >= -EPS && ny * sy >= -EPS) offer(t, nx, ny)
    }
  }
  return best
}

class MinHeap {
  constructor () { this.items = [] }
  push (item) {
    const a = this.items; let i = a.length; a.push(item)
    while (i > 0) { const p = (i - 1) >> 1; if (a[p].score <= item.score) break; a[i] = a[p]; i = p }
    a[i] = item
  }
  pop () {
    const a = this.items; const first = a[0]; const last = a.pop()
    if (a.length) {
      let i = 0
      while (i * 2 + 1 < a.length) {
        let c = i * 2 + 1
        if (c + 1 < a.length && a[c + 1].score < a[c].score) c++
        if (a[c].score >= last.score) break
        a[i] = a[c]; i = c
      }
      a[i] = last
    }
    return first
  }
}

class TileMap {
  constructor (grid, assets) {
    assets.validateGrid(grid, 'battle')
    this.width = grid[0].length
    this.height = grid.length
    this.logicWidth = this.width * TILE
    this.logicHeight = this.height * TILE
    this.tiles = []
    this.markers = new Map()
    this.destroyed = new Map()
    this.revision = 0
    for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) {
      const code = grid[y][x]
      const definition = assets.tileCodes.get(code) || assets.tileCodes.get('.')
      this.tiles.push(Object.freeze({ code, definition, x, y, index: this.tiles.length }))
      if (/^[0-9]$/.test(code)) {
        if (!this.markers.has(code)) this.markers.set(code, [])
        this.markers.get(code).push(Object.freeze({ x: x * TILE + 150, y: y * TILE + 150 }))
      }
    }
  }

  tile (x, y) { return x < 0 || y < 0 || x >= this.width || y >= this.height ? null : this.tiles[y * this.width + x] }
  blocks (tile, projectiles = false) {
    return !tile || (!this.destroyed.has(tile.index) && enabled(tile.definition[projectiles ? 'BlocksProjectiles' : 'BlocksMovement']))
  }

  canOccupy (x, y, radius = 0, projectiles = false) {
    if (![x, y, radius].every(Number.isFinite) || radius < 0 || x - radius < 0 || y - radius < 0 || x + radius > this.logicWidth || y + radius > this.logicHeight) return false
    const x0 = clamp(Math.floor((x - radius) / TILE), 0, this.width - 1)
    const x1 = clamp(Math.floor((x + radius) / TILE), 0, this.width - 1)
    const y0 = clamp(Math.floor((y - radius) / TILE), 0, this.height - 1)
    const y1 = clamp(Math.floor((y + radius) / TILE), 0, this.height - 1)
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
      if (!this.blocks(this.tile(tx, ty), projectiles)) continue
      const cx = clamp(x, tx * TILE, (tx + 1) * TILE)
      const cy = clamp(y, ty * TILE, (ty + 1) * TILE)
      if ((x - cx) ** 2 + (y - cy) ** 2 < radius * radius - EPS || (radius === 0 && x >= tx * TILE && x < (tx + 1) * TILE && y >= ty * TILE && y < (ty + 1) * TILE)) return false
    }
    return true
  }

  trace (x, y, targetX, targetY, radius = 0, projectiles = false, ignoreTiles = false) {
    if (![x, y, targetX, targetY, radius].every(Number.isFinite) || radius < 0) throw new RangeError('Invalid collision coordinates')
    const dx = targetX - x; const dy = targetY - y
    let best = null
    const offer = hit => { if (hit && (!best || hit.t < best.t)) best = hit }
    for (const [delta, pos, low, high, nx, ny] of [[dx, x, radius, this.logicWidth - radius, 1, 0], [dy, y, radius, this.logicHeight - radius, 0, 1]]) {
      if (delta < 0 && pos + delta < low) offer({ t: Math.max(0, (low - pos) / delta), nx, ny, tile: null })
      if (delta > 0 && pos + delta > high) offer({ t: Math.max(0, (high - pos) / delta), nx: -nx, ny: -ny, tile: null })
    }
    if (ignoreTiles) return best
    const x0 = clamp(Math.floor((Math.min(x, targetX) - radius) / TILE), 0, this.width - 1)
    const x1 = clamp(Math.floor((Math.max(x, targetX) + radius) / TILE), 0, this.width - 1)
    const y0 = clamp(Math.floor((Math.min(y, targetY) - radius) / TILE), 0, this.height - 1)
    const y1 = clamp(Math.floor((Math.max(y, targetY) + radius) / TILE), 0, this.height - 1)
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
      const tile = this.tile(tx, ty)
      if (!this.blocks(tile, projectiles)) continue
      const hit = hitRectangle(x, y, dx, dy, radius, tx * TILE, ty * TILE, (tx + 1) * TILE, (ty + 1) * TILE)
      if (hit) offer({ ...hit, tile })
    }
    return best
  }

  move (x, y, targetX, targetY, radius) {
    if (!this.canOccupy(x, y, radius)) return { x, y }
    let dx = targetX - x; let dy = targetY - y
    for (let pass = 0; pass < 4 && dx * dx + dy * dy > EPS; pass++) {
      const hit = this.trace(x, y, x + dx, y + dy, radius)
      if (!hit) { x += dx; y += dy; break }
      const t = Math.max(0, hit.t - 0.001 / Math.max(1, Math.hypot(dx, dy)))
      x += dx * t; y += dy * t
      dx *= 1 - t; dy *= 1 - t
      const normal = dx * hit.nx + dy * hit.ny
      if (normal < 0) { dx -= normal * hit.nx; dy -= normal * hit.ny }
    }
    return { x, y }
  }

  destroy (x, y, radius, tick, normalWeapon = false) {
    const removed = []
    const x0 = clamp(Math.floor((x - radius) / TILE), 0, this.width - 1)
    const x1 = clamp(Math.floor((x + radius) / TILE), 0, this.width - 1)
    const y0 = clamp(Math.floor((y - radius) / TILE), 0, this.height - 1)
    const y1 = clamp(Math.floor((y + radius) / TILE), 0, this.height - 1)
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
      const tile = this.tile(tx, ty); const d = tile.definition
      if (this.destroyed.has(tile.index) || !(normalWeapon ? enabled(d.IsDestructibleNormalWeapon) : enabled(d.IsDestructible) || enabled(d.IsDestructibleNormalWeapon))) continue
      const cx = clamp(x, tx * TILE, (tx + 1) * TILE); const cy = clamp(y, ty * TILE, (ty + 1) * TILE)
      if ((x - cx) ** 2 + (y - cy) ** 2 > radius ** 2) continue
      const seconds = Number(d.RespawnSeconds) || 0
      this.destroyed.set(tile.index, seconds > 0 ? tick + seconds * 20 : Infinity)
      removed.push(tile.index)
    }
    if (removed.length) this.revision++
    return removed
  }

  tick (tick) {
    for (const [index, due] of this.destroyed) {
      if (due <= tick) { this.destroyed.delete(index); this.revision++ }
    }
  }

  path (x, y, targetX, targetY, radius) {
    if (!this.canOccupy(x, y, radius) || !this.canOccupy(targetX, targetY, radius)) return []
    if (!this.trace(x, y, targetX, targetY, radius)) return [{ x: targetX, y: targetY }]
    const sx = Math.floor(x / TILE); const sy = Math.floor(y / TILE)
    const gx = Math.min(this.width - 1, Math.floor(targetX / TILE)); const gy = Math.min(this.height - 1, Math.floor(targetY / TILE))
    const start = sy * this.width + sx; const goal = gy * this.width + gx
    const cost = new Float64Array(this.tiles.length).fill(Infinity)
    const previous = new Int32Array(this.tiles.length).fill(-1)
    const open = new MinHeap(); const visited = new Uint8Array(this.tiles.length)
    cost[start] = 0; open.push({ index: start, score: 0 })
    while (open.items.length) {
      const current = open.pop().index
      if (visited[current]) continue
      if (current === goal) {
        const points = [{ x: targetX, y: targetY }]
        for (let i = goal; i !== start; i = previous[i]) {
          if (i < 0) return []
          points.push({ x: (i % this.width) * TILE + 150, y: Math.floor(i / this.width) * TILE + 150 })
        }
        points.reverse()
        const out = []; let origin = { x, y }
        for (let i = 0; i < points.length;) {
          let last = i
          while (last + 1 < points.length && !this.trace(origin.x, origin.y, points[last + 1].x, points[last + 1].y, radius)) last++
          origin = points[last]; out.push(origin); i = last + 1
        }
        return out
      }
      visited[current] = 1
      const cx = current % this.width; const cy = Math.floor(current / this.width)
      const fromX = current === start ? x : cx * TILE + 150
      const fromY = current === start ? y : cy * TILE + 150
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue
        const nx = cx + dx; const ny = cy + dy
        if (nx < 0 || ny < 0 || nx >= this.width || ny >= this.height) continue
        const next = ny * this.width + nx
        if (visited[next]) continue
        const px = next === goal ? targetX : nx * TILE + 150; const py = next === goal ? targetY : ny * TILE + 150
        if (!this.canOccupy(px, py, radius) || this.trace(fromX, fromY, px, py, radius)) continue
        const nextCost = cost[current] + Math.hypot(px - fromX, py - fromY)
        if (nextCost >= cost[next]) continue
        cost[next] = nextCost; previous[next] = current
        open.push({ index: next, score: nextCost + Math.hypot(targetX - px, targetY - py) })
      }
    }
    return []
  }
}

module.exports = { TileMap, TILE }
