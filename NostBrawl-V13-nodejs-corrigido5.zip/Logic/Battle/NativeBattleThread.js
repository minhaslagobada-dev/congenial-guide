'use strict'
const { parentPort, workerData } = require('node:worker_threads')
const { NativeBattleRuntime } = require('./NativeBattleRuntime')
const runtime = new NativeBattleRuntime(workerData.options)
function reply (control, buffer, result, error) {
  const signal = new Int32Array(control)
  let bytes = Buffer.from(JSON.stringify(error ? { error: error.message, fatal: runtime.closed } : { result }))
  if (bytes.length > buffer.byteLength) { error = new Error('Native response exceeded shared buffer'); bytes = Buffer.from(JSON.stringify({ error: error.message })) }
  new Uint8Array(buffer).set(bytes); Atomics.store(signal, 1, bytes.length)
  Atomics.store(signal, 0, error ? -1 : 1); Atomics.notify(signal, 0)
}
runtime.on('engineFailure', error => parentPort.postMessage({ engineFailure: error.message }))
runtime.start().then(() => reply(workerData.control, workerData.buffer, true), error => reply(workerData.control, workerData.buffer, null, error))
parentPort.on('message', async ({ command, fields, control, buffer, async: asyncId }) => {
  if (asyncId) {
    // Pipelined request: the coordinator thread keeps serving sockets while
    // the engine computes; the reply is a message, not a shared-memory wake.
    try {
      const result = await runtime.request(command, fields)
      parentPort.postMessage({ asyncId, result })
    } catch (error) { parentPort.postMessage({ asyncId, error: error.message, fatal: runtime.closed }) }
    return
  }
  try {
    const result = command === 'shutdown' ? await runtime.close() : await runtime.request(command, fields)
    reply(control, buffer, result === undefined ? true : result)
    if (command === 'shutdown') parentPort.close()
  } catch (error) { reply(control, buffer, null, error) }
})
