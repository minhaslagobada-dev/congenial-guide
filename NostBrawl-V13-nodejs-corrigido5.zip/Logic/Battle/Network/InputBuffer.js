'use strict'

// Retransmitted UDP commands must never
// execute an attack or spend ammunition twice. Commit only on the battle tick.
class InputBuffer {
  constructor (capacity = 128) {
    this.capacity = capacity
    this.pending = new Map()
    this.committed = -1
    this.highest = -1
    this.lastAcknowledged = 0
    this.dropped = 0
  }

  push (inputs) {
    let added = 0
    for (const input of inputs) {
      if (!Number.isInteger(input.counter) || input.counter < 0 || input.counter > 2147483647 ||
          !Number.isInteger(input.category) || input.category !== 1 ||
          !Number.isInteger(input.code) || input.code < 0 || input.code > 110 ||
          !Number.isInteger(input.x) || Math.abs(input.x) > 32767 ||
          !Number.isInteger(input.y) || Math.abs(input.y) > 32767) { this.dropped++; continue }
      const index = input.counter
      if (index <= this.committed || this.pending.has(index)) continue
      if ((this.highest >= 0 && index - this.highest > 1024) || this.pending.size >= this.capacity) { this.dropped++; continue }
      this.highest = Math.max(this.highest, index)
      this.pending.set(index, { ...input })
      added++
    }
    return added
  }

  drain () {
    const indices = Array.from(this.pending.keys()).sort((a, b) => a - b)
    const out = []
    for (const index of indices) {
      out.push(this.pending.get(index))
      this.committed = index
      this.lastAcknowledged = index
    }
    this.pending.clear()
    return out
  }

  clear () { this.pending.clear() }
}

module.exports = { InputBuffer }
