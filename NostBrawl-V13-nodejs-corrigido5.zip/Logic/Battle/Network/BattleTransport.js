'use strict'

const net = require('net')
const { EventEmitter } = require('events')
const { performance } = require('perf_hooks')
const { UdpGateway } = require('./UdpGateway')
const { InputBuffer } = require('./InputBuffer')
const { decodeInput } = require('./V13BattleCodec')

function isPrivateIPv4 (ip) {
  if (!net.isIPv4(ip)) return false
  const [a, b] = ip.split('.').map(Number)
  return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254)
}

class BattleTransport extends EventEmitter {
  constructor (settings = {}) {
    super()
    this.settings = settings
    if (settings.Transport !== undefined && !['auto', 'udp', 'tcp'].includes(String(settings.Transport).toLowerCase())) throw new Error('Battle.Transport must be "auto", "udp" or "tcp"')
    if (settings.AdvertiseHost && !net.isIPv4(settings.AdvertiseHost)) throw new Error('Battle.AdvertiseHost must be a public or LAN IPv4 address; v13 does not resolve hostnames')
    this.gateway = new UdpGateway(settings)
    this.gateway.on('transportError', error => this.emit('transportError', error))
    this.gateway.on('sendError', error => this.emit('transportError', error))
    this.gateway.on('input', (session, input) => this.accept(session, input))
    this.gateway.on('release', (session, reason) => {
      if (session.input) session.input.clear()
      if (session.player.udp_session === session) session.player.udp_session = null
      this.emit('release', session, reason)
    })
  }

  async start () { await this.gateway.start(); return this }

  attach (player, client) {
    if (!player.logged_in) throw new Error('Battle transport requires login')
    const current = player.udp_session
    if (current && !current.closed && current.client === client && this.gateway.sessions.get(current.key) === current) {
      current.lastSeen = performance.now()
      return current
    }
    const session = this.gateway.createSession(player, client)
    session.input = new InputBuffer()
    session.host = this.udpHost(client)
    if (session.host === undefined) {
      this.gateway.release(session, 'invalid-address')
      throw new Error('Configure Battle.AdvertiseHost with the IPv4 address clients can reach')
    }
    // host === null: 24112 carries a null host and the v13 client keeps no UDP
    // socket, so it sends input and receives vision over the TCP session from
    // the very first frame (libg 24112 handler 0x478fb4 skips the socket when
    // the host string is null; the input sender 0x4e6500 then uses TCP).
    session.tcpOnly = session.host === null
    player.udp_session = session
    return session
  }

  // Which IPv4 the client must send UDP to, or null for the TCP-only path.
  // Advertising an address the phone cannot reach is the worst choice: the
  // client keeps sending its inputs into the void until its 10 s UDP timeout
  // (UdpSocket +0x5b8) and only then falls back to TCP, freezing the start of
  // every match. Battle.Transport: "auto" (default), "udp" or "tcp".
  udpHost (client) {
    const mode = String(this.settings.Transport || 'auto').toLowerCase()
    if (mode === 'tcp') return null
    if (this.settings.AdvertiseHost) return this.settings.AdvertiseHost
    const local = String(client.localAddress || '').replace(/^::ffff:/, '')
    const usable = net.isIPv4(local) && local !== '0.0.0.0'
    if (mode === 'udp') return usable ? local : undefined
    if (!usable) return null
    // A private/loopback socket address seen by a public client means NAT or
    // container port mapping (e.g. Docker/Pterodactyl hosting): that address
    // is unreachable from the phone, so use the TCP path instead.
    const remote = String(client.remoteAddress || '').replace(/^::ffff:/, '')
    if (isPrivateIPv4(local) && !isPrivateIPv4(remote)) return null
    return local
  }

  accept (session, input) {
    if (session.closed || !session.player.logged_in) return false
    session.lastSeen = performance.now()
    session.input.push(input.inputs)
    session.client.lastBattleActivity = Date.now()
    this.emit('input', session, input)
    return true
  }

  acceptTcp (player, client, bytes) {
    const session = player.udp_session
    if (!session || session.closed || session.client !== client) return false
    return this.accept(session, decodeInput(bytes))
  }

  send (session, type, payload) { return this.gateway.send(session, type, payload) }
  release (player, client, reason = 'disconnect') {
    const session = player.udp_session
    if (session && session.client === client) return this.gateway.release(session, reason)
    return false
  }
  async close () { await this.gateway.close() }
}

module.exports = { BattleTransport, isPrivateIPv4 }
