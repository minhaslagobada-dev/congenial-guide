'use strict'

const dgram = require('dgram')
const crypto = require('crypto')
const { EventEmitter } = require('events')
const { performance } = require('perf_hooks')
const { envelope, readEnvelope, decodeInput } = require('./V13BattleCodec')

function address (ip) { return String(ip || '').replace(/^::ffff:/, '') }

class UdpGateway extends EventEmitter {
  constructor (settings = {}) {
    super()
    this.host = settings.BindIP || '0.0.0.0'
    this.port = settings.Port === undefined ? 9339 : settings.Port
    this.idleMs = settings.SessionTimeoutMs === undefined ? 30000 : settings.SessionTimeoutMs
    if (!Number.isInteger(this.port) || this.port < 0 || this.port > 65535) throw new Error('Battle.Port must be 0..65535')
    if (!Number.isFinite(this.idleMs) || this.idleMs < 1000) throw new Error('Battle.SessionTimeoutMs must be at least 1000')
    this.sessions = new Map()
    this.owners = new Map()
    this.socket = null
    this.timer = null
    this.starting = null
    this.closed = false
    this.metrics = { received: 0, sent: 0, malformed: 0, unknown: 0, throttled: 0, expired: 0, sendErrors: 0, oversized: 0 }
  }

  async start () {
    if (this.closed) throw new Error('UDP gateway is closed')
    if (this.starting) return this.starting
    if (this.socket) return this
    const socket = dgram.createSocket('udp4')
    this.socket = socket
    socket.on('message', (packet, remote) => this.receive(packet, remote))
    socket.on('error', error => this.emit('transportError', error))
    this.starting = new Promise((resolve, reject) => {
      const fail = error => { socket.removeListener('listening', ready); reject(error) }
      const ready = () => { socket.removeListener('error', fail); resolve() }
      socket.once('error', fail)
      socket.once('listening', ready)
      socket.bind(this.port, this.host)
    })
    try {
      await this.starting
      if (this.closed) throw new Error('UDP gateway closed during startup')
      this.port = socket.address().port
      this.timer = setInterval(() => this.expire(), 1000)
      this.timer.unref()
      return this
    } catch (error) {
      try { socket.close() } catch (_) {}
      this.socket = null
      throw error
    } finally { this.starting = null }
  }

  createSession (player, client) {
    if (!this.socket || this.closed || this.starting) throw new Error('UDP gateway is not listening')
    const owner = Number(player.low_id)
    if (!Number.isSafeInteger(owner) || owner <= 0) throw new Error('UDP session requires an authenticated account')
    const previous = this.owners.get(owner)
    if (previous) this.release(previous, 'replaced')
    // No global player cap: a session needs an authenticated TCP login and is
    // unique per account (previous one replaced above); datagram size, IP
    // binding, per-session rate limiting and idle expiry bound each session.
    let header, key
    do { header = crypto.randomBytes(10); key = header.toString('hex') } while (this.sessions.has(key))
    const now = performance.now()
    const session = {
      key, header, player, client, owner,
      ip: address(client.remoteAddress), endpoint: null,
      createdAt: now, lastSeen: now, windowAt: now, receivedInWindow: 0,
      closed: false
    }
    this.sessions.set(key, session)
    this.owners.set(owner, session)
    return session
  }

  receive (packet, remote) {
    this.metrics.received++
    // v13 native UdpSocket limits the whole datagram to 0x578 bytes.
    if (packet.length < 12 || packet.length > 1400) { this.metrics.malformed++; return false }
    const session = this.sessions.get(packet.subarray(0, 10).toString('hex'))
    if (!session || session.closed || address(remote.address) !== session.ip) { this.metrics.unknown++; return false }
    const now = performance.now()
    if (now - session.windowAt >= 1000) { session.windowAt = now; session.receivedInWindow = 0 }
    if (++session.receivedInWindow > 120) { this.metrics.throttled++; return false }
    let input
    try {
      const message = readEnvelope(packet.subarray(10))
      if (message.type !== 10555) { this.metrics.unknown++; return false }
      input = decodeInput(message.payload)
    } catch (_) { this.metrics.malformed++; return false }
    session.lastSeen = now
    session.lastUdpSeen = now
    session.udpStalled = false
    // Header possession plus the TCP source IP permits NAT port rebinding.
    session.endpoint = { address: remote.address, port: remote.port }
    this.emit('input', session, input)
    return true
  }

  send (session, type, payload) {
    if (this.closed || !this.socket || session.closed || this.sessions.get(session.key) !== session || !session.endpoint) return false
    const packet = Buffer.concat([session.header, envelope(type, payload)])
    if (packet.length > 1400) { this.metrics.oversized++; return false }
    try {
      this.socket.send(packet, session.endpoint.port, session.endpoint.address, error => {
        if (error) { this.metrics.sendErrors++; this.emit('sendError', error, session) }
      })
      this.metrics.sent++
      return true
    } catch (error) { this.metrics.sendErrors++; this.emit('sendError', error, session); return false }
  }

  release (session, reason = 'released') {
    if (!session || session.closed) return false
    session.closed = true
    this.sessions.delete(session.key)
    if (this.owners.get(session.owner) === session) this.owners.delete(session.owner)
    this.emit('release', session, reason)
    return true
  }

  expire (now = performance.now()) {
    for (const session of this.sessions.values()) {
      // A live battle still has its authenticated TCP peer. Preserve its input
      // ACK/deduplication state while falling back to TCP; the same UDP header
      // can recover through NAT rebinding. Match/disconnect cleanup owns expiry.
      const battle = session.player.onlineBattle
      if (battle && battle.phase !== 'finished' && !session.client.destroyed && !session.client.readableEnded) {
        if (now - (session.lastUdpSeen ?? session.createdAt) >= this.idleMs) {
          if (!session.udpStalled) this.metrics.expired++
          session.udpStalled = true; session.endpoint = null
        }
        continue
      }
      if (now - session.lastSeen < this.idleMs) continue
      this.metrics.expired++; this.release(session, 'timeout')
    }
  }

  async close () {
    if (this.closed) return
    this.closed = true
    if (this.timer) clearInterval(this.timer)
    this.timer = null
    if (this.starting) { try { await this.starting } catch (_) {} }
    for (const session of Array.from(this.sessions.values())) this.release(session, 'shutdown')
    const socket = this.socket
    this.socket = null
    if (socket) await new Promise(resolve => { try { socket.close(resolve) } catch (_) { resolve() } })
  }
}

module.exports = { UdpGateway }
