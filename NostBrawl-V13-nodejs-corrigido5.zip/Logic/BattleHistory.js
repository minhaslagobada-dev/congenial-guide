'use strict'
// Persistent battle log (histórico de batalhas).
//
// Every finished online battle is stored once per human account in the
// existing SQLite file (table battle_history, key (player_id, battle_id) where
// battle_id is the unique world id), and shown through the original v13
// packets only:
//   14114 GetBattleLogMessage  (client, empty body)  -> 23458 BattleLogMessage
//   23458 with the leading flag = true replaces the client's list, = false
//   prepends the entries to the list the client already holds.
// The v13 client asks for the log once per session (libg 0xd7588 keeps a
// "requested" flag in the BattleLog singleton 0x568bd8), so battles played
// after that first request are pushed with the incremental form when the
// player is back in the lobby.
//
// Recording never runs heavy work inside the battle tick: result() only
// queues a small object; the INSERT happens on setImmediate, all entries of
// the same tick in one transaction.

const Config = require('../Utils/Config')

// LogicBattleLogEntry types used by the v13 popup (libg 0x30bef8, jump table
// at 0x6009e8): 1 = 3v3 ("tvst"), 2 = Showdown, 3 = co-op survival/boss,
// 4 = Big Game (boss fight with a player boss), 5 = duo Showdown.
const ENTRY_TYPES = Object.freeze({
  CoinRush: 1,
  AttackDefend: 1,
  BountyHunter: 1,
  LaserBall: 1,
  BattleRoyale: 2,
  Survival: 3,
  Raid: 3,
  BossFight: 4,
  BattleRoyaleTeam: 5
})

// Results as the client colours them (TID_BATTLE_LOG_TVST_RESULT_0/1/2 and
// DEATHMATCH_RESULT_0/1/2): 0 victory (green), 1 defeat (red), 2 draw (grey).
const RESULT = Object.freeze({ VICTORY: 0, DEFEAT: 1, DRAW: 2 })

const DEFAULT_LIMIT = 25
const MAX_LIMIT = 100
// Participant kinds of LogicBattleLogPlayer (+0): 1 = account, 3 = bot.
const PLAYER_KIND = 1
const BOT_KIND = 3

function int (value, fallback = 0) {
  const parsed = Math.trunc(Number(value))
  return Number.isFinite(parsed) ? parsed : fallback
}

// Showdown placement -> result, same thresholds as the client (libg 0x4dc028).
function showdownResult (entryType, rank) {
  if (entryType === 5) return rank < 3 ? RESULT.VICTORY : rank === 3 ? RESULT.DRAW : RESULT.DEFEAT
  return rank < 4 ? RESULT.VICTORY : rank <= 7 ? RESULT.DRAW : RESULT.DEFEAT
}

const queue = []
let scheduled = false
let flushHook = null

class BattleHistory {
  static limit () {
    const config = (Config.GetValue() || {}).BattleLog || {}
    const value = int(config.Limit, DEFAULT_LIMIT)
    return Math.max(1, Math.min(MAX_LIMIT, value || DEFAULT_LIMIT))
  }

  static entry_type (locationGameMode) {
    return ENTRY_TYPES[locationGameMode] || null
  }

  // Snapshot of one finished battle from the point of view of `entry`.
  // Called from BattleCoordinator.result(); pure, no I/O.
  static snapshot (world, entry, data, tickMs) {
    const entryType = BattleHistory.entry_type(world.mode && world.mode.name)
    if (!entryType || !entry || entry.bot || !entry.player || !(entry.player.low_id > 0)) return null
    const rank = int(data.rank)
    let result
    if (entryType === 2 || entryType === 5) result = showdownResult(entryType, rank)
    else result = world.outcome.winner === null ? RESULT.DRAW : world.outcome.winner === entry.team ? RESULT.VICTORY : RESULT.DEFEAT
    const mvpIndex = Number.isInteger(data.mvp_index) ? data.mvp_index : -1
    let botNumber = 0
    const participants = world.players.map(other => {
      const bot = Boolean(other.bot)
      return {
        kind: bot ? BOT_KIND : PLAYER_KIND,
        high_id: bot ? 0 : int(other.player.high_id),
        low_id: bot ? ++botNumber : int(other.player.low_id),
        team: int(other.team),
        mvp: other.index === mvpIndex,
        name: bot ? '' : String(other.player.name || ''),
        brawler_id: int(other.brawlerId),
        trophies: bot ? 0 : int(other.historyTrophies),
        power_level: int(other.powerLevel) + 1,
        rank: int(other.rank)
      }
    })
    // The local entry carries the placement actually paid (rank fallback of
    // result()), so the client's "RANK n" header and row match the rewards.
    const own = participants[world.players.indexOf(entry)]
    if (own) own.rank = rank
    return {
      battle_id: String(world.id),
      created_at: Date.now(),
      location_mode: String(world.mode.name),
      entry_type: entryType,
      game_mode: int(data.game_mode),
      map_id: int(world.mapId),
      duration: Math.max(0, Math.round(int(world.outcome.tick) * (tickMs || 50) / 1000)),
      result,
      rank,
      team: int(entry.team),
      brawler_id: int(entry.brawlerId),
      practice: Boolean(world.practice || data.practice),
      mvp: mvpIndex >= 0 && mvpIndex === entry.index,
      participants
    }
  }

  // Completes a snapshot with the committed trophy change of its owner.
  static complete (snapshot, rewards) {
    const record = Object.assign({}, snapshot)
    const r = rewards && (rewards.rewards || rewards)
    const before = int(r && r.brawler_trophies)
    const change = int(r && r.trophies_gain)
    record.trophies_before = before
    record.trophy_change = change
    record.trophies_after = Math.max(0, before + change)
    if (record.participants) {
      record.participants = record.participants.map(p => Object.assign({}, p))
    }
    return record
  }

  static _insert (connection, playerId, record) {
    return connection.prepare(
      'INSERT OR IGNORE INTO battle_history (' +
      'player_id, battle_id, created_at, location_mode, entry_type, game_mode, map_id, duration, ' +
      'result, rank, team, brawler_id, trophies_before, trophies_after, trophy_change, practice, mvp, participants_json' +
      ') VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      int(playerId), String(record.battle_id), int(record.created_at), String(record.location_mode || ''),
      int(record.entry_type), int(record.game_mode), int(record.map_id), int(record.duration),
      int(record.result), int(record.rank), int(record.team), int(record.brawler_id),
      int(record.trophies_before), int(record.trophies_after), int(record.trophy_change),
      record.practice ? 1 : 0, record.mvp ? 1 : 0, JSON.stringify(record.participants || [])
    ).changes === 1
  }

  // Synchronous insert (login/restore paths and tests). Returns true when a
  // new row was written, false when the battle was already recorded.
  static record_now (playerId, record) {
    if (!record || !(int(playerId) > 0)) return false
    const DataBase = require('../Database/DatabaseManager')
    return DataBase._connection(connection => BattleHistory._insert(connection, playerId, record))
  }

  // Off-tick insert. `onStored(record)` runs only for a row that was new.
  static queue (playerId, record, onStored = null) {
    if (!record || !(int(playerId) > 0)) return false
    queue.push({ playerId: int(playerId), record, onStored })
    if (!scheduled) { scheduled = true; setImmediate(BattleHistory.flush) }
    return true
  }

  static flush () {
    scheduled = false
    if (!queue.length) return 0
    const batch = queue.splice(0, queue.length)
    const DataBase = require('../Database/DatabaseManager')
    try {
      DataBase._connection(connection => {
        for (const item of batch) {
          try { item.stored = BattleHistory._insert(connection, item.playerId, item.record) } catch (error) {
            item.stored = false
            console.log(`[BattleLog] Falha ao gravar a partida ${item.record.battle_id} do jogador ${item.playerId}: ${error.message}`)
          }
        }
      })
    } catch (error) {
      console.log(`[BattleLog] Falha ao gravar o histórico: ${error.message}`)
      return 0
    }
    let stored = 0
    for (const item of batch) {
      if (!item.stored) continue
      stored++
      if (item.onStored) { try { item.onStored(item.record) } catch (error) { console.log(`[BattleLog] ${error.message}`) } }
    }
    if (flushHook) flushHook(batch)
    return stored
  }

  static _on_flush (hook) { flushHook = hook }

  static _row_to_record (row) {
    let participants = []
    try { participants = JSON.parse(row.participants_json) } catch (_) {}
    return {
      battle_id: row.battle_id,
      created_at: int(row.created_at),
      location_mode: row.location_mode,
      entry_type: int(row.entry_type),
      game_mode: int(row.game_mode),
      map_id: int(row.map_id),
      duration: int(row.duration),
      result: int(row.result),
      rank: int(row.rank),
      team: int(row.team),
      brawler_id: int(row.brawler_id),
      trophies_before: int(row.trophies_before),
      trophies_after: int(row.trophies_after),
      trophy_change: int(row.trophy_change),
      practice: Boolean(row.practice),
      mvp: Boolean(row.mvp),
      participants: Array.isArray(participants) ? participants : []
    }
  }

  // Newest first. The full history stays in the database; only the most
  // recent `limit` entries are sent (the original game shows the last 25).
  static list (playerId, limit = BattleHistory.limit()) {
    const DataBase = require('../Database/DatabaseManager')
    const rows = DataBase._connection(connection => connection.prepare(
      'SELECT * FROM battle_history WHERE player_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?'
    ).all(int(playerId), Math.max(1, int(limit, DEFAULT_LIMIT))))
    return rows.map(BattleHistory._row_to_record)
  }

  static count (playerId) {
    const DataBase = require('../Database/DatabaseManager')
    return DataBase._connection(connection => connection.prepare(
      'SELECT COUNT(*) AS n FROM battle_history WHERE player_id = ?'
    ).get(int(playerId)).n)
  }

  // Lobby side. The client holds its list after the first 14114 of the
  // session; new battles are pushed (flag = false) once the player is home.
  static mark_requested (player, client) {
    player.battleLogClient = client || null
    player.battleLogUnsent = []
  }

  static stored_for (player, record, home = false) {
    if (!player || !player.battleLogClient) return false
    if (!Array.isArray(player.battleLogUnsent)) player.battleLogUnsent = []
    if (!player.battleLogUnsent.some(r => r.battle_id === record.battle_id)) player.battleLogUnsent.push(record)
    if (home) return BattleHistory.push_pending(player, player.battleLogClient)
    return false
  }

  static push_pending (player, client) {
    if (!player || !Array.isArray(player.battleLogUnsent) || !player.battleLogUnsent.length) return false
    // Only the session that already received the full list keeps one to
    // prepend to; a new connection asks for the full list itself.
    if (!client || client !== player.battleLogClient) return false
    if (client.destroyed || client.writableEnded) return false
    const records = player.battleLogUnsent.splice(0, player.battleLogUnsent.length)
    records.sort((a, b) => a.created_at - b.created_at)
    const BattleLogMessage = require('../Packets/Messages/Server/Battle/BattleLogMessage')
    new BattleLogMessage(client, player, records, false).send()
    return true
  }
}

BattleHistory.ENTRY_TYPES = ENTRY_TYPES
BattleHistory.RESULT = RESULT
BattleHistory.PLAYER_KIND = PLAYER_KIND
BattleHistory.BOT_KIND = BOT_KIND
BattleHistory.DEFAULT_LIMIT = DEFAULT_LIMIT
BattleHistory.SCHEMA = `
        CREATE TABLE IF NOT EXISTS battle_history (
            player_id INTEGER NOT NULL,
            battle_id TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            location_mode TEXT NOT NULL DEFAULT '',
            entry_type INTEGER NOT NULL,
            game_mode INTEGER NOT NULL DEFAULT 0,
            map_id INTEGER NOT NULL,
            duration INTEGER NOT NULL DEFAULT 0,
            result INTEGER NOT NULL,
            rank INTEGER NOT NULL DEFAULT 0,
            team INTEGER NOT NULL DEFAULT 0,
            brawler_id INTEGER NOT NULL,
            trophies_before INTEGER NOT NULL DEFAULT 0,
            trophies_after INTEGER NOT NULL DEFAULT 0,
            trophy_change INTEGER NOT NULL DEFAULT 0,
            practice INTEGER NOT NULL DEFAULT 0,
            mvp INTEGER NOT NULL DEFAULT 0,
            participants_json TEXT NOT NULL DEFAULT '[]',
            PRIMARY KEY (player_id, battle_id),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS battle_history_recent
            ON battle_history(player_id, created_at DESC);
    `

module.exports = { BattleHistory }
