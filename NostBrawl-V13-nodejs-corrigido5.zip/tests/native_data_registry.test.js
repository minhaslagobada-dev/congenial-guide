'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const types = { Hero: 0, Npc_Boss: 1, Minion_FollowOwner: 2, Minion_FindEnemies: 3, Minion_Building: 4, Campaign_DefendTarget: 5,
  Pvp_Base: 6, Minion_Building_charges_ulti: 7, Minion_Dog: 8, LaserBall: 9, LootBox: 10, Minion_FindEnemies2: 11 }
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'data-registry-vectors.json')))
const assets = new BattleAssets()
for (const v of vectors) {
  const d = assets.named('characters', v.name)
  assert.equal(v.dataId, 16000000 + d.id, v.name)
  assert.equal(v.hp, Number(d.Hitpoints) || 0, v.name)
  assert.equal(v.maxHp, v.hp, v.name)
  assert.equal(v.type, types[d.Type], v.name)
  assert.equal(v.radius, Number(d.CollisionRadius) || 0, v.name)
  assert.equal(v.speed, Number(d.Speed) || 0, v.name)
  assert.equal(v.projectileStartZ, Number(d.ProjectileStartZ) || 0, v.name)
  assert.equal(v.state, 4, v.name)
  assert.equal(v.skills, Number(Boolean(d.WeaponSkill)) + Number(Boolean(d.UltimateSkill)), v.name)
}
assert.equal(vectors.length, 73)
console.log('Actual client metadata + native constructors: all 73 characters matched IDs, HP, types, radius, speed, projectile height and skills; no CSV/gameplay substitutions')
