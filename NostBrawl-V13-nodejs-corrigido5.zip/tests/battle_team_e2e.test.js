'use strict'
// Real encrypted clients: two friends form a team (14350 / 14351), both press
// Play (14355 ready), the pair enters matchmaking together, gets the same
// match, plays, returns home, and can immediately search again. Also covers
// a member dropping while the team is queued: the survivor must be able to
// start a new search without any restart.
const assert = require('node:assert/strict')
const { Server } = require('../main')
const { GameRoomService } = require('../Logic/GameRoomService')
const Skins = require('../Files/CsvLogic/Skins')
const DataBase = require('../Database/DatabaseManager')
const { createClientFactory, vint, bool, wait } = require('./helpers/v13_client')

const server = new Server('127.0.0.1', 0)
const factory = createClientFactory(server)
assert.equal(factory.settings.Store.Enabled, false, 'Use the isolated battle test runner')

const createTeam = (peer, map = 0, slot = 1) => peer.send(14350, Buffer.concat([vint(map), vint(slot), vint(0), bool(false)]))
const joinTeam = (peer, roomId) => peer.send(14351, Buffer.concat([vint(0), vint(roomId), vint(0), vint(0)]))
const ready = (peer, value) => peer.send(14355, Buffer.concat([bool(value), vint(0)]))
const roomOf = peer => {
  for (const room of Object.values(GameRoomService._entries)) if (room.members.some(m => m.low_id === peer.account.low)) return room
  return null
}

// Team mates may not share a brawler (native TeamError 17): the friend
// picks Colt (14354) like a player would before pressing PRONTO.
function unlock (peer) {
  const player = server.Clients.Clients[String(peer.account.low)].Player
  const state = { ...(player.BrawlersUnlockedState || {}), 0: 1, 1: 1 }
  player.BrawlersUnlockedState = state
  DataBase.replaceValues({ player }, { UnlockedBrawlers: state })
}
const pickColt = peer => peer.send(14354, Buffer.concat([vint(0), vint(29), vint(Skins.get_default_skin(1))]))

async function formTeam (a, b) {
  const sinceA = a.messages.length; const sinceB = b.messages.length
  createTeam(a)
  await a.waitFor(24124, 3000, sinceA)
  const room = roomOf(a); assert(room, 'Team created')
  joinTeam(b, room.id)
  await b.waitFor(24124, 3000, sinceB)
  assert.equal(roomOf(b), room, 'Friend joined the same team')
  unlock(b); pickColt(b); await wait(150)
  return room
}

async function main () {
  try {
    await server.start()
    const coordinator = server.battleCoordinator
    const errors = []; coordinator.on('battleError', e => errors.push(e))
    const a = await factory.login('host'); const b = await factory.login('friend')

    // ---- 1. team Play: both enter matchmaking together, no disconnect ----
    let room = await formTeam(a, b)
    let sinceA = a.messages.length; let sinceB = b.messages.length
    ready(b, true); ready(a, true)
    await a.waitFor(20405, 3000, sinceA); await b.waitFor(20405, 3000, sinceB)
    await wait(200)
    assert(!a.closed && !b.closed, 'Nobody is disconnected when the team presses Play')
    assert(coordinator.matchmaker.players.has(a.account.low) && coordinator.matchmaker.players.has(b.account.low), 'Both members are queued')
    assert.equal(coordinator.matchmaker.players.get(a.account.low), coordinator.matchmaker.players.get(b.account.low), 'One ticket for the team')
    assert.equal(roomOf(a), room, 'The team is kept while searching')

    // ---- 2. cancel (un-ready) and search again ----
    sinceA = a.messages.length
    ready(a, false)
    await a.waitFor(20406, 3000, sinceA)
    await wait(100)
    assert(!coordinator.matchmaker.players.has(a.account.low) && !coordinator.matchmaker.players.has(b.account.low), 'Cancel removes the whole team ticket')
    sinceA = a.messages.length; sinceB = b.messages.length
    ready(a, true); ready(b, true)
    await a.waitFor(20405, 3000, sinceA)
    assert(coordinator.matchmaker.players.has(a.account.low), 'Team can search again after cancelling')

    // ---- 3. the team gets ONE match (bots fill after the 15 s queue) ----
    await a.waitFor(20559, 20000, sinceA); await b.waitFor(20559, 3000, sinceB)
    assert.equal(coordinator.worlds.size, 1)
    const world = Array.from(coordinator.worlds.values())[0]
    const ea = world.players.find(p => !p.bot && p.player.low_id === a.account.low)
    const eb = world.players.find(p => !p.bot && p.player.low_id === b.account.low)
    assert(ea && eb && ea.team === eb.team, 'Team mates play on the same side')
    await wait(300)
    assert(a.visions.length > 2 && b.visions.length > 2, 'Both receive live ticks')

    // ---- 4. end -> result -> home -> team stays -> search again ----
    world.finish(ea.team, 'test-result-pipeline')
    await a.waitFor(23456, 3000, sinceA); await b.waitFor(23456, 3000, sinceB)
    sinceA = a.messages.length; sinceB = b.messages.length
    // Online return-home ids of the v13 client: 14101 (bool) and 14108 (empty).
    a.send(14101, Buffer.from([0])); b.send(14108, Buffer.alloc(0))
    await a.waitFor(24101, 3000, sinceA); await b.waitFor(24101, 3000, sinceB)
    await wait(150)
    assert(!a.closed && !b.closed)
    room = roomOf(a)
    if (!room) room = await formTeam(a, b)
    sinceA = a.messages.length
    ready(a, true); ready(b, true)
    await a.waitFor(20405, 3000, sinceA)
    assert(coordinator.matchmaker.players.has(a.account.low), 'Team searches again after a match')
    sinceA = a.messages.length; ready(a, false); await a.waitFor(20406, 3000, sinceA)

    // ---- 5. a member drops while queued: the survivor searches again ----
    sinceA = a.messages.length
    ready(a, true); ready(b, true)
    await a.waitFor(20405, 3000, sinceA)
    b.socket.destroy(); try { b.udp.close() } catch (_) {}
    await wait(400)
    assert(!a.closed, 'Survivor stays connected')
    assert(!coordinator.matchmaker.players.has(a.account.low) && !coordinator.matchmaker.players.has(b.account.low), 'Dropped team ticket is cleaned')
    sinceA = a.messages.length
    a.send(14103, Buffer.concat([vint(16), vint(0), vint(0), vint(1), vint(0), vint(0)]))
    await a.waitFor(20405, 3000, sinceA)
    assert(coordinator.matchmaker.players.has(a.account.low), 'Survivor can start a new search (solo Play)')
    sinceA = a.messages.length; a.send(14106, Buffer.alloc(0)); await a.waitFor(20406, 3000, sinceA)
    await wait(100)
    assert(!coordinator.matchmaker.players.has(a.account.low))

    // ---- 6. friend logs back in, team again, Play works ----
    const b2 = await factory.login('friend-again', b.account)
    // Closing the game is not leaving: the friend is put back into the same
    // team automatically on login (24124 right after the home data).
    await b2.waitFor(24124, 3000, 0); await wait(100)
    room = roomOf(a)
    assert(room && roomOf(b2) === room, 'Reconnected friend is back in the same team automatically')
    unlock(b2); pickColt(b2); await wait(150)
    sinceA = a.messages.length
    ready(a, true); ready(b2, true)
    await a.waitFor(20405, 3000, sinceA)
    assert(coordinator.matchmaker.players.has(b2.account.low), 'Reconnected friend queues with the team')

    // ---- 7. refused team Play (engine unavailable) keeps both connected ----
    sinceA = a.messages.length; let sinceB2 = b2.messages.length
    ready(a, false); await a.waitFor(20406, 3000, sinceA)
    sinceA = a.messages.length; sinceB2 = b2.messages.length
    coordinator.engineFailed = true
    ready(b2, true); ready(a, true)
    await a.waitFor(20406, 3000, sinceA); await b2.waitFor(20406, 3000, sinceB2)
    coordinator.engineFailed = false
    await wait(150)
    assert(!a.closed && !b2.closed, 'A refused team search must not disconnect anyone')
    assert(roomOf(a) && roomOf(a) === roomOf(b2), 'Nobody is removed from the team')
    assert(roomOf(a).members.every(m => !m.ready), 'Ready flags are cleared after a refusal')
    sinceA = a.messages.length
    ready(a, true); ready(b2, true)
    await a.waitFor(20405, 3000, sinceA)
    assert(coordinator.matchmaker.players.has(a.account.low), 'Team searches again right after a refusal')

    // ---- 8. one member goes home mid-match: it can search again at once ----
    sinceA = a.messages.length; sinceB2 = b2.messages.length
    await a.waitFor(20559, 20000, sinceA); await b2.waitFor(20559, 3000, sinceB2)
    const world2 = Array.from(coordinator.worlds.values())[0]
    await wait(300)
    sinceA = a.messages.length
    a.send(14101, Buffer.from([0]))
    await a.waitFor(24101, 3000, sinceA)
    assert(!coordinator.accounts.has(a.account.low), 'An explicit exit frees the account immediately')
    assert(coordinator.accounts.has(b2.account.low), 'The team mate keeps playing')
    sinceA = a.messages.length
    a.send(14103, Buffer.concat([vint(16), vint(0), vint(0), vint(1), vint(0), vint(0)]))
    await a.waitFor(20405, 3000, sinceA)
    assert(!a.closed && coordinator.matchmaker.players.has(a.account.low), 'Leaver searches again while the old match is still running')
    sinceA = a.messages.length; sinceB2 = b2.messages.length
    world2.finish(0, 'test-result-pipeline')
    await b2.waitFor(23456, 3000, sinceB2)
    await wait(200)
    assert(!a.messages.slice(sinceA).some(m => m.type === 23456), 'No stale result screen for the player who already left')
    assert(coordinator.matchmaker.players.has(a.account.low), 'Leaver stays queued when the old match ends')

    // ---- 9. result never acknowledged (client skipped GoHome): Play still works ----
    sinceB2 = b2.messages.length
    b2.send(14103, Buffer.concat([vint(16), vint(1), vint(0), vint(1), vint(0), vint(0)]))
    await b2.waitFor(20405, 3000, sinceB2)
    assert(!b2.closed && coordinator.matchmaker.players.has(b2.account.low), 'A pending result no longer swallows Play')

    // ---- 10. diverging brawler in Play is refused without a disconnect ----
    sinceA = a.messages.length; a.send(14106, Buffer.alloc(0)); await a.waitFor(20406, 3000, sinceA)
    sinceA = a.messages.length
    a.send(14103, Buffer.concat([vint(16), vint(999), vint(0), vint(1), vint(0), vint(0)]))
    await a.waitFor(20406, 3000, sinceA)
    await wait(100)
    assert(!a.closed, 'Refused solo Play keeps the connection')

    const unexpected = errors.filter(e => !/Busca recusada/.test(e.message))
    assert.equal(unexpected.length, 0, unexpected.map(e => e.stack).join('\n'))
    console.log('TEAM E2E OK: team Play queues both members -> cancel/search again -> one shared match -> result/home -> search again -> member drop cleans the ticket -> survivor and re-logged friend search again -> refused searches keep sessions -> mid-match leaver searches again -> pending result does not block Play')
  } finally {
    factory.closeAll()
    await server.close()
  }
}
const timer = setTimeout(() => { console.error('Team e2e timeout'); process.exit(1) }, 110000)
main().then(() => clearTimeout(timer), error => { clearTimeout(timer); console.error(error); process.exitCode = 1 })
