'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { angle } = require('../Native/V13/Aim')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'angle-vectors.json')))
for (const v of vectors) assert.equal(angle(v.x, v.y), v.angle, JSON.stringify(v))
console.log('Native integer aim angle:', vectors.length, 'cases matched original v13')
