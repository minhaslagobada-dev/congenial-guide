'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { readDictRows } = require('../Files/CsvLogic/CsvRows')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'upgrade-skin-data-vectors.json')))
const assets = new BattleAssets()
for (const [kind, filename] of [[23, 'cards'], [29, 'skins']]) {
  const rows = readDictRows(path.join(__dirname, '../GameAssets/csv_logic', filename + '.csv')).slice(1)
  assert.equal(records[kind].length, rows.length)
  for (const [i, record] of records[kind].entries()) {
    assert.equal(record.name, rows[i].Name)
    assert.equal(record.id, kind * 1000000 + i)
    if (kind !== 29) continue
    for (const [key, column] of [['mainProjectile', 'MainAttackProjectile'], ['superProjectile', 'UltiProjectile']]) {
      assert.equal(record[key], rows[i][column] ? 6000000 + assets.named('projectiles', rows[i][column]).id : null, record.name)
    }
  }
}
console.log('Original references: 125 card IDs and 67 skin IDs/projectile overrides matched exact client CSVs; rendering excluded')
