'use strict'
// Trophy rewards and their synchronisation with real encrypted v13 clients
// (solo Play 14103 through the real matchmaker and battle coordinator):
//  - 3v3 win = +10 (+6 from 350 brawler trophies), Showdown win (rank 1) =
//    +15 (+9 from 350), applied to
//    the brawler that played; defeats keep the original tables;
//  - the result screen (23456), the home data (24101: brawler and account
//    totals) and the database all carry the same, committed values;
//  - returning home twice, replaying the result and logging in again (game
//    restart) never grant the reward twice;
//  - a Showdown entry without a placement is never paid as a win.
// The team/gameroom side (menu badge in 24124, duo Showdown) is covered by
// battle_team_full_cycle_e2e.test.js.
const assert = require('node:assert/strict')
const { Server } = require('../main')
const DataBase = require('../Database/DatabaseManager')
const Device = require('../Logic/Device')
const { Players } = require('../Logic/Player')
const { createClientFactory, vint, wait, Reader } = require('./helpers/v13_client')
const { readHomeTrophies } = require('./helpers/native_home')

const server = new Server('127.0.0.1', 0)
const factory = createClientFactory(server)
assert.equal(factory.settings.Store.Enabled, false, 'Use the isolated battle test runner')

const session = low => server.Clients.Clients[String(low)] && server.Clients.Clients[String(low)].Player
const play = (peer, slot, brawler = 0) => peer.send(14103, Buffer.concat([vint(16), vint(brawler), vint(0), vint(slot), vint(0), vint(0)]))
const lastOf = (peer, type, since = 0) => { const list = peer.messages.slice(since).filter(m => m.type === type); return list.length ? list[list.length - 1] : null }
const resultHeader = raw => { const r = new Reader(raw); return { mode: r.vint(), result: r.vint(), tokens: r.vint(), trophies: r.vint() } }

function stored (peer) {
  const loaded = new Players(new Device({ write: () => {} }))
  loaded.token = session(peer.account.low).token
  assert.notEqual(DataBase.loadAccount({ player: loaded }), false)
  return { brawler: Math.trunc((loaded.brawlers_trophies || {})['0'] || 0), total: Math.trunc(loaded.trophies || 0) }
}

function setTrophies (peer, value) {
  const player = session(peer.account.low)
  player.brawlers_trophies = { ...(player.brawlers_trophies || {}), 0: value }
  player.trophies = value
  DataBase.replaceValues({ player }, { brawlersTrophies: player.brawlers_trophies, trophies: value })
}

async function expire (coordinator) {
  // Test clock only: skip the 15 s queue window (bots fill the match).
  for (const bucket of coordinator.matchmaker.buckets.values()) for (const ticket of bucket) ticket.joinedAt -= 60000
}

async function match (coordinator, peer, slot) {
  const since = peer.messages.length
  play(peer, slot)
  await peer.waitFor(20405, 3000, since)
  await expire(coordinator)
  await peer.waitFor(20559, 5000, since)
  const world = Array.from(coordinator.worlds.values()).find(w => w.players.some(p => !p.bot && p.player.low_id === peer.account.low))
  assert(world, 'match started')
  await wait(300)
  return [world, world.players.find(p => !p.bot && p.player.low_id === peer.account.low)]
}

// Ends the match, returns home and checks every place the trophies show up.
async function finishAndCheck (peer, world, winner, expectedGain, label) {
  const before = stored(peer)
  let since = peer.messages.length
  world.finish(winner, 'test-result')
  await peer.waitFor(23456, 3000, since)
  const result = resultHeader(lastOf(peer, 23456, since).raw)
  since = peer.messages.length
  peer.send(14101, Buffer.from([0]))
  await peer.waitFor(24101, 3000, since)
  const home = readHomeTrophies(lastOf(peer, 24101, since).raw)
  const after = stored(peer)
  const expected = Math.max(0, before.brawler + expectedGain)
  assert.equal(result.trophies, expected - before.brawler, `${label}: result screen shows ${expected - before.brawler}`)
  assert.equal(after.brawler, expected, `${label}: database ${expected}`)
  assert.equal(home.brawlers[0], expected, `${label}: home brawler trophies ${expected}`)
  assert.equal(home.total, after.total, `${label}: home account total matches the database`)
  assert.equal(after.total - before.total, expected - before.brawler, `${label}: account total moves by the same amount`)
  assert.equal(home.selected, 0)
  assert(!peer.closed, `${label}: still connected`)
  console.log(`${label}: ${before.brawler} -> ${after.brawler} (result ${result.trophies}) ok`)
  return { result, home, after }
}

async function main () {
  try {
    await server.start()
    const coordinator = server.battleCoordinator
    let peer = await factory.login('trophies')
    setTrophies(peer, 100)

    // ---- 1. solo 3v3 win: exactly +10 (100 -> 110) ------------------------
    let [world, entry] = await match(coordinator, peer, 0)
    assert.equal(world.mode.name, 'CoinRush', 'slot 0 is the 3v3 Gem Grab event')
    await finishAndCheck(peer, world, entry.team, 10, '3v3 win')
    assert.equal(stored(peer).brawler, 110, 'example from the request: 100 -> 110')

    // ---- 2. no duplicate reward: second GoHome, replayed result, relogin --
    let since = peer.messages.length
    peer.send(14101, Buffer.from([0])); await peer.waitFor(24101, 3000, since)
    assert.equal(readHomeTrophies(lastOf(peer, 24101, since).raw).brawlers[0], 110, 'second GoHome changes nothing')
    coordinator.result(world, entry, true)
    await wait(100)
    assert.equal(stored(peer).brawler, 110, 'replaying the same result is idempotent (ledger)')
    const account = peer.account
    peer.socket.destroy(); try { peer.udp.close() } catch (_) {}
    await wait(400)
    peer = await factory.login('trophies-again', account)
    assert.equal(readHomeTrophies(lastOf(peer, 24101).raw).brawlers[0], 110, 'game restart: login home data shows 110')
    assert.equal(stored(peer).brawler, 110, 'game restart: nothing granted twice')

    // ---- 3. solo 3v3 defeat keeps the original table (-2 at 110) ----------
    ;[world, entry] = await match(coordinator, peer, 0)
    await finishAndCheck(peer, world, 1 - entry.team, -2, '3v3 defeat')

    // ---- 4. 3v3 draw: 0 -----------------------------------------------------
    ;[world, entry] = await match(coordinator, peer, 0)
    await finishAndCheck(peer, world, null, 0, '3v3 draw')

    // ---- 5. Showdown win (rank 1): exactly +15 ------------------------------
    setTrophies(peer, 100)
    ;[world, entry] = await match(coordinator, peer, 2)
    assert.equal(world.mode.name, 'BattleRoyale', 'slot 2 is the solo Showdown event')
    let rank = 2
    for (const other of world.players) other.rank = other === entry ? 1 : rank++
    await finishAndCheck(peer, world, entry.team, 15, 'Showdown win')
    assert.equal(stored(peer).brawler, 115, 'example from the request: 100 -> 115')

    // ---- 6. Showdown 4th place keeps the original table (+3 at 115) -------
    ;[world, entry] = await match(coordinator, peer, 2)
    rank = 1
    for (const other of world.players) if (other !== entry) { if (rank === 4) rank++; other.rank = rank++ }
    entry.rank = 4
    await finishAndCheck(peer, world, world.players.find(p => p.rank === 1).team, 3, 'Showdown 4th')

    // ---- 7. Showdown last place (rank 10): -4 at 118 ----------------------
    ;[world, entry] = await match(coordinator, peer, 2)
    rank = 1
    for (const other of world.players) other.rank = other === entry ? 10 : rank++
    await finishAndCheck(peer, world, world.players.find(p => p.rank === 1).team, -4, 'Showdown 10th')

    // ---- 8. missing placement is never paid as a win ---------------------
    ;[world, entry] = await match(coordinator, peer, 2)
    for (const other of world.players) other.rank = 0
    const winner = world.players.find(p => p !== entry).team
    const { result } = await finishAndCheck(peer, world, winner, -4, 'Showdown without placement')
    assert.equal(result.result, 10, 'reported as last place, not as a win')

    // ---- 9. from 350 trophies the wins drop: 3v3 +6, Showdown +9 ---------
    setTrophies(peer, 340)
    ;[world, entry] = await match(coordinator, peer, 0)
    await finishAndCheck(peer, world, entry.team, 10, '3v3 win at 340 (below 350)')
    ;[world, entry] = await match(coordinator, peer, 0)
    await finishAndCheck(peer, world, entry.team, 6, '3v3 win at 350 (threshold crossed)')
    ;[world, entry] = await match(coordinator, peer, 0)
    await finishAndCheck(peer, world, 1 - entry.team, -5, '3v3 defeat at 356 (original table)')
    setTrophies(peer, 400)
    ;[world, entry] = await match(coordinator, peer, 0)
    await finishAndCheck(peer, world, entry.team, 6, '3v3 win at 400')
    const showdownWin = async (from, gain) => {
      setTrophies(peer, from)
      ;[world, entry] = await match(coordinator, peer, 2)
      let r = 2
      for (const other of world.players) other.rank = other === entry ? 1 : r++
      await finishAndCheck(peer, world, entry.team, gain, `Showdown win at ${from}`)
    }
    await showdownWin(349, 15)
    await showdownWin(350, 9)
    await showdownWin(400, 9)
    // 2nd place above 350 keeps the original table (+6 at 300-499)
    setTrophies(peer, 360)
    ;[world, entry] = await match(coordinator, peer, 2)
    rank = 1
    for (const other of world.players) if (other !== entry) { if (rank === 2) rank++; other.rank = rank++ }
    entry.rank = 2
    await finishAndCheck(peer, world, world.players.find(p => p.rank === 1).team, 6, 'Showdown 2nd at 360')

    console.log('TROPHIES E2E OK: 3v3 win +10 (+6 from 350), Showdown win +15 (+9 from 350), defeats/draw/placements unchanged, result screen = home data = database, no duplicate reward, persists across login')
  } catch (error) {
    console.error(error)
    process.exitCode = 1
  } finally {
    factory.closeAll(); await server.close()
  }
}

main()
