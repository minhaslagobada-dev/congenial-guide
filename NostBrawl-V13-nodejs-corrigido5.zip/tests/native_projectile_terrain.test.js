'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { rectangle } = require('../Native/V13/CollisionGeometry')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'projectile-terrain-vectors.json')))
let contacts = 0; let destructions = 0
for (const v of vectors) {
  if (['Open', 'Water', 'Forest'].includes(v.tile)) {
    assert.equal(v.result, 0, JSON.stringify(v))
    assert.deepEqual(v.position, v.current, JSON.stringify(v))
  }
  if (v.tile === 'Indestructible') {
    assert.equal(v.result, v.properties.PassesEnvironment === 'true' ? 0 : 1, JSON.stringify(v))
    assert.equal(v.destroyed, false, JSON.stringify(v))
  }
  if (v.result === 1) {
    const hit = rectangle([...v.previous, ...v.current, 3000, 4500, 3300, 4800])
    assert.equal(v.tileIndex, 325, JSON.stringify(v))
    assert.equal(v.side, hit.result, JSON.stringify(v))
    assert.deepEqual(v.position, hit.point, JSON.stringify(v))
    contacts++
  }
  if (v.destroyed) destructions++
}
assert(contacts > 0 && destructions > 0, 'Both native contact and native destruction must be exercised')
console.log('Native controlled terrain:', vectors.length, 'cases;', contacts, 'exact contacts;', destructions, 'destructions; broadphase/enemy collision not yet transcribed')
