'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { stepAttackSkillSetup } = require('../Native/V13/AttackSkillSetup')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'skill-attack-setup-vectors.json')))
for (const v of vectors) {
  const state = { definition: v.definition, projectile: v.projectile, activeMs: Math.max(1, Number(v.definition.ActiveTime) || 0),
    cooldownMs: 0, ammo: v.ammo, consumed: v.consumed, level: v.level, target: [3500, 5000], executing: 1, pending: 1, slot: v.role === 'super' ? 1 : 0 }
  const other = { definition: v.otherDefinition, activeMs: 0, cooldownMs: 0, executing: 0 }
  const owner = { x: 3000, y: 4500, attackAngle: 0, moveAngle: 0, castingMs: v.casting, berserk: false,
    i32: Object.fromEntries(Object.keys(v.attack.i32).map(key => [key, key === '0x2fc' ? (v.aimTicks < 0 ? -1 : 100 - v.aimTicks) : 0])),
    u8: Object.fromEntries(Object.keys(v.attack.u8).map(key => [key, 0])), skills: v.role === 'main' ? [state, other] : [other, state] }
  owner.u8['0x2f9'] = 1
  if (v.hasPlayer) owner.player = { superCharge: 1000 }
  stepAttackSkillSetup(state, owner, { mode: 0, team: 0, tick: 100, bossReloadDivisor: 20 })
  assert.deepEqual(Object.fromEntries(Object.keys(v.skill).map(key => [key, state[key]])), v.skill, v.name + ' skill')
  if (v.hasPlayer) assert.equal(owner.player.superCharge, v.playerCharge, v.name + ' super charge')
  assert.equal(other.cooldownMs, v.otherCooldownMs, v.name + ' linked cooldown')
  assert.equal(owner.attackAngle, v.attack.attackAngle, v.name + ' attack angle')
  assert.equal(owner.moveAngle, v.attack.moveAngle, v.name + ' move angle')
  // Configuration also stores last-shot tick, which is measured in its own oracle.
  delete owner.i32['0x7c']
  assert.deepEqual({ i32: owner.i32, u8: owner.u8 }, { i32: v.attack.i32, u8: v.attack.u8 }, v.name + ' configuration')
}
console.log('Native active attack skill setup:', vectors.length, 'cases matched original full Skill::tick; main/Super slots, casting, levels, ammo and consumption')
