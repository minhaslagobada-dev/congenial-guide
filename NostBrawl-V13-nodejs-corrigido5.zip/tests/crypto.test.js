'use strict'
const assert = require('assert')
const fs = require('fs')
const path = require('path')

process.chdir(path.join(__dirname, '..'))

const NaCl19 = require('../Core/NaCl19')
const { Crypto, Nonce } = require('../Core/Crypto')
const Writer = require('../Utils/Writer')
const { BSMessageReader } = require('../Utils/Reader')

const vectors = JSON.parse(fs.readFileSync(path.join(__dirname, 'vectors.json'), 'utf-8'))

const hex = (value) => Buffer.from(value, 'hex')

let passed = 0
function check (name, fn) {
  fn()
  passed += 1
  console.log(`ok - ${name}`)
}

check('scalarmult matches reference vectors', () => {
  for (const entry of vectors.scalarmult) {
    const result = NaCl19.scalarmult(hex(entry.scalar), hex(entry.point))
    assert.strictEqual(result.toString('hex'), entry.result)
  }
})

check('scalarmultBase produces the configured client public key', () => {
  const clientSk = hex('BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D')
  assert.strictEqual(NaCl19.scalarmultBase(clientSk).toString('hex'), vectors.client_pk)
})

check('boxBeforenm produces the configured shared key', () => {
  const serverKey = hex('EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041')
  const clientSk = hex('BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D')
  assert.strictEqual(NaCl19.boxBeforenm(serverKey, clientSk).toString('hex'), vectors.shared_key)
})

check('secretbox/open round-trip matches reference bytes', () => {
  const { nonce, key, message, sealed, opened } = vectors.secretbox
  const sealedActual = NaCl19.secretbox(hex(message), hex(nonce), hex(key))
  assert.strictEqual(sealedActual.toString('hex'), sealed)
  const openedActual = NaCl19.secretboxOpen(hex(sealed), hex(nonce), hex(key))
  assert.strictEqual(openedActual.toString('hex'), opened)
  assert.strictEqual(openedActual.toString('hex'), message)
})

check('secretboxOpen rejects a tampered ciphertext', () => {
  const { nonce, key, sealed } = vectors.secretbox
  const tampered = hex(sealed)
  tampered[tampered.length - 1] ^= 1
  assert.throws(() => NaCl19.secretboxOpen(tampered, hex(nonce), hex(key)), NaCl19.VerificationError)
})

check('Nonce blake2b derivation matches python', () => {
  const nonce = new Nonce(null, hex(vectors.client_pk), hex('EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041'))
  assert.strictEqual(nonce.toBuffer().toString('hex'), vectors.nonce_blake)
})

check('Nonce increment (+2 LE) matches python', () => {
  const nonce = new Nonce(new Uint8Array(Array.from({ length: 24 }, (_, index) => index)))
  nonce.increment()
  assert.strictEqual(nonce.toBuffer().toString('hex'), vectors.nonce_incremented)
})

check('full session flow matches python byte-for-byte', () => {
  const flow = vectors.flow
  const crypto = new Crypto({ Enabled: true })
  crypto.encryptNonce = new Nonce(hex(flow.encrypt_nonce))
  crypto.shared_en = hex(flow.shared_en)

  const rawLogin = crypto.decrypt(10101, hex(flow.wire_login))
  assert.strictEqual(rawLogin.toString('hex'), flow.raw_login)
  assert.strictEqual(crypto.session_key.toString('hex'), flow.session_key)

  const loginOk = crypto.encrypt(20104, hex(flow.loginok_plain))
  assert.strictEqual(loginOk.toString('hex'), flow.loginok_wire)

  const keepAlive = crypto.encrypt(20108, Buffer.from('PING'))
  assert.strictEqual(keepAlive.toString('hex'), flow.keepalive_wire)

  const incoming = crypto.decrypt(14350, hex(flow.incoming_wire))
  assert.strictEqual(incoming.toString('hex'), flow.incoming_plain)
})

check('passthrough rules match (10100/20100/20103 unencrypted)', () => {
  const crypto = new Crypto({ Enabled: true })
  const raw = Buffer.from('payload')
  assert.strictEqual(crypto.decrypt(10100, raw), raw)
  assert.strictEqual(crypto.encrypt(20100, raw), raw)
  assert.strictEqual(crypto.encrypt(20103, raw), raw)
  assert.throws(() => crypto.encrypt(20104, raw), /LoginOk/)
  assert.throws(() => crypto.decrypt(10101, Buffer.alloc(10)), /too short/)
})

check('legacy writeVint matches python bytes', () => {
  for (const [value, expected] of vectors.vint_legacy) {
    const writer = new Writer(null)
    writer.writeVint(Number.parseInt(value, 10))
    assert.strictEqual(writer.buffer.toString('hex'), expected, `writeVint(${value})`)
  }
})

check('native V13 writeVint matches python bytes', () => {
  for (const [value, expected] of Object.entries(vectors.vint_native)) {
    const writer = new Writer(null).enable_native_v13()
    writer.writeVint(Number.parseInt(value, 10))
    assert.strictEqual(writer.buffer.toString('hex'), expected, `native writeVint(${value})`)
  }
})

check('writeScId variants match python', () => {
  let writer = new Writer(null)
  writer.writeScId(3, 7)
  assert.strictEqual(writer.buffer.toString('hex'), vectors.scid_3_7_legacy)

  writer = new Writer(null).enable_native_v13()
  writer.writeScId(3, 7)
  assert.strictEqual(writer.buffer.toString('hex'), vectors.scid_3_7_native)

  writer = new Writer(null).enable_native_v13()
  writer.writeScId(0, 5)
  assert.strictEqual(writer.buffer.toString('hex'), vectors.scid_0_5_native)
})

check('native packed booleans match python', () => {
  const writer = new Writer(null).enable_native_v13()
  for (const flag of [true, true, false, true, false, false, false, true, true]) {
    writer.writeBoolean(flag)
  }
  assert.strictEqual(writer.buffer.toString('hex'), vectors.native_booleans)
})

check('writeString/writeInt/writeLong/writeUInt8/little-endian/writeHexa match python', () => {
  const writer = new Writer(null)
  writer.writeString('Olá')
  writer.writeString()
  assert.strictEqual(writer.buffer.toString('hex'), vectors.strings)

  const mixed = new Writer(null)
  mixed.writeInt(-2)
  mixed.writeInt(-1, 2)
  mixed.writeUInt8(255)
  mixed.writeLong(1, 2)
  mixed.writeIntLittleEndian(1000, 4)
  mixed.writeHexa('AA-BB CC')
  mixed.writeVint(-7, false)
  assert.strictEqual(mixed.buffer.toString('hex'), vectors.mixed_writes)
})

check('reader round-trips the python-produced buffers', () => {
  for (const [value] of vectors.vint_legacy) {
    const expected = Number.parseInt(value, 10)
    const writer = new Writer(null)
    writer.writeVint(expected)
    const reader = new BSMessageReader(writer.buffer)
    assert.strictEqual(reader.read_Vint(), expected, `read_Vint(${expected})`)
  }
  for (const [value] of Object.entries(vectors.vint_native)) {
    const expected = Number.parseInt(value, 10)
    const writer = new Writer(null).enable_native_v13()
    writer.writeVint(expected)
    const reader = new BSMessageReader(writer.buffer).enable_native_v13()
    assert.strictEqual(reader.read_Vint(), expected, `native read_Vint(${expected})`)
  }

  const native = new Writer(null).enable_native_v13()
  native.writeVint(-300)
  native.writeBoolean(true)
  native.writeBoolean(false)
  native.writeVint(123456)
  native.writeString('Olá')
  const reader = new BSMessageReader(native.buffer).enable_native_v13()
  assert.strictEqual(reader.read_Vint(), -300)
  assert.strictEqual(reader.read_boolean(), true)
  assert.strictEqual(reader.read_boolean(), false)
  assert.strictEqual(reader.read_Vint(), 123456)
  assert.strictEqual(reader.read_string(), 'Olá')
  reader.ensure_end()
})

check('readScId/readLogicLong/read_int/read_short round-trip', () => {
  const writer = new Writer(null)
  writer.writeScId(3, 7)
  const reader = new BSMessageReader(writer.buffer)
  assert.deepStrictEqual(reader.readScId(), [3, 7])

  const longWriter = new Writer(null)
  longWriter.writeVint(4)
  longWriter.writeVint(11)
  const longReader = new BSMessageReader(longWriter.buffer)
  assert.deepStrictEqual(longReader.readLogicLong(), [4, 11])

  const intWriter = new Writer(null)
  intWriter.writeInt(65536)
  intWriter.writeInt16(513)
  const intReader = new BSMessageReader(intWriter.buffer)
  assert.strictEqual(intReader.read_int(), 65536)
  assert.strictEqual(intReader.read_short(), 513)
})

console.log(`\n${passed} checks passed`)
