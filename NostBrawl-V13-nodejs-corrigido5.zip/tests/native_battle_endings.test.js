'use strict'
const assert = require('node:assert/strict')
const { NativeBattleBridge } = require('../Logic/Battle/NativeBattleBridge')
const { NativeBattleWorld } = require('../Logic/Battle/Game/NativeBattleWorld')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
const assets = new BattleAssets(); const runtime = new NativeBattleBridge()
const selected = process.env.NATIVE_ENDING_MODES ? process.env.NATIVE_ENDING_MODES.split(',') : null
try {
  const seen = new Set()
  for (const location of assets.tables.locations) {
    if (!location.AllowedMaps || location.Disabled === 'true' || location.GameMode === 'Tutorial' || seen.has(location.GameMode)) continue
    if (selected && !selected.includes(location.GameMode)) continue
    seen.add(location.GameMode)
    const human = { index: 0, team: 0, brawlerId: 0, skinId: 0, powerLevel: 0,
      player: { low_id: 1, name: 'Native ending', Brawler_starPower: {} }, session: { input: new InputBuffer() } }
    const world = new NativeBattleWorld('ending-' + seen.size, assets, location.id, [human], 17, runtime)
    world.players[0].ready = true
    let ends = 0; let result
    world.on('finished', value => { ends++; result = value })
    for (let i = 0; i < 6500 && world.phase !== 'finished'; i++) world.step()
    assert.equal(world.phase, 'finished', location.GameMode)
    assert.equal(ends, 1); assert.equal(result.reason, 'native-game-over')
    assert.equal(world.nativeActive, false)
    if ([0, 2, 3, 5].includes(world.mode.variation)) {
      const [a, b] = world.state.teamScores
      assert.equal(result.winner, a === b ? null : a > b ? 0 : 1)
    }
    if ([6, 9].includes(world.mode.variation)) {
      assert(world.players.every(player => player.rank >= 1 && player.rank <= (world.mode.variation === 6 ? 10 : 5)))
      assert.equal(world.players.find(player => player.rank === 1).team, result.winner)
      if (world.mode.variation === 9) for (const entry of world.players) {
        assert(world.players.filter(other => other.team === entry.team).every(other => other.rank === entry.rank))
      }
    }
    world.step(); world.finish(null, 'shutdown'); assert.equal(ends, 1)
    console.log('Native adapter ended:', location.GameMode, 'tick', world.tick, 'winner', result.winner, 'human rank', world.players[0].rank)
  }
  assert.equal(seen.size, selected ? selected.length : 9)
  console.log(`${seen.size} native session adapters ended once, projected results/placements and destroyed their original matches`)
} finally { runtime.close() }
