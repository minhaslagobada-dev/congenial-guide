'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'mode-lifecycles.json')))
assert.equal(records.length, 9)
assert.equal(new Set(records.map(record => record.gameMode)).size, 9)
for (const record of records) {
  assert.equal(record.error, undefined)
  assert.equal(record.cleanupError, undefined)
  assert.equal(record.finished, true, record.gameMode)
  assert.equal(record.initial.ended, false)
  assert.equal(record.checkpoints.at(-1).ended, true)
  assert.equal(record.checkpoints.at(-1).tick, record.framesProcessed)
  assert(record.checkpoints.slice(0, -1).every(state => !state.ended))
}
console.log('Nine original mode lifecycles naturally ended and were destroyed; one idle human and native bots, no Android/UDP certification')
