'use strict'
// Full team cycle with real encrypted v13 protocol clients:
//  4-character room code -> join by code (typed with and without the client's
//  'X') -> same brawler -> PRONTO refused with the native TeamError 17 ->
//  brawler change -> both PRONTO -> 24130 + matchmaking together -> one match,
//  same side -> result -> both return home (winner and loser) -> room and code
//  kept -> new match -> member closes the game -> room persists -> automatic
//  return on login -> leader closes the game -> room persists -> return ->
//  brawler change after PRONTO revalidated -> offline expiry. Repeated on
//  several maps/modes.
const assert = require('node:assert/strict')
const { Server } = require('../main')
const { GameRoomService } = require('../Logic/GameRoomService')
const TeamCode = require('../Logic/TeamCode')
const Skins = require('../Files/CsvLogic/Skins')
const DataBase = require('../Database/DatabaseManager')
const Device = require('../Logic/Device')
const { Players } = require('../Logic/Player')
const { createClientFactory, vint, bool, string, wait, Reader } = require('./helpers/v13_client')

const server = new Server('127.0.0.1', 0)
const factory = createClientFactory(server)
assert.equal(factory.settings.Store.Enabled, false, 'Use the isolated battle test runner')

const createTeam = (peer, map = 0, slot = 1) => peer.send(14350, Buffer.concat([vint(map), vint(slot), vint(0), bool(false)]))
const ready = (peer, value) => peer.send(14355, Buffer.concat([bool(value), vint(0)]))
const leave = peer => peer.send(14353, Buffer.alloc(0))
const setBrawler = (peer, brawler) => peer.send(14354, Buffer.concat([vint(0), vint(29), vint(Skins.get_default_skin(brawler))]))
// Client join-by-code (libg 0x3088f8 / 0x31b200): skips the FIRST typed
// character, converts the rest from base 31 and sends high, low, 1.
const typeCode = (peer, typed) => {
  let value = 0
  for (const ch of typed.toUpperCase().slice(1)) value = value * 31 + TeamCode.ALPHABET.indexOf(ch)
  peer.send(14358, Buffer.concat([vint(value & 0xff), vint(Math.floor(value / 256)), vint(1)]))
}
const joinOrCreate = (peer, text) => peer.send(14371, string(text))

function parseRoom (raw) {
  const r = new Reader(raw)
  const room = { type: r.vint(), practice: r.boolean(), capacity: r.vint() }
  room.high = r.take(4).readInt32BE(); room.id = r.take(4).readInt32BE()
  r.vint(); r.boolean(); r.boolean(); r.vint(); room.slot = r.vint(); r.vint(); room.map = r.vint()
  const count = r.vint(); room.members = []
  for (let i = 0; i < count; i++) {
    const m = { host: r.boolean() }
    m.high = r.take(4).readInt32BE(); m.low = r.take(4).readInt32BE()
    m.name = r.take(r.take(4).readInt32BE()).toString(); r.vint()
    r.vint(); m.brawler = r.vint(); r.vint(); m.skin = r.vint()
    m.trophies = r.vint(); m.highest = r.vint(); m.power = r.vint(); m.status = r.vint(); m.ready = r.boolean(); m.team = r.vint(); r.vint()
    room.members.push(m)
  }
  return room
}
const lastRoom = (peer, since = 0) => {
  const list = peer.messages.slice(since).filter(m => m.type === 24124)
  return list.length ? parseRoom(list[list.length - 1].raw) : null
}
const teamErrors = (peer, since) => peer.messages.slice(since).filter(m => m.type === 24129).map(m => { const r = new Reader(m.raw); r.vint(); return r.vint() })
const roomOf = low => { for (const room of Object.values(GameRoomService._entries)) if (room.members.some(m => m.low_id === low)) return room; return null }
const session = low => server.Clients.Clients[String(low)] && server.Clients.Clients[String(low)].Player
const trophiesOf = (peer, brawler) => Math.trunc((session(peer.account.low).brawlers_trophies || {})[String(brawler)] || 0)
const storedTrophies = (peer, brawler) => {
  const loaded = new Players(new Device({ write: () => {} }))
  loaded.token = session(peer.account.low).token
  assert.notEqual(DataBase.loadAccount({ player: loaded }), false)
  return Math.trunc((loaded.brawlers_trophies || {})[String(brawler)] || 0)
}
// 23456 header: game mode, result/rank, tokens, trophies (libg 0x2395f4).
const resultHeader = (peer, since) => {
  const message = peer.messages.slice(since).find(m => m.type === 23456)
  const r = new Reader(message.raw)
  return { mode: r.vint(), result: r.vint(), tokens: r.vint(), trophies: r.vint() }
}

function unlockAll (peer) {
  const player = session(peer.account.low)
  const state = { ...(player.BrawlersUnlockedState || {}) }
  for (const id of [0, 1, 2, 3, 16, 23]) state[String(id)] = 1
  player.BrawlersUnlockedState = state
  // Start at 100 trophies so defeats really take trophies away.
  const trophies = { ...(player.brawlers_trophies || {}) }
  for (const id of [0, 1, 2, 3, 16, 23]) trophies[String(id)] = 100
  player.brawlers_trophies = trophies
  DataBase.replaceValues({ player }, { UnlockedBrawlers: state, brawlersTrophies: trophies })
}

async function expire (coordinator) {
  // Test clock only: skip the 15 s queue window (bots fill the match).
  for (const bucket of coordinator.matchmaker.buckets.values()) for (const ticket of bucket) ticket.joinedAt -= 60000
}

async function main () {
  try {
    await server.start()
    const coordinator = server.battleCoordinator
    const errors = []; coordinator.on('battleError', e => errors.push(e.message))
    let a = await factory.login('leader'); let b = await factory.login('member')
    unlockAll(a); unlockAll(b)

    // ---- 1. code: 4 characters, unique, generated at creation ----------
    let since = a.messages.length
    createTeam(a)
    await a.waitFor(24124, 3000, since)
    let room = lastRoom(a, since)
    assert(room.id >= 117 && room.id <= 3607, 'room id gives a 4-character code')
    const code = TeamCode.short_code(room.id)
    assert.match(code, /^[A-Z0-9]{4}$/, 'code is 4 uppercase alphanumerics')
    assert.equal(TeamCode.to_code(0, room.id), 'X' + code, 'the v13 client shows X + the same 4 characters')
    const roomId = room.id
    console.log('team code', code, '(client shows X' + code + ')')

    // ---- 2. invalid / unknown codes -> native team errors, nobody moved --
    since = b.messages.length
    joinOrCreate(b, 'ZZ!!'); await b.waitFor(24129, 3000, since)
    assert.deepEqual(teamErrors(b, since), [5], 'invalid code -> TID_TEAM_ERROR_5')
    let unknown = 117; while (GameRoomService._entries[unknown]) unknown++
    since = b.messages.length
    joinOrCreate(b, TeamCode.short_code(unknown)); await b.waitFor(24129, 3000, since)
    assert.deepEqual(teamErrors(b, since), [6], 'unknown code -> TID_TEAM_ERROR_6')
    since = b.messages.length
    typeCode(b, 'X' + TeamCode.short_code(unknown)); await b.waitFor(24129, 3000, since)
    assert.deepEqual(teamErrors(b, since), [6], 'unknown code typed in the client -> TID_TEAM_ERROR_6')
    assert.equal(roomOf(b.account.low), null)

    // ---- 3. join by typing ONLY the 4 characters (client drops the first) --
    since = b.messages.length
    typeCode(b, code); await b.waitFor(24124, 3000, since)
    room = lastRoom(b, since)
    assert.equal(room.id, roomId, 'typed 4-char code joins the right room')
    assert.equal(room.members.length, 2)
    // leave and re-join with the client form X+code and with 14371 'x' + code
    since = b.messages.length; leave(b); await wait(200)
    assert.equal(roomOf(b.account.low), null)
    typeCode(b, 'X' + code); await b.waitFor(24124, 3000, since)
    assert.equal(roomOf(b.account.low).id, roomId, 'X+code joins the same room')
    since = b.messages.length; leave(b); await wait(200)
    joinOrCreate(b, ' x' + code.toLowerCase() + ' '); await b.waitFor(24124, 3000, since)
    assert.equal(roomOf(b.account.low).id, roomId, '14371 accepts the 4 characters with/without X, any case')

    const maps = [7, 0, 17, 24, 48, 34, 35]
    const WINS = new Set([0, 35])
    let first = true
    for (const map of maps) {
      GameRoomService._entries[roomId].map_id = map
      // ---- 4. same brawler -> PRONTO refused with TeamError 17 ----------
      setBrawler(a, 0); setBrawler(b, 0); await wait(250)
      since = b.messages.length; let sinceA = a.messages.length
      ready(b, true)
      await b.waitFor(24129, 3000, since)
      assert.deepEqual(teamErrors(b, since), [17], 'duplicate brawler -> native TID_TEAM_ERROR_17')
      await wait(150)
      assert(!b.closed && roomOf(b.account.low).id === roomId, 'refused member stays in the room')
      assert(roomOf(b.account.low).members.every(m => !m.ready), 'ready not confirmed')
      assert(lastRoom(b, since).members.every(m => !m.ready), 'clients see nobody ready')
      assert(!coordinator.matchmaker.players.has(b.account.low), 'no search with duplicates')
      // crafted: leader ready too -> also refused; still no search
      ready(a, true); await a.waitFor(24129, 3000, sinceA)
      assert(!coordinator.matchmaker.players.has(a.account.low))

      // ---- 5. change brawler -> both ready -> 24130 + search together ----
      setBrawler(b, first ? 1 : 16); await wait(200)
      since = b.messages.length; sinceA = a.messages.length
      ready(a, true); ready(b, true)
      await a.waitFor(24130, 3000, sinceA); await b.waitFor(24130, 3000, since)
      await a.waitFor(20405, 3000, sinceA); await b.waitFor(20405, 3000, since)
      const idx = (p, s, t) => p.messages.slice(s).findIndex(m => m.type === t)
      assert(idx(a, sinceA, 24130) < idx(a, sinceA, 20405), '24130 opens the popup before the first 20405')
      assert.equal(coordinator.matchmaker.players.get(a.account.low), coordinator.matchmaker.players.get(b.account.low), 'one ticket')
      await expire(coordinator)
      await a.waitFor(20559, 5000, sinceA); await b.waitFor(20559, 5000, since)
      const worlds = Array.from(coordinator.worlds.values()).filter(w => w.players.some(p => !p.bot && p.player.low_id === a.account.low))
      assert.equal(worlds.length, 1, 'exactly one match for the team')
      const world = worlds[0]
      const ea = world.players.find(p => !p.bot && p.player.low_id === a.account.low)
      const eb = world.players.find(p => !p.bot && p.player.low_id === b.account.low)
      assert(ea && eb && ea.team === eb.team, 'allies on the same side')
      assert.notEqual(ea.brawlerId, eb.brawlerId, 'no duplicate brawler in the match')
      assert(!a.closed && !b.closed)
      await wait(400)

      // ---- 6. end: alternate defeat / victory; both return home ----------
      const lose = !WINS.has(map)
      const showdown = world.mode.name === 'BattleRoyaleTeam'
      const before = { a: trophiesOf(a, ea.brawlerId), b: trophiesOf(b, eb.brawlerId) }
      if (showdown && !lose) {
        // Duo Showdown win: the team is the last one standing (rank 1).
        for (const entry of world.players) entry.rank = entry.team === ea.team ? 1 : 2 + (entry.team % 4)
      }
      world.finish(lose ? 1 - ea.team : ea.team, 'test-result')
      await a.waitFor(23456, 3000, sinceA); await b.waitFor(23456, 3000, since)
      const resultA = resultHeader(a, sinceA); const resultB = resultHeader(b, since)
      const sinceHomeA = a.messages.length; const sinceHomeB = b.messages.length
      sinceA = a.messages.length; since = b.messages.length
      a.send(14101, Buffer.from([0])); b.send(first ? 14108 : 14101, first ? Buffer.alloc(0) : Buffer.from([0]))
      await a.waitFor(24101, 3000, sinceA); await b.waitFor(24101, 3000, since)
      await wait(200)
      // ---- trophies: reward, result screen, menu badge, database ----------
      for (const [peer, entry, result, sinceHome, key] of [[a, ea, resultA, sinceHomeA, 'a'], [b, eb, resultB, sinceHomeB, 'b']]) {
        const after = trophiesOf(peer, entry.brawlerId)
        const gain = after - before[key]
        if (!lose) assert.equal(gain, showdown ? 15 : 10, `${showdown ? 'Showdown' : '3v3'} win gives exactly +${showdown ? 15 : 10} (map ${map})`)
        else assert(gain < 0, `a defeat takes trophies away (map ${map}, ${gain})`)
        assert.equal(result.trophies, gain, 'result screen shows the trophies actually granted')
        assert.equal(storedTrophies(peer, entry.brawlerId), after, 'trophies persisted in the database')
        const list = peer.messages.slice(sinceHome)
        const homeAt = list.findIndex(m => m.type === 24101)
        const roomAfterHome = list.slice(homeAt + 1).filter(m => m.type === 24124)
        assert(roomAfterHome.length > 0, 'room data follows the home data')
        const room = parseRoom(roomAfterHome[roomAfterHome.length - 1].raw)
        for (const [other, otherEntry] of [[a, ea], [b, eb]]) {
          const member = room.members.find(m => m.low === other.account.low)
          assert.equal(member.trophies, trophiesOf(other, otherEntry.brawlerId), 'menu badges show the new trophies at once (own and team mate)')
        }
      }
      assert(!a.closed && !b.closed, `${lose ? 'losers' : 'winners'} return to the menu connected (map ${map})`)
      assert.equal(roomOf(a.account.low).id, roomId, 'room kept after the match')
      assert.equal(roomOf(b.account.low).id, roomId)
      console.log('map', map, world.mode.name, lose ? 'defeat' : 'victory', 'trophies', `a ${before.a}->${trophiesOf(a, ea.brawlerId)}`, `b ${before.b}->${trophiesOf(b, eb.brawlerId)}`, 'ok')
      first = false
    }

    // ---- 7. brawler change after PRONTO is revalidated -------------------
    setBrawler(a, 0); setBrawler(b, 1); await wait(200)
    let since2 = b.messages.length
    ready(b, true); await wait(200)
    assert(roomOf(b.account.low).members.find(m => m.low_id === b.account.low).ready, 'b ready')
    setBrawler(b, 0); await b.waitFor(24129, 3000, since2)
    await wait(150)
    assert.deepEqual(teamErrors(b, since2), [17])
    assert(!roomOf(b.account.low).members.find(m => m.low_id === b.account.low).ready, 'ready invalidated by the change')
    // queued team: the duplicate cancels the search (20406) for everyone
    setBrawler(b, 1); await wait(150)
    let sinceA2 = a.messages.length; since2 = b.messages.length
    ready(a, true); ready(b, true); await a.waitFor(20405, 3000, sinceA2)
    setBrawler(a, 1)
    await a.waitFor(20406, 3000, sinceA2); await b.waitFor(20406, 3000, since2)
    await wait(150)
    assert(!coordinator.matchmaker.players.has(a.account.low) && !coordinator.matchmaker.players.has(b.account.low), 'search cancelled')
    assert(roomOf(a.account.low).members.every(m => !m.ready))
    // non-duplicate change while queued keeps the search with the new brawler
    setBrawler(a, 0); await wait(150)
    sinceA2 = a.messages.length
    ready(a, true); ready(b, true); await a.waitFor(20405, 3000, sinceA2)
    setBrawler(b, 16); await wait(200)
    const ticket = coordinator.matchmaker.players.get(b.account.low)
    assert(ticket && ticket.members.find(m => m.player.low_id === b.account.low).brawlerId === 16, 'queued ticket follows the new brawler')
    sinceA2 = a.messages.length; ready(a, false); await a.waitFor(20406, 3000, sinceA2)

    // ---- 8. member closes the game: room persists, automatic return -------
    sinceA2 = a.messages.length
    b.socket.destroy(); try { b.udp.close() } catch (_) {}
    await a.waitFor(24124, 3000, sinceA2); await wait(200)
    let internal = GameRoomService._entries[roomId]
    assert(internal && internal.members.length === 2, 'room NOT disbanded when a member closes the game')
    room = lastRoom(a, sinceA2)
    assert.equal(room.members.find(m => m.low === b.account.low).status, 0, 'member shown OFFLINE')
    assert.equal(roomOf(a.account.low).id, roomId, 'same room id / code')
    b = await factory.login('member-back', b.account)
    await b.waitFor(24124, 3000, 0)
    room = lastRoom(b)
    assert.equal(room.id, roomId, 'member returns automatically to the same room')
    assert.equal(room.members.length, 2, 'no duplicate member')
    assert(room.members.every(m => !m.ready), 'ready revalidated after reconnect')
    assert.notEqual(room.members.find(m => m.low === b.account.low).status, 0, 'member online again')
    assert.equal(Object.values(GameRoomService._entries).filter(r => r.members.some(m => m.low_id === b.account.low)).length, 1, 'no ghost room')

    // ---- 9. leader closes the game: room persists, leader returns ---------
    let sinceB = b.messages.length
    a.socket.destroy(); try { a.udp.close() } catch (_) {}
    await b.waitFor(24124, 3000, sinceB); await wait(200)
    internal = GameRoomService._entries[roomId]
    assert(internal && internal.members.length === 2, 'room NOT disbanded when the leader closes the game')
    assert(internal.members.find(m => m.low_id === a.account.low).host, 'leader keeps the host flag')
    a = await factory.login('leader-back', a.account)
    await a.waitFor(24124, 3000, 0)
    room = lastRoom(a)
    assert.equal(room.id, roomId)
    assert(room.members.find(m => m.low === a.account.low).host, 'leader back as host')
    assert.equal(TeamCode.short_code(room.id), code, 'code unchanged across disconnects')

    // ---- 10. after reconnects the team plays again (allies, one match) ----
    setBrawler(a, 0); setBrawler(b, 1); await wait(200)
    sinceA2 = a.messages.length; sinceB = b.messages.length
    ready(a, true); ready(b, true)
    await a.waitFor(24130, 3000, sinceA2); await a.waitFor(20405, 3000, sinceA2)
    await expire(coordinator)
    await a.waitFor(20559, 5000, sinceA2); await b.waitFor(20559, 5000, sinceB)
    const world = Array.from(coordinator.worlds.values()).find(w => w.players.some(p => !p.bot && p.player.low_id === a.account.low))
    assert.equal(world.players.find(p => p.player.low_id === a.account.low).team, world.players.find(p => p.player.low_id === b.account.low).team)
    await wait(300)
    world.finish(null, 'test-result')
    await a.waitFor(23456, 3000, sinceA2)
    sinceA2 = a.messages.length; sinceB = b.messages.length
    a.send(14101, Buffer.from([0])); b.send(14101, Buffer.from([0]))
    await a.waitFor(24101, 3000, sinceA2); await b.waitFor(24101, 3000, sinceB)

    // ---- 11. everybody offline -> configurable expiry retires the room ----
    GameRoomService._offline_expiry_ms = () => 600
    a.socket.destroy(); b.socket.destroy(); await wait(300)
    assert(GameRoomService._entries[roomId], 'room still alive right after both closed the game')
    await wait(800)
    assert(!GameRoomService._entries[roomId], 'room retired after the offline expiry')
    const a3 = await factory.login('leader-late', a.account)
    await wait(300)
    assert.equal(roomOf(a3.account.low), null, 'no ghost room after expiry')
    assert.equal(session(a3.account.low).room_id, 0)

    assert.deepEqual(errors.filter(e => !/recusada/.test(e)), [], 'no battle errors')
    console.log('TEAM FULL CYCLE E2E OK')
  } finally {
    factory.closeAll(); await server.close()
  }
}

const timer = setTimeout(() => { console.error('team full cycle e2e timeout'); process.exit(1) }, 140000)
main().then(() => { clearTimeout(timer) }, error => { clearTimeout(timer); console.error(error); process.exitCode = 1 })
