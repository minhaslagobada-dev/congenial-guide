'use strict'
const assert = require('node:assert/strict')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
const { EventEmitter } = require('node:events')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const { TileMap } = require('../Logic/Battle/World/TileMap')
class Transport extends EventEmitter {
  constructor () { super(); this.gateway = { port: 12345 } }
  attach (player, client) {
    player.battleTransport = this
    const session = { player, client, header: Buffer.alloc(10), host: '127.0.0.1', input: new InputBuffer(), closed: false }
    player.udp_session = session
    return session
  }
  release (player) { if (player.udp_session) player.udp_session.closed = true; player.udp_session = null; return true }
  send () { return false }
}
let nextId = 5000
const member = () => ({ player: { low_id: ++nextId, logged_in: true, brawler_id: 0, skin_id: 0, Brawler_level: {} }, client: { destroyed: false, writes: [], write (bytes) { this.writes.push(bytes); return true } } })
const coordinator = new BattleCoordinator(new Transport())
clearInterval(coordinator.timer)
const errors = []; coordinator.on('battleError', error => errors.push(error))
let now = 0; coordinator.matchmaker.now = () => now
try {
  const human = member(); coordinator.enqueue([human], 7)
  coordinator.step(); assert.equal(coordinator.worlds.size, 0)
  now = 14999; coordinator.step(); assert.equal(coordinator.worlds.size, 0)
  now = 15000; coordinator.step()
  const world = coordinator.accounts.get(human.player.low_id)
  assert(world); assert.equal(world.players.length, 6)
  const bots = world.players.filter(p => p.bot)
  assert.equal(bots.length, 5)
  assert.equal(coordinator.accounts.size, 1, 'Bots cannot consume authenticated account slots')
  assert(bots.every(p => p.session === null && p.client === null && p.ready))
  assert.equal(new Set(world.players.map(p => p.player.low_id)).size, 6)
  assert.equal(world.phase, 'loading', 'Only the human needs to finish loading')
  assert.equal(human.client.writes.filter(b => b.readUInt16BE() === 20559).length, 1)
  world.input(world.players[0], { type: 4 }); world.step()
  assert.equal(world.phase, 'running', 'Bots must not wait for nonexistent UDP peers')
  world.map = new TileMap(Array(33).fill('.'.repeat(21)), coordinator.assets)
  const own = world.characters.get(human.player.low_id)
  Object.assign(own, { x: 1500, y: 1500 })
  for (const entry of bots) Object.assign(world.characters.get(entry.player.low_id), { x: 1500 + entry.team * 500, y: 2400 + entry.index * 300 })
  const positions = bots.map(entry => ({ ...world.characters.get(entry.player.low_id) }))
  let damage = false
  for (let tick = 0; tick < 100; tick++) {
    world.step()
    if (Array.from(world.characters.values()).some(c => c.hp < c.maxHp)) damage = true
  }
  assert(bots.some((entry, i) => {
    const char = world.characters.get(entry.player.low_id)
    return Math.hypot(char.x - positions[i].x, char.y - positions[i].y) > 100
  }), 'Bots must navigate the world')
  assert(damage, 'Bots must deal authoritative combat damage')
  assert(bots.some(entry => world.characters.get(entry.player.low_id).lastAttack >= 0), 'Bots must activate real skills')
  coordinator.disconnect(human.player, human.client)
  assert.equal(coordinator.worlds.size, 0, 'The last real player leaving must clean up bots')
  assert.equal(coordinator.accounts.size, 0)
  for (const mapId of [13, 34, 21, 27, 57]) {
    const h = member(); coordinator.enqueue([h], mapId); now += 15000; coordinator.step()
    const w = coordinator.accounts.get(h.player.low_id)
    assert(w); assert.equal(w.players.length, w.mode.capacity)
    const counts = new Map()
    for (const p of w.players) counts.set(p.team, (counts.get(p.team) || 0) + 1)
    if (mapId === 21) assert.deepEqual(Array.from(counts.values()), [5, 1])
    if (mapId === 34) assert(Array.from(counts.values()).every(n => n === 2))
    coordinator.disconnect(h.player, h.client)
  }
  assert.equal(errors.length, 0, errors.map(e => e.stack).join('\n'))
  console.log('BOTS OK: timeout roster, native loading, all team capacities, navigation, real skill damage and last-human cleanup')
} finally { coordinator.close() }
