'use strict'
const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const { GameRoomService } = require('../Logic/GameRoomService')
const { BattleRewardsManager } = require('../Logic/BattleRewardsManager')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
class Transport extends EventEmitter {
  constructor () { super(); this.gateway = { port: 12345 } }
  attach (player, client) { player.battleTransport = this; const session = { player, client, header: Buffer.alloc(10), host: '127.0.0.1', input: new InputBuffer(), closed: false }; player.udp_session = session; return session }
  release (player) { player.udp_session = null }
  send () { return true }
}
let roomId = 0, nextId = 10000, now = 0
const rooms = new Map(), oldGet = GameRoomService.get
GameRoomService.get = id => rooms.get(id) || null
const c = new BattleCoordinator(new Transport()); clearInterval(c.timer); c.matchmaker.now = () => now
const errors = []; c.on('battleError', error => errors.push(error))
function room (mapId = 7, count = 1) {
  const members = Array.from({ length: count }, () => ({ player: { low_id: ++nextId, logged_in: true, brawler_id: 0, name: 'Private', Brawler_level: {} }, client: { destroyed: false, write () { return true } } }))
  const registry = Object.fromEntries(members.map(m => [m.player.low_id, { Player: m.player, SocketInfo: m.client }]))
  for (const m of members) m.player.ClientDict = { Clients: registry }
  const snapshot = { id: ++roomId, map_id: mapId, practice: true, members: members.map(m => ({ low_id: m.player.low_id, team: 0, ready: true, brawler_id: 0, skin_id: 0 })) }
  rooms.set(snapshot.id, snapshot)
  return { members, snapshot, player: members[0].player }
}
try {
  const a = room(), b = room()
  const ticket = c.readyRoom(a.player, a.snapshot)
  c.readyRoom(b.player, b.snapshot)
  assert.equal(c.readyRoom(a.player, a.snapshot), ticket, 'Repeated ready cannot reset deadline')
  assert.equal(c.matchmaker.players.size, 0, 'Private participants never enter public matchmaking')
  now = 14999; c.step(); assert.equal(c.worlds.size, 0)
  now = 15000; c.step(); assert.equal(c.worlds.size, 2, 'Separate private rooms cannot be combined')
  const world = c.accounts.get(a.player.low_id)
  assert.equal(world.players.length, 6); assert.equal(world.players.filter(p => p.bot).length, 5)
  assert.equal(world.practice, true); assert.equal(c.privatePlayers.size, 0)
  c.disconnect(a.player, a.members[0].client); c.disconnect(b.player, b.members[0].client)
  const cancel = room(); c.readyRoom(cancel.player, cancel.snapshot)
  assert(c.cancel(cancel.player, cancel.members[0].client)); now += 16000; c.step()
  assert.equal(c.worlds.size, 0)
  const changed = room(); c.readyRoom(changed.player, changed.snapshot)
  changed.snapshot.map_id = 13; c.step(); assert.equal(c.privateRooms.size, 0, 'Changing the room cancels the stale queue')
  const full = room(7, 6); c.readyRoom(full.player, full.snapshot); c.step()
  const fullWorld = c.accounts.get(full.player.low_id)
  assert(fullWorld); assert.equal(fullWorld.players.filter(p => p.bot).length, 0)
  assert.deepEqual(fullWorld.players.map(p => p.team), [0, 0, 0, 1, 1, 1])
  assert.equal(errors.length, 0, errors.map(e => e.stack).join('\n'))
  const player = { brawlers_trophies: { 0: 500 }, brawlers_trophies_in_rank: { 0: 600 }, trophies: 500, player_experience: 100, battle_tokens: 200, tokensdoubler: 1000, tutorial: 2 }
  const before = structuredClone(player)
  const reward = new BattleRewardsManager(player)._apply_rewards({ GameMode: 0, Victory: 0, Practice: true, Heroes: [{ IsPlayer: true, Brawler: { ID: [16, 0] } }] })
  assert.equal(reward.tokens_gain, 0); assert.equal(reward.trophies_gain, 0); assert.equal(reward.experience, 0); assert.equal(reward.star_player_exp, 0)
  assert.deepEqual(player, before, 'Friendly matches cannot grant progression or consume resources')
  console.log('PRIVATE ROOMS OK: isolated 15-second queues, bots, full roster, cancellation, room changes and zero rewards')
} finally { c.close(); GameRoomService.get = oldGet }
