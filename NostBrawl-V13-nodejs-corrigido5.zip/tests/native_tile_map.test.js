'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
if (process.env.V13_MAP) throw new Error('Full map audit requires every map, without V13_MAP filter')
const maps = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'tile-map-vectors.json')))
const assets = new BattleAssets()
assert.equal(maps.length, assets.maps.size)
assert.equal(new Set(maps.map(map => map.name)).size, maps.length)
let staticMaps = 0
for (const map of maps) {
  const source = assets.maps.get(map.name)
  assert(source, map.name)
  assert.equal(map.logicWidth, map.width * 300, map.name)
  assert.equal(map.logicHeight, map.height * 300, map.name)
  assert.equal(map.fineWidth, map.width * 3, map.name)
  assert.equal(map.fineHeight, map.height * 3, map.name)
  assert.equal(map.tiles, map.width * map.height, map.name)
  assert.equal(map.grid.length, map.height, map.name)
  assert(map.grid.every(row => row.length === map.width), map.name)
  for (const row of map.grid) for (const code of row) assert(assets.tileCodes.has(code) || /^[0-9]$/.test(code), `${map.name}: ${code}`)
  if (!source.fromBlocks) { assert.deepEqual(map.grid, source.rows, map.name); staticMaps++ }
}
console.log(`Original map constructors: ${maps.length} groups, ${staticMaps} exact static CSV grids; native generated grids, dimensions and fine-grid allocation verified`)
