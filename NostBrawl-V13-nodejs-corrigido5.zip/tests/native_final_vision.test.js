'use strict'
const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const { NativeBattleBridge } = require('../Logic/Battle/NativeBattleBridge')
const { NativeBattleWorld } = require('../Logic/Battle/Game/NativeBattleWorld')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
class Transport extends EventEmitter {
  release (player) { player.udp_session.closed = true; player.udp_session = null }
}
const runtime = new NativeBattleBridge(); const coordinator = new BattleCoordinator(new Transport(), { NativeRuntime: runtime })
clearInterval(coordinator.timer)
const errors = []; coordinator.on('battleError', error => errors.push(error))
const client = { destroyed: false, writableLength: 300000, packets: [], write (packet) { this.packets.push(packet); return true } }
const player = { low_id: 1, name: 'Final vision', brawler_id: 0, Brawler_level: {} }
const session = { player, client, input: new InputBuffer(), closed: false }
try {
  const map = coordinator.assets.named('locations', 'Gemgrab1').id
  const world = new NativeBattleWorld('final-vision', coordinator.assets, map, [{ index: 0, team: 0, brawlerId: 0, skinId: 0, powerLevel: 0, player, client, session }], 17, runtime)
  player.onlineBattle = world; player.udp_session = session; world.players[0].ready = true
  coordinator.worlds.set(world.id, world); coordinator.accounts.set(player.low_id, world)
  let results = 0
  coordinator.result = (finished, entry) => {
    assert(finished.state.ended)
    const packet = client.packets.at(-1)
    assert(packet && packet.readUInt16BE() === 24109, 'Final native vision must precede result delivery')
    assert.deepEqual(packet.subarray(7), finished.nativeVisionPayload(entry))
    assert(Number.isInteger(finished.state.mvpIndex))
    results++
  }
  world.on('finished', outcome => coordinator.finished(world, outcome))
  for (let i = 0; i < 6500 && world.phase !== 'finished'; i++) world.step()
  assert.equal(world.phase, 'finished'); assert.equal(results, 1)
  assert.equal(coordinator.metrics.tcpSnapshots, 1, 'Final state bypasses routine snapshot backpressure once')
  assert.equal(coordinator.accounts.size, 0); assert.equal(world.nativeActive, false)
  assert.deepEqual(errors, [])
  console.log('Natural native ending: final original vision sent before result settlement, including under TCP backpressure; sessions and match released once')
} finally { coordinator.close() }
