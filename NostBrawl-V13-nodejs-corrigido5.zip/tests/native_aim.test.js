'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { turnToward } = require('../Native/V13/Aim')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'aim-vectors.json')))
for (const v of vectors) {
  const actor = { x: 3000, y: 4500, attackAngle: 90, moveAngle: 90, skills: [{ definition: v.definition, activeMs: v.activeMs, executing: v.executing }] }
  turnToward(actor, v.target)
  assert.equal(actor.attackAngle, v.attackAngle, JSON.stringify(v))
  assert.equal(actor.moveAngle, v.moveAngle, JSON.stringify(v))
}
console.log('Native turn/active-skill selection:', vectors.length, 'cases matched original v13')
