'use strict'
const assert = require('node:assert/strict')
const { NativeBattleBridge } = require('../Logic/Battle/NativeBattleBridge')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const { rules } = require('../Logic/Battle/World/GameModes')
const assets = new BattleAssets(); const runtime = new NativeBattleBridge(); const seen = new Set()
let cases = 0
try {
  for (const location of assets.tables.locations) {
    if (!location.AllowedMaps || location.Disabled === 'true' || location.GameMode === 'Tutorial' || seen.has(location.GameMode)) continue
    seen.add(location.GameMode)
    const mode = rules(location.GameMode)
    const capacities = mode.cooperative ? [mode.capacity] : mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize)
    const rosters = capacities.flatMap((_, team) => [[team]])
    for (const count of new Set([2, Math.ceil(mode.capacity / 2), mode.capacity - 1, mode.capacity])) {
      const remaining = capacities.slice(); const teams = []
      while (teams.length < count) for (let team = capacities.length - 1; team >= 0 && teams.length < count; team--) {
        if (remaining[team] > 0) { teams.push(team); remaining[team]-- }
      }
      rosters.push(teams)
    }
    for (const teams of rosters) {
      const id = 'roster-' + (++cases)
      const humans = teams.map((team, index) => ({ hero: assets.heroes[index % assets.heroes.length].Name, team, accountId: index + 1, name: 'Human ' + index, powerLevel: 1 }))
      const prepared = runtime.create(id, location.Name, 17, humans)
      try {
        assert.equal(prepared.state.players.length, mode.capacity)
        const counts = capacities.map((_, team) => prepared.state.players.filter(player => player.team === team).length)
        assert.deepEqual(counts, capacities, `${location.GameMode}: human teams ${teams}`)
        assert.equal(prepared.state.players.filter(player => !player.bot).length, teams.length)
        assert.deepEqual(prepared.state.players.slice(0, teams.length).map(player => player.team), mode.variation === 6 ? teams.map((_, index) => index) : teams)
        const frame = runtime.frame(id)
        assert.equal(frame.vision.length, teams.length)
      } finally { runtime.destroy(id) }
    }
  }
  console.log('Native mixed rosters:', cases, 'cases across 9 modes, each team as human host, partial/full human populations, original bot fill and per-human visions')
} finally { runtime.close() }
