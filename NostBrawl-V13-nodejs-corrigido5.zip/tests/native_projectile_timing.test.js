'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { timing } = require('../Native/V13/ProjectileTiming')
const directory = process.env.V13_RESEARCH_DIR
if (!directory) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(directory, 'projectile-launch-vectors.json')))
for (const v of vectors) {
  const result = timing({ ...v, start: v.actualStart })
  assert.deepEqual(result, { launch: v.launch, finish: v.finish, progressStep: v.progressStep }, JSON.stringify(v))
}
console.log('Native projectile timing:', vectors.length, 'vectors matched original v13 initializer')
