'use strict'
const assert = require('node:assert/strict')
const { battleAssets } = require('../Logic/Battle/World/BattleAssets')
const { rules } = require('../Logic/Battle/World/GameModes')
const { BattleWorld } = require('../Logic/Battle/Game/BattleWorld')
const { encodeHeader } = require('../Logic/Battle/Game/V13WorldCodec')
const { V13BitStream } = require('../Logic/Battle/Game/V13BitStream')
const assets = battleAssets()
function world (mapId) {
  const mode = rules(assets.tables.locations[mapId].GameMode)
  const caps = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
  const roster = caps.flatMap((count, team) => Array.from({ length: count }, () => ({ team })))
  for (const [index, entry] of roster.entries()) Object.assign(entry, { index, player: { low_id: index + 1, brawler_id: 0, Brawler_level: {} } })
  const w = new BattleWorld('objectives-' + mapId, assets, mapId, roster)
  roster.forEach(p => w.input(p, { type: 4 })); w.step(); return w
}
const gems = w => Array.from(w.objects.values()).filter(o => o.dataClass === 18 && assets.tables.items[o.dataId].Name === 'Point')
let maps = 0
for (const location of assets.tables.locations.filter(l => l.AllowedMaps && l.Disabled !== 'true' && l.GameMode === 'CoinRush')) {
  const w = world(location.id)
  assert.equal(gems(w).length, 0)
  assert.equal(assets.tables.items[w.gemSpawner.dataId].Name, 'OrbSpawner')
  assert(w.map.canOccupy(w.gemSpawn.x, w.gemSpawn.y, 0))
  w.tick = 139; w.step(); assert.equal(gems(w).length, 1)
  const own = w.characters.get(1)
  Object.assign(own, w.gemSpawn); w.step(); assert.equal(own.score, 1); assert.equal(gems(w).length, 0)
  own.score = 10; w.step(); assert(w.countdown)
  const stream = new V13BitStream(); encodeHeader(stream, w, w.players[0])
  const decoded = new V13BitStream(stream.bytes()); decoded.readUint(21)
  assert.equal(decoded.readUint(15), w.countdown.due, 'Native counter must contain countdown deadline, not current tick')
  const opponent = w.characters.get(4); opponent.score = 10; w.step(); assert.equal(w.countdown, null, 'A tie cancels the countdown')
  opponent.score = 11; w.step(); assert.equal(w.countdown.team, 1)
  w.damage(opponent, opponent.hp, own); assert.equal(opponent.score, 0); assert.equal(gems(w).length, 11)
  // Isolate the countdown test from pickup/respawn movement.
  for (const object of gems(w)) w.objects.delete(object.id)
  own.score = 10; w.step(); const due = w.countdown.due
  let finished = 0; w.on('finished', () => finished++)
  w.tick = due - 2; w.step(); assert.equal(w.phase, 'running')
  w.step(); assert.equal(w.phase, 'finished'); assert.equal(w.outcome.winner, 0)
  w.step(); w.finish(1, 'duplicate'); assert.equal(finished, 1)
  maps++
}
{
  const w = world(0); const own = w.characters.get(1); const opponent = w.characters.get(4)
  w.damage(opponent, opponent.hp, own)
  assert.equal(w.teamScores[0], 2); assert.equal(w.players[0].score, 2)
  w.tick = 3599; w.step(); assert.equal(w.outcome.winner, 0)
}
{
  const w = world(17)
  assert.deepEqual(w.bases.map(base => base.team), [0, 1])
  w.damage(w.bases[1], w.bases[1].hp, w.characters.get(1)); w.step()
  assert.equal(w.outcome.winner, 0); assert.equal(w.outcome.reason, 'base-destroyed')
}
for (const mapId of [13, 34]) {
  const w = world(mapId)
  for (const char of w.characters.values()) if (char.team !== 0) w.damage(char, char.hp, null)
  w.step(); assert.equal(w.phase, 'finished'); assert.equal(w.outcome.winner, 0)
  assert(w.players.filter(p => p.team === 0).every(p => p.rank === 1))
}
{
  // Poison must eventually cover the centre too; otherwise peaceful survivors
  // can leave a Showdown battle running forever.
  const w = world(13)
  for (const char of w.characters.values()) Object.assign(char, { x: w.map.logicWidth / 2, y: w.map.logicHeight / 2 })
  w.tick = 7199
  for (let tick = 0; tick < 200 && w.phase !== 'finished'; tick++) w.step()
  assert.equal(w.phase, 'finished')
}
{
  const w = world(24); const goal = w.map.markers.get('7')[1]
  Object.assign(w.ball, goal); w.ball.pickupAfter = Infinity; w.step()
  assert.equal(w.teamScores[0], 1); assert.equal(w.phase, 'running')
  w.tick = w.goalPauseUntil; Object.assign(w.ball, goal); w.step()
  assert.equal(w.teamScores[0], 2); assert.equal(w.outcome.winner, 0)
}
for (const mapId of [21, 57]) {
  const w = world(mapId); assert(w.boss)
  w.damage(w.boss, w.boss.hp, w.characters.get(1)); w.step()
  assert.equal(w.outcome.winner, 0); assert.equal(w.outcome.reason, 'boss-defeated')
}
{
  const w = world(21); w.tick = 2399; w.step(); assert.equal(w.outcome.winner, 1)
}
{
  const w = world(27); w.step(); assert.equal(w.wave, 1)
  assert(Array.from(w.objects.values()).some(o => o.dataClass === 16 && o.team === 1))
  w.damage(w.bases[0], w.bases[0].hp, null); w.step(); assert.equal(w.outcome.winner, 1)
}
{
  const w = world(27); w.tick = 7499; w.step(); assert.equal(w.outcome.winner, 0)
}
{
  const w = world(57)
  for (const char of w.characters.values()) w.damage(char, char.hp, w.boss)
  w.step(); assert.equal(w.outcome.winner, 1)
}
console.log(`OBJECTIVES OK: ${maps} Gem Grab maps, pickup/drop/countdown/reset, bounty, heist, solo/duo ranks, closing poison, goals, boss and cooperative endings`)
