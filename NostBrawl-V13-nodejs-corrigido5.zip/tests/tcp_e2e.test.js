'use strict'
// TCP end-to-end: boots the real Server on an ephemeral port and plays the
// exact V13 client flow with sockets + crypto: ClientHello -> ServerHello ->
// Login -> LoginOk + OwnHomeData. Covers the production scenario reported
// from the hosting container (new account, fingerprint mismatch, relogin,
// wrong token, persistence).
const path = require('path')
process.chdir(path.resolve(__dirname, '..'))

const cryptoMod = require('crypto')
const net = require('net')
const { blake2b } = require('blakejs')

const NaCl19 = require('../Core/NaCl19')
const { Nonce, DEFAULT_CLIENT_PRIVATE_KEY } = require('../Core/Crypto')
const DataBase = require('../Database/DatabaseManager')
const Config = require('../Utils/Config')
const { BSMessageReader } = require('../Utils/Reader')
const { Server } = require('../main')

let passed = 0
function check (label, condition) {
  if (!condition) {
    console.error(`FAIL ${label}`)
    process.exit(1)
  }
  passed += 1
  console.log(`ok ${label}`)
}

const CLIENT_SK = Buffer.from(DEFAULT_CLIENT_PRIVATE_KEY, 'hex')
const CLIENT_PK = NaCl19.scalarmultBase(CLIENT_SK)
const SERVER_PK = Buffer.from(
  (Config.GetValue().Crypto && Config.GetValue().Crypto.ServerPublicKey) ||
    'EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041',
  'hex'
)
const SHARED_KEY = NaCl19.boxBeforenm(SERVER_PK, CLIENT_SK)

function frame (id, payload, version = 0) {
  const header = Buffer.alloc(7)
  header.writeUInt16BE(id, 0)
  header.writeUIntBE(payload.length, 2, 3)
  header.writeUInt16BE(version, 5)
  return Buffer.concat([header, payload])
}

function buildLoginPayload (highId, lowId, token, fingerprintSha) {
  const settings = Config.GetValue()
  const int32 = (v) => { const b = Buffer.alloc(4); b.writeInt32BE(v, 0); return b }
  const string = (v) => { const raw = Buffer.from(String(v), 'utf-8'); return Buffer.concat([int32(raw.length), raw]) }
  return Buffer.concat([
    int32(highId), int32(lowId), string(token),
    int32(settings.ClientMajor), int32(settings.ClientMinor), int32(settings.ClientBuild),
    string(fingerprintSha),
    string(''),
    string('tcp-e2e-udid'), string('tcp-e2e-android'), string('tcp-e2e-os')
  ])
}

function parseFrames (state) {
  const packets = []
  while (state.buf.length >= 7) {
    const length = state.buf.readUIntBE(2, 3)
    if (state.buf.length < 7 + length) break
    packets.push({ id: state.buf.readUInt16BE(0), payload: state.buf.subarray(7, 7 + length) })
    state.buf = state.buf.subarray(7 + length)
  }
  return packets
}

// Runs one full client session over a real socket. Resolves with the list of
// received packet descriptors; rejects on socket error/timeout.
function runClientSession (port, { highId = 0, lowId = 0, token = '', fingerprintSha = null }) {
  return new Promise((resolve, rejectWith) => {
    const fingerprint = fingerprintSha !== null ? fingerprintSha : require('../Utils/Fingerprint').loadFinger('GameAssets/fingerprint.json')
    const socket = net.connect(port, '127.0.0.1')
    const state = { buf: Buffer.alloc(0) }
    const packets = []
    const session = {
      sendNonce: cryptoMod.randomBytes(24),
      sessionKey: null,
      encryptNonce: null,
      sharedEn: null
    }
    const timeout = setTimeout(() => rejectWith(new Error('client session timed out')), 8000)

    socket.on('connect', () => {
      const settings = Config.GetValue()
      const int32 = (v) => { const b = Buffer.alloc(4); b.writeInt32BE(v, 0); return b }
      const string = (v) => { const raw = Buffer.from(String(v), 'utf-8'); return Buffer.concat([int32(raw.length), raw]) }
      const hello = Buffer.concat([
        int32(1), int32(1),
        int32(settings.ClientMajor), int32(settings.ClientMinor), int32(settings.ClientBuild),
        string(require('../Utils/Fingerprint').loadFinger('GameAssets/fingerprint.json')),
        int32(0), int32(0)
      ])
      socket.write(frame(10100, hello))
    })

    socket.on('error', (error) => { clearTimeout(timeout); rejectWith(error) })
    socket.on('data', (chunk) => {
      try {
        state.buf = Buffer.concat([state.buf, chunk])
        for (const packet of parseFrames(state)) {
          packets.push(packet)
          if (packet.id === 20100) {
            session.sessionKey = packet.payload.subarray(4, 28)
            const helloNonce = Buffer.from(blake2b(Buffer.concat([CLIENT_PK, SERVER_PK]), null, 24))
            const inner = Buffer.concat([session.sessionKey, session.sendNonce, buildLoginPayload(highId, lowId, token, fingerprint)])
            const encrypted = NaCl19.secretbox(inner, helloNonce, SHARED_KEY)
            socket.write(frame(10101, Buffer.concat([CLIENT_PK, encrypted]), 1))
          } else if (packet.id === 20104) {
            const loginNonce = new Nonce(session.sendNonce, CLIENT_PK, SERVER_PK)
            const decrypted = NaCl19.secretboxOpen(packet.payload, loginNonce.toBuffer(), SHARED_KEY)
            session.encryptNonce = new Nonce(decrypted.subarray(0, 24))
            session.sharedEn = decrypted.subarray(24, 56)
            packets[packets.length - 1].plaintext = decrypted.subarray(56)
          } else if (packet.id === 24101) {
            session.encryptNonce.increment()
            packets[packets.length - 1].plaintext = NaCl19.secretboxOpen(packet.payload, session.encryptNonce.toBuffer(), session.sharedEn)
            clearTimeout(timeout)
            socket.end()
            resolve({ packets, session })
          } else if (packet.id === 20103) {
            clearTimeout(timeout)
            socket.end()
            resolve({ packets, session, rejected: true })
          }
        }
      } catch (error) {
        clearTimeout(timeout)
        rejectWith(error)
      }
    })
  })
}

async function main () {
  const fs = require('fs')
  const dbPath = (Config.GetValue().DB_PATH) || 'Database/players.sqlite'
  for (const suffix of ['', '-wal', '-shm']) fs.rmSync(dbPath + suffix, { force: true })

  const server = new Server('127.0.0.1', 0)
  await server.start()
  const port = server.server.address().port
  console.log(`tcp_e2e: server on 127.0.0.1:${port}`)

  try {
    // 1. New account over the wire (low_id=0) — the exact production failure case
    const fresh = await runClientSession(port, { lowId: 0, token: '' })
    check('new account: not rejected', !fresh.rejected)
    const ids = fresh.packets.map((p) => p.id)
    check('new account: got ServerHello(20100)', ids.includes(20100))
    check('new account: got LoginOk(20104)', ids.includes(20104))
    check('new account: got OwnHomeData(24101)', ids.includes(24101))
    check('new account: LoginOk decrypts non-empty', fresh.packets.find((p) => p.id === 20104).plaintext.length > 0)

    const reader = new BSMessageReader(fresh.packets.find((p) => p.id === 20104).plaintext).enable_native_v13()
    const assignedHighId = reader.read_int()
    const assignedLowId = reader.read_int()
    check('new account: server assigned valid ids', assignedLowId > 0 && assignedHighId === 0)

    // 2. Persistence: account row exists in SQLite right after login
    const row = DataBase._connection((c) => c.prepare('SELECT token, name FROM players WHERE lowID = ?').get(assignedLowId), false)
    check('persistence: account row exists in sqlite', !!row && typeof row.token === 'string' && row.token.length === 40)

    // 3. Relogin with the generated credentials over a second TCP session
    const again = await runClientSession(port, { lowId: assignedLowId, token: row.token })
    check('relogin: not rejected', !again.rejected)
    check('relogin: got LoginOk(20104)', again.packets.some((p) => p.id === 20104))

    // 4. Wrong token -> LoginFailed (20103), no LoginOk
    const wrong = await runClientSession(port, { lowId: assignedLowId, token: 'wrong-token-value' })
    check('wrong token: LoginFailed(20103) sent', wrong.rejected === true && wrong.packets.some((p) => p.id === 20103))
    check('wrong token: no LoginOk', !wrong.packets.some((p) => p.id === 20104))

    // 5. Fingerprint mismatch is tolerated when patch=false (Python parity:
    //    only patch=true rejects with code 7)
    const mismatch = await runClientSession(port, { lowId: 0, token: '', fingerprintSha: 'd525c0cc3ec001b06785d174e89fbd8247c135f3' })
    check('fingerprint mismatch + patch=false: login accepted', !mismatch.rejected && mismatch.packets.some((p) => p.id === 20104))
  } finally {
    server.close()
  }

  console.log(`${passed} checks passed`)
  console.log('TCP E2E OK')
  process.exit(0)
}

main().catch((error) => {
  console.error('TCP E2E FAILED', error)
  process.exit(1)
})
