'use strict'
// Native V13 wire reader and OwnHomeData (24101) walker shared by the
// battle-return and trophy end-to-end tests. Field order follows the client
// decoder (libg 0x1f38e8 -> LogicClientHome 0x22e7e8 / LogicClientAvatar).
class NativeReader {
  constructor (payload) {
    this.payload = payload
    this.offset = 0
    this.bit_index = 0
    this.bit_buffer = 0
  }

  byte () {
    if (this.offset >= this.payload.length) throw new Error('Unexpected end of payload')
    return this.payload[this.offset++]
  }

  align () { this.bit_index = 0 }

  vint () {
    this.align()
    const first = this.byte()
    const negative = Boolean(first & 0x40)
    let result = first & 0x3f
    if (!(first & 0x80)) {
      if (negative) result |= (-1 << 6)
      return result | 0
    }
    for (let group = 1; group < 4; group++) {
      const b = this.byte()
      result |= (b & 0x7f) << (6 + (group - 1) * 7)
      if (!(b & 0x80)) {
        if (negative) result |= (-1 << (6 + group * 7))
        return result | 0
      }
    }
    result |= this.byte() << 27
    if (negative) result = (result | 0x80000000) >>> 0
    result = result >>> 0
    return result & 0x80000000 ? result - 0x100000000 : result
  }

  boolean () {
    if (this.bit_index === 0) this.bit_buffer = this.byte()
    const value = Boolean(this.bit_buffer & (1 << this.bit_index))
    this.bit_index = (this.bit_index + 1) & 7
    return value
  }

  int32 () {
    this.align()
    return this.take(4).readInt32BE(0)
  }

  string () {
    this.align()
    const length = this.int32()
    if (length === -1) return ''
    return this.take(length).toString('utf-8')
  }

  dataref () {
    const classId = this.vint()
    return [classId, classId ? this.vint() : 0]
  }

  long () {
    this.align()
    const raw = this.take(8)
    return [raw.readInt32BE(0), raw.readInt32BE(4)]
  }

  array () { const out = []; const n = this.vint(); for (let i = 0; i < n; i++) out.push(this.vint()); return out }

  references () { const out = []; const n = this.vint(); for (let i = 0; i < n; i++) out.push([this.vint(), this.vint()]); return out }

  brawler_values () { const out = []; const n = this.vint(); for (let i = 0; i < n; i++) out.push([this.vint(), this.vint(), this.vint()]); return out }

  take (length) {
    const end = this.offset + length
    if (end > this.payload.length) throw new Error('Unexpected end of payload')
    const value = this.payload.subarray(this.offset, end)
    this.offset = end
    return value
  }

  ensure_end () {
    if (this.offset !== this.payload.length) {
      throw new Error(`trailing bytes: ${this.payload.length - this.offset}`)
    }
  }

  // OwnHomeData aliases used by the Python regression test
  v () { this.align(); return this.vint() }
  b () { return this.boolean() }
  i () { this.align(); return this.int32() }
  s () { this.align(); return this.string() }
  read () { return this.payload.subarray(this.offset) }
}

function readHomeCommodities (payload) {
  const r = new NativeReader(payload)
  r.dailyTimestamp = r.v()
  r.v()
  for (let i = 0; i < 5; i++) r.v()
  for (let i = 0; i < 3; i++) r.v()
  r.references()
  r.references()
  r.b()
  for (let i = 0; i < 6; i++) r.v()
  r.tokenLimit = r.b()
  r.v()
  r.b()
  for (let i = 0; i < 2; i++) r.v()
  for (let i = 0; i < 4; i++) r.b()
  for (let i = 0; i < 3; i++) r.v()
  r.b()
  for (let i = 0, n = r.v(); i < n; i++) {
    for (let j = 0, m = r.v(); j < m; j++) {
      r.v(); r.v()
      const targetClass = r.v()
      if (targetClass) r.v()
      r.v()
    }
    for (let j = 0; j < 5; j++) r.v()
    r.b(); r.v(); r.b(); r.v(); r.s()
  }
  r.dailyHomeFields = [r.v(), r.v(), r.v(), r.v(), r.v(), r.v()]
  r.selectedBrawler = [r.v(), r.v()]
  r.shopTimestamp = r.v()
  for (let i = 0; i < 11; i++) r.v()
  r.array()
  r.array()
  r.events = []
  for (let i = 0, n = r.v(); i < n; i++) {
    r.events.push([r.v(), r.v(), r.v(), r.v(), r.v(), r.v(), r.v(), r.v()])
    r.s(); r.v(); r.array(); r.v()
  }
  r.v()
  for (let i = 0; i < 6; i++) r.array()
  r.v()
  r.dailyFields = [r.v(), r.v(), r.v(), r.v(), r.v()]
  for (let i = 0; i < 3; i++) r.b()
  for (let i = 0; i < 2; i++) r.v()
  r.b(); r.v(); r.long()
  for (let i = 0, n = r.v(); i < n; i++) { r.v(); r.v() }
  r.v(); r.b(); r.v()
  for (let i = 0; i < 3; i++) { r.v(); r.v() }
  r.s(); r.b(); r.s(); r.v()
  const commodities = []
  for (let i = 0, n = r.v(); i < n; i++) commodities.push([r.v(), r.v(), r.v()])
  return [r, commodities]
}

// Account totals and per-brawler trophies exactly as the client reads them.
function readHomeTrophies (payload) {
  const r = new NativeReader(payload)
  r.v(); r.v()
  const total = r.v(); const highest = r.v()
  const [reader] = readHomeCommodities(payload)
  const brawlers = {}
  for (const [, id, value] of reader.brawler_values()) brawlers[id] = value
  const highestByBrawler = {}
  for (const [, id, value] of reader.brawler_values()) highestByBrawler[id] = value
  return { total, highest, brawlers, highestByBrawler, selected: reader.selectedBrawler[1] }
}

module.exports = { NativeReader, readHomeCommodities, readHomeTrophies }
