'use strict'
// Minimal real V13 protocol client for end-to-end tests: encrypted TCP login
// (10100/10101 -> 20104), message log, battle bootstrap (20559 -> 24112 ->
// TCP 24109) and UDP 10555 inputs exactly as the APK sends them.
const assert = require('node:assert/strict')
const net = require('node:net')
const dgram = require('node:dgram')
const crypto = require('node:crypto')
const { blake2b } = require('blakejs')
const Config = require('../../Utils/Config')
const readLoading = require('./v13_loading')
const NaCl19 = require('../../Core/NaCl19')
const { Nonce, DEFAULT_CLIENT_PRIVATE_KEY } = require('../../Core/Crypto')
const { Reader, vint, envelope, encodeInput, readEnvelope } = require('../../Logic/Battle/Network/V13BattleCodec')

const int = value => { const b = Buffer.alloc(4); b.writeInt32BE(value); return b }
const string = value => { const b = Buffer.from(value); return Buffer.concat([int(b.length), b]) }
const bool = value => Buffer.from([value ? 1 : 0])
const frame = (type, payload, version = 0) => {
  const b = Buffer.alloc(7); b.writeUInt16BE(type); b.writeUIntBE(payload.length, 2, 3); b.writeUInt16BE(version, 5)
  return Buffer.concat([b, payload])
}
const wait = ms => new Promise(resolve => setTimeout(resolve, ms))

function createClientFactory (server) {
  const settings = Config.GetValue()
  const fingerprint = require('../../Utils/Fingerprint').loadFinger('GameAssets/fingerprint.json')
  const peers = []

  // Resolves once logged in (24101 received). options.onMessage(type, raw, peer)
  // runs for every decrypted server message.
  function login (name, account = null, options = {}) {
    return new Promise((resolve, reject) => {
      const sk = Buffer.from(DEFAULT_CLIENT_PRIVATE_KEY, 'hex'); const pk = NaCl19.scalarmultBase(sk)
      const serverPk = Buffer.from(settings.Crypto.ServerPublicKey, 'hex'); const shared = NaCl19.boxBeforenm(serverPk, sk)
      const sendNonce = new Nonce(crypto.randomBytes(24)); let recvNonce; let sessionKey
      const socket = net.connect(server.port, '127.0.0.1'); const udp = dgram.createSocket('udp4')
      const peer = { name, socket, udp, visions: [], messages: [], types: [], counter: 0, account, closed: false, waiters: [] }
      peers.push(peer)
      peer.send = (type, payload) => { sendNonce.increment(); socket.write(frame(type, NaCl19.secretbox(payload, sendNonce.toBuffer(), sessionKey))) }
      // Like the APK (libg 0x4e6500): UDP while a UDP endpoint is configured,
      // otherwise the TCP 10555 path ("Sending input with TCP!").
      peer.input = inputs => {
        const payload = encodeInput({ tick: 0, inputs })
        if (peer.host === null) return peer.send(10555, payload)
        return udp.send(Buffer.concat([peer.header, envelope(10555, payload)]), peer.port, peer.host)
      }
      peer.count = type => peer.types.filter(t => t === type).length
      // Wait until a message of `type` arrives after `since` (index into types).
      peer.waitFor = (type, timeoutMs = 5000, since = 0) => new Promise((resolve, reject) => {
        const found = () => { for (let i = since; i < peer.messages.length; i++) if (peer.messages[i].type === type) return peer.messages[i]; return null }
        const hit = found(); if (hit) return resolve(hit)
        const timer = setTimeout(() => reject(new Error(`${name}: timeout waiting for ${type}; got ${peer.types.slice(since).join(',')}`)), timeoutMs)
        peer.waiters.push(() => { const m = found(); if (m) { clearTimeout(timer); resolve(m); return true } return false })
      })
      socket.on('error', () => {}); udp.on('error', () => {})
      socket.on('close', () => { peer.closed = true; if (!peer.loggedIn) reject(new Error(`${name}: closed before login`)) })
      udp.on('message', bytes => {
        const msg = readEnvelope(bytes.subarray(10)); if (msg.type !== 24109) return
        const reader = new Reader(msg.payload); const tick = reader.vint(); const ack = reader.vint()
        peer.visions.push({ tick, ack, at: Date.now(), payload: msg.payload })
      })
      let rx = Buffer.alloc(0)
      socket.on('connect', () => socket.write(frame(10100, Buffer.concat([int(1), int(1), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), int(0), int(0)]))))
      socket.on('data', chunk => {
        try {
          rx = Buffer.concat([rx, chunk])
          while (rx.length >= 7) {
            const type = rx.readUInt16BE(); const len = rx.readUIntBE(2, 3)
            if (rx.length < len + 7) break
            const payload = rx.subarray(7, len + 7); rx = rx.subarray(len + 7)
            if (type === 20100) {
              const nonce = Buffer.from(blake2b(Buffer.concat([pk, serverPk]), null, 24))
              const [high, low, token] = account ? [0, account.low, account.token] : [0, 0, '']
              const body = Buffer.concat([int(high), int(low), string(token), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), string(''), string('e2e-' + name), string('e2e-test'), string('test')])
              socket.write(frame(10101, Buffer.concat([pk, NaCl19.secretbox(Buffer.concat([payload.subarray(4, 28), sendNonce.toBuffer(), body]), nonce, shared)]), 1))
            } else if (type === 20104) {
              const raw = NaCl19.secretboxOpen(payload, new Nonce(sendNonce.toBuffer(), pk, serverPk).toBuffer(), shared)
              assert(raw); recvNonce = new Nonce(raw.subarray(0, 24)); sessionKey = raw.subarray(24, 56)
              const r = raw.subarray(56); const low = r.readInt32BE(4); const tokenLength = r.readInt32BE(16)
              peer.account = { low, token: r.subarray(20, 20 + tokenLength).toString() }
            } else if (type === 20103) reject(new Error(`${name}: login rejected`))
            else {
              recvNonce.increment(); const raw = NaCl19.secretboxOpen(payload, recvNonce.toBuffer(), sessionKey); assert(raw)
              peer.types.push(type); peer.messages.push({ type, raw, at: Date.now() })
              if (type === 20559) { peer.loading = readLoading(raw); peer.loadingAt = Date.now() }
              if (type === 24112) {
                const r = new Reader(raw); peer.port = r.vint(); const hostLength = r.take(4).readInt32BE()
                // A null host (-1) selects the TCP-only battle path, as in the APK.
                peer.host = hostLength < 0 ? null : r.take(hostLength).toString(); peer.header = r.take(r.take(4).readInt32BE())
              }
              if (type === 24109) {
                const r = new Reader(raw); const tick = r.vint(); const ack = r.vint()
                peer.visions.push({ tick, ack, tcp: true, at: Date.now(), payload: raw })
                if (!peer.bootstrap && options.autoBootstrap !== false) {
                  peer.bootstrap = true
                  if (peer.host === null) peer.input([])
                  else udp.bind(0, '127.0.0.1', () => peer.input([]))
                }
              }
              if (options.onMessage) options.onMessage(type, raw, peer)
              peer.waiters = peer.waiters.filter(w => !w())
              if (type === 24101 && !peer.loggedIn) { peer.loggedIn = true; resolve(peer) }
            }
          }
        } catch (error) { reject(error) }
      })
    })
  }
  function closeAll () { for (const peer of peers) { peer.socket.destroy(); try { peer.udp.close() } catch (_) {} } }
  return { login, peers, closeAll, settings }
}

module.exports = { createClientFactory, int, string, bool, vint, frame, wait, Reader }
