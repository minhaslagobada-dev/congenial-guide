'use strict'
const assert = require('node:assert/strict')
const { Reader } = require('../../Logic/Battle/Network/V13BattleCodec')

// Matches the native 0x20fe1c / 0x3fba9c decoders, including the LogicLong
// prefix at 0x3e67fc that the original integration test failed to inspect.
module.exports = function readLoading (payload) {
  const reader = new Reader(payload)
  const int = () => reader.take(4).readInt32BE()
  const string = () => { const length = int(); return length < 0 ? null : reader.take(length).toString('utf8') }
  const ref = () => { const type = reader.vint(); return [type, type ? reader.vint() : 0] }
  const result = { count: int(), ownIndex: int(), ownTeam: int(), entries: [] }
  assert(result.count > 0 && result.count <= 10)
  assert.equal(int(), result.count)
  for (let i = 0; i < result.count; i++) {
    const entry = { highId: int(), lowId: int(), name: string(), index: reader.vint(), team: reader.vint(), unknown: reader.vint(), objectId: int(), brawler: ref(), skin: ref() }
    assert.equal(reader.boolean(), false, 'Unexpected optional avatar in test packet')
    assert.equal(entry.index, i)
    assert.equal(entry.brawler[0], 16)
    assert.equal(entry.skin[0], 29)
    assert.equal(typeof entry.name, 'string')
    result.entries.push(entry)
  }
  assert.equal(int(), 0, 'Unexpected auxiliary entries in test packet')
  assert.equal(int(), 0, 'Unexpected custom map entries in test packet')
  result.seed = int(); result.loadingType = reader.vint()
  assert.equal(({ 0: 10, 1: 6, 3: 3, 5: 1, 6: 10, 7: 3 })[result.loadingType], result.count, 'Loading category must carry the correct roster')
  result.controls = [reader.vint(), reader.vint()]
  result.flag = reader.boolean(); result.tail = [reader.vint(), reader.vint()]
  result.map = ref(); assert.equal(result.map[0], 15)
  reader.end()
  assert(result.ownIndex >= 0 && result.ownIndex < result.entries.length)
  assert.equal(result.entries[result.ownIndex].team, result.ownTeam)
  assert(result.entries[result.ownIndex].lowId > 0, 'Missing local account identity')
  return result
}
