'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'hero-enemy-vectors.json')))
const assets = new BattleAssets()
const initialHp = Number(assets.named('characters', 'LootBox').Hitpoints)
assert.equal(records.length, assets.heroes.length * 2)
const seen = new Set()
for (const record of records) {
  const key = `${record.hero}:${record.slot}`
  assert(!seen.has(key)); seen.add(key)
  assert.equal(record.error, undefined, key)
  const hero = assets.named('characters', record.hero)
  const skill = assets.named('skills', hero[record.slot ? 'UltimateSkill' : 'WeaponSkill'])
  assert.equal(record.skill, skill.Name)
  assert.equal(record.frames.length, 40)
  let hp = initialHp
  const spawnedIds = new Set()
  for (const [i, frame] of record.frames.entries()) {
    assert.equal(frame.tick, 150 + i)
    assert(frame.enemyHp >= 0 && frame.enemyHp <= hp, key)
    assert.equal(frame.hp, Number(hero.Hitpoints), key)
    assert.equal(frame.objectDataIds.length, frame.objects, key)
    for (const id of frame.objectDataIds) { assert(Number.isInteger(id) && id > 0, key); spawnedIds.add(id) }
    hp = frame.enemyHp
  }
  if (!record.slot) assert(hp < initialHp, `${key}: primary did not damage enemy`)
  if (skill.SummonedCharacter) assert(spawnedIds.has(16000000 + assets.named('characters', skill.SummonedCharacter).id), `${key}: native summon ID missing`)
  if (skill.SpawnedItem) assert(spawnedIds.has(18000000 + assets.named('items', skill.SpawnedItem).id), `${key}: native item ID missing`)
}
console.log(`Native enemy exercise: all 22 primary attacks damaged real LootBox metadata; 44 skills ran with original object updates; summon/item IDs matched client CSVs. Forty-tick controlled scenario only.`)
