'use strict'
// Real encrypted TCP + UDP: a player drops mid-battle, logs in again with the
// same account and must land in the SAME match (same brawler, live state),
// while the other players never stop receiving ticks.
const assert = require('node:assert/strict')
const net = require('node:net')
const dgram = require('node:dgram')
const crypto = require('node:crypto')
const { blake2b } = require('blakejs')
const { Server } = require('../main')
const Config = require('../Utils/Config')
const readLoading = require('./helpers/v13_loading')
const NaCl19 = require('../Core/NaCl19')
const { Nonce, DEFAULT_CLIENT_PRIVATE_KEY } = require('../Core/Crypto')
const { Reader, vint, envelope, encodeInput, readEnvelope } = require('../Logic/Battle/Network/V13BattleCodec')
const int = value => { const b = Buffer.alloc(4); b.writeInt32BE(value); return b }
const string = value => { const b = Buffer.from(value); return Buffer.concat([int(b.length), b]) }
const frame = (type, payload, version = 0) => {
  const b = Buffer.alloc(7); b.writeUInt16BE(type); b.writeUIntBE(payload.length, 2, 3); b.writeUInt16BE(version, 5)
  return Buffer.concat([b, payload])
}
const settings = Config.GetValue()
assert.equal(settings.Store.Enabled, false, 'Use the isolated battle test runner')
const fingerprint = require('../Utils/Fingerprint').loadFinger('GameAssets/fingerprint.json')
const server = new Server('127.0.0.1', 0)
const peers = []
const wait = ms => new Promise(resolve => setTimeout(resolve, ms))

function connect (number, account = null, queue = true) {
  return new Promise((resolve, reject) => {
    const sk = Buffer.from(DEFAULT_CLIENT_PRIVATE_KEY, 'hex'); const pk = NaCl19.scalarmultBase(sk)
    const serverPk = Buffer.from(settings.Crypto.ServerPublicKey, 'hex'); const shared = NaCl19.boxBeforenm(serverPk, sk)
    const sendNonce = new Nonce(crypto.randomBytes(24)); let recvNonce; let sessionKey
    const socket = net.connect(server.port, '127.0.0.1'); const udp = dgram.createSocket('udp4')
    const peer = { number, socket, udp, visions: [], results: [], types: [], loaded: false, counter: 0, account }; peers.push(peer)
    peer.send = (type, payload) => { sendNonce.increment(); socket.write(frame(type, NaCl19.secretbox(payload, sendNonce.toBuffer(), sessionKey))) }
    peer.input = inputs => udp.send(Buffer.concat([peer.header, envelope(10555, encodeInput({ tick: 0, inputs }))]), peer.port, peer.host)
    socket.on('error', () => {}); udp.on('error', reject)
    udp.on('message', bytes => {
      const msg = readEnvelope(bytes.subarray(10)); assert.equal(msg.type, 24109)
      const reader = new Reader(msg.payload); const tick = reader.vint(); const ack = reader.vint()
      peer.visions.push({ tick, ack, at: Date.now() })
      if (!peer.resolved) { peer.resolved = true; resolve(peer) }
    })
    let rx = Buffer.alloc(0)
    socket.on('connect', () => socket.write(frame(10100, Buffer.concat([int(1), int(1), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), int(0), int(0)]))))
    socket.on('data', chunk => {
      try {
        rx = Buffer.concat([rx, chunk])
        while (rx.length >= 7) {
          const type = rx.readUInt16BE(); const len = rx.readUIntBE(2, 3)
          if (rx.length < len + 7) break
          const payload = rx.subarray(7, len + 7); rx = rx.subarray(len + 7)
          if (type === 20100) {
            const nonce = Buffer.from(blake2b(Buffer.concat([pk, serverPk]), null, 24))
            const [high, low, token] = account ? [0, account.low, account.token] : [0, 0, '']
            const login = Buffer.concat([int(high), int(low), string(token), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), string(''), string('reconnect-' + number), string('reconnect-test'), string('test')])
            socket.write(frame(10101, Buffer.concat([pk, NaCl19.secretbox(Buffer.concat([payload.subarray(4, 28), sendNonce.toBuffer(), login]), nonce, shared)]), 1))
          } else if (type === 20104) {
            const raw = NaCl19.secretboxOpen(payload, new Nonce(sendNonce.toBuffer(), pk, serverPk).toBuffer(), shared)
            assert(raw); recvNonce = new Nonce(raw.subarray(0, 24)); sessionKey = raw.subarray(24, 56)
            const r = raw.subarray(56); const low = r.readInt32BE(4); const tokenLength = r.readInt32BE(16)
            peer.account = { low, token: r.subarray(20, 20 + tokenLength).toString() }
          } else if (type === 20103) reject(new Error('Login rejected'))
          else {
            recvNonce.increment(); const raw = NaCl19.secretboxOpen(payload, recvNonce.toBuffer(), sessionKey); assert(raw)
            peer.types.push(type)
            if (type === 23456) peer.results.push(raw)
            if (type === 24101 && queue) peer.send(14103, Buffer.concat([vint(16), vint(0), vint(0), vint(1), vint(0), vint(0)]))
            if (type === 20406) reject(new Error('Unexpected matchmaking cancellation'))
            if (type === 20559) { peer.loading = readLoading(raw); peer.loaded = true }
            if (type === 24112) {
              const r = new Reader(raw); peer.port = r.vint(); peer.host = r.take(r.take(4).readInt32BE()).toString(); peer.header = r.take(r.take(4).readInt32BE())
            }
            if (type === 24109) {
              const r = new Reader(raw); const tick = r.vint(); const ack = r.vint()
              peer.visions.push({ tick, ack, tcp: true, at: Date.now() })
              if (!peer.bootstrap) { peer.bootstrap = true; udp.bind(0, '127.0.0.1', () => peer.input([])) }
            }
          }
        }
      } catch (error) { reject(error) }
    })
  })
}

function actor (world, entry) { return world.state.objects.find(object => object.id === world.state.players[entry.index].characterId) }

async function main () {
  try {
    await server.start()
    const coordinator = server.battleCoordinator
    const ready = await Promise.all(Array.from({ length: 6 }, (_, i) => connect(i)))
    assert.equal(coordinator.worlds.size, 1)
    const world = Array.from(coordinator.worlds.values())[0]
    assert.equal(world.phase, 'running')
    const leaver = ready[0]
    const entry = world.players.find(p => !p.bot && p.player.low_id === leaver.account.low)
    assert(entry)
    // Move once so the restored state differs from the spawn.
    const origin = actor(world, entry)
    leaver.input([{ counter: ++leaver.counter, category: 1, code: 100, x: 3150, y: 6150 }])
    await wait(400)
    const before = actor(world, entry)
    const tickBefore = world.tick
    // Drop the TCP connection (app closed / network loss).
    leaver.socket.destroy(); leaver.udp.close()
    await wait(300)
    assert.equal(world.phase, 'running', 'The match must survive a dropped player')
    assert.equal(coordinator.accounts.get(leaver.account.low), world, 'The account stays bound to its live match')
    const others = ready.slice(1)
    const seen = others.map(p => p.visions.length)
    await wait(300)
    assert(others.every((p, i) => p.visions.length > seen[i]), 'Other players keep receiving ticks')
    assert(world.tick > tickBefore, 'The original clock keeps running')
    const away = actor(world, entry)
    assert(away && away.hp > 0, 'The brawler stays in the match while disconnected')
    // Login again with the same account: straight back into the battle.
    const started = Date.now()
    const back = await connect(9, leaver.account, false)
    const rejoinMs = Date.now() - started
    assert.equal(back.account.low, leaver.account.low)
    const order = back.types.filter(type => [24101, 20559, 24112].includes(type))
    assert.deepEqual(order.slice(0, 3), [24101, 20559, 24112], 'Login -> home -> StartLoading -> UDP info')
    assert(back.visions[0].tcp && back.visions[0].tick >= tickBefore, 'First snapshot is the live tick, not a restart')
    assert.equal(back.loading.count, 6); assert.equal(back.loading.ownIndex, entry.index, 'Same brawler slot')
    assert.equal(world.players.filter(p => !p.bot).length, 6, 'No duplicate brawler')
    assert.equal(coordinator.worlds.size, 1); assert.equal(server.battleTransport.gateway.sessions.size, 6)
    assert.equal(entry.disconnected, false)
    const restored = actor(world, entry)
    assert(Math.hypot(restored.x - origin.x, restored.y - origin.y) > 0 && restored.id === away.id, 'Live engine state kept (no respawn, same object)')
    assert(Math.hypot(before.x - origin.x, before.y - origin.y) > 0, 'Pre-drop movement applied')
    // New counters from the rebuilt client battle are accepted and acknowledged.
    back.input([{ counter: ++back.counter, category: 1, code: 100, x: origin.x, y: origin.y }])
    await wait(400)
    const moved = actor(world, entry)
    assert(Math.hypot(moved.x - restored.x, moved.y - restored.y) > 0, 'Rejoined player controls the same brawler')
    assert(back.visions.some(v => v.ack === back.counter), 'Server acknowledges the rejoined client counters')
    world.finish(entry.team, 'test-result-pipeline')
    await wait(150)
    assert.equal(back.results.length, 1, 'Result goes to the new connection')
    assert.equal(coordinator.metrics.failures, 0)
    assert.equal(coordinator.metrics.reconnects, 1)
    console.log(`RECONNECT E2E OK: drop mid-battle -> match keeps running for 5 others -> login with same account -> 20559/24112/live 24109 in ${rejoinMs} ms -> same slot and live position -> new counters move the same brawler -> result on new connection`)
  } finally {
    for (const peer of peers) { peer.socket.destroy(); try { peer.udp.close() } catch (_) {} }
    await server.close()
  }
}
const timer = setTimeout(() => { console.error('Reconnect e2e timeout'); process.exit(1) }, 30000)
main().then(() => clearTimeout(timer), error => { clearTimeout(timer); console.error(error); process.exitCode = 1 })
