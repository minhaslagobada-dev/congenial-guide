'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'earned-supers.json')))
assert.deepEqual(records.map(record => record.hero).sort(), new BattleAssets().heroes.map(hero => hero.Name).sort())
for (const record of records) {
  assert.equal(record.error, undefined); assert.equal(record.cleanupError, undefined)
  assert.equal(record.earned, true, record.hero); assert.equal(record.cast, true, record.hero)
  assert(record.superCommands.length > 0)
  assert(record.activations.length > 0, `Native activation was not observed for ${record.hero}`)
  assert(record.superCommands.every(command => command.charge === 4000))
  assert(record.postCastFrames >= 40)
  assert(record.checkpoints.find(state => state.tick === record.castTick).players[0].superCharge < 4000)
}
console.log('All 22 enabled heroes earned charge and cast their Supers through original client input; full native matches, no forced charge/HP')
