'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'hero-death-vectors.json')))
const assets = new BattleAssets()
const targetId = 16000000 + assets.named('characters', 'LootBox').id
assert.equal(records.length, assets.heroes.length * 2)
const primaries = records.filter(record => record.slot === 0)
assert.equal(new Set(primaries.map(record => record.hero)).size, assets.heroes.length)
for (const record of records) {
  assert.equal(record.error, undefined, record.hero)
  assert.equal(record.frames.length, 40)
  for (const frame of record.frames) assert(frame.enemyHp >= 0 && frame.enemyHp <= 500, record.hero)
  if (record.slot) continue
  const last = record.frames.at(-1)
  assert.equal(last.enemyHp, 0, record.hero)
  assert(!last.objectDataIds.includes(targetId), `${record.hero}: dead target remains registered`)
  assert.equal(last.hp, Number(assets.named('characters', record.hero).Hitpoints), record.hero)
}
console.log('Native damage/death/removal: all 22 primaries killed the injured LootBox and original manager removed it; 44 skill scenarios completed. Does not verify player deaths or match results.')
