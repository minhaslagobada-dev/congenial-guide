'use strict'
// Battle log (histórico de batalhas) and profile brawler order, with real
// encrypted v13 protocol clients and the original packets only:
//  14114 GetBattleLogMessage -> 23458 BattleLogMessage (decoded exactly like
//  the client: libg 0x3fb954 / 0x47f288 / 0x21b324), incremental 23458 after
//  GoHome for battles finished after the first request, 14113 -> 24113.
// Covers: 3v3 win, 3v3 defeat, Showdown placement, team 3v3 (both members),
// duo Showdown, participants/teams/brawlers/trophies, newest first, no
// duplicates (result processed twice, replay, restore), many matches with the
// client limit while the database keeps everything, persistence across a
// game restart (new login) and a SERVER restart, profile ordered by current
// trophies with the order following a trophy change from a real match.
const assert = require('node:assert/strict')
const { Server } = require('../main')
const DataBase = require('../Database/DatabaseManager')
const Skins = require('../Files/CsvLogic/Skins')
const TeamCode = require('../Logic/TeamCode')
const { BattleHistory } = require('../Logic/BattleHistory')
const { createClientFactory, vint, bool, int, wait } = require('./helpers/v13_client')
const { NativeReader } = require('./helpers/native_home')

let server = new Server('127.0.0.1', 0)
let factory = createClientFactory(server)
assert.equal(factory.settings.Store.Enabled, false, 'Use the isolated battle test runner')

const session = low => server.Clients.Clients[String(low)] && server.Clients.Clients[String(low)].Player
const play = (peer, slot, brawler = 0) => peer.send(14103, Buffer.concat([vint(16), vint(brawler), vint(0), vint(slot), vint(0), vint(0)]))
const createTeam = (peer, map = 0, slot = 1) => peer.send(14350, Buffer.concat([vint(map), vint(slot), vint(0), bool(false)]))
const ready = (peer, value) => peer.send(14355, Buffer.concat([bool(value), vint(0)]))
const setBrawler = (peer, brawler) => peer.send(14354, Buffer.concat([vint(0), vint(29), vint(Skins.get_default_skin(brawler))]))
const typeCode = (peer, typed) => {
  let value = 0
  for (const ch of typed.toUpperCase().slice(1)) value = value * 31 + TeamCode.ALPHABET.indexOf(ch)
  peer.send(14358, Buffer.concat([vint(value & 0xff), vint(Math.floor(value / 256)), vint(1)]))
}
const lastOf = (peer, type, since = 0) => { const list = peer.messages.slice(since).filter(m => m.type === type); return list.length ? list[list.length - 1] : null }

// ---- 23458 exactly as the v13 client decodes it -------------------------
function parseBattleLog (raw) {
  const r = new NativeReader(raw)
  const log = { replace: r.b(), entries: [] }
  const count = r.v()
  for (let i = 0; i < count; i++) {
    const e = { unused: r.v(), age: r.v(), type: r.v(), trophyChange: r.v(), duration: r.v(), friendly: r.b() }
    const cls = r.v(); e.location = cls ? [cls, r.v()] : null
    e.result = r.v(); e.replay = r.v()
    r.i(); r.i(); r.i(); r.i()
    e.players = []
    for (let p = 0, n = r.v(); p < n; p++) {
      const player = { kind: r.v(), high: r.i(), low: r.i(), team: r.v(), mvp: r.b(), name: r.s() }
      const hc = r.v(); player.hero = hc ? [hc, r.v()] : null
      player.trophies = r.v(); player.level = r.v(); player.rank = r.v()
      e.players.push(player)
    }
    log.entries.push(e)
  }
  assert.equal(r.offset, raw.length, '23458 fully consumed (no trailing bytes)')
  return log
}

async function requestLog (peer) {
  const since = peer.messages.length
  peer.send(14114, Buffer.alloc(0))
  await peer.waitFor(23458, 3000, since)
  const log = parseBattleLog(lastOf(peer, 23458, since).raw)
  assert.equal(log.replace, true, '14114 answer replaces the client list')
  return log
}

// ---- 24113 profile: brawler order ----------------------------------------
async function profileOrder (peer, targetLow) {
  const since = peer.messages.length
  peer.send(14113, Buffer.concat([int(0), int(targetLow), bool(false)]))
  await peer.waitFor(24113, 3000, since)
  const r = new NativeReader(lastOf(peer, 24113, since).raw)
  r.v(); assert.equal(r.v(), targetLow); r.s(); r.v()
  const list = []
  for (let i = 0, n = r.v(); i < n; i++) {
    assert.equal(r.v(), 16); const id = r.v(); assert.equal(r.v(), 0)
    list.push({ id, trophies: r.v(), highest: r.v(), level: r.v() })
  }
  return list
}

function prepare (peer, trophies) {
  const player = session(peer.account.low)
  const state = { ...(player.BrawlersUnlockedState || {}) }
  for (const id of Object.keys(trophies)) state[id] = 1
  player.BrawlersUnlockedState = state
  player.brawlers_trophies = { ...(player.brawlers_trophies || {}), ...trophies }
  DataBase.replaceValues({ player }, { UnlockedBrawlers: state, brawlersTrophies: player.brawlers_trophies })
}

async function expire (coordinator) {
  for (const bucket of coordinator.matchmaker.buckets.values()) for (const ticket of bucket) ticket.joinedAt -= 60000
}

async function soloMatch (coordinator, peer, slot) {
  const since = peer.messages.length
  play(peer, slot)
  await peer.waitFor(20405, 3000, since)
  await expire(coordinator)
  await peer.waitFor(20559, 5000, since)
  const world = Array.from(coordinator.worlds.values()).find(w => w.players.some(p => !p.bot && p.player.low_id === peer.account.low))
  assert(world, 'match started')
  await wait(250)
  return [world, world.players.find(p => !p.bot && p.player.low_id === peer.account.low)]
}

// Ends the match, returns home and returns the pushed incremental entry.
async function finishHome (peer, world, winner, expectPush = true) {
  let since = peer.messages.length
  world.finish(winner, 'test-result')
  await peer.waitFor(23456, 3000, since)
  since = peer.messages.length
  peer.send(14101, Buffer.from([0]))
  await peer.waitFor(24101, 3000, since)
  if (!expectPush) return null
  await peer.waitFor(23458, 3000, since)
  const types = peer.messages.slice(since).map(m => m.type)
  assert(types.indexOf(24101) < types.indexOf(23458), 'incremental log after OwnHomeData (lobby on screen)')
  const log = parseBattleLog(lastOf(peer, 23458, since).raw)
  assert.equal(log.replace, false, 'new battle is prepended (incremental form)')
  assert.equal(log.entries.length, 1)
  return log.entries[0]
}

function checkEntry (entry, expected, label) {
  for (const [key, value] of Object.entries(expected)) assert.deepEqual(entry[key], value, `${label}: ${key}`)
}

const outboxRows = low => DataBase._connection(c => c.prepare('SELECT COUNT(*) AS n FROM battle_result_outbox WHERE player_id=?').get(low).n)
const trophies = (peer, id) => Math.trunc((session(peer.account.low).brawlers_trophies || {})[String(id)] || 0)

async function main () {
  try {
    await server.start()
    let coordinator = server.battleCoordinator
    const errors = []; coordinator.on('battleError', e => errors.push(e.message))
    let a = await factory.login('LogAlpha')
    let b = await factory.login('LogBravo')
    prepare(a, { 0: 100, 1: 100, 16: 100 })
    prepare(b, { 0: 50, 1: 300, 2: 350, 3: 10, 16: 120, 23: 0 })

    // ---- 0. empty log --------------------------------------------------
    let log = await requestLog(a)
    assert.equal(log.entries.length, 0, 'no battles yet')
    await requestLog(b)

    // ---- 1. 3v3 win ------------------------------------------------------
    let [world, entry] = await soloMatch(coordinator, a, 0)
    assert.equal(world.mode.name, 'CoinRush')
    let before = trophies(a, 0)
    let e = await finishHome(a, world, entry.team)
    checkEntry(e, { type: 1, result: 0, friendly: false, trophyChange: 10, location: [15, world.mapId], replay: -1 }, '3v3 win')
    assert.equal(trophies(a, 0), before + 10)
    assert.equal(e.players.length, 6, '3v3: six participants')
    const own = e.players.find(p => p.kind === 1 && p.low === a.account.low)
    assert(own, 'own row identified by account id (own_name_txt)')
    assert.deepEqual(own.hero, [16, 0]); assert.equal(own.name, session(a.account.low).name); assert.equal(own.trophies, before, 'brawler trophies at match start')
    assert.equal(own.team, entry.team)
    assert.equal(e.players.filter(p => p.team === entry.team).length, 3, 'three allies')
    assert.equal(e.players.filter(p => p.team !== entry.team).length, 3, 'three enemies')
    const bots = e.players.filter(p => p.kind === 3)
    assert.equal(bots.length, 5, 'bots reported as bots')
    assert.deepEqual(bots.map(p => p.low), [1, 2, 3, 4, 5], 'TID_BOT_1..5')
    for (const p of e.players) assert(p.hero && p.hero[0] === 16 && p.level >= 1, 'every participant has a brawler and level')
    let rec = BattleHistory.list(a.account.low, 1)[0]
    assert.equal(rec.battle_id, String(world.id), 'unique match id = world id')
    assert.deepEqual([rec.trophies_before, rec.trophies_after, rec.trophy_change, rec.result, rec.brawler_id, rec.map_id, rec.location_mode, rec.team], [before, before + 10, 10, 0, 0, world.mapId, 'CoinRush', entry.team], 'stored record')
    assert(rec.created_at <= Date.now() && rec.created_at > Date.now() - 60000, 'date/time stored')
    assert.equal(rec.participants.length, 6, 'participants stored')
    console.log('3v3 win recorded ok')

    // ---- 2. 3v3 defeat ---------------------------------------------------
    ;[world, entry] = await soloMatch(coordinator, a, 0)
    before = trophies(a, 0)
    e = await finishHome(a, world, 1 - entry.team)
    checkEntry(e, { type: 1, result: 1 }, '3v3 defeat')
    assert.equal(e.trophyChange, trophies(a, 0) - before, 'defeat: real trophy change')
    assert(e.trophyChange < 0, 'defeat loses trophies at 110')
    console.log('3v3 defeat recorded ok', e.trophyChange)

    // ---- 3. Showdown, 4th place -----------------------------------------
    ;[world, entry] = await soloMatch(coordinator, a, 2)
    assert.equal(world.mode.name, 'BattleRoyale')
    let rank = 1
    for (const other of world.players) if (other !== entry) { if (rank === 4) rank++; other.rank = rank++ }
    entry.rank = 4
    before = trophies(a, 0)
    e = await finishHome(a, world, world.players.find(p => p.rank === 1).team)
    checkEntry(e, { type: 2, result: 2, trophyChange: trophies(a, 0) - before }, 'Showdown 4th')
    assert.equal(e.players.length, 10)
    assert.equal(e.players.find(p => p.low === a.account.low && p.kind === 1).rank, 4, 'own placement')
    assert.deepEqual(e.players.map(p => p.rank).sort((x, y) => x - y), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 'every placement 1..10 (RANK rows)')
    console.log('Showdown recorded ok', e.trophyChange)

    // ---- 4. team 3v3 (both members recorded, same side) ----------------
    let since = a.messages.length
    createTeam(a, 7)
    await a.waitFor(24124, 3000, since)
    const room = Object.values(require('../Logic/GameRoomService').GameRoomService._entries).find(r => r.members.some(m => m.low_id === a.account.low))
    since = b.messages.length
    typeCode(b, TeamCode.short_code(room.id)); await b.waitFor(24124, 3000, since)
    async function teamMatch (map, brawlerA, brawlerB) {
      room.map_id = map
      setBrawler(a, brawlerA); setBrawler(b, brawlerB); await wait(250)
      const sa = a.messages.length; const sb = b.messages.length
      ready(a, true); ready(b, true)
      await a.waitFor(20405, 3000, sa); await b.waitFor(20405, 3000, sb)
      await expire(coordinator)
      await a.waitFor(20559, 5000, sa); await b.waitFor(20559, 5000, sb)
      const w = Array.from(coordinator.worlds.values()).find(x => x.players.some(p => !p.bot && p.player.low_id === a.account.low))
      await wait(300)
      return [w, w.players.find(p => !p.bot && p.player.low_id === a.account.low), w.players.find(p => !p.bot && p.player.low_id === b.account.low)]
    }
    async function bothHome (w, winner) {
      const sa = a.messages.length; const sb = b.messages.length
      w.finish(winner, 'test-result')
      await a.waitFor(23456, 3000, sa); await b.waitFor(23456, 3000, sb)
      const ha = a.messages.length; const hb = b.messages.length
      a.send(14101, Buffer.from([0])); b.send(14101, Buffer.from([0]))
      await a.waitFor(23458, 3000, ha); await b.waitFor(23458, 3000, hb)
      return [parseBattleLog(lastOf(a, 23458, ha).raw).entries[0], parseBattleLog(lastOf(b, 23458, hb).raw).entries[0]]
    }
    let ea; let eb
    ;[world, ea, eb] = await teamMatch(7, 0, 1)
    assert.equal(ea.team, eb.team)
    let [la, lb] = await bothHome(world, ea.team)
    for (const [l, label] of [[la, 'leader'], [lb, 'member']]) {
      checkEntry(l, { type: 1, result: 0, location: [15, 7] }, `team win ${label}`)
      const pa = l.players.find(p => p.kind === 1 && p.low === a.account.low)
      const pb = l.players.find(p => p.kind === 1 && p.low === b.account.low)
      assert(pa && pb, `${label}: both humans listed`)
      assert.equal(pa.team, pb.team, `${label}: teammates on the same side`)
      assert.deepEqual([pa.hero[1], pb.hero[1]], [0, 1], `${label}: brawlers used`)
      assert.deepEqual([pa.name, pb.name], [session(a.account.low).name, session(b.account.low).name])
    }
    assert.equal(lb.players.find(p => p.low === b.account.low).trophies, 300, 'member brawler trophies before the match')
    console.log('team 3v3 recorded for both members ok')

    // ---- 5. duo Showdown win (team) --------------------------------------
    ;[world, ea, eb] = await teamMatch(34, 16, 2)
    assert.equal(world.mode.name, 'BattleRoyaleTeam')
    for (const other of world.players) other.rank = other.team === ea.team ? 1 : 2 + (other.team % 4)
    ;[la, lb] = await bothHome(world, ea.team)
    for (const l of [la, lb]) {
      checkEntry(l, { type: 5, result: 0 }, 'duo Showdown')
      assert.equal(l.players.length, 10)
      assert.deepEqual(l.players.filter(p => p.rank === 1).map(p => p.low).sort(), [a.account.low, b.account.low].sort(), 'duo pair shares rank 1')
    }
    assert.equal(la.trophyChange, 15, 'duo win +15 (brawler below 350)')
    assert.equal(lb.trophyChange, 9, 'duo win +9 (brawler at 350)')
    assert.equal(trophies(b, 2), 359)
    console.log('duo Showdown recorded ok')

    // ---- 6. no duplicates: same result processed again -----------------
    const countA = BattleHistory.count(a.account.low)
    assert.equal(countA, 5, 'five battles for the leader')
    assert.equal(BattleHistory.count(b.account.low), 2, 'two battles for the member')
    coordinator.result(world, ea, true)
    coordinator.result(world, ea, false)
    BattleHistory.flush(); await wait(150)
    const latest = BattleHistory.list(a.account.low, 1)[0]
    assert.equal(BattleHistory.record_now(a.account.low, latest), false, 'same battle cannot be inserted twice')
    assert.equal(BattleHistory.count(a.account.low), countA, 'repeated end/result never duplicates')
    // a second GoHome pushes nothing new
    since = a.messages.length
    a.send(14101, Buffer.from([0])); await a.waitFor(24101, 3000, since); await wait(200)
    assert.equal(a.messages.slice(since).filter(m => m.type === 23458).length, 0, 'nothing pushed twice')
    console.log('no duplicates ok')
    // leave the room again: solo Play is used below
    setBrawler(a, 0); await wait(150); setBrawler(b, 0); await wait(250)
    assert.equal(session(a.account.low).brawler_id, 0); assert.equal(session(b.account.low).brawler_id, 0)
    a.send(14353, Buffer.alloc(0)); b.send(14353, Buffer.alloc(0)); await wait(300)

    // ---- 7. full log: newest first, consistent with the database -------
    log = await requestLog(a)
    assert.equal(log.entries.length, 5)
    assert.deepEqual(log.entries.map(x => x.type), [5, 1, 2, 1, 1], 'newest first')
    assert.deepEqual(log.entries.map(x => x.result), [0, 0, 2, 1, 0])
    for (let i = 1; i < log.entries.length; i++) assert(log.entries[i - 1].age <= log.entries[i].age, 'ages grow down the list')

    // ---- 8. many matches: real matches + the client limit ---------------
    for (let i = 0; i < 8; i++) {
      ;[world, entry] = await soloMatch(coordinator, a, 0)
      await finishHome(a, world, i % 2 ? 1 - entry.team : entry.team)
    }
    assert.equal(BattleHistory.count(a.account.low), 13)
    const base = Date.now() - 86400000
    for (let i = 0; i < 20; i++) {
      assert.equal(BattleHistory.record_now(a.account.low, { battle_id: 'old-' + i, created_at: base + i * 1000, location_mode: 'CoinRush', entry_type: 1, game_mode: 0, map_id: 7, duration: 120, result: i % 3, rank: 0, team: 0, brawler_id: 0, trophies_before: 1, trophies_after: 2, trophy_change: 1, practice: false, mvp: false, participants: [] }), true)
    }
    assert.equal(BattleHistory.count(a.account.low), 33, 'database keeps the full history')
    log = await requestLog(a)
    assert.equal(log.entries.length, BattleHistory.DEFAULT_LIMIT, 'client receives the most recent 25')
    assert.equal(log.entries[0].type, 1); assert.equal(log.entries[0].players.length, 6, 'newest real match first')
    assert.equal(log.entries.filter(x => x.players.length === 0).length, 25 - 13, 'older entries after the 13 real ones')
    for (let i = 1; i < log.entries.length; i++) assert(log.entries[i - 1].age <= log.entries[i].age)
    console.log('many matches ok (db 33, client 25)')

    // ---- 8b. game closed DURING the battle: result settled by the outbox -
    ;[world, entry] = await soloMatch(coordinator, a, 0)
    const offlineAccount = a.account
    before = trophies(a, 0)
    a.socket.destroy(); await wait(400)
    world.finish(entry.team, 'test-result'); await wait(400)
    assert.equal(BattleHistory.count(a.account.low), 34, 'battle finished offline is recorded once')
    assert.equal(outboxRows(offlineAccount.low), 1, 'result kept in the outbox while the game is closed')
    a = await factory.login('LogAlpha', offlineAccount)
    await wait(300)
    assert.equal(BattleHistory.count(a.account.low), 34, 'outbox replay on login does not duplicate the entry')
    assert.equal(outboxRows(a.account.low), 0, 'outbox entry settled and retired by the login')
    assert.equal(trophies(a, 0), before + 10, 'reward paid once')
    rec = BattleHistory.list(a.account.low, 1)[0]
    assert.equal(rec.battle_id, String(world.id))
    assert.deepEqual([rec.trophies_before, rec.trophy_change], [before, 10])
    // a result processed again after the replay is still a no-op
    coordinator.result(world, entry, false); BattleHistory.flush(); await wait(200)
    assert.equal(BattleHistory.count(a.account.low), 34)
    log = await requestLog(a)
    assert.equal(log.entries[0].trophyChange, 10); assert.equal(log.entries[0].players.length, 6)
    const before8 = log.entries.map(x => [x.type, x.result, x.trophyChange, x.players.length])
    console.log('closed during battle: recorded once ok')

    // ---- 9. game restart (new login) ------------------------------------
    const accountA = a.account; const accountB = b.account
    a.socket.destroy(); b.socket.destroy(); await wait(400)
    a = await factory.login('LogAlpha', accountA)
    log = await requestLog(a)
    assert.deepEqual(log.entries.map(x => [x.type, x.result, x.trophyChange, x.players.length]), before8, 'same log after a new login')

    // ---- 10. SERVER restart ---------------------------------------------
    factory.closeAll(); await server.close(); await wait(300)
    server = new Server('127.0.0.1', 0); factory = createClientFactory(server)
    await server.start(); coordinator = server.battleCoordinator
    coordinator.on('battleError', err => errors.push(err.message))
    a = await factory.login('LogAlpha', accountA)
    b = await factory.login('LogBravo', accountB)
    log = await requestLog(a)
    assert.deepEqual(log.entries.map(x => [x.type, x.result, x.trophyChange, x.players.length]), before8, 'same log after a server restart')
    assert.equal(BattleHistory.count(a.account.low), 34)
    const logB = await requestLog(b)
    assert.deepEqual(logB.entries.map(x => x.type), [5, 1], 'member history persisted too')
    console.log('persistence across login and server restart ok')

    // ---- 11. profile: current trophies, descending, ties by id ----------
    prepare(b, { 0: 115, 1: 300, 2: 300, 3: 10, 16: 120, 23: 0 })
    let order = await profileOrder(a, b.account.low)
    assert.deepEqual(order.map(x => x.id), [1, 2, 16, 0, 3, 23], 'ordered by current trophies (ties by brawler id)')
    assert.deepEqual(order.map(x => x.trophies), [300, 300, 120, 115, 10, 0])
    // highest-ever must not drive the order
    const pb = session(b.account.low)
    pb.brawlers_trophies_in_rank = { ...(pb.brawlers_trophies_in_rank || {}), 23: 999 }
    DataBase.replaceValues({ player: pb }, { brawlersTrophiesForRank: pb.brawlers_trophies_in_rank })
    order = await profileOrder(a, b.account.low)
    assert.equal(order[order.length - 1].id, 23, 'highest trophies do not change the order')
    // a real match changes the order: Shelly 115 -> 125 (3v3 win) passes 16 (120)
    ;[world, entry] = await soloMatch(coordinator, b, 0)
    await finishHome(b, world, entry.team, false)
    await wait(150)
    order = await profileOrder(a, b.account.low)
    assert.deepEqual(order.map(x => x.id), [1, 2, 0, 16, 3, 23], 'order follows the match result')
    assert.equal(order.find(x => x.id === 0).trophies, 125)
    // own profile and many brawlers
    const many = {}; for (let id = 0; id < 24; id++) many[id] = (id * 37) % 50
    prepare(b, many)
    order = await profileOrder(b, b.account.low)
    assert(order.length >= 24, 'all unlocked brawlers listed')
    for (let i = 1; i < order.length; i++) {
      const p = order[i - 1]; const q = order[i]
      assert(p.trophies > q.trophies || (p.trophies === q.trophies && p.id < q.id), 'stable descending order')
    }
    console.log('profile order ok')

    assert.deepEqual(errors, [], 'no battle errors')
    console.log('BATTLE LOG E2E OK: 3v3 win/defeat, Showdown, team, duo, participants, trophies, newest first, no duplicates, limit 25 with full DB, persistence (login + server restart), profile by current trophies')
  } catch (error) {
    console.error(error)
    process.exitCode = 1
  } finally {
    factory.closeAll(); await server.close()
  }
}

main()
