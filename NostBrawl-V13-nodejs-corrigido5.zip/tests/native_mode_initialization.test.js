'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const { rules } = require('../Logic/Battle/World/GameModes')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'mode-initialization-vectors.json')))
const assets = new BattleAssets()
const expected = new Set(assets.tables.locations.filter(location => location.AllowedMaps && location.Disabled !== 'true').map(location => location.GameMode))
assert.equal(records.length, expected.size)
for (const record of records) {
  assert(expected.delete(record.gameMode), record.gameMode)
  assert.equal(record.error, undefined, record.gameMode)
  assert.equal(record.nativeMode, rules(record.gameMode).variation, record.gameMode)
  assert(record.width > 0 && record.height > 0 && record.emptyUpdateCompleted, record.gameMode)
}
assert.equal(expected.size, 0)
console.log(`Original location/map selection: ${records.length} mode names matched IDs and completed empty updates; player objectives and results excluded`)
