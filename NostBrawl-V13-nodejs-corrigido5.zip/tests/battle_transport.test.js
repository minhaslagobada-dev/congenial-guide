'use strict'
const assert = require('node:assert/strict')
const dgram = require('node:dgram')
const path = require('node:path')
const { once } = require('node:events')
const { performance } = require('node:perf_hooks')
process.chdir(path.resolve(__dirname, '..'))
const { Reader, vint, envelope, readEnvelope, decodeInput, encodeInput } = require('../Logic/Battle/Network/V13BattleCodec')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
const { BattleTransport } = require('../Logic/Battle/Network/BattleTransport')
const UDPConnectionInfo = require('../Packets/Messages/Server/Battle/UDPConnectionInfo')
const ClientInput = require('../Packets/Messages/Client/Battle/ClientInputMessage')

async function main () {
  // Fixed vectors from the native ByteStream layout, not the v36 bit layout.
  const vectors = new Map([
    [0, '00'], [63, '3f'], [64, '8001'], [-1, '7f'], [-63, '41'],
    [-64, 'c07f'], [8191, 'bf7f'], [8192, '808001'], [-8192, 'c0807f'],
    [2147483647, 'bfffffff0f'], [-2147483648, 'c080808000']
  ])
  for (const [value, hex] of vectors) {
    assert.equal(vint(value).toString('hex'), hex)
    assert.equal(new Reader(Buffer.from(hex, 'hex')).vint(), value)
  }
  const fixture = Buffer.from('011402020101a401ac369c94010000020100d47bb01284897a01', 'hex')
  const expected = {
    tick: 1, latency: 20, sequence: 2,
    inputs: [
      { counter: 1, category: 1, code: 100, x: 3500, y: 9500, targetId: 0, flag: false },
      { counter: 2, category: 1, code: 0, x: -300, y: 1200, targetId: 1000004, flag: true }
    ]
  }
  assert.deepEqual(decodeInput(fixture), expected)
  assert.deepEqual(encodeInput(expected), fixture)
  for (let n = 0; n < fixture.length; n++) assert.throws(() => decodeInput(fixture.subarray(0, n)))
  assert.throws(() => decodeInput(Buffer.concat([fixture, Buffer.from([0])])))
  assert.throws(() => decodeInput(Buffer.from([0, 0, 0, 31])))
  assert.throws(() => readEnvelope(Buffer.from([1, 2, 0])))
  assert.throws(() => readEnvelope(Buffer.from([1, 0, 0])))

  const queue = new InputBuffer(4)
  assert.equal(queue.push([expected.inputs[1], expected.inputs[0], expected.inputs[0]]), 2)
  assert.deepEqual(queue.drain().map(x => x.counter), [1, 2])
  assert.equal(queue.push(expected.inputs), 0)
  assert.equal(queue.lastAcknowledged, 2)
  const wrap = new InputBuffer()
  wrap.push([{ ...expected.inputs[0], counter: 32767 }]); wrap.drain()
  wrap.push([{ ...expected.inputs[0], counter: 32768 }])
  assert.equal(wrap.drain()[0].counter, 32768)

  const transport = new BattleTransport({ BindIP: '127.0.0.1', Port: 0, SessionTimeoutMs: 1000 })
  const peer = dgram.createSocket('udp4')
  const rebound = dgram.createSocket('udp4')
  const errors = []
  transport.on('transportError', e => errors.push(e))
  try {
    await transport.start()
    const player = { low_id: 7, logged_in: true }
    const client = { remoteAddress: '::ffff:127.0.0.1', localAddress: '127.0.0.1' }
    player.battleTransport = transport
    const session = transport.attach(player, client)
    assert.equal(transport.attach(player, client), session)
    const info = new UDPConnectionInfo(client, player)._encode_payload()
    const r = new Reader(info)
    assert.equal(r.vint(), transport.gateway.port)
    const hostLen = r.take(4).readInt32BE()
    assert.equal(r.take(hostLen).toString(), '127.0.0.1')
    assert.equal(r.take(4).readInt32BE(), 10)
    assert.deepEqual(r.take(10), session.header)
    assert.equal(r.take(4).readInt32BE(), 0)
    r.end()
    const packet = Buffer.concat([session.header, envelope(10555, fixture)])
    const received = once(transport, 'input')
    await new Promise((resolve, reject) => peer.send(packet, transport.gateway.port, '127.0.0.1', e => e ? reject(e) : resolve()))
    const [found, input] = await received
    assert.equal(found, session)
    assert.deepEqual(input, expected)
    assert.equal(session.input.drain().length, 2)
    const tcp = new ClientInput(client, player, fixture)
    tcp.decode(); assert.equal(tcp.process(), true)
    assert.equal(session.input.drain().length, 0, 'TCP fallback must deduplicate UDP commands')
    const response = once(peer, 'message')
    assert.equal(transport.send(session, 24109, Buffer.from([1, 2, 0, 0, 0, 0, 0, 0])), true)
    const [wire] = await response
    assert.deepEqual(wire.subarray(0, 10), session.header)
    assert.equal(readEnvelope(wire.subarray(10)).type, 24109)
    assert.equal(transport.gateway.receive(packet, { address: '127.0.0.2', port: 9000 }), false)
    assert.equal(transport.gateway.receive(Buffer.alloc(10), { address: '127.0.0.1', port: 9000 }), false)
    assert.equal(transport.gateway.receive(Buffer.concat([session.header, Buffer.from([1, 2, 0])]), { address: '127.0.0.1', port: 9000 }), false)
    player.onlineBattle = { phase: 'running' }
    session.lastSeen = performance.now() + 2000 // TCP remains active while UDP goes stale.
    transport.gateway.expire(performance.now() + 2000)
    assert.equal(player.udp_session, session)
    assert.equal(session.endpoint, null, 'Stale UDP must fall back to TCP')
    assert.equal(session.input.lastAcknowledged, 2, 'UDP recovery must preserve command deduplication')
    const recovered = once(transport, 'input')
    rebound.send(packet, transport.gateway.port, '127.0.0.1')
    await recovered
    assert.equal(session.endpoint.port, rebound.address().port)
    assert.equal(session.input.drain().length, 0, 'Retransmitted attacks cannot execute twice after recovery')
    player.onlineBattle = null
    transport.gateway.expire(performance.now() + 2000)
    assert.equal(player.udp_session, null)
    assert.equal(transport.gateway.sessions.size, 0)
    assert.equal(transport.gateway.receive(packet, { address: '127.0.0.1', port: 9000 }), false)
    assert.equal(transport.send(session, 24109, Buffer.alloc(0)), false)
    assert.equal(errors.length, 0)
  } finally {
    peer.close()
    rebound.close()
    await transport.close()
  }
  console.log('BATTLE TRANSPORT OK: native vectors, real UDP, TCP fallback, deduplication, timeout and cleanup')
}
const deadline = setTimeout(() => { console.error('Battle transport test timed out'); process.exit(1) }, 10000)
main().then(() => clearTimeout(deadline), error => { clearTimeout(deadline); console.error(error); process.exitCode = 1 })
