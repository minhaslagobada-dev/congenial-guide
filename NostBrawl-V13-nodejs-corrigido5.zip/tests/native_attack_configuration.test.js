'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { configureAttack } = require('../Native/V13/AttackSetup')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'attack-configuration-vectors.json')))
for (const v of vectors) {
  const owner = { x: 3000, y: 4500, i32: { '0x7c': 17 }, u8: {}, skills: [{ behavior: 3, activeMs: 50 }],
    byte1cc: v.variant === 'interruptInvisibility', byte3a0: v.variant === 'interruptInvisibility',
    superProjectileOverride: v.variant === 'skinOverride' ? v.override : null }
  configureAttack(owner, { ...v.input, projectile: v.projectile }, 100)
  assert.equal(owner.skills[0].activeMs, v.afterInvisibilityMs, v.projectile.Name)
  assert.equal(owner.projectile === v.override, v.resolvedProjectileIsOverride, v.projectile.Name)
  assert.deepEqual({ i32: owner.i32, u8: owner.u8 }, v.output, v.projectile.Name)
}
console.log('Native attack configuration:', vectors.length, 'cases matched original v13')
