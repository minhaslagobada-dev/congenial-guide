'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { castingRangeBonus } = require('../Native/V13/SkillRange')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'skill-range-vectors.json')))
for (const v of vectors) assert.equal(castingRangeBonus(v.definition, v.elapsed), v.bonus, v.definition.Name)
console.log('Native charged-aim range:', vectors.length, 'cases matched original v13')
