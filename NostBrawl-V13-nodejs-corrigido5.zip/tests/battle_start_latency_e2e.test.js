'use strict'
// Start-of-match control and command latency with real encrypted clients.
// 1. UDP path (reachable LAN/loopback): first move accepted on the first ticks.
// 2. TCP-only path (server behind NAT/container or Battle.Transport "tcp"):
//    24112 carries a null host, the client sends 10555 over TCP at once and
//    the server acknowledges and applies it on the next tick, so there is no
//    multi-second window in which inputs go to an unreachable UDP address.
// 3. Auto detection: private socket address + public client -> TCP-only.
const assert = require('node:assert/strict')
const { Server } = require('../main')
const { BattleTransport } = require('../Logic/Battle/Network/BattleTransport')
const { createClientFactory, vint, wait } = require('./helpers/v13_client')

const server = new Server('127.0.0.1', 0)
const factory = createClientFactory(server)
assert.equal(factory.settings.Store.Enabled, false, 'Use the isolated battle test runner')

function autoHost (settings, local, remote) {
  const t = new BattleTransport({ BindIP: '127.0.0.1', Port: 0, ...settings })
  return t.udpHost({ localAddress: local, remoteAddress: remote })
}

async function playAndMeasure (peer, label) {
  const coordinator = server.battleCoordinator
  let since = peer.messages.length
  peer.send(14103, Buffer.concat([vint(16), vint(0), vint(0), vint(1), vint(0), vint(0)]))
  await peer.waitFor(20405, 3000, since)
  await peer.waitFor(20559, 20000, since)
  const loadingAt = Date.now()
  await peer.waitFor(24112, 3000, since)
  await peer.waitFor(24109, 3000, since)
  const world = Array.from(coordinator.worlds.values()).find(w => w.players.some(p => !p.bot && p.player.low_id === peer.account.low))
  assert(world, 'match started')
  const entry = world.players.find(p => !p.bot && p.player.low_id === peer.account.low)
  const characterOf = () => {
    const native = world.state.players[entry.index]
    return world.state.objects.find(o => o.id === native.characterId)
  }
  const start = characterOf(); assert(start, 'own brawler exists in the first frame')
  const startTick = world.tick
  // First command right after the bootstrap snapshot: move far to the side.
  const sentAt = Date.now(); const counter = 1
  peer.input([{ counter, category: 1, code: 100, x: start.x + 2000, y: start.y }])
  let ackAt = null; let movedAt = null; let movedTick = null
  for (let i = 0; i < 200 && (ackAt === null || movedAt === null); i++) {
    await wait(5)
    if (ackAt === null && peer.visions.some(v => v.at >= sentAt && v.ack >= counter)) ackAt = Date.now()
    const now = characterOf()
    if (movedAt === null && now && (now.x !== start.x || now.y !== start.y)) { movedAt = Date.now(); movedTick = world.tick }
  }
  assert(ackAt !== null, `${label}: first input acknowledged`)
  assert(movedAt !== null, `${label}: brawler moves on the first command`)
  // Attack command: acknowledged on the next tick as well.
  const attackAt = Date.now()
  peer.input([{ counter: 2, category: 1, code: 0, x: start.x + 2000, y: start.y }])
  let attackAck = null
  for (let i = 0; i < 100 && attackAck === null; i++) {
    await wait(5)
    if (peer.visions.some(v => v.at >= attackAt && v.ack >= 2)) attackAck = Date.now()
  }
  assert(attackAck !== null, `${label}: attack acknowledged`)
  const result = {
    label,
    transport: peer.host === null ? 'TCP' : 'UDP',
    firstInputMsAfterStartLoading: sentAt - loadingAt,
    inputAckMs: ackAt - sentAt,
    moveAppliedMs: movedAt - sentAt,
    moveTicksAfterStart: movedTick - startTick,
    attackAckMs: attackAck - attackAt,
    visionBytesMax: Math.max(...peer.visions.map(v => v.payload.length))
  }
  console.log('LATENCY', JSON.stringify(result))
  assert(result.inputAckMs <= 150, `${label}: input acknowledged within a few ticks (${result.inputAckMs} ms)`)
  assert(result.attackAckMs <= 150, `${label}: attack acknowledged within a few ticks (${result.attackAckMs} ms)`)
  assert(result.moveTicksAfterStart <= 4, `${label}: movement applied within the first ticks`)
  world.finish(null, 'abandoned')
  await wait(100)
  return result
}

async function main () {
  // Auto transport selection (pure function of the socket addresses).
  assert.equal(autoHost({}, '::ffff:172.18.0.5', '::ffff:187.10.20.30'), null, 'Container IP behind port mapping -> TCP-only')
  assert.equal(autoHost({}, '10.0.0.4', '201.1.2.3'), null, 'Private host IP + public client -> TCP-only')
  assert.equal(autoHost({}, '192.168.0.10', '192.168.0.20'), '192.168.0.10', 'LAN keeps UDP')
  assert.equal(autoHost({}, '127.0.0.1', '127.0.0.1'), '127.0.0.1', 'Loopback keeps UDP')
  assert.equal(autoHost({}, '45.1.2.3', '187.10.20.30'), '45.1.2.3', 'Public host IP keeps UDP')
  assert.equal(autoHost({ AdvertiseHost: '45.1.2.3' }, '172.18.0.5', '187.10.20.30'), '45.1.2.3', 'Explicit AdvertiseHost keeps UDP')
  assert.equal(autoHost({ Transport: 'tcp', AdvertiseHost: '45.1.2.3' }, '45.1.2.3', '187.10.20.30'), null, 'Transport tcp forces TCP-only')
  assert.equal(autoHost({}, '::1', '::1'), null, 'No IPv4 socket address -> TCP-only instead of a failed match')
  assert.throws(() => new BattleTransport({ Transport: 'quic' }), /Battle.Transport/)
  try {
    await server.start()
    const errors = []; server.battleCoordinator.on('battleError', e => errors.push(e))
    const udpPeer = await factory.login('udp-latency')
    const udp = await playAndMeasure(udpPeer, 'udp')
    assert.equal(udp.transport, 'UDP')
    server.battleTransport.settings.Transport = 'tcp'
    const tcpPeer = await factory.login('tcp-latency')
    const tcp = await playAndMeasure(tcpPeer, 'tcp')
    assert.equal(tcp.transport, 'TCP', '24112 announced the TCP-only path')
    assert(!tcpPeer.closed && !udpPeer.closed)
    assert.equal(errors.length, 0, errors.map(e => e.stack).join('\n'))
    console.log('START LATENCY E2E OK: auto transport selection; first move/attack acknowledged and applied within the first ticks over UDP and over TCP-only')
  } finally {
    factory.closeAll()
    await server.close()
  }
}
const timer = setTimeout(() => { console.error('Start latency e2e timeout'); process.exit(1) }, 90000)
main().then(() => clearTimeout(timer), error => { clearTimeout(timer); console.error(error); process.exitCode = 1 })
