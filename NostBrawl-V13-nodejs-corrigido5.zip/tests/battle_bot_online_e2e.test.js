'use strict'
process.env.BATTLE_E2E_CLIENTS = '1'
require('./battle_online_e2e.test')
