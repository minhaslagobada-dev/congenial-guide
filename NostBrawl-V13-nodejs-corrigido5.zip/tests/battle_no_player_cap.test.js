'use strict'
// The old Battle.MaxPlayers = 200 cap refused the 201st battle player in the
// UDP gateway, the coordinator and the matchmaker. It must be gone, while the
// real per-session protections (one session per account) still hold.
const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const { battleAssets } = require('../Logic/Battle/World/BattleAssets')
const { Matchmaker } = require('../Logic/Battle/Matchmaker')
const { BattleTransport } = require('../Logic/Battle/Network/BattleTransport')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const Config = require('../Utils/Config')
const COUNT = 260

async function main () {
  assert.equal(Config.DEFAULT_SETTINGS.Battle.MaxPlayers, undefined, 'No default player cap')
  const assets = battleAssets()
  let id = 0
  const member = () => ({ player: { low_id: ++id, logged_in: true, brawler_id: 0 }, client: { destroyed: false, write () { return true } } })

  const matchmaker = new Matchmaker(assets)
  for (let i = 0; i < COUNT; i++) matchmaker.enqueue([member()], 0)
  assert.equal(matchmaker.players.size, COUNT, 'Matchmaker queues more than 200 players')

  const coordinator = new BattleCoordinator(new EventEmitter())
  clearTimeout(coordinator.timer)
  try {
    for (let i = 0; i < COUNT; i++) assert(coordinator.enqueue([member()], 0))
    assert.equal(coordinator.matchmaker.players.size, COUNT, 'Coordinator accepts more than 200 players')
  } finally { coordinator.close() }

  const transport = new BattleTransport({ BindIP: '127.0.0.1', Port: 0, SessionTimeoutMs: 30000 })
  try {
    await transport.start()
    const sessions = new Set()
    for (let i = 1; i <= COUNT; i++) {
      const player = { low_id: 100000 + i, logged_in: true }
      sessions.add(transport.attach(player, { remoteAddress: '127.0.0.1', localAddress: '127.0.0.1' }))
    }
    assert.equal(sessions.size, COUNT)
    assert.equal(transport.gateway.sessions.size, COUNT, 'UDP gateway opens more than 200 sessions')
    // Security limit kept: one live UDP session per account.
    const again = { low_id: 100001, logged_in: true }
    transport.attach(again, { remoteAddress: '127.0.0.1', localAddress: '127.0.0.1' })
    assert.equal(transport.gateway.sessions.size, COUNT, 'A second session for the same account replaces the first')
  } finally { await transport.close() }
  console.log(`NO PLAYER CAP OK: ${COUNT} players in matchmaker, coordinator and UDP gateway; one session per account kept`)
}
main().catch(error => { console.error(error); process.exitCode = 1 })
