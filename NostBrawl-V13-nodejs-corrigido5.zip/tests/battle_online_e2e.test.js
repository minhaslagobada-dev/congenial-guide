'use strict'
const assert = require('node:assert/strict')
const net = require('node:net')
const dgram = require('node:dgram')
const crypto = require('node:crypto')
const { blake2b } = require('blakejs')
const { Server } = require('../main')
const Config = require('../Utils/Config')
const readLoading = require('./helpers/v13_loading')
const NaCl19 = require('../Core/NaCl19')
const { Nonce, DEFAULT_CLIENT_PRIVATE_KEY } = require('../Core/Crypto')
const { Reader, vint, envelope, encodeInput, readEnvelope } = require('../Logic/Battle/Network/V13BattleCodec')
const int = value => { const b = Buffer.alloc(4); b.writeInt32BE(value); return b }
const string = value => { const b = Buffer.from(value); return Buffer.concat([int(b.length), b]) }
const frame = (type, payload, version = 0) => {
  const b = Buffer.alloc(7); b.writeUInt16BE(type); b.writeUIntBE(payload.length, 2, 3); b.writeUInt16BE(version, 5)
  return Buffer.concat([b, payload])
}
const settings = Config.GetValue()
assert.equal(settings.Store.Enabled, false, 'Use the isolated battle test runner')
const fingerprint = require('../Utils/Fingerprint').loadFinger('GameAssets/fingerprint.json')
const server = new Server('127.0.0.1', 0)
const peers = []
const tcpOnly = process.env.BATTLE_E2E_TCP_ONLY === '1'
const clientCount = Number(process.env.BATTLE_E2E_CLIENTS || 6)
assert([1, 6].includes(clientCount))
function freeMove (world, char) {
  if (world.nativeVisionPayload) return { x: 3150, y: 6150 }
  return [[0, -300], [0, 300], [-300, 0], [300, 0]].map(([dx, dy]) => ({ x: Math.trunc(char.x + dx), y: Math.trunc(char.y + dy) }))
    .find(p => world.map.canOccupy(p.x, p.y, char.radius) && !world.map.trace(char.x, char.y, p.x, p.y, char.radius))
}
function actor (world, entry) {
  if (!world.state) return world.characters.get(entry.player.low_id)
  return world.state.objects.find(object => object.id === world.state.players[entry.index].characterId)
}
function connect (number) {
  return new Promise((resolve, reject) => {
    const sk = Buffer.from(DEFAULT_CLIENT_PRIVATE_KEY, 'hex'); const pk = NaCl19.scalarmultBase(sk)
    const serverPk = Buffer.from(settings.Crypto.ServerPublicKey, 'hex'); const shared = NaCl19.boxBeforenm(serverPk, sk)
    const sendNonce = new Nonce(crypto.randomBytes(24)); let recvNonce; let sessionKey
    const socket = net.connect(server.port, '127.0.0.1'); const udp = dgram.createSocket('udp4')
    const peer = { socket, udp, visions: [], results: [], statuses: [], loaded: false, counter: 0 }; peers.push(peer)
    peer.send = (type, payload) => { sendNonce.increment(); socket.write(frame(type, NaCl19.secretbox(payload, sendNonce.toBuffer(), sessionKey))) }
    peer.input = inputs => {
      const payload = encodeInput({ tick: 0, inputs })
      if (tcpOnly) peer.send(10555, payload)
      else udp.send(Buffer.concat([peer.header, envelope(10555, payload)]), peer.port, peer.host)
    }
    socket.on('error', reject); udp.on('error', reject)
    udp.on('message', bytes => {
      try {
        const msg = readEnvelope(bytes.subarray(10)); assert.equal(msg.type, 24109)
        const reader = new Reader(msg.payload); const tick = reader.vint(); const ack = reader.vint()
        reader.vint(); reader.vint(); const bits = reader.take(reader.take(4).readInt32BE()); reader.end()
        assert(bits.length > 40); peer.visions.push({ tick, ack, bits })
        if (!peer.resolved) { peer.resolved = true; resolve(peer) }
      } catch (error) { reject(error) }
    })
    let rx = Buffer.alloc(0)
    socket.on('connect', () => socket.write(frame(10100, Buffer.concat([int(1), int(1), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), int(0), int(0)]))))
    socket.on('data', chunk => {
      try {
        rx = Buffer.concat([rx, chunk])
        while (rx.length >= 7) {
          const type = rx.readUInt16BE(); const len = rx.readUIntBE(2, 3)
          if (rx.length < len + 7) break
          const payload = rx.subarray(7, len + 7); rx = rx.subarray(len + 7)
          if (type === 20100) {
            const nonce = Buffer.from(blake2b(Buffer.concat([pk, serverPk]), null, 24))
            const login = Buffer.concat([int(0), int(0), string(''), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), string(''), string('online-' + number), string('online-test'), string('test')])
            socket.write(frame(10101, Buffer.concat([pk, NaCl19.secretbox(Buffer.concat([payload.subarray(4, 28), sendNonce.toBuffer(), login]), nonce, shared)]), 1))
          } else if (type === 20104) {
            const raw = NaCl19.secretboxOpen(payload, new Nonce(sendNonce.toBuffer(), pk, serverPk).toBuffer(), shared)
            assert(raw); recvNonce = new Nonce(raw.subarray(0, 24)); sessionKey = raw.subarray(24, 56)
          } else if (type === 20103) reject(new Error('Login rejected'))
          else {
            recvNonce.increment(); const raw = NaCl19.secretboxOpen(payload, recvNonce.toBuffer(), sessionKey); assert(raw)
            if (type === 23456) peer.results.push(raw)
            if (type === 24101) { peer.queuedAt = Date.now(); peer.send(14103, Buffer.concat([vint(16), vint(0), vint(0), vint(1), vint(0), vint(0)])) }
            if (type === 20405) { assert.equal(raw.length, 20); peer.statuses.push(raw.readInt32BE()) }
            if (type === 20406) reject(new Error('Unexpected matchmaking cancellation'))
            if (type === 20559) { peer.loading = readLoading(raw); assert.equal(peer.loading.count, 6); peer.loaded = true; peer.loadedAt = Date.now() }
            if (type === 24112) {
              const r = new Reader(raw); peer.port = r.vint(); peer.host = r.take(r.take(4).readInt32BE()).toString(); peer.header = r.take(r.take(4).readInt32BE())
              assert.equal(r.take(4).readInt32BE(), 0); r.end()

            }
            if (type === 24109) {
              assert(peer.loaded && peer.header, 'Bootstrap order must be Loading -> UDPInfo -> Vision')
              const r = new Reader(raw); const tick = r.vint(); const ack = r.vint(); r.vint(); r.vint()
              const bits = r.take(r.take(4).readInt32BE()); r.end(); assert(bits.length > 40)
              peer.visions.push({ tick, ack, bits, tcp: true })
              if (!peer.bootstrap) {
                peer.bootstrap = true
                if (tcpOnly) peer.input([])
                else udp.bind(0, '127.0.0.1', () => peer.input([]))
              } else if (tcpOnly && tick > 0 && !peer.resolved) { peer.resolved = true; resolve(peer) }
            }
          }
        }
      } catch (error) { reject(error) }
    })
  })
}
async function main () {
  try {
    await server.start()
    const ready = await Promise.all(Array.from({ length: clientCount }, (_, i) => connect(i)))
    assert.equal(server.battleCoordinator.worlds.size, 1)
    const world = Array.from(server.battleCoordinator.worlds.values())[0]
    assert.equal(world.phase, 'running'); assert.equal(world.players.length, 6)
    if (clientCount === 1) {
      const peer = ready[0]
      assert(peer.loadedAt - peer.queuedAt >= 14900, 'One player must wait the full 15 seconds')
      assert(peer.loadedAt - peer.queuedAt < 18000, 'The timeout must start the match promptly')
      assert.equal(peer.statuses[0], 15)
      assert(peer.statuses.includes(1), 'Client must receive countdown updates')
      assert.equal(world.players.filter(entry => entry.bot).length, 5)
      assert.equal(peer.loading.entries.filter(entry => entry.lowId === 0).length, 5)
      assert(world.players.filter(entry => entry.bot).every(entry => entry.ready && !entry.session))
      assert.equal(server.battleTransport.gateway.sessions.size, 1)
      assert.equal(server.battleCoordinator.accounts.size, 1)
      assert.equal(Boolean(world.players[0].session.endpoint), !tcpOnly)
      assert(server.battleCoordinator.metrics.tcpSnapshots > 0, 'First real world must be sent without waiting for UDP')
      await new Promise(resolve => setTimeout(resolve, 350))
      assert(peer.visions.length >= 4, 'The solo human must receive continuing world snapshots')
      if (tcpOnly) {
        const char = actor(world, world.players[0]); const origin = { x: char.x, y: char.y }; const target = freeMove(world, char); assert(target)
        peer.input([{ counter: ++peer.counter, category: 1, code: 100, ...target }])
        await new Promise(resolve => setTimeout(resolve, 250))
        const moved = actor(world, world.players[0])
        assert(Math.hypot(moved.x - origin.x, moved.y - origin.y) > 0, 'TCP-only native move must affect the world')
        assert(peer.visions.some(v => v.ack === peer.counter))
      }
      world.finish(0, 'gems')
      await new Promise(resolve => setTimeout(resolve, 100))
      assert.equal(peer.results.length, 1)
      const result = world.players[0].player.authoritativeBattleResult
      assert.equal(result.participants.filter(p => p.is_player).length, 1, 'Only humans may have account IDs in results')
      assert.equal(result.participants.length, 6)
      assert.equal(server.battleCoordinator.worlds.size, 0)
      assert.equal(server.battleCoordinator.accounts.size, 0)
      assert.equal(server.battleTransport.gateway.sessions.size, 0)
      assert.equal(server.battleCoordinator.metrics.failures, 0)
      console.log('BOT ONLINE E2E OK (' + (tcpOnly ? 'TCP-only' : 'UDP') + '): one encrypted login -> 15-second countdown -> five server bots -> one UDP peer -> native snapshots -> human-only rewards/result -> cleanup')
      return
    }

    const entry = world.players[0]; const character = actor(world, entry)
    const peer = ready.find(p => p.header.equals(entry.session.header)); assert(peer)
    const origin = { x: character.x, y: character.y }
    const target = freeMove(world, character); assert(target)
    peer.input([{ counter: ++peer.counter, category: 1, code: 100, ...target }])
    await new Promise(resolve => setTimeout(resolve, 300))
    const moved = actor(world, entry)
    assert(Math.hypot(moved.x - origin.x, moved.y - origin.y) > 0, 'Movement must reach authoritative world')
    assert(peer.visions.some(v => v.ack === peer.counter), 'Server must acknowledge committed movement')
    assert(ready.every(p => p.loaded && p.visions.length >= 2))
    if (world.nativeVisionPayload) {
      // This checks result delivery/idempotency only. Natural native objective
      // endings are independently exercised by native_battle_endings.test.js.
      world.finish(entry.team, 'test-result-pipeline')
    } else {
      character.score = 10; entry.score = 10
      world.step()
      assert(world.countdown, 'Ten gems must start the authoritative countdown')
      for (let i = 0; i < 300; i++) world.step()
    }
    await new Promise(resolve => setTimeout(resolve, 100))
    assert.equal(world.phase, 'finished')
    assert(ready.every(p => p.results.length === 1), 'Every actual player must receive one result')
    const outcomes = ready.map(p => { const r = new Reader(p.results[0]); assert.equal(r.vint(), 0); return r.vint() })
    assert.equal(outcomes.filter(n => n === 0).length, 3)
    assert.equal(outcomes.filter(n => n === 1).length, 3)
    world.finish(1, 'duplicate')
    peer.send(14110, Buffer.from([0])) // An untrusted upload cannot replace the server outcome.
    await new Promise(resolve => setTimeout(resolve, 50))
    assert(ready.every(p => p.results.length === 1))
    for (const p of ready) p.socket.destroy()
    await new Promise(resolve => setTimeout(resolve, 100))
    assert.equal(server.battleCoordinator.accounts.size, 0)
    assert.equal(server.battleCoordinator.worlds.size, 0)
    assert.equal(server.battleTransport.gateway.sessions.size, 0)
    console.log('ONLINE E2E OK: six encrypted TCP logins -> real matchmaking -> 20559 -> six UDP sessions -> 24109 snapshots -> movement/ack -> result delivery -> duplicate rejection -> cleanup; native objective endings tested separately')
  } finally {
    for (const peer of peers) { peer.socket.destroy(); try { peer.udp.close() } catch (_) {} }
    await server.close()
  }
}
const timer = setTimeout(() => { console.error('Online battle e2e timeout'); process.exit(1) }, clientCount === 1 ? 25000 : 15000)
main().then(() => clearTimeout(timer), error => { clearTimeout(timer); console.error(error); process.exitCode = 1 })
