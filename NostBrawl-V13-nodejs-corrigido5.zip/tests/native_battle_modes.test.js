'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const { rules } = require('../Logic/Battle/World/GameModes')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'battle-modes-vectors.json')))
const assets = new BattleAssets()
assert.equal(records.length, 9)
assert.equal(new Set(records.map(record => record.gameMode)).size, 9)
for (const record of records) {
  assert.equal(record.error, undefined, JSON.stringify(record.error))
  const mode = rules(record.gameMode)
  const initial = record.afterSetup
  assert.equal(initial.players.length, mode.capacity, record.gameMode)
  assert.equal(initial.players.filter(player => !player.bot).length, 1)
  const counts = new Map()
  for (const player of initial.players) {
    counts.set(player.team, (counts.get(player.team) || 0) + 1)
    const actor = initial.objects.find(object => object.id === player.characterId)
    assert(actor && actor.hp > 0, record.gameMode)
  }
  const sizes = Array.from(counts.values()).sort((a, b) => a - b)
  const expected = mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize)
  assert.deepEqual(sizes, expected.slice().sort((a, b) => a - b), record.gameMode)
  if (record.gameMode === 'BossFight') {
    const boss = initial.players.find(player => player.team === 1)
    const actor = initial.objects.find(object => object.id === boss.characterId)
    assert(actor.hp > Number(assets.tables.characters[actor.dataId - 16000000].Hitpoints))
  }
  assert.equal(record.frames.length, 40)
  for (const [i, frame] of record.frames.entries()) {
    assert.equal(frame.tick, i + 1)
    assert.equal(frame.nativeMode, mode.variation)
    assert.equal(frame.ended, false, record.gameMode)
    assert.equal(frame.vision.length, 1)
    assert.equal(frame.vision[0].hex.length / 2, Math.ceil(frame.vision[0].bits / 8))
  }
}
console.log('Original populated startup: 9 modes, native team capacities, bot fill, boss HP scaling and 360 encoded frames; objectives/endings excluded')
