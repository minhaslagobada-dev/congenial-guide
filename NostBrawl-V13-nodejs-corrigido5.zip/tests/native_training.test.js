'use strict'
const assert = require('node:assert/strict')
const { NativeBattleBridge } = require('../Logic/Battle/NativeBattleBridge')
const { NativeBattleWorld } = require('../Logic/Battle/Game/NativeBattleWorld')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const { GameRoomService } = require('../Logic/GameRoomService')
const AskEnd = require('../Packets/Messages/Client/Battle/AskForBattleEndMessage')
const runtime = new NativeBattleBridge(); const assets = new BattleAssets()
try {
  const player = { low_id: 1, name: 'Training', brawler_id: 0, Brawler_level: {} }; const client = {}
  const map = assets.named('locations', 'Tutorial').id
  const world = new NativeBattleWorld('training', assets, map, [{ index: 0, team: 0, brawlerId: 0, powerLevel: 0, player, client }], 17, runtime)
  assert.equal(world.loadingGameType, 5); assert.equal(world.players.length, 1)
  assert.equal(world.practice, true); assert.equal(GameRoomService._capacity(map), 1)
  assert(world.state.objects.length > 1)
  player.onlineBattle = world; world.players[0].ready = true
  for (let i = 0; i < 40; i++) world.step()
  let exits = 0; world.on('finished', result => { assert.equal(result.reason, 'abandoned'); exits++ })
  const request = new AskEnd(client, player, Buffer.alloc(0)); request.decode(); request.process()
  assert.equal(exits, 1); assert.equal(world.nativeActive, false)
  console.log('Original training kind 5: one human, native targets, 40 frames and reward-free client exit')
} finally { runtime.close() }
