'use strict'
const assert = require('node:assert/strict')
const DataBase = require('../Database/DatabaseManager')
const { Players } = require('../Logic/Player')
const { BattleRewardsManager } = require('../Logic/BattleRewardsManager')
const original = DataBase.replaceValues
// Exercise reward arithmetic with an in-memory persistence boundary. Real
// ledger/outbox idempotency is covered by the isolated server regression suite.
DataBase.replaceValues = () => true
function reward (isMvp, mode = 0, practice = false) {
  const player = new Players(null); player.tutorial = 2; player.brawler_id = 0
  player.brawlers_trophies = { 0: 0 }; player.brawlers_trophies_in_rank = { 0: 0 }
  player.player_experience = 100; player.battle_tokens = 200
  const fields = { GameMode: mode, MapID: 7, Victory: 0, Rank: 1, Practice: practice, IsMvp: isMvp, Heroes: [{ IsPlayer: true, Brawler: { ID: [16, 0] } }] }
  return new BattleRewardsManager(player).process_rewards(fields)
}
try {
  const ordinary = reward(false); const mvp = reward(true)
  assert.equal(ordinary.star_player_exp, 0); assert.equal(ordinary.starplayer, 0)
  assert.equal(mvp.star_player_exp, 10); assert.equal(mvp.starplayer, 1)
  assert.equal(ordinary.experience, mvp.experience, 'MVP bonus must not be added twice')
  for (const mode of [2, 3, 4, 5, 6]) assert.equal(reward(false, mode).star_player_exp, 0)
  assert.equal(reward(true, 0, true).star_player_exp, 0)
  console.log('Native rewards: only the original MVP earns bonus XP, no duplicated bonus, no Solo/Duo/co-op MVP grants and no practice rewards')
} finally { DataBase.replaceValues = original }
