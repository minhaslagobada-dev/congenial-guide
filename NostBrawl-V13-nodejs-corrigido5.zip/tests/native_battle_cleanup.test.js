'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR')
const record = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'battle-cleanup-vectors.json')))
assert.equal(record.error, undefined)
assert.equal(record.matches.length, 5)
for (const match of record.matches) {
  assert.equal(match.liveBytes, record.baselineBytes, `match ${match.index} retained guest memory`)
  assert.deepEqual(match.outstanding, [])
}
console.log('Five native matches constructed, advanced and destroyed without retained guest allocations; repeated close is harmless')
