'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { intervalTicks } = require('../Native/V13/AttackTiming')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'attack-timing-vectors.json')))
for (const v of vectors) assert.equal(intervalTicks({ skills: [{ definition: v.definition, activeMs: v.activeMs, executing: v.executing }],
  attackIntervalMs: Number(v.definition.MsBetweenAttacks) || 0, castingMs: v.castingMs, characterType: v.characterType,
  cachedInterval: v.cachedInterval, mainDefinition: v.definition }), v.result, JSON.stringify(v))
console.log('Native attack timing:', vectors.length, 'cases matched original v13')
