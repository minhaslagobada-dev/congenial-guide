# Otimização do servidor de batalha (V13)

Medições feitas em sandbox com 2 vCPU / 1 GB RAM, Node 20, motor nativo (libg via unicorn + koffi).
"Antes" = commit `9ea76ae` (porte entregue); "depois" = `7464d6e`.
Ferramentas: `work/perf/stress/stress.js` (clientes reais TCP+UDP que se movem e atiram juntos no centro),
`bench_sd.js` e `bench_sd_hash.js` (a mesma partida quadro a quadro; o hash do estado é idêntico antes e depois,
ou seja, a mecânica não mudou).

## 1. Lag global: causa e correções

A causa era o tempo de CPU por tick do motor emulado. Ele passava de 50 ms quando muitos personagens
lutavam juntos. O loop atrasava, a entrega de ticks ficava irregular e a fila de ticks atrasados crescia
para todos os jogadores ao mesmo tempo.

| Correção | Onde |
|---|---|
| Hook JS de asserção removido do caminho quente (agora só no ramo de falha) | `native_data.js` |
| TLB virtual por região no unicorn: elimina o caminho lento `notdirty` em cada escrita | `lib/unicorn_native.js` |
| O TLB do unicorn cresce até o tamanho do conjunto de trabalho da batalha (flush só após rajadas de misses) | `lib/unicorn_native.js` |
| Timeout por watchdog em memória compartilhada, sem thread de timer por chamada | `emulate_v13.js` |
| Um único round-trip por tick (`step`: entradas + quadro + visão), em vez de JSON por entrada + describe | `battle_worker.js`, Bridge/Thread/Runtime |
| Tick assíncrono: o event loop não fica bloqueado durante o quadro | `NativeBattleWorld.stepAsync` |
| Relógio sem deriva + limite de catch-up: sem acúmulo de backlog | `BattleCoordinator` |

### Quadro do motor (Showdown, 10 humanos, 400 quadros, mesmo hash `00c4f57068b82452`)

| | média | p95 | máx |
|---|---|---|---|
| antes | 28,03 ms | 49,89 ms | 66,66 ms |
| depois | 3,58 ms | 5,27 ms | 24,90 ms |

### Stress: Showdown, 10 clientes juntos no centro, UDP, 20 s

| métrica | antes | depois |
|---|---|---|
| ticks/s (alvo 20) | 17,43 | 20,03 |
| atraso dos ticks em relação ao relógio (p50) | 2504 ms, crescendo | 5 ms |
| intervalo entre ticks p95 / máx | 83,8 / 107,6 ms | 51,2 / 52,0 ms |
| intervalo de chegada no cliente p95 | 84,9 ms | 59,0 ms |
| lacunas > 100 ms no cliente | 30 | 0 |
| atraso do event loop p99 / máx | 86,9 / 107,6 ms | 6,2 / 10,7 ms |
| tempo do event loop gasto no tick | 46,7 ms (bloqueante) | 0,19 ms (assíncrono) |
| snapshot médio / máx | 360 / 854 B | 351 / 770 B |

### Stress: 3 partidas simultâneas (Showdown 10 + Showdown 10 + Gem Grab 6), 26 clientes

| métrica | antes | depois |
|---|---|---|
| ticks/s | 5,82 | 20,01 |
| atraso dos ticks p50 / máx | 7,8 s / 14,1 s | 6,8 / 34,6 ms |
| lacunas > 100 ms / > 250 ms | 2756 / 78 | 0 / 0 |
| atraso do event loop médio / máx | 172 / 404 ms | 5,2 / 20,5 ms |

### Stress: Showdown 10, só TCP, movimentos longos (joystick de 5000 unidades)

| métrica | antes | depois |
|---|---|---|
| ticks/s | 1,53 | 20,10 |
| atraso dos ticks p50 | 8,2 s | 10,6 ms |
| lacunas > 250 ms | 300 | 0 |

## 2. Travamento na tela inicial

A causa real era um impasse no protocolo: o servidor só começava a avançar os ticks depois que todos os
humanos estavam "prontos" ou tinham enviado entrada, e o cliente original espera os ticks antes de sair
da introdução. Agora o motor começa no primeiro passo após o 20559/24112 (`NativeBattleWorld.begin`).
Nenhum atraso artificial foi adicionado. O timer de matchmaking de 15 s continua como manda o protocolo.

Do StartLoading até o mundo avançar, em todos os modos testados (p50):

| mapa | antes | depois |
|---|---|---|
| BountyHunter (0) | 70 ms | 10 ms |
| CoinRush (7) | 70 ms | 9 ms |
| Gemgrab (12) | 70 ms | 9 ms |
| Survival/Showdown (13), 10 jogadores | 63 ms | 18 ms |
| AttackDefend (17) | 68 ms | 10 ms |
| BossFight (21) | 58 ms | 6 ms |
| LaserBall (24) | 69 ms | 12 ms |
| Coop (27) | 60 ms | 4 ms |
| BR Team (28), 10 jogadores | 106 ms | 14 ms |
| Raid (57) | 11 ms | 6 ms |

Os clientes de stress mandam entrada logo de início. Por isso o "antes" aparece em milissegundos aqui; com
o cliente real, que espera os ticks, o impasse durava até o timeout. Os testes `native_battle_world` e
`native_coordinator_lifecycle` reproduzem esse cenário e verificam que o tick avança sem nenhuma entrada.

## 3. Reconexão

- Se o jogador cai (TCP/UDP), a partida continua para os outros. O slot fica reservado por
  `ReconnectWindowSeconds` (padrão 180 s) e só é abandonado se todos os humanos ficarem fora durante essa janela.
- No login, `LoginMessage._resume_battle` procura uma partida ativa da conta e reenvia a sequência original:
  24101 → 20559 → 24112 → 24109 ao vivo.
- O jogador volta para o mesmo slot e o mesmo objeto do motor: posição, vida, munição e super vêm do estado
  vivo do motor. Não há respawn nem personagem duplicado.
- Se a partida já acabou, segue o fluxo normal (resultado pelo outbox, depois o menu).
- Sair pelo botão "home" (`GoHomeFromOfflinePractise`) continua significando abandono.
- Teste e2e real `tests/battle_reconnect_e2e.test.js`, com 6 clientes: o jogador cai no meio da batalha e
  volta em 26–44 ms (do login até o 24109 ao vivo), com o mesmo id de objeto, entradas novas aceitas e o
  resultado entregue na nova conexão.

## Validação

- `node scripts/test_battles.js --regression`: 26 suítes OK, incluindo a nova de reconexão.
- Os testes `tests/native_*` que não precisam de `V13_RESEARCH_DIR` (dados de oráculo externos) passam.
- O hash do estado do motor é idêntico ao do porte original.

## Limites honestos

- Os números são do sandbox de 2 vCPU. Na hospedagem os valores absolutos mudam, mas as causas removidas
  (tick bloqueante, backlog, caminho lento do emulador) são as mesmas.
- Movimentos de alvo muito distante ainda custam alguns ms dentro do motor original (código nativo de movimentação).
  Isso não foi alterado para não mudar a mecânica.
- Nenhum pacote npm novo foi adicionado: as melhorias vieram do uso correto das dependências que já existiam.
