'use strict'

class LogicOfferItem {
  static _reference (writer, reference) {
    if (!reference) {
      writer.v(0)
      return
    }
    let csvId
    let itemId
    try {
      csvId = Math.trunc(reference[0])
      itemId = Math.trunc(reference[1])
      if (Number.isNaN(csvId) || Number.isNaN(itemId)) {
        throw new TypeError()
      }
    } catch (error) {
      throw new Error('Invalid offer DataReference')
    }
    if (csvId <= 0 || itemId < 0) {
      throw new Error('Invalid offer DataReference')
    }
    writer.v(csvId)
    writer.v(itemId)
  }

  static encode (writer, item) {
    writer.v(Math.trunc(item.offerId))
    writer.v(Math.trunc(item.amount !== undefined ? item.amount : 0))
    LogicOfferItem._reference(writer, item.target)
    writer.v(Math.trunc(item.value !== undefined ? item.value : 0))
  }
}

module.exports = LogicOfferItem
