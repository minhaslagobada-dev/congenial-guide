'use strict'

// Proxy provisório: resolve para Logic/ClubService da raiz quando a etapa
// 4 (Social) portar o serviço completo de clubes.
module.exports = require('../../Logic/ClubService')
