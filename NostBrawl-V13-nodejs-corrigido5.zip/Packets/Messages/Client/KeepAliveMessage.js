'use strict'
const KeepAliveOkMessage = require('../Server/KeepAliveOkMessage')
const { BSMessageReader } = require('../../../Utils/Reader')

class KeepAliveMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
  }

  decode () {
    return
  }

  process () {
    new KeepAliveOkMessage(this.client, this.player).send()
  }
}

module.exports = KeepAliveMessage
