'use strict'

const { BSMessageReader } = require('../../../../Utils/Reader')
const { returnHome } = require('./GoHomeFromOfflinePractiseMessage')

// 14101: return to the lobby after an online battle (libg encode 0x343ea8:
// one boolean). Without a reply the client stays on the 92% loading screen.
class GoHomeMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    // A return request is never worth a disconnect: an unexpected layout
    // must still bring the player home instead of tripping ensure_end().
    this.unknown = this.buffer.length ? this.read_boolean() : false
  }

  process () {
    return returnHome(this.client, this.player)
  }
}

module.exports = GoHomeMessage
