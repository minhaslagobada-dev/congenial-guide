'use strict'
const BattleLogMessage = require('../../Server/Battle/BattleLogMessage')
const { BattleHistory } = require('../../../../Logic/BattleHistory')
const { BSMessageReader } = require('../../../../Utils/Reader')

// 14114 GetBattleLogMessage: sent by the v13 BattleLogPopup (button_battlelog)
// the first time the log is opened in a session (libg 0xd7588; the message
// encode 0x39af48 writes no fields). The client class HomeBattleReplayMessage
// shares the id but carries a replay request (vint + ids); replays are not
// recorded by this server, so a non-empty body is ignored.
class GetBattleLogMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.replayRequest = this._payload_length > 0
  }

  process () {
    if (this.replayRequest) return null
    if (!this.player || !(this.player.low_id > 0)) return null
    const entries = BattleHistory.list(this.player.low_id)
    BattleHistory.mark_requested(this.player, this.client)
    new BattleLogMessage(this.client, this.player, entries, true).send()
    return entries
  }
}

module.exports = GetBattleLogMessage
