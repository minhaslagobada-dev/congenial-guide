'use strict'

const { BSMessageReader } = require('../../../../Utils/Reader')
const { returnHome } = require('./GoHomeFromOfflinePractiseMessage')

// 14108: the return-home variant without payload (libg encode 0x464bfc),
// chosen by the same client sender as 14101/14109.
class GoHomeFromSpectateMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {}

  process () {
    return returnHome(this.client, this.player)
  }
}

module.exports = GoHomeFromSpectateMessage
