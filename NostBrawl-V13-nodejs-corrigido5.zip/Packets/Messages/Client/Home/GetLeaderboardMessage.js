'use strict'

const { LeaderboardService } = require('../../../../Logic/LeaderboardService')
const LeaderboardMessage = require('../../Server/Leaderboard/LeaderboardMessage')
const GetLeaderboardClubGlobalOkMessage = require('../../Server/Leaderboard/TopGlobalClubsDataMessage')
const GetLeaderboardGlobalOkMessage = require('../../Server/Leaderboard/TopGlobalPlayersDataMessage')
const GetLeaderboardClubLocalOkMessage = require('../../Server/Leaderboard/TopLocalClubsDataMessage')
const GetLeaderboardLocalOkMessage = require('../../Server/Leaderboard/TopLocalPlayersDataMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class GetLeaderboardMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.is_local = this.read_boolean()
    this.type = this.read_Vint()
    this.target_brawler = 0
    const reference = this.readScId()
    if (reference[0] === 16) {
      this.target_brawler = reference[1]
    }
  }

  process () {
    if (this.type === 0 || this.type === 1) {
      const brawler = this.type === 0 ? this.target_brawler : null
      const players = LeaderboardService.players(brawler)
      if (this.type === 0) {
        new LeaderboardMessage(
          this.client,
          this.player,
          0,
          this.is_local,
          players,
          this.target_brawler
        ).send()
      } else if (this.is_local) {
        new GetLeaderboardLocalOkMessage(this.client, this.player, players).send()
      } else {
        new GetLeaderboardGlobalOkMessage(this.client, this.player, players).send()
      }
    } else if (this.type === 2) {
      if (this.is_local) {
        new GetLeaderboardClubLocalOkMessage(this.client, this.player, this.type).send()
      } else {
        new GetLeaderboardClubGlobalOkMessage(this.client, this.player, this.type).send()
      }
    }
  }
}

module.exports = GetLeaderboardMessage
