'use strict'

const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

// Shared battle -> lobby transition of the three v13 "return home" messages.
// The client's return sender (libg 0xb3c6c) emits 14109 after offline/practice
// battles, 14108 or 14101 after online ones; every variant waits at the 92%
// loading screen for OwnHomeData, so all of them must settle the same state.
function returnHome (client, player) {
  require('../../../../Logic/Battle/ResultOutbox').ResultOutbox.acknowledge(player)
  // Explicit exit to home: the brawler leaves for good (no reconnection).
  if (player.battleCoordinator) player.battleCoordinator.disconnect(player, client, true)
  if (player.battleTransport) player.battleTransport.release(player, client, 'home')
  const { BattleInstanceService } = require('../../../../Logic/BattleInstances')
  const battle = player.battle_thread !== undefined ? player.battle_thread : null
  if (battle !== null) {
    battle.started = 0
    player.battle_thread = null
  }
  BattleInstanceService.mark_home(player)
  new OwnHomeDataMessage(client, player).send()
  // The lobby keeps showing the gameroom (solo Play also uses a one-member
  // room) and draws each brawler's trophy badge from the last 24124 it got,
  // which was sent before the match. Resend the room with the trophies the
  // server just committed, the same packet a brawler change (14354) answers
  // with, so the badge is current as soon as the menu appears.
  const { GameRoomService } = require('../../../../Logic/GameRoomService')
  const room = GameRoomService.lobby_snapshot(player)
  if (room !== null) require('../../../../Logic/GameRoomGateway').GameRoomGateway.broadcast_data(player, room, client)
  // Battle log: the client asks for the full list once per session, so the
  // battles finished since then are prepended (23458, incremental) now that
  // the lobby is on screen.
  require('../../../../Logic/BattleHistory').BattleHistory.push_pending(player, client)
  return null
}

class GoHomeFromOfflinePractiseMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.unknown = this.read_boolean()
    this.ensure_end()
  }

  process () {
    return returnHome(this.client, this.player)
  }
}

GoHomeFromOfflinePractiseMessage.returnHome = returnHome
module.exports = GoHomeFromOfflinePractiseMessage
