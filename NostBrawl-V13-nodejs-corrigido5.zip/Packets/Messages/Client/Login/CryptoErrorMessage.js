'use strict'
const CryptoError = require('../../Server/Login/CryptoError')
const { BSMessageReader } = require('../../../../Utils/Reader')

class CryptoErrorMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.CryptoError = this.read_int()
  }

  process () {
    new CryptoError(this.client, this.player, this.CryptoError).send()
  }
}

module.exports = CryptoErrorMessage
