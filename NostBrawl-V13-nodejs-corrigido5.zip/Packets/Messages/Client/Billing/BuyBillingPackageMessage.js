'use strict'

const Store = require('../../../../Store')
const { BSMessageReader } = require('../../../../Utils/Reader')

// 10160 — toque num pacote pago da loja (esta build do cliente v13 faz
// billing server-side: o clique vem para o servidor, não para o Google).
// Aqui o clique NUNCA concede gemas: vira um ticket da Lakey Store
// (uso único, 5 min) empurrado ao site por HMAC com o IP da conexão.
class BuyBillingPackageMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
    this.version = 0
    this.sku = ''
  }

  decode () {
    this.version = this.read_int()
    this.sku = this.read_string()
  }

  process () {
    try {
      const store = Store.get()
      if (!store) {
        return
      }
      store.handleShopClick(this.client, this.player, this.sku, 'Billing 10160')
    } catch (error) {
      console.warn('Store | Falha ao registrar intenção de compra:', error.message)
    }
  }
}

module.exports = BuyBillingPackageMessage
