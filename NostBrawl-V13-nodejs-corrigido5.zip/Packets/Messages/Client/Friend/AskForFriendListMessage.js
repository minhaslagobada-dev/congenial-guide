'use strict'
const { FriendService } = require('../../../../Logic/FriendService')
const FriendListMessage = require('../../Server/Friend/FriendListMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AskForFriendListMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.ensure_end()
  }

  process () {
    new FriendListMessage(this.client, this.player).send()
    return FriendService.friends(this.player)
  }
}

module.exports = AskForFriendListMessage
