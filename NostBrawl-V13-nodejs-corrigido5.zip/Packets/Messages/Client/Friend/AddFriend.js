'use strict'
const { FriendService, FriendError } = require('../../../../Logic/FriendService')
const PresenceService = require('../../../../Logic/PresenceService')
const AddFriendFailedMessage = require('../../Server/Friend/Events/AddFriendFailedMessage')
const FriendListUpdateMessage = require('../../Server/Friend/FriendListUpdateMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AddFriend extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.high_id = 0
    this.low_id = 0
    this.source = 0
    this.unknown = 0
  }

  decode () {
    this.high_id = this.read_int()
    this.low_id = this.read_int()
    this.source = this.read_int()
    this.unknown = this.read_int()
    this.ensure_end()
  }

  process () {
    let result
    try {
      if (this.high_id !== 0) {
        throw new FriendError('Conta de amizade inexistente')
      }
      result = FriendService.add(this.player, this.low_id, this.source)
    } catch (error) {
      if (error instanceof FriendError || error instanceof TypeError || error instanceof ValueError) {
        new AddFriendFailedMessage(this.client, this.player).send()
        return { accepted: false, error: String(error.message !== undefined ? error.message : error) }
      }
      throw error
    }
    new FriendListUpdateMessage(
      this.client, this.player, result.entry, false, true
    ).send()
    new FriendListUpdateMessage(
      this.client, this.player, result.reverse_entry, false, true
    ).sendWithLowID(result.friend_id)
    if (result.accepted) {
      PresenceService.sync_pair(this.player, result.friend_id)
    }
    return result
  }
}

module.exports = AddFriend
