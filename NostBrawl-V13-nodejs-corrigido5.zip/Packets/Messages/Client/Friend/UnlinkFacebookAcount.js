'use strict'
const { FriendService, FriendError } = require('../../../../Logic/FriendService')
const FBAccountDisconnectedOKMessage = require('../../Server/Friend/Events/FBAccountDisconnectedOKMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class UnlinkFacebookAcount extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.facebook_id = ''
    this.facebook_token = ''
  }

  decode () {
    this.read_Vint()
    this.facebook_id = this.read_string()
    this.facebook_token = this.read_string()
  }

  process () {
    let progression
    try {
      progression = FriendService.set_facebook(this.player, '', '', false)
    } catch (error) {
      if (error instanceof FriendError || error instanceof TypeError || error instanceof ValueError) {
        return { linked: false, error: String(error.message !== undefined ? error.message : error) }
      }
      throw error
    }
    new FBAccountDisconnectedOKMessage(this.client, this.player).send()
    return { linked: false, progression }
  }
}

module.exports = UnlinkFacebookAcount
