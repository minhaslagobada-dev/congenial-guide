'use strict'
const { FriendService } = require('../../../../Logic/FriendService')
const AddableFriendsMessage = require('../../Server/Friend/AddableFriendsMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AskForAddableFriendsMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.facebook_ids = []
    this.game_center_ids = []
  }

  _read_ids () {
    const count = this.read_int()
    if (count === -1) {
      return []
    }
    if (!(count >= 0 && count <= 10000)) {
      throw new Error('Quantidade de contatos inválida')
    }
    const ids = []
    for (let index = 0; index < count; index++) {
      ids.push(this.read_string())
    }
    return ids
  }

  decode () {
    this.facebook_ids = this._read_ids()
    this.game_center_ids = this._read_ids()
  }

  process () {
    let entries
    try {
      entries = FriendService.addable(
        this.player, this.facebook_ids, this.game_center_ids
      )
    } catch (error) {
      entries = []
    }
    new AddableFriendsMessage(this.client, this.player, entries).send()
    return entries
  }
}

module.exports = AskForAddableFriendsMessage
