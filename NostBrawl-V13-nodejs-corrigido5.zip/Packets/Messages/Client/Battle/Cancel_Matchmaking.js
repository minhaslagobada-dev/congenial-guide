'use strict'
const MatchMakingCancelledMessage = require('../../Server/Battle/MatchMakingCancelledMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class CancelMatchMaking extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
  }

  process () {
    if (this.player.battleCoordinator) return this.player.battleCoordinator.cancel(this.player, this.client)
    new MatchMakingCancelledMessage(this.client, this.player).send()
  }
}

module.exports = CancelMatchMaking
