'use strict'
const { BattleEndService, BattleEndError } = require('../../../../Logic/BattleEnd')
const { BattleInstanceService } = require('../../../../Logic/BattleInstances')
const BattleResultBigGameMessage = require('../../Server/Battle/BattleResultBigGameMessage')
const BattleResultBossFightMessage = require('../../Server/Battle/BattleResultBossFightMessage')
const BattleResultDuoShowdownMessage = require('../../Server/Battle/BattleResultDuoShowdownMessage')
const BattleResultMessage = require('../../Server/Battle/BattleResultMessage')
const BattleResultRoboRumbleMessage = require('../../Server/Battle/BattleResultRoboRumbleMessage')
const BattleResultRoboWarsMessage = require('../../Server/Battle/BattleResultRoboWarsMessage')
const BattleResultShowdownMessage = require('../../Server/Battle/BattleResultShowdownMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AskForBattleEndMessage extends BSMessageReader {
  static get RESULT_MESSAGES () {
    return {
      0: BattleResultMessage,
      1: BattleResultRoboWarsMessage,
      2: BattleResultShowdownMessage,
      3: BattleResultRoboRumbleMessage,
      4: BattleResultBigGameMessage,
      5: BattleResultDuoShowdownMessage,
      6: BattleResultBossFightMessage
    }
  }

  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.initial_bytes = initialBytes
    this.battle = null
  }

  decode () {
    if (this.player.onlineBattle || this.player.authoritativeBattleResult) return
    this.battle = BattleEndService.decode(this, this.initial_bytes)
  }

  process () {
    if (this.player.onlineBattle) {
      const world = this.player.onlineBattle
      if (world.nativeVisionPayload && world.mode.variation === 11 && world.players.some(entry => entry.player === this.player && entry.client === this.client)) world.finish(null, 'abandoned')
      return null
    }
    if (this.player.authoritativeBattleResult) {
      if (!this.player.pendingBattleResultSent) require('../../../../Logic/Battle/ResultOutbox').ResultOutbox.send(this.player, this.client)
      return { authoritative: true }
    }
    if (this.battle === null || this.battle === undefined) {
      throw new BattleEndError('BattleEnd não foi decodificado')
    }
    const currentTime = process.hrtime.bigint()
    const payloadHash = this.battle.battle_id
    const battleId = BattleInstanceService.resolve_result(
      this.player, payloadHash, this.battle.game_mode
    )
    BattleEndService.apply_to_player(this.player, this.battle)
    this.player.battle_end_id = battleId
    const MessageClass = AskForBattleEndMessage.RESULT_MESSAGES[this.battle.game_mode]
    const message = new MessageClass(this.client, this.player)
    message.send()
    this.player.last_battle_end_hash = payloadHash
    this.player.last_battle_instance_id = battleId
    this.player.last_battle_end_time = currentTime
    return {
      gameMode: this.battle.game_mode,
      mapID: this.battle.map_id,
      participants: this.battle.participants.length,
      battleID: battleId
    }
  }
}

module.exports = AskForBattleEndMessage
