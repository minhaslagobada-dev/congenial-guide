'use strict'
const UDPConnectionInfo = require('../../Server/Battle/UDPConnectionInfo')
const { BSMessageReader } = require('../../../../Utils/Reader')

class ClientInfoMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.network = this.read_string()
  }

  process () {
    const transport = this.player.battleTransport
    if (!transport) return false
    transport.attach(this.player, this.client)
    new UDPConnectionInfo(this.client, this.player).send()
    return true
  }
}

module.exports = ClientInfoMessage
