'use strict'
const { decodeInput } = require('../../../../Logic/Battle/Network/V13BattleCodec')

class ClientInputMessage {
  constructor (client, player, initialBytes) {
    this.client = client
    this.player = player
    this.bytes = initialBytes
    this.input = null
  }

  decode () { this.input = decodeInput(this.bytes) }

  process () {
    const transport = this.player.battleTransport
    if (!transport) return false
    const session = this.player.udp_session
    if (!session || session.closed || session.client !== this.client) return false
    return transport.accept(session, this.input)
  }
}

module.exports = ClientInputMessage
