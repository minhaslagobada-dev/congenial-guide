'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError, GameRoomInviteError } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const TeamInvitationMessage = require('../../Server/Gameroom/TeamInvitationMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamInviteMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.high_id = 0
    this.recipient_id = 0
    this.invite_type = 0
  }

  decode () {
    this.high_id = this.read_Vint()
    this.recipient_id = this.read_Vint()
    this.invite_type = this.read_Vint()
    this.ensure_end()
  }

  process () {
    if (this.high_id !== 0) {
      return null
    }
    let room
    let invite
    try {
      ;[room, invite] = GameRoomService.invite(
        this.player, this.recipient_id, this.invite_type
      )
    } catch (error) {
      if (error instanceof GameRoomFullError) {
        new TeamErrorMessage(this.client, this.player, 25).send()
        return null
      }
      if (error instanceof GameRoomInviteError) {
        new TeamErrorMessage(this.client, this.player, error.code).send()
        return null
      }
      throw error
    }
    if (room === null) {
      return null
    }
    GameRoomGateway.broadcast_data(this.player, room, this.client)
    const delivered = new TeamInvitationMessage(
      null, this.player, invite
    ).sendWithLowID(this.recipient_id)
    if (!delivered) {
      ;[room, invite] = GameRoomService.mark_invite(
        this.player, this.recipient_id, GameRoomService.INVITE_OFFLINE
      )
      if (room !== null) {
        GameRoomGateway.broadcast_data(this.player, room, this.client)
      }
      new TeamErrorMessage(
        this.client, this.player, GameRoomInviteError.OFFLINE
      ).send()
      return { room, invite, delivered: false }
    }
    return { room, invite, delivered: true }
  }
}

module.exports = TeamInviteMessage
