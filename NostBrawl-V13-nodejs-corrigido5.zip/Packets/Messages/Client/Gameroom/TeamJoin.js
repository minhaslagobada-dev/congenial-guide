'use strict'
const TeamJoinMessage = require('./TeamJoinMessage')

class TeamJoin extends TeamJoinMessage {
}

module.exports = TeamJoin
