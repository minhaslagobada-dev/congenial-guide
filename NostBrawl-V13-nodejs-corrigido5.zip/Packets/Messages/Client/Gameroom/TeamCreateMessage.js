'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamCreateMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.map_slot = 0
    this.requested_map = 0
    this.room_type = 0
    this.practice = false
    this.has_optional_data = false
    this.optional_text = ''
    this.optional_value = 0
    this.optional_reference = [0, -1]
  }

  decode () {
    this.requested_map = this.read_Vint()
    this.map_slot = this.read_Vint()
    this.room_type = this.read_Vint()
    this.practice = this.read_boolean()
    this.ensure_end()
  }

  process () {
    const [room, previous, departed] = GameRoomService.create_transition(
      this.player, this.map_slot, this.requested_map,
      this.room_type, this.practice
    )
    if (departed) {
      GameRoomGateway.send_left(
        this.player, this.player.low_id, 0, this.client
      )
    }
    if (previous !== null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, previous)
    }
    GameRoomGateway.broadcast_data_and_stream(
      this.player, room, this.client
    )
    GameRoomService.sync_presence(this.player, GameRoomService.TEAM_PRESENCE)
    return room
  }
}

module.exports = TeamCreateMessage
