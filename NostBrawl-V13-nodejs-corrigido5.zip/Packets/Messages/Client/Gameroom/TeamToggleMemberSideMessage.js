'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamToggleMemberSideMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.targets = []
    this.team = 0
  }

  decode () {
    const count = this.read_Vint()
    if (!(count >= 0 && count <= 10)) {
      throw new Error('Quantidade de membros inválida')
    }
    this.targets = []
    for (let index = 0; index < count; index++) {
      this.targets.push(this.readLogicLong())
    }
    this.team = this.read_Vint()
    this.ensure_end()
  }

  process () {
    const room = GameRoomService.set_teams(this.player, this.targets, this.team)
    if (room !== null) {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
    }
    return room
  }
}

module.exports = TeamToggleMemberSideMessage
