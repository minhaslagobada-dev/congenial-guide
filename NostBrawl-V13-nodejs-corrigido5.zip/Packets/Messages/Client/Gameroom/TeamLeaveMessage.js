'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const TeamLeftMessage = require('../../Server/Gameroom/TeamLeftMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamLeaveMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
  }

  decode () {
    this.ensure_end()
  }

  process () {
    const outcome = GameRoomService.leave_transition(this.player)
    const room = outcome.room
    if (room !== null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, room)
    }
    if (outcome.departed) {
      new TeamLeftMessage(this.client, this.player).send()
    }
    for (const member of outcome.disbanded) {
      GameRoomGateway.send_left(
        this.player,
        Math.trunc(member.low_id),
        GameRoomService.DISBAND_REASON
      )
    }
    if (outcome.departed) {
      GameRoomService.sync_presence(
        this.player, GameRoomService.HOME_PRESENCE
      )
    }
    for (const member of outcome.disbanded) {
      const participant = member._player !== undefined ? member._player : null
      if (participant !== null) {
        GameRoomService.sync_presence(
          participant, GameRoomService.HOME_PRESENCE
        )
      }
    }
    return room
  }
}

module.exports = TeamLeaveMessage
