'use strict'
const DataBase = require('../../../../Database/DatabaseManager')
const Skins = require('../../../../Files/CsvLogic/Skins')
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

function deepCopy (value) {
  if (value === null || value === undefined) return value
  return JSON.parse(JSON.stringify(value))
}

class TeamChangeMemberSettingsMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.brawler_reference = [0, -1]
    this.skin_reference = [0, -1]
    this.unknown = 0
  }

  decode () {
    this.unknown = this.read_Vint()
    this.skin_reference = this.readScId()
    this.ensure_end()
  }

  process () {
    const [, skinId] = this.skin_reference
    const brawlerId = Skins.getBrawler(skinId)
    this.brawler_reference = [16, Math.trunc(brawlerId)]
    this.player.brawler_id = Math.trunc(brawlerId)
    this.player.skin_id = Math.trunc(skinId)
    let selected = deepCopy(this.player.brawlers_skins)
    if (typeof selected !== 'object' || selected === null) {
      selected = {}
    }
    selected[String(this.player.brawler_id)] = this.player.skin_id
    this.player.brawlers_skins = selected
    DataBase.replaceValue(this, 'skinID', this.player.skin_id)
    DataBase.replaceValue(this, 'brawlerID', this.player.brawler_id)
    DataBase.replaceValue(this, 'brawlersSkins', selected)
    let room = GameRoomService.set_member_settings(
      this.player, this.player.brawler_id, this.player.skin_id
    )
    if (room === null) {
      return room
    }
    room = this._revalidate(room)
    GameRoomGateway.broadcast_data(this.player, room, this.client)
    return room
  }

  // A brawler change after PRONTO re-checks the team: a repeated brawler on
  // the same side invalidates the ready of the member who changed (and any
  // running team search, which the matchmaker cancels for the whole ticket
  // with 20406); otherwise a queued search keeps going with the new brawler.
  _revalidate (room) {
    const coordinator = this.player.battleCoordinator
    const ticket = coordinator && coordinator.matchmaker ? coordinator.matchmaker.players.get(this.player.low_id) : null
    const queued = ticket && ticket.state === 'queued' && ticket.roomId === room.id ? ticket : null
    if (GameRoomService.has_duplicate_brawler(this.player)) {
      const self = room.members.find((member) => member.low_id === this.player.low_id)
      if (queued) coordinator.matchmaker.cancel(this.player, this.client, 'revalidate')
      if (queued || (self && self.ready)) {
        new TeamErrorMessage(this.client, this.player, 17).send()
        const fresh = GameRoomService.set_ready(this.player, false)
        if (fresh) room = fresh
      }
      return room
    }
    if (queued) {
      const entry = queued.members.find((member) => member.player === this.player)
      if (entry) {
        entry.brawlerId = this.player.brawler_id
        entry.skinId = this.player.skin_id || 0
        entry.powerLevel = Math.max(0, Math.min(9, Number((this.player.Brawler_level || {})[this.player.brawler_id]) || 0))
      }
    }
    return room
  }
}

module.exports = TeamChangeMemberSettingsMessage
