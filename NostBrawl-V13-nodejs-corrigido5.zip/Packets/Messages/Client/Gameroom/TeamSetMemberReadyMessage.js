'use strict'
const { BattleInstanceService } = require('../../../../Logic/BattleInstances')
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const MatchMakingCancelledMessage = require('../../Server/Battle/MatchMakingCancelledMessage')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamSetMemberReadyMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.ready = false
    this.unknown = 0
  }

  decode () {
    this.ready = this.read_boolean()
    this.unknown = this.read_Vint()
    this.ensure_end()
  }

  // Original refusal for a repeated brawler: TeamErrorMessage 24129 with
  // code 17, shown by the v13 client as TID_TEAM_ERROR_17 ("Cannot start
  // game. Duplicate Brawlers are not allowed."). The player stays in the
  // room, un-ready, and every member sees the refreshed ready flags.
  _refuse_duplicate () {
    new TeamErrorMessage(this.client, this.player, 17).send()
    const fresh = GameRoomService.set_ready(this.player, false)
    if (fresh) GameRoomGateway.broadcast_data(this.player, fresh, this.client)
    return fresh
  }

  process () {
    if (this.ready && GameRoomService.has_duplicate_brawler(this.player)) {
      return this._refuse_duplicate()
    }
    const room = GameRoomService.set_ready(this.player, this.ready)
    if (room === null) {
      return null
    }
    if (this.player.battleCoordinator) {
      const coordinator = this.player.battleCoordinator
      GameRoomGateway.broadcast_data(this.player, room, this.client)
      if (!this.ready) {
        coordinator.cancel(this.player, this.client)
        return room
      }
      try {
        coordinator.readyRoom(this.player, room)
      } catch (error) {
        if (error && error.teamError === 17) {
          // Another member's brawler changed in the meantime: same native
          // warning; no search starts and nobody is disconnected.
          return this._refuse_duplicate()
        }
        // A refused team search is a lobby state, not a broken connection:
        // clear the ready flags, tell every member, keep everyone online.
        coordinator.refuse(this.player, this.client, room, error)
        const fresh = GameRoomService.set_ready(this.player, false)
        if (fresh) GameRoomGateway.broadcast_data(this.player, fresh, this.client)
        return fresh
      }
      return room
    }
    if (this.ready) {
      BattleInstanceService.begin(this.player)
    }
    GameRoomGateway.broadcast_data(this.player, room, this.client)
    if (this.ready) {
      this.player.map_id = 15
      this.player.mmplayers = 1
      new MatchMakingCancelledMessage(this.client, this.player).send()
    }
    return room
  }
}

module.exports = TeamSetMemberReadyMessage
