'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamSetRankedLocationMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.map_id = 0
    this.slot = 0
  }

  decode () {
    this.map_id = this.read_Vint()
    this.slot = this.read_Vint()
    this.ensure_end()
  }

  process () {
    const room = GameRoomService.set_ranked_location(
      this.player, this.map_id, this.slot
    )
    if (room !== null) {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
    }
    return room
  }
}

module.exports = TeamSetRankedLocationMessage
