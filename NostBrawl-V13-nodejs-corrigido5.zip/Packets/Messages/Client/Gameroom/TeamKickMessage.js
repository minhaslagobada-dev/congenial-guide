'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamKickMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.target_high_id = 0
    this.target_id = 0
  }

  decode () {
    this.target_high_id = this.read_Vint()
    this.target_id = this.read_Vint()
    this.ensure_end()
  }

  process () {
    if (this.target_high_id !== 0) {
      return null
    }
    const outcome = GameRoomService.kick_transition(this.player, this.target_id)
    const room = outcome.room
    const targetId = outcome.target_id
    if (!targetId) {
      return null
    }
    if (room !== null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, room)
    }
    GameRoomGateway.send_leave_ok(this.player, targetId)
    const target = outcome.target
    if (target !== null) {
      GameRoomService.sync_presence(target, GameRoomService.HOME_PRESENCE)
    }
    return room
  }
}

module.exports = TeamKickMessage
