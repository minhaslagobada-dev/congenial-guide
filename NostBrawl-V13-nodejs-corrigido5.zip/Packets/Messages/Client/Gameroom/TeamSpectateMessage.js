'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamCode = require('../../../../Logic/TeamCode')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamSpectateMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.map_slot = 0
    this.room_id = 0
    this.requested_map = 0
  }

  // v13 join-by-code (client 0x3088f8): the typed code is converted locally
  // (first character skipped) into a LogicLong and sent as vint high,
  // vint low, vint 1. The room is the low part; high is always 0 for the
  // codes this server hands out.
  decode () {
    this.high_id = this.read_Vint()
    this.room_id = this.read_Vint()
    this.requested_map = this.read_Vint()
    this.map_slot = this.high_id
    this.ensure_end()
  }

  process () {
    let room = null
    let previous = null
    let departed = false
    let candidates
    try {
      candidates = TeamCode.join_candidates(this.high_id, this.room_id)
    } catch (error) {
      candidates = null
    }
    if (!candidates || !candidates.length) {
      // TID_TEAM_ERROR_5: invalid team code.
      new TeamErrorMessage(this.client, this.player, 5).send()
      return null
    }
    for (const roomId of candidates) {
      try {
        ;[room, previous, departed] = GameRoomService.request_join_transition(
          this.player, roomId
        )
      } catch (error) {
        if (error instanceof GameRoomFullError) {
          new TeamErrorMessage(this.client, this.player, 2).send()
          return null
        }
        throw error
      }
      if (room !== null) break
    }
    if (room === null) {
      new TeamErrorMessage(this.client, this.player, 6).send()
      return null
    }
    if (departed) {
      GameRoomGateway.send_left(
        this.player, this.player.low_id, 0, this.client
      )
    }
    if (previous !== null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, previous)
    }
    GameRoomGateway.broadcast_data_and_stream(
      this.player, room, this.client
    )
    GameRoomService.sync_presence(this.player, GameRoomService.TEAM_PRESENCE)
    return room
  }
}

module.exports = TeamSpectateMessage
