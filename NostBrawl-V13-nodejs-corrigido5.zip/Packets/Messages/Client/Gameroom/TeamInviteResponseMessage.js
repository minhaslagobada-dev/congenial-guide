'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamInviteResponseMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.room_id = 0
    this.accepted = 0
  }

  decode () {
    this.room_id = this.read_Vint()
    this.accepted = this.read_Vint()
    this.ensure_end()
  }

  process () {
    const accepted = this.accepted === 1
    let previous = accepted ? GameRoomService.for_player(this.player) : null
    const operation = accepted
      ? GameRoomService.accept_invite
      : GameRoomService.clear_invite
    let room
    let invite
    try {
      ;[room, invite] = operation(this.player, this.room_id)
    } catch (error) {
      if (error instanceof GameRoomFullError) {
        new TeamErrorMessage(this.client, this.player, 2).send()
        return null
      }
      throw error
    }
    if (room === null) {
      return null
    }
    if (accepted) {
      if (previous !== null && previous.id !== room.id) {
        GameRoomGateway.send_left(
          this.player, this.player.low_id, 0, this.client
        )
        previous = GameRoomService.get(previous.id)
        if (previous !== null) {
          GameRoomGateway.broadcast_data_and_stream(
            this.player, previous
          )
        }
      }
      GameRoomGateway.broadcast_data_and_stream(
        this.player, room, this.client
      )
    } else {
      GameRoomGateway.broadcast_data(this.player, room)
    }
    return { room, invite, accepted }
  }
}

module.exports = TeamInviteResponseMessage
