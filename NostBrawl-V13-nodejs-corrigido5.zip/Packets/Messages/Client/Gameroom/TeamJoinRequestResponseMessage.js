'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamJoinRequestResponseMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.request_high_id = 0
    this.request_id = 0
    this.accepted = false
    this.mute_requester = false
  }

  decode () {
    this.request_high_id = this.read_int()
    this.request_id = this.read_int()
    this.accepted = this.read_boolean()
    this.mute_requester = this.read_boolean()
    this.ensure_end()
  }

  process () {
    if (this.request_high_id !== 0) {
      return null
    }
    let outcome
    try {
      outcome = GameRoomService.respond_join_request(
        this.player,
        this.request_id,
        this.accepted,
        this.mute_requester
      )
    } catch (error) {
      if (error instanceof GameRoomFullError) {
        new TeamErrorMessage(this.client, this.player, 2).send()
        return null
      }
      throw error
    }
    if (outcome === null) {
      return null
    }
    const room = outcome.room
    if (room === null) {
      return outcome
    }
    if (outcome.accepted) {
      const previous = outcome.previous
      if (previous !== null) {
        GameRoomGateway.send_left(
          this.player,
          Math.trunc(outcome.request.requester_id)
        )
        GameRoomGateway.broadcast_data(this.player, previous)
      }
      GameRoomGateway.broadcast_data_and_stream(
        this.player, room, this.client
      )
      const requesterId = Math.trunc(outcome.request.requester_id)
      let requester = null
      for (const member of room.members || []) {
        if (Math.trunc(member.low_id) === requesterId) {
          requester = member._player !== undefined ? member._player : null
          break
        }
      }
      if (requester !== null) {
        GameRoomService.sync_presence(
          requester, GameRoomService.TEAM_PRESENCE
        )
      }
    } else {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
    }
    return outcome
  }
}

module.exports = TeamJoinRequestResponseMessage
