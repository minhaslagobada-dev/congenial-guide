'use strict'
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AskForAllianceDataMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.clubHighID = this.read_int()
    this.clubLowID = this.read_int()
    this.hasAdditionalID = this.read_boolean()
    this.additionalHighID = 0
    this.additionalLowID = 0
    if (this.hasAdditionalID) {
      this.additionalHighID = this.read_int()
      this.additionalLowID = this.read_int()
    }
  }

  process () {
    new AllianceDataMessage(this.client, this.player, this.clubHighID, this.clubLowID).send()
  }
}

module.exports = AskForAllianceDataMessage
