'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const { FriendService } = require('../../../../Logic/FriendService')
const PresenceService = require('../../../../Logic/PresenceService')
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const AllianceChatServerMessage = require('../../Server/Alliance/Alliance_Chat_Server_Message')
const AllianceKickMemberOK = require('../../Server/Alliance/Events/KickMemberOK')
const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Kick_Member_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.highID = this.read_int()
    this.lowID = this.read_int()
    this.reason = this.read_string()
  }

  process () {
    let club
    let entry
    let targetId
    try {
      if (this.highID !== 0) {
        throw new ClubError('Conta não encontrada')
      }
      ;[club, entry, targetId] = ClubService.kick(this.player, this.lowID)
    } catch (error) {
      if (error instanceof ClubError) {
        return String(error.message)
      }
      throw error
    }
    new AllianceKickMemberOK(this.client, this.player).send()
    new MyAllianceMessage(this.client, this.player, club.id).send()
    const target = ClubService.refresh_online_player(this.player, targetId)
    if (target !== null && target !== undefined) {
      new MyAllianceMessage(null, target, 0).sendWithLowID(targetId)
    }
    FriendService.push_account(this.player, targetId)
    for (const memberId of club.member_ids) {
      new AllianceDataMessage(
        this.client, this.player, 0, club.id, true
      ).sendWithLowID(memberId)
      new AllianceChatServerMessage(
        this.client, this.player, 1, club.id, false, entry
      ).sendWithLowID(memberId)
    }
    for (const memberId of club.member_ids) {
      PresenceService.sync_subject(this.player, targetId, memberId)
      PresenceService.sync_subject(this.player, memberId, targetId)
    }
    return club
  }
}

module.exports = Kick_Member_Message
