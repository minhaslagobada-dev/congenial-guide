'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const { FriendService } = require('../../../../Logic/FriendService')
const PresenceService = require('../../../../Logic/PresenceService')
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
const AllianceChatServerMessage = require('../../Server/Alliance/Alliance_Chat_Server_Message')
const AllianceJoinOkMessage = require('../../Server/Alliance/Events/AllianceJoinOkMessage')
const AllianceJoinFail = require('../../Server/Alliance/Events/JoinFail')
const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Join_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.club_high_id = this.read_int()
    this.clubID = this.read_int()
  }

  process () {
    let club
    let entry
    try {
      if (this.club_high_id !== 0) {
        throw new ClubError('Clube não encontrado')
      }
      ;[club, entry] = ClubService.join(this.player, this.clubID)
    } catch (error) {
      if (error instanceof ClubError) {
        new AllianceJoinFail(this.client, this.player).send()
        return String(error.message)
      }
      throw error
    }
    new AllianceJoinOkMessage(this.client, this.player).send()
    new MyAllianceMessage(this.client, this.player, club.id).send()
    new AllianceStreamMessage(this.client, this.player, club.id, 0).send()
    new AllianceDataMessage(this.client, this.player, 0, club.id).send()
    for (const memberId of club.member_ids) {
      if (memberId !== this.player.low_id) {
        new AllianceDataMessage(this.client, this.player, 0, club.id, true).sendWithLowID(memberId)
      }
      new AllianceChatServerMessage(
        this.client, this.player, 3, club.id, false, entry
      ).sendWithLowID(memberId)
    }
    FriendService.push_presence(this.player)
    for (const memberId of club.member_ids) {
      if (memberId !== this.player.low_id) {
        PresenceService.sync_pair(this.player, memberId)
      }
    }
    return club
  }
}

module.exports = Join_Message
