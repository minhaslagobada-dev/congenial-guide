'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const { FriendService } = require('../../../../Logic/FriendService')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const AllianceCreateOkMessage = require('../../Server/Alliance/Events/AllianceCreateOkMessage')
const AllianceJoinFail = require('../../Server/Alliance/Events/JoinFail')
const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
const Helpers = require('../../../../Utils/Helpers')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Create_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.clubHighID = 0
    this.clubLowID = Helpers.randomClubID(this)
    this.RegionIdentifier = 0
    this.clubregionID = 0
    this.clubfriendlyfamily = 0
    this.clubName = this.read_string()
    this.clubdescription = this.read_string()
    this.BadgeIdentifier = this.read_Vint()
    this.clubbadgeID = this.read_Vint()
    this.clubtype = this.read_Vint()
    this.clubtrophiesneeded = this.read_Vint()
  }

  process () {
    let club
    try {
      ;[club] = ClubService.create(
        this.player,
        this.clubLowID,
        this.clubName,
        this.clubdescription,
        this.clubbadgeID,
        this.clubtype,
        this.clubtrophiesneeded,
        this.clubfriendlyfamily
      )
    } catch (error) {
      if (error instanceof ClubError) {
        new AllianceJoinFail(this.client, this.player).send()
        return String(error.message)
      }
      throw error
    }
    new AllianceCreateOkMessage(this.client, this.player).send()
    new MyAllianceMessage(this.client, this.player, club.id).send()
    new AllianceStreamMessage(this.client, this.player, club.id, 0).send()
    new AllianceDataMessage(this.client, this.player, 0, club.id).send()
    FriendService.push_presence(this.player)
    return club
  }
}

module.exports = Create_Message
