'use strict'
const JoinableAllianceListMessage = require('../../Server/Alliance/JoinableAllianceListMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Ask_Joinable_Alliances_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
  }

  process () {
    new JoinableAllianceListMessage(this.client, this.player).send()
  }
}

module.exports = Ask_Joinable_Alliances_Message
