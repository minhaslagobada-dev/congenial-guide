'use strict'

const Writer = require('../../../Utils/Writer')

class OutOfSyncMessage extends Writer {
  constructor (client, player, message) {
    super(client)
    this.id = 24104
    this.player = player
    this.msg = message
  }

  encode () {
    this.writeInt(0)
  }
}

module.exports = OutOfSyncMessage
