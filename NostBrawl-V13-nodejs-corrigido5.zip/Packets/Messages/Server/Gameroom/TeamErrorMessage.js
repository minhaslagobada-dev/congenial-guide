'use strict'
const Writer = require('../../../../Utils/Writer')

class TeamErrorMessage extends Writer {
  constructor (client, player, error, detail = 0) {
    super(client)
    this.enable_native_v13()
    this.id = 24129
    this.player = player
    this.error = Math.trunc(error)
    this.detail = Math.trunc(detail)
  }

  encode () {
    this.writeVint(this.detail)
    this.writeVint(this.error)
  }
}

module.exports = TeamErrorMessage
