'use strict'
const Writer = require('../../../../Utils/Writer')

class TeamLeftMessage extends Writer {
  constructor (client, player, reason = 0) {
    super(client)
    this.enable_native_v13()
    this.id = 24125
    this.player = player
    this.reason = Math.trunc(reason)
  }

  encode () {
    this.writeInt(this.reason)
  }
}

module.exports = TeamLeftMessage
