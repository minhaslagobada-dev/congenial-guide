'use strict'
const Writer = require('../../../../Utils/Writer')

class TeamGameStartingMessage extends Writer {
  constructor (client, player, room) {
    super(client)
    this.enable_native_v13()
    this.id = 24130
    this.player = player
    this.room = room
  }

  encode () {
    this.writeVint(0)
    this.writeVint(0)
    this.writeScId(15, this.room.map_id)
  }
}

module.exports = TeamGameStartingMessage
