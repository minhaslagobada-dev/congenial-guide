'use strict'
const Writer = require('../../../../Utils/Writer')

class SetInvitesBlockedOkMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.enable_native_v13()
    this.id = 24111
    this.player = player
  }

  encode () {
    this.writeVint(213)
    this.writeBoolean(Math.trunc(this.player.do_not_distrub || 0) === 1)
  }
}

module.exports = SetInvitesBlockedOkMessage
