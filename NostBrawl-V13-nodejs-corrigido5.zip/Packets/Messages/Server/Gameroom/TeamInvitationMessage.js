'use strict'
const { encode_friend_entry } = require('../../../../Logic/FriendPayload')
const Writer = require('../../../../Utils/Writer')

class TeamInvitationMessage extends Writer {
  static get INVITE_NOTIFICATION () { return 1 }

  constructor (client, player, invite) {
    super(client)
    this.enable_native_v13()
    this.id = 24589
    this.player = player
    this.invite = invite
  }

  encode () {
    const entry = this.invite.entry !== undefined ? this.invite.entry : null
    if (entry === null || entry === undefined) {
      throw new Error('Convite sem perfil real do remetente')
    }
    this.writeVint(TeamInvitationMessage.INVITE_NOTIFICATION)
    this.writeLong(0, Math.trunc(this.invite.sender_id))
    encode_friend_entry(this, entry)
  }
}

module.exports = TeamInvitationMessage
