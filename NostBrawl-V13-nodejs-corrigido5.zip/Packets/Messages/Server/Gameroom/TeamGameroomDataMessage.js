'use strict'
const { encode_friend_entry } = require('../../../../Logic/FriendPayload')
const Writer = require('../../../../Utils/Writer')

class TeamGameroomDataMessage extends Writer {
  constructor (client, player, room = null) {
    super(client)
    this.enable_native_v13()
    this.id = 24124
    this.player = player
    this.room = room
  }

  encode () {
    let room = this.room
    if (room === null || room === undefined) {
      const { GameRoomService } = require('../../../../Logic/GameRoomService')
      room = GameRoomService.for_player(this.player)
    }
    if (room === null || room === undefined) {
      room = {
        id: 0, type: 0, slot_index: 0, map_id: 0,
        practice: false, capacity: 0, advertise_band: false,
        advertise_friends: false, members: [], invites: [],
        join_requests: []
      }
    }
    this.writeVint(room.type)
    this.writeBoolean(room.practice)
    this.writeVint(room.capacity !== undefined ? room.capacity : 0)
    this.writeLong(0, room.id)
    this.writeVint(1)
    this.writeBoolean(room.advertise_band || false)
    this.writeBoolean(room.advertise_friends || false)
    this.writeVint(0)
    this.writeVint(room.slot_index)
    this.writeScId(15, room.map_id)
    const members = room.members
    this.writeVint(members.length)
    for (const member of members) {
      this.writeBoolean(member.host)
      this.writeLong(member.high_id, member.low_id)
      this.writeString(member.name)
      this.writeVint(0)
      this.writeScId(16, member.brawler_id)
      this.writeScId(29, member.skin_id)
      this.writeVint(member.trophies)
      this.writeVint(member.highest_trophies)
      this.writeVint(member.power_level + 1)
      this.writeVint(member.status)
      this.writeBoolean(member.ready)
      this.writeVint(member.team)
      this.writeVint(0)
    }
    const invites = room.invites || []
    this.writeVint(invites.length)
    for (const invite of invites) {
      this.writeLong(0, invite.sender_id)
      this.writeLong(0, invite.recipient_id)
      this.writeString(invite.name)
      this.writeVint(invite.invite_type)
      this.writeVint(invite.status)
    }
    const requests = room.join_requests || []
    this.writeVint(requests.length)
    for (const request of requests) {
      this.writeLong(request.key_high_id !== undefined ? request.key_high_id : 0, request.key)
      this.writeLong(
        request.recipient_high_id !== undefined ? request.recipient_high_id : 0,
        request.recipient_id
      )
      encode_friend_entry(this, request.entry)
    }
  }
}

module.exports = TeamGameroomDataMessage
