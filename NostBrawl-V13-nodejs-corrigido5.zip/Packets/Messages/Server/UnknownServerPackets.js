'use strict'

const Writer = require('../../../Utils/Writer')

class UnknownServerPackets extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24131
    this.player = player
  }

  encode () {
    this.writeVint(2)
    this.writeVint(0)
    this.writeVint(1)
    this.writeVint(1)
    this.writeVint(1)
    this.writeString('Gaby')
    this.writeVint(1)
    this.writeVint(0)
    this.writeString('Hey')
  }
}

module.exports = UnknownServerPackets
