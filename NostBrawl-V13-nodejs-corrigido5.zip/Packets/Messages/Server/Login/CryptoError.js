'use strict'
const Writer = require('../../../../Utils/Writer')

class CryptoError extends Writer {
  constructor (client, player, CryptoErrorCode) {
    super(client)
    this.id = 29997
    this.client = client
    this.player = player
    this.CryptoError = CryptoErrorCode
  }

  encode () {
    this.writeVint(this.CryptoError)
  }
}

module.exports = CryptoError
