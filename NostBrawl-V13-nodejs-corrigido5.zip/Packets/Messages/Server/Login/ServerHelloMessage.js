'use strict'
const crypto = require('crypto')
const Writer = require('../../../../Utils/Writer')

class ServerHelloMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 20100
    this.player = player
  }

  encode () {
    const sessionValue = crypto.randomBytes(11)
    this.player.server_hello_value = sessionValue
    this.writeInt(sessionValue.length + ServerHelloMessage.SUFFIX.length)
    this.writeBytes(sessionValue)
    this.writeBytes(ServerHelloMessage.SUFFIX)
  }
}

ServerHelloMessage.SUFFIX = Buffer.from('00446f6e277420747279203a29', 'hex')

module.exports = ServerHelloMessage
