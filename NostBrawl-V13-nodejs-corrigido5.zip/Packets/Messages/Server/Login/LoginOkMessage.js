'use strict'

const Config = require('../../../../Utils/Config')
const Writer = require('../../../../Utils/Writer')

class LoginOkMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.player = player
    this.id = 20104
    this.version = 1
    this.enable_native_v13()
  }

  encode () {
    const settings = Config.GetValue()

    this.writeInt(this.player.high_id)
    this.writeInt(this.player.low_id)

    this.writeInt(this.player.high_id)
    this.writeInt(this.player.low_id)

    this.writeString(this.player.token)
    this.writeString()
    this.writeString()

    this.writeInt(settings.ClientMajor)
    this.writeInt(settings.ClientMinor)
    this.writeInt(settings.ClientBuild)

    this.writeString('dev')

    this.writeInt(0)
    this.writeInt(0)
    this.writeInt(0)

    this.writeString()
    this.writeString()
    this.writeString()
    this.writeInt(0)
    this.writeString()

    this.writeString(this.player.region !== undefined ? this.player.region : (settings.Region !== undefined ? settings.Region : 'BR'))
    this.writeString()
    this.writeInt(1)

    this.writeString()
    this.writeString()
    this.writeString()
    this.writeVint(0)
    const scidToken = this.player.scid_token !== undefined ? this.player.scid_token : null
    if (scidToken) {
      this.writeCompressedString(scidToken)
    } else {
      this.writeInt(-1)
    }
    this.writeBoolean(true)
    this.writeBoolean(false)
  }
}

module.exports = LoginOkMessage
