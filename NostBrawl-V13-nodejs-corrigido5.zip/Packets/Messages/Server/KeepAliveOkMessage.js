'use strict'
const Writer = require('../../../Utils/Writer')

class KeepAliveOkMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 20108
    this.player = player
  }

  encode () {
    return
  }
}

module.exports = KeepAliveOkMessage
