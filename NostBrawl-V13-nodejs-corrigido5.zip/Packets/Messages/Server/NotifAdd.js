'use strict'

const NotificationFactory = require('../../../Logic/NotificationFactory')
const Writer = require('../../../Utils/Writer')

class LogicAddNotificationCommand extends Writer {
  constructor (client, player, msg, notification = null) {
    super(client)
    this.id = 24111
    this.player = player
    this.msg = msg
    this.notification = notification
  }

  encode () {
    let notification = this.notification
    if (notification === null || notification === undefined) {
      const clubId = Math.trunc((this.player.club_low_id || 0) || 0)
      const { ClubService } = require('../../../Logic/ClubService')
      const notifications = clubId ? ClubService.get_notifications(clubId, 1) : []
      notification = notifications.length ? notifications[notifications.length - 1] : null
    }
    this.writeVint(206)
    if (notification !== null && notification !== undefined) {
      this.writeVint(1)
      const notificationType = Math.trunc(Number(notification.Type || 0) || 0)
      if (notificationType === NotificationFactory.SKIN_REWARD_TYPE) {
        this.writeVint(NotificationFactory.SKIN_REWARD_TYPE)
        this.writeVint(
          NotificationFactory.SKIN_GLOBAL_ID +
          NotificationFactory._skin_id(notification)
        )
        return
      }
      if (notificationType === 99) {
        this.writeVint(99)
        NotificationFactory.encode_season(this, notification)
        return
      }
      this.writeVint(82)
      this.writeInt(0)
      this.writeByte(0)
      this.writeInt(0)
      this.writeString(notification.text)
      this.writeString(String(this.player.name !== undefined ? this.player.name : '') || '')
      const nameColor = Math.trunc(Number(this.player.name_color || 0) || 0)
      const profileIcon = Math.trunc(Number(this.player.profile_icon || 0) || 0)
      this.writeVint(43000000 + nameColor)
      this.writeVint(28000000 + profileIcon)
      this.writeVint(43000000 + nameColor)
    }
  }
}

module.exports = { LogicAddNotificationCommand }
