'use strict'
const Writer = require('../../../../../Utils/Writer')

class AllianceRoleChangedOKMessage extends Writer {
  constructor (client, player, type) {
    super(client)
    this.id = 24333
    this.version = 11
    this.player = player
    this.type = type
  }

  encode () {
    if (this.type === 0) {
      this.writeVint(81)
    } else if (this.type === 1) {
      this.writeVint(82)
    }
  }
}

module.exports = AllianceRoleChangedOKMessage
