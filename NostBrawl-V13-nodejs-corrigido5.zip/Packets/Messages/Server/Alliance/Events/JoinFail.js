'use strict'
const Writer = require('../../../../../Utils/Writer')

class AllianceJoinFail extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24333
    this.version = 11
    this.player = player
  }

  encode () {
    this.writeVint(42)
  }
}

module.exports = AllianceJoinFail
