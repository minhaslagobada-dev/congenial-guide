'use strict'
const Writer = require('../../../../../Utils/Writer')

class AllianceMailWindow extends Writer {
  constructor (client, player, data) {
    super(client)
    this.id = 24333
    this.version = 11
    this.player = player
    this.data = data
  }

  encode () {
    this.writeVint(this.data)
  }
}

module.exports = AllianceMailWindow
