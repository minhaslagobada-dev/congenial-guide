'use strict'

const ClubService = require('../../../../Logic/ClubService').ClubService
const Writer = require('../../../../Utils/Writer')

class AllianceDataMessage extends Writer {
  constructor (client, player, clubHighID, clubLowID, memberOverride = null) {
    super(client)
    this.enable_native_v13()
    this.id = 24301
    this.version = 11
    this.player = player
    this.clubHighID = clubHighID
    this.clubLowID = clubLowID
    this.member_override = memberOverride
  }

  _can_deliver (lowId) {
    if (this.member_override === true) {
      return ClubService.is_member(lowId, this.clubLowID)
    }
    return true
  }

  encode () {
    const club = ClubService.get_club(this.clubLowID, this.player) || {
      id: this.clubLowID,
      name: '',
      description: '',
      region: '',
      badge_id: 0,
      type: 0,
      required_trophies: 0,
      members: [],
      member_count: 0,
      trophies: 0
    }
    const isMember = this.member_override === null
      ? Math.trunc((this.player.club_low_id || 0)) === Math.trunc(this.clubLowID)
      : this.member_override
    this.writeBoolean(Boolean(isMember))
    this.writeInt(0)
    this.writeInt(club.id)
    this.writeString(club.name)
    this.writeVint(8)
    this.writeVint(club.badge_id)
    this.writeVint(club.type)
    this.writeVint(club.member_count)
    this.writeVint(club.trophies)
    this.writeVint(club.required_trophies)
    this.writeVint(0)
    this.writeVint(club.online_count !== undefined ? club.online_count : 0)
    this.writeString(club.description)
    this.writeVint(club.member_count)
    for (const member of club.members) {
      this.writeInt(0)
      this.writeInt(member.low_id)
      this.writeString(member.name)
      this.writeVint(member.role)
      this.writeVint(member.trophies)
      this.writeVint(member.trophies)
      this.writeVint(member.status)
      this.writeVint(member.last_seen_seconds)
      this.writeScId(28, member.profile_icon)
    }
  }
}

module.exports = AllianceDataMessage
