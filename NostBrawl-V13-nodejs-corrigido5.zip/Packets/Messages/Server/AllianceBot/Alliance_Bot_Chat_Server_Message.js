'use strict'

const { ClubService } = require('../../../../Logic/ClubService')
const Writer = require('../../../../Utils/Writer')

class AllianceBotChatServerMessage extends Writer {
  constructor (client, player, botMsgContent) {
    super(client)
    this.bot_msg_content = botMsgContent
    this.id = 24312
    this.version = 11
    this.player = player
  }

  encode () {
    const clubId = Math.trunc(this.player.club_low_id || 0)
    const messageCount = clubId ? ClubService.get_messages(clubId).length : 0
    this.writeVint(2)
    this.writeVint(0)
    this.writeVint(messageCount)
    this.writeVint(1)
    this.writeVint(1)
    this.writeString('Club Bot')
    this.writeVint(3)
    this.writeVint(0)
    this.writeVint(0)
    this.writeString(this.bot_msg_content)
  }
}

module.exports = AllianceBotChatServerMessage
