'use strict'

const Writer = require('../../../../Utils/Writer')

class BotProfileMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24113
    this.player = player
  }

  encode () {
    this.writeVint(1)
    this.writeVint(1)

    this.writeBoolean(false)

    this.writeVint(this.player.brawlers_id.length)

    for (const brawlerId of this.player.brawlers_id) {
      this.writeScId(16, brawlerId)
      this.writeVint(0)
      this.writeVint(99999)
      this.writeVint(99999)
      this.writeVint(10)
    }

    this.writeVint(15)

    this.writeVint(1)
    this.writeVint(99999)

    this.writeVint(2)
    this.writeVint(1262469)

    this.writeVint(3)
    this.writeVint(this.player.trophies)

    this.writeVint(4)
    this.writeVint(this.player.trophies)

    this.writeVint(5)
    this.writeVint(this.player.brawlers_id.length)

    this.writeVint(6)
    this.writeVint(0)

    this.writeVint(7)
    this.writeVint(99999)

    this.writeVint(8)
    this.writeVint(99999)

    this.writeVint(9)
    this.writeVint(99999)

    this.writeVint(10)
    this.writeVint(99999)

    this.writeVint(11)
    this.writeVint(99999)
  }
}

module.exports = BotProfileMessage
