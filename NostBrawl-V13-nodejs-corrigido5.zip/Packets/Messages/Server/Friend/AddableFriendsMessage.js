'use strict'

const { encode_addable_friend } = require('../../../../Logic/FriendPayload')
const Writer = require('../../../../Utils/Writer')

class AddableFriendsMessage extends Writer {
  constructor (client, player, entries) {
    super(client)
    this.id = 20107
    this.player = player
    this.entries = Array.from(entries)
  }

  encode () {
    this.writeInt(this.entries.length)
    for (const entry of this.entries) {
      encode_addable_friend(this, entry)
    }
  }
}

module.exports = AddableFriendsMessage
