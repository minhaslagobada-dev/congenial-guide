'use strict'

const { encode_friend_entry } = require('../../../../Logic/FriendPayload')
const Writer = require('../../../../Utils/Writer')

class FriendListMessage extends Writer {
  constructor (client, player, entries = null, refresh = false) {
    super(client)
    this.id = 20105
    this.player = player
    this.entries = entries
    this.refresh = Boolean(refresh)
  }

  _can_deliver (lowId) {
    if (this.refresh) {
      const { FriendService } = require('../../../../Logic/FriendService')
      this.entries = FriendService.friends_for_account(lowId)
    }
    return true
  }

  encode () {
    let entries = this.entries
    if (entries === null || entries === undefined) {
      const { FriendService } = require('../../../../Logic/FriendService')
      entries = FriendService.friends(this.player)
    }
    this.writeInt(0)
    this.writeBoolean(true)
    this.writeInt(entries.length)
    for (const entry of entries) {
      encode_friend_entry(this, entry)
    }
  }
}

module.exports = FriendListMessage
