'use strict'
const Writer = require('../../../../../Utils/Writer')

class FBAccountDisconnectedOKMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24214
    this.player = player
  }

  encode () {
  }
}

module.exports = FBAccountDisconnectedOKMessage
