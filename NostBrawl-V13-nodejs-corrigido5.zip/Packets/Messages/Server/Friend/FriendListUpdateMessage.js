'use strict'

const { encode_friend_entry } = require('../../../../Logic/FriendPayload')
const { FriendService } = require('../../../../Logic/FriendService')
const Writer = require('../../../../Utils/Writer')

class FriendListUpdateMessage extends Writer {
  constructor (client, player, entry, removed = false, refresh = false) {
    super(client)
    this.id = 20106
    this.player = player
    this.entry = entry
    this.removed = Boolean(removed)
    this.refresh = Boolean(refresh)
  }

  _can_deliver (lowId) {
    if (!this.refresh) {
      return true
    }
    const entry = FriendService.current_entry(lowId, this.entry.low_id)
    if (entry === null || entry === undefined) {
      return false
    }
    this.entry = entry
    return true
  }

  encode () {
    this.writeBoolean(this.removed)
    encode_friend_entry(this, this.entry)
  }
}

module.exports = FriendListUpdateMessage
