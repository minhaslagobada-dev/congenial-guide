'use strict'

const Writer = require('../../../../Utils/Writer')

class GoogleBillingProcessedByServerMessage extends Writer {
  constructor (client, player, product, transactionId, result = 0) {
    super(client)
    this.id = 20152
    this.player = player
    this.product = product
    this.transaction_id = transactionId
    this.result = result
  }

  encode () {
    this.writeString(this.product)
    this.writeString(this.transaction_id)
    this.writeInt(this.result)
  }
}

module.exports = GoogleBillingProcessedByServerMessage
