'use strict'

const { LeaderboardService } = require('../../../../Logic/LeaderboardService')
const LeaderboardMessage = require('./LeaderboardMessage')

class GetLeaderboardClubGlobalOkMessage extends LeaderboardMessage {
  constructor (client, player, type = 2) {
    super(client, player, 2, false, LeaderboardService.clubs())
  }
}

module.exports = GetLeaderboardClubGlobalOkMessage
