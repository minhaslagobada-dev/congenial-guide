'use strict'

const Writer = require('../../../../Utils/Writer')

class LeaderboardMessage extends Writer {
  static LIMIT = 200

  constructor (client, player, leaderboardType, isLocal, entries, targetBrawler = 0) {
    super(client)
    this.id = 24403
    this.version = 13
    this.player = player
    this.leaderboard_type = Math.trunc(leaderboardType)
    this.is_local = Boolean(isLocal)
    this.entries = Array.from(entries)
    this.target_brawler = Math.trunc(targetBrawler)
    this.region = String((player && player.region) ? player.region : 'BR') || 'BR'
    if (![0, 1, 2].includes(this.leaderboard_type)) {
      throw new Error('Unsupported leaderboard type')
    }
  }

  own_rank () {
    const fallback = this.leaderboard_type === 2 ? 0 : 1
    let ownId
    let key
    if (this.leaderboard_type === 2) {
      ownId = Math.trunc((this.player && this.player.club_low_id) || 0)
      key = 'id'
    } else {
      ownId = Math.trunc((this.player && this.player.low_id) || 0)
      key = 'low_id'
    }
    let rank = 1
    for (const entry of this.entries) {
      if (Math.trunc(entry[key] || 0) === ownId) {
        return rank
      }
      rank += 1
    }
    return fallback
  }

  encode () {
    const displayed = this.entries.slice(0, LeaderboardMessage.LIMIT)
    this.writeVint(this.leaderboard_type)
    if (this.leaderboard_type === 0) {
      this.writeScId(16, this.target_brawler)
    } else {
      this.writeVint(0)
    }
    this.writeString(this.is_local ? this.region : null)
    this.writeVint(displayed.length)

    let rank = 1
    for (const entry of displayed) {
      if (this.leaderboard_type === 2) {
        this.writeVint(0)
        this.writeVint(entry.id)
        this.writeVint(rank)
        this.writeVint(entry.trophies)
        this.writeVint(2)
        this.writeString(entry.name)
        this.writeVint(entry.member_count)
        this.writeScId(8, entry.badge_id)
        rank += 1
        continue
      }

      this.writeVint(0)
      this.writeVint(entry.low_id)
      this.writeVint(rank)
      this.writeVint(entry.trophies)
      this.writeVint(1)
      this.writeString(entry.name)
      this.writeString(entry.club_name || null)
      this.writeVint(entry.player_experience)
      this.writeScId(28, entry.profile_icon)
      this.writeVint(0)
      rank += 1
    }

    this.writeVint(0)
    this.writeVint(this.own_rank())
    this.writeVint(0)
    this.writeVint(0)
    this.writeString(this.region)
  }
}

module.exports = LeaderboardMessage
