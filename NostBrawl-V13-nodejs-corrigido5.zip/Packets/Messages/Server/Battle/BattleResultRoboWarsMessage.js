'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const BattleResultMessage = require('./BattleResultMessage')

class BattleResultRoboWarsMessage extends BattleResultMessage {
  static get GAME_MODE () { return 1 }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, 1)
    }
    return apply_battle_result_rewards(this.player, 1, battleId)
  }
}

module.exports = BattleResultRoboWarsMessage
