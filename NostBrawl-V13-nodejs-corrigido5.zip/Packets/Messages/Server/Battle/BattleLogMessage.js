'use strict'
const Writer = require('../../../../Utils/Writer')
const Config = require('../../../../Utils/Config')

// 23458 BattleLogMessage, layout recovered from the v13 client:
//   decode 0x3fb954: bool replace, vint count, count x LogicBattleLogEntry
//   handler 0x408484: replace = true -> the list is replaced (message order is
//   display order, newest first); false -> each entry is inserted at the top.
// LogicBattleLogEntry (decode 0x47f288):
//   vint  (+0x00) unused by the v13 UI (0)
//   vint  age in seconds at reception (TID_BATTLE_LOG_AGE)
//   vint  entry type (1 3v3, 2 Showdown, 3 co-op, 4 Big Game, 5 duo Showdown)
//   vint  trophy change of the owner (shown as +n / -n, sets the colour)
//   vint  duration in seconds (VICTORY_IN / SURVIVED_FOR)
//   bool  friendly (practice): FRIENDLY label instead of RANKED, no trophies
//   DataRef location (15, map) -> mode name/icon and map name
//   vint  3v3 result (TID_BATTLE_LOG_TVST_RESULT_0/1/2 = victory/defeat/draw)
//   vint  replay state (-1 = "No replay available yet")
//   long  replay id, long replay id (23459/14115 replay messages; unused)
//   vint  player count, then LogicBattleLogPlayer (decode 0x21b324):
//     vint kind (1 account, 3 bot -> TID_BOT_<low>), int high, int low,
//     vint team, bool star player, string name, DataRef hero (16, id),
//     vint brawler trophies, vint power level, vint Showdown placement
class BattleLogMessage extends Writer {
  constructor (client, player, entries = [], replace = true, now = Date.now()) {
    super(client)
    this.enable_native_v13()
    this.id = 23458
    this.version = 0
    this.player = player
    this.entries = Array.isArray(entries) ? entries : []
    this.replace = replace !== false
    this.now = now
  }

  static clamp (value) {
    const parsed = Math.trunc(Number(value))
    if (!Number.isFinite(parsed)) return 0
    return Math.max(-0x80000000, Math.min(0x7FFFFFFF, parsed))
  }

  encode () {
    const v = value => this.writeVint(BattleLogMessage.clamp(value))
    this.writeBoolean(this.replace)
    v(this.entries.length)
    for (const entry of this.entries) {
      v(0)
      v(Math.max(0, Math.floor((this.now - Number(entry.created_at || this.now)) / 1000)))
      v(entry.entry_type)
      v(entry.practice ? 0 : entry.trophy_change)
      v(entry.duration)
      this.writeBoolean(Boolean(entry.practice))
      this.writeScId(15, BattleLogMessage.clamp(entry.map_id))
      v(entry.result)
      v(-1)
      this.writeLong(0, 0)
      this.writeLong(0, 0)
      const players = Array.isArray(entry.participants) ? entry.participants : []
      v(players.length)
      for (const p of players) {
        v(p.kind)
        this.writeInt(BattleLogMessage.clamp(p.high_id))
        this.writeInt(BattleLogMessage.clamp(p.low_id))
        v(p.team)
        this.writeBoolean(Boolean(p.mvp))
        this.writeString(String(p.name || ''))
        this.writeScId(16, BattleLogMessage.clamp(p.brawler_id))
        v(p.trophies)
        v(p.power_level)
        v(p.rank)
      }
    }

    if (Config.GetValue().ShowPacketsInLog) {
      console.log(`[INFO] Message BattleLogMessage has been sent (${this.entries.length} entradas, ${this.replace ? 'lista completa' : 'incremental'}).`)
    }
  }
}

module.exports = BattleLogMessage
