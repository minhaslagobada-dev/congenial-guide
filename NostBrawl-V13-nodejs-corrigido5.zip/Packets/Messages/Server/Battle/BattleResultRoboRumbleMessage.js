'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const BattleResultMessage = require('./BattleResultMessage')

class BattleResultRoboRumbleMessage extends BattleResultMessage {
  static get GAME_MODE () { return 3 }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, 3)
    }
    return apply_battle_result_rewards(this.player, 3, battleId)
  }
}

module.exports = BattleResultRoboRumbleMessage
