'use strict'
const { LogicGameObjectManager } = require('../../../../Logic/Battle/Game/LogicGameObjectManager')
const BitStream = require('../../../../Utils/BitStream')
const Writer = require('../../../../Utils/Writer')

class VisionUpdateMessage extends Writer {
  constructor (client, player, room = null, participants = null) {
    super(client)
    this.enable_native_v13()
    this.id = 24109
    this.player = player
    this.room = room !== null && room !== undefined ? room : player.battle_room
    this.participants =
      participants !== null && participants !== undefined
        ? participants
        : player.battle_participants
  }

  encode () {
    this.writeVint(this.player.battleTick || 0)
    this.writeVint(this.player.dudu || 0)
    this.writeVint(0)
    this.writeVint(0)
    const stream = new BitStream()
    new LogicGameObjectManager().encode.call(this.player, stream, this.participants)
    this.writeInt(stream.size())
    this.writeBytes(stream.getBuff())
  }
}

module.exports = VisionUpdateMessage
