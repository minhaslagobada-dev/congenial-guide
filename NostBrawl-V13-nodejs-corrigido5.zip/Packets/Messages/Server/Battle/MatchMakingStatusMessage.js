'use strict'
const Writer = require('../../../../Utils/Writer')

// v13 20405.encode 0x3edc50: exactly five big-endian int32 fields.
class MatchMakingStatusMessage extends Writer {
  constructor (client, player, seconds, found, capacity) {
    super(client)
    this.enable_native_v13()
    this.player = player
    this.id = 20405
    this.seconds = seconds
    this.found = found
    this.capacity = capacity
  }
  encode () {
    this.writeInt(this.seconds)
    this.writeInt(this.found)
    this.writeInt(this.capacity)
    this.writeInt(0)
    this.writeInt(0)
  }
}
module.exports = MatchMakingStatusMessage
