'use strict'

const SeasonService = require('../../../Logic/SeasonService')

class NotifManager {
  constructor (player, client) {
    this.plr = player
    this.cl = client
  }

  getClubNotifications () {
    const { ClubService } = require('../../../Logic/ClubService')
    const clubId = Math.trunc((this.plr.club_low_id || 0) || 0)
    if (!clubId) {
      return []
    }
    return ClubService.get_notifications(clubId).map((item) => JSON.stringify(item))
  }

  getSysNotifications () {
    return undefined
  }

  SeasonEnd () {
    return SeasonService.end_now(this.plr)
  }

  getAllNotif () {
    const notifications = new NotifManager(this.plr, this.cl).getClubNotifications()
    notifications.push(
      `Привет, ${this.plr.name}! Обновление от 20.11.2021 уже тут!\n` +
      'Нововведения:\nКлубная почта'
    )
    return undefined
  }
}

module.exports = NotifManager
