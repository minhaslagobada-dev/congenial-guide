'use strict'

const { ValueError } = require('../../../Utils/Errors')

class LogicBoxDataEchoCommand {
  static _count (reader, label) {
    const count = reader.read_Vint()
    if (count < 0 || count > 64) {
      throw new ValueError(`Invalid 203 ${label}: ${count}`)
    }
    return count
  }

  static decode (reader) {
    reader.box_type = reader.read_Vint()
    reader.box_count_or_type = reader.box_type
    const unitCount = LogicBoxDataEchoCommand._count(reader, 'unit count')
    reader.box_count = unitCount
    reader.box_id = 0
    reader.rewards = []
    reader.reward_units = []

    for (let unitIndex = 0; unitIndex < unitCount; unitIndex++) {
      const unitType = reader.read_Vint()
      const rewardCount = LogicBoxDataEchoCommand._count(reader, 'reward count')
      if (unitIndex === 0) {
        reader.box_id = unitType
      }
      const unitRewards = []
      for (let index = 0; index < rewardCount; index++) {
        const amount = reader.read_Vint()
        const primaryReference = reader.readScId()
        const rewardType = reader.read_Vint()
        const secondaryReference = reader.readScId()
        const dropData = reader.read_Vint()
        const reference = (
          secondaryReference[0]
            ? secondaryReference
            : primaryReference
        )
        const reward = [amount, rewardType, reference]
        unitRewards.push([reward, dropData])
        reader.rewards.push(reward)
      }
      reader.reward_units.push([unitType, unitRewards])
    }

    reader.trophy_road = reader.read_Vint()
    reader.turn_context = Array.from({ length: 5 }, () => reader.read_Vint())
  }

  static process (reader) {
    return null
  }
}

module.exports = LogicBoxDataEchoCommand
