'use strict'

class LogicChangeResourcesEchoCommand {
  static decode (reader) {
    reader.resource_global_id = reader.read_Vint()
    reader.resource_amount = reader.read_Vint()
    reader.response_tail = Array.from({ length: 5 }, () => reader.read_Vint())
  }

  static process (reader) {
    return null
  }
}

module.exports = LogicChangeResourcesEchoCommand
