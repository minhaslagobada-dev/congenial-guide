'use strict'

const { RewardError, RewardTransaction } = require('../../../Logic/Rewards')
const ShopCatalog = require('../../../Logic/ShopCatalog')
const { ValueError } = require('../../../Utils/Errors')

class LogicPurchaseHeroLvlUpMaterialCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.gold = reader.read_Vint()
  }

  static process (reader) {
    try {
      if (!(reader.gold >= 0 && reader.gold < ShopCatalog.GOLD_OFFERS.length)) {
        throw new RewardError('Pacote de gold inválido')
      }
      const offer = ShopCatalog.GOLD_OFFERS[reader.gold]
      const transaction = new RewardTransaction(reader.player)
      transaction.charge('gems', offer.Cost)
      transaction.add_reward('Coins', offer.Amount)
      transaction.commit()
      return { gold: reader.player.gold, gems: reader.player.gems }
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
  }
}

module.exports = LogicPurchaseHeroLvlUpMaterialCommand
