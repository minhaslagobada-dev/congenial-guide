'use strict'

const { RewardError, RewardTransaction } = require('../../../Logic/Rewards')
const ShopCatalog = require('../../../Logic/ShopCatalog')
const { ValueError } = require('../../../Utils/Errors')

class LogicPurchaseDoubleCoinsCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
  }

  static process (reader) {
    try {
      const transaction = new RewardTransaction(reader.player)
      transaction.charge('gems', ShopCatalog.TOKEN_DOUBLER.Cost)
      transaction.add_reward(
        'tokens_doubler', ShopCatalog.TOKEN_DOUBLER.Amount
      )
      transaction.commit()
      return {
        gems: reader.player.gems,
        tokensdoubler: reader.player.tokensdoubler
      }
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
  }
}

module.exports = LogicPurchaseDoubleCoinsCommand
