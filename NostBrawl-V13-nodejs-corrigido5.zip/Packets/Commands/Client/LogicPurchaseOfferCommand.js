'use strict'

const RewardDelivery = require('../../../Logic/RewardDelivery')
const { RewardError } = require('../../../Logic/Rewards')
const ShopService = require('../../../Logic/ShopService')
const { ValueError } = require('../../../Utils/Errors')

class LogicPurchaseOfferCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.offer_index = reader.read_Vint()
    reader.target_reference = reader.readScId()
  }

  static process (reader) {
    const [csvId, itemId] = reader.target_reference
    if (![0, 16].includes(csvId)) {
      return 'DataReference inválida para compra da oferta'
    }
    const selectedBrawler = csvId === 16 ? itemId : 0
    let result
    try {
      result = ShopService.purchase(
        reader.player, reader.offer_index, selectedBrawler
      )
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
    RewardDelivery.send_many(reader.client, reader.player, result.responses)
    return result
  }
}

module.exports = LogicPurchaseOfferCommand
