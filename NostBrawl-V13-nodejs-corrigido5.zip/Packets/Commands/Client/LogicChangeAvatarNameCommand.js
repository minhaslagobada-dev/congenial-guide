'use strict'

class LogicChangeAvatarNameCommand {
  static decode (reader) {
    reader.echoed_name = reader.read_string()
    reader.avatar_fields = Array.from({ length: 6 }, () => reader.read_Vint())
  }

  static process (reader) {
    return { ignored: 'avatar-name echo', name: reader.echoed_name }
  }
}

module.exports = LogicChangeAvatarNameCommand
