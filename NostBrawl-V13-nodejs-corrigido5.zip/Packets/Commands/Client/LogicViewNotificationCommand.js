'use strict'

const NotificationFactory = require('../../../Logic/NotificationFactory')
const LogicSkinDataCommand = require('../Server/LogicSkinDataCommand')
const { ValueError } = require('../../../Utils/Errors')

class LogicViewNotificationCommand {
  static decode (reader) {
    if (reader.command_count === 1) {
      const values = []
      while (reader.tell() < reader.initial_bytes.length) {
        values.push(reader.read_Vint())
      }
      if (values.length === 2) {
        reader.notification_index = values[0]
        return
      }
      if (values.length === 5) {
        reader.notification_index = values[4]
        return
      }
      throw new ValueError('Payload de visualização de notificação inválido')
    }
    for (let index = 0; index < 4; index++) {
      reader.read_Vint()
    }
    reader.notification_index = reader.read_Vint()
  }

  static process (reader) {
    let result
    try {
      const notificationType = NotificationFactory.notification_type_at_index(
        reader.player, reader.notification_index
      )
      if (notificationType === NotificationFactory.SEASON_END_TYPE) {
        return NotificationFactory.mark_season_seen(
          reader.player, reader.notification_index
        )
      }
      result = NotificationFactory.claim_skin(
        reader.player, reader.notification_index
      )
    } catch (error) {
      if (error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
    new LogicSkinDataCommand(
      reader.client,
      reader.player,
      result.skin,
      result.brawlerReward !== undefined ? result.brawlerReward : null
    ).send()
    return result
  }
}

module.exports = LogicViewNotificationCommand
