'use strict'

const DataBase = require('../../../Database/DatabaseManager')

class LogicSetPlayerNameColorCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.player.name_color = reader.read_Vint()
  }

  static process (reader) {
    DataBase.replaceValue(reader, 'namecolor', reader.player.name_color)
  }
}

module.exports = LogicSetPlayerNameColorCommand
