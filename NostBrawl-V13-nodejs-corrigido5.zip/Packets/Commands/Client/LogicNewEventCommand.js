'use strict'

const { EventRotation } = require('../../../Logic/EventRotation')

class LogicNewEventCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.event_index = reader.read_Vint()
    reader.event_state = reader.read_Vint()
  }

  static process (reader) {
    return EventRotation.apply_state(
      reader.player, reader.event_index, reader.event_state
    )
  }
}

module.exports = LogicNewEventCommand
