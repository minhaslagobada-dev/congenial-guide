'use strict'

const LogicBuyItem = require('./LogicBuyItem')

class LogicSkinDataCommand extends LogicBuyItem {
  constructor (client, player, ID, brawler = null) {
    let skin
    if (typeof ID === 'object' && ID !== null) {
      const result = ID
      if (!(Array.isArray(result.rewardNames) && result.rewardNames.length === 1 && result.rewardNames[0] === 'Skin')) {
        throw new Error('LogicSkinDataCommand requires one skin reward')
      }
      skin = Math.trunc(result.skin !== undefined ? result.skin : result.rewards[0])
    } else {
      skin = Math.trunc(ID)
    }
    const rewards = []
    if (brawler !== null && brawler !== undefined) {
      rewards.push({ type: 6, amount: 1, brawler: Math.trunc(brawler) })
    }
    rewards.push({ type: 7, amount: 1, skin })
    super(client, player, rewards, 0, [0, 1, 0, 0, 0])
  }
}

module.exports = LogicSkinDataCommand
