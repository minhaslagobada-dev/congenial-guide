'use strict'

const DataBase = require('../../../Database/DatabaseManager')
const Writer = require('../../../Utils/Writer')

class LogicChangeAvatarNameCommand extends Writer {
  constructor (client, player, state) {
    super(client)
    this.id = 24111
    this.player = player
    this.state = state
  }

  encode () {
    this.writeVint(201)
    this.writeString(this.player.name)
    this.writeVint(this.state)

    DataBase.replaceValue(this, 'name', this.player.name)
  }
}

module.exports = LogicChangeAvatarNameCommand
