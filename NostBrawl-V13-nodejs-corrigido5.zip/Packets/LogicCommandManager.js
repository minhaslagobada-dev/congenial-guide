'use strict'
const { BSMessageReader } = require('../Utils/Reader')
const { ValueError } = require('../Utils/Errors')

function lazy (path) {
  let cached = null
  let failed = false
  return function load () {
    if (failed) return undefined
    if (cached === null) {
      try {
        cached = require(path)
      } catch (error) {
        if (error && error.code === 'MODULE_NOT_FOUND' && String(error.message).includes(path)) {
          failed = true
          return undefined
        }
        throw error
      }
    }
    return cached
  }
}

const COMMAND_HANDLERS = {
  201: lazy('./Commands/Client/LogicChangeAvatarNameCommand'),
  500: lazy('./Commands/Client/LogicPurchaseBoxCommand'),
  535: lazy('./Commands/Client/LogicPurchaseBoxCommand'),
  517: lazy('./Commands/Client/LogicClaimRankUpRewardCommand'),
  515: lazy('./Commands/Client/LogicClearShopTickersCommand'),
  519: lazy('./Commands/Client/LogicPurchaseOfferCommand'),
  503: lazy('./Commands/Client/LogicNewEventCommand'),
  505: lazy('./Commands/Client/LogicSetPlayerThumbnailCommand'),
  203: lazy('./Commands/Client/LogicBoxDataEchoCommand'),
  207: lazy('./Commands/Client/LogicChangeResourcesEchoCommand'),
  506: lazy('./Commands/Client/LogicSelectSkinCommand'),
  507: lazy('./Commands/Client/LogicBuySkinCommand'),
  525: lazy('./Commands/Client/LogicSelectBrawlerCommand'),
  520: lazy('./Commands/Client/LogicUpgradeBrawler'),
  521: lazy('./Commands/Client/LogicPurchaseHeroLvlUpMaterialCommand'),
  522: lazy('./Commands/Client/LogicRemoveNewTagBrawler'),
  509: lazy('./Commands/Client/LogicPurchaseDoubleCoinsCommand'),
  527: lazy('./Commands/Client/LogicSetPlayerNameColorCommand'),
  529: lazy('./Commands/Client/LogicSetPlayerStarpowerCommand'),
  514: lazy('./Commands/Client/LogicDeleteNotificationCommand'),
  528: lazy('./Commands/Client/LogicViewNotificationCommand')
}

const IGNORED_COMMAND_ECHOES = {
  201: 'avatar-name echo; SetNameMessage already handles the rename',
  203: 'box/reward echo; the originating command already committed it',
  207: 'resource echo; the originating command already committed it'
}

class EndClientTurn extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
    this.initial_bytes = initialBytes
    this.command_count = 0
    this.command_ids = []
    this.commandID = null
  }

  decode () {
    this.read_Vint()
    this.tick = this.read_Vint()
    this.ping = this.read_Vint()
    this.command_count = this.read_Vint()
    if (this.command_count < 0 || this.command_count > 64) {
      throw new ValueError(`Invalid EndClientTurn command count: ${this.command_count}`)
    }

    this.command_ids = []
    this.commandID = null
  }

  process () {
    for (let index = 0; index < this.command_count; index++) {
      const commandId = this.read_Vint()
      this.commandID = commandId
      this.command_ids.push(commandId)
      console.log(
        `Client | EndClientTurn commandID: ${commandId}; ` +
        `command: ${index + 1}/${this.command_count}; ` +
        `payload: ${this.initial_bytes.length} bytes; ` +
        `remaining: ${this.initial_bytes.length - this.tell()} bytes; ` +
        `payload_hex: ${Buffer.from(this.initial_bytes).toString('hex')}; ` +
        `remaining_hex: ${Buffer.from(this.initial_bytes).subarray(this.tell()).toString('hex')}`
      )

      if (commandId in IGNORED_COMMAND_ECHOES) {
        console.log(
          `Client | CommandID ${commandId} decoded but not applied: ` +
          `${IGNORED_COMMAND_ECHOES[commandId]}`
        )
      }

      const loader = COMMAND_HANDLERS[commandId]
      const handler = loader ? loader() : undefined
      if (handler === undefined || handler === null) {
        console.log(`Client | CommandID ${commandId} not handled`)

        return
      }

      try {
        handler.decode(this)
      } catch (error) {
        if (error instanceof ValueError) {
          console.log(
            `Client | CommandID ${commandId} ignored: ` +
            `incomplete/invalid payload (${error.message})`
          )
          return
        }
        throw error
      }

      const result = handler.process(this)
      if (typeof result === 'string') {
        console.log(`Client | CommandID ${commandId} rejected: ${result}`)
      }
    }

    return null
  }
}

module.exports = EndClientTurn
module.exports.COMMAND_HANDLERS = COMMAND_HANDLERS
module.exports.IGNORED_COMMAND_ECHOES = IGNORED_COMMAND_ECHOES
