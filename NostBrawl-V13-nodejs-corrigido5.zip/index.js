'use strict'
// Entry point. Starts the ported Brawl Stars V13 server (see main.js).
// Reads config.json: ServerHost/ServerPort (default 0.0.0.0:25454), crypto, etc.
const { Server } = require('./main')

const server = new Server()
let stopping = false
const shutdown = () => {
  if (stopping) return
  stopping = true
  console.log('\nServer | Server stopped')
  server.running = false
  server.stop_scid()
  try {
    const DataBase = require('./Database/DatabaseManager')
    DataBase.resetOnlineStatus()
  } catch (error) {
    console.warn('Server | Could not reset account online states during shutdown')
  }
  server.close()
  process.exit(0)
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
server.start_scid()
server.start().catch((error) => {
  console.error(error && error.stack ? error.stack : error)
  process.exit(1)
})
