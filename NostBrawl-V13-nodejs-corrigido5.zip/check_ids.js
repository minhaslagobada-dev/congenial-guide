'use strict'
const fs = require('fs')
const path = require('path')
const vm = require('vm')

const base = '/home/user/pyserver/extracted/Packets/Messages'
const files = []
function walk (dir) {
  for (const entry of fs.readdirSync(dir)) {
    const full = path.join(dir, entry)
    if (fs.statSync(full).isDirectory()) {
      if (entry === 'Server') { // skip server (ids not registered client-side)
        continue
      }
      walk(full)
    } else if (entry.endsWith('.py')) {
      files.push(full)
    }
  }
}
walk(path.join(base, 'Client'))
const ids = []
for (const file of files) {
  const src = fs.readFileSync(file, 'utf8')
  const importMatch = src.match(/from Packets\.MessageFactory import Packets/)
  if (!importMatch) continue
  const idsMatch = src.match(/def getMessageIDs\(self\):\s*[^\[]*\[(.*?)\]/s)
  if (!idsMatch) continue
  ids.push({ file: path.relative(base, file), ids: idsMatch[1].trim() })
}
console.log(JSON.stringify(ids, null, 1))
