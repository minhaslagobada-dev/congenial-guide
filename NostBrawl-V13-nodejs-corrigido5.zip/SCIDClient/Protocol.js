'use strict'

const zlib = require('zlib')

const { ValueError } = require('../Utils/Errors')

const MAX_COMPRESSED_SIZE = 900000
const MAX_TOKEN_SIZE = 16384

function encode_compressed_string (value) {
  const raw = Buffer.from(String(value), 'utf-8')
  const compressed = zlib.deflateSync(raw, { level: 9 })
  const prefix = Buffer.alloc(8)
  prefix.writeInt32BE(compressed.length + 4, 0)
  prefix.writeUInt32LE(raw.length, 4)
  return Buffer.concat([prefix, compressed])
}

function decode_compressed_string (payload, offset = 0, maxSize = MAX_TOKEN_SIZE) {
  payload = Buffer.from(payload)
  if (offset < 0 || offset + 12 > payload.length) {
    throw new ValueError('Compressed string incompleta')
  }
  const size = payload.readInt32BE(offset)
  if (size < 4 || size - 4 > MAX_COMPRESSED_SIZE) {
    throw new ValueError('Tamanho de compressed string inválido')
  }
  const end = offset + 4 + size
  if (end > payload.length) {
    throw new ValueError('Compressed string truncada')
  }
  const expected = payload.readUInt32LE(offset + 4)
  if (expected > maxSize) {
    throw new ValueError('Compressed string expandida demais')
  }
  const compressed = payload.subarray(offset + 8, end)
  let raw
  let engine
  try {
    const result = zlib.inflateSync(compressed, { info: true })
    raw = result.buffer
    engine = result.engine
    if (raw.length > expected) {
      throw new ValueError('Compressed string excede o tamanho declarado')
    }
  } catch (error) {
    if (error instanceof ValueError) {
      throw error
    }
    throw new ValueError('Zlib inválido')
  }
  const consumed = engine.bytesRead !== undefined ? engine.bytesRead : engine.bytesWritten
  if (consumed !== compressed.length || raw.length !== expected) {
    throw new ValueError('Compressed string inconsistente')
  }
  return [raw.toString('utf-8'), end]
}

function extract_scid_token (payload, start, validator) {
  payload = Buffer.from(payload)
  if (start < 0 || start >= payload.length) {
    return null
  }
  for (let offset = start; offset < payload.length - 11; offset++) {
    const size = payload.readInt32BE(offset)
    if (size < 6 || size - 4 > MAX_COMPRESSED_SIZE) {
      continue
    }
    const end = offset + 4 + size
    if (
      end !== payload.length &&
      !(end + 1 === payload.length && (payload[end] === 0 || payload[end] === 1))
    ) {
      continue
    }
    const expected = payload.readUInt32LE(offset + 4)
    if (expected < 1 || expected > MAX_TOKEN_SIZE || payload[offset + 8] !== 0x78) {
      continue
    }
    let decoded
    try {
      ;[decoded] = decode_compressed_string(payload, offset)
    } catch (error) {
      if (error instanceof ValueError || error instanceof Error) {
        continue
      }
      throw error
    }
    if (validator(decoded)) {
      return decoded
    }
  }
  return null
}

module.exports = {
  MAX_COMPRESSED_SIZE,
  MAX_TOKEN_SIZE,
  encode_compressed_string,
  decode_compressed_string,
  extract_scid_token
}
