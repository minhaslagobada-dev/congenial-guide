'use strict'

const { SCIDError } = require('./Models')
const { get_service } = require('./Runtime')
const Config = require('../Utils/Config')

class SCIDGame {
  static enabled () {
    const scid = Config.GetValue().SCID || {}
    return Boolean(scid.Enabled !== undefined ? scid.Enabled : true)
  }

  static before_account_load (message, requestedLowId) {
    const token = message.scid_token !== undefined ? message.scid_token : null
    if (!token || !SCIDGame.enabled()) {
      return requestedLowId
    }
    const service = get_service()
    if (service === null || service === undefined) {
      throw new SCIDError('scid_unavailable')
    }
    const account = service.authenticate(token)
    if (account === null || account === undefined) {
      throw new SCIDError('invalid_token')
    }
    message.scid_account = account
    if (account.game_low_id) {
      if (requestedLowId && requestedLowId !== account.game_low_id) {
        throw new SCIDError('game_account_bound')
      }
      const game = service.store.game_account(account.game_low_id)
      if (game === null || game === undefined) {
        throw new SCIDError('game_account_not_found')
      }
      message.player.low_id = game.low_id
      message.player.high_id = 0
      message.player.token = game.token
      return game.low_id
    }
    return requestedLowId
  }

  static after_account_load (message) {
    if (!SCIDGame.enabled()) {
      return
    }
    let account = message.scid_account !== undefined ? message.scid_account : null
    let suppliedToken = message.scid_token !== undefined ? message.scid_token : null
    const service = get_service()
    if (service === null || service === undefined) {
      throw new SCIDError('scid_unavailable')
    }
    if (account !== null && account !== undefined) {
      if (account.game_low_id === 0) {
        service.link_game(account, message.player.low_id)
        account = service.store.by_id(account.id)
        message.scid_account = account
        suppliedToken = null
      }
      if (account.game_low_id !== message.player.low_id) {
        throw new SCIDError('game_account_bound')
      }
      message.player.scid_account = account
      message.player.scid_token = suppliedToken || service.tokens.issue(account)
      return
    }
    const [tokenAccount, token] = service.token_for_game(message.player.low_id)
    if (tokenAccount !== null && tokenAccount !== undefined) {
      message.player.scid_account = tokenAccount
      message.player.scid_token = token
    }
  }
}

module.exports = { SCIDGame }
