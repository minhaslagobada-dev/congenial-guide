'use strict'

const crypto = require('crypto')

const { SCIDAccount } = require('./Models')
const { ValueError } = require('../Utils/Errors')

const API_PREFIX = '/internal/game/v1'
const NONCE_TTL_SECONDS = 120
const MAX_TIMESTAMP_SKEW_SECONDS = 60

function key_bytes (value) {
  const key = Buffer.from(String(value || ''), 'utf-8')
  if (key.length < 32) {
    throw new ValueError('A chave de integração SCID deve ter pelo menos 32 bytes')
  }
  return key
}

function new_nonce () {
  return crypto.randomBytes(16).toString('hex')
}

function request_signature (key, method, path, timestamp, nonce, body) {
  const canonical = Buffer.concat([
    Buffer.from('SCID-GAME-REQUEST-V1', 'utf-8'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(String(method).toUpperCase(), 'ascii'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(String(path), 'utf-8'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(String(Math.trunc(timestamp)), 'ascii'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(String(nonce), 'ascii'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(crypto.createHash('sha256').update(body).digest('hex'), 'ascii')
  ])
  return crypto.createHmac('sha256', key_bytes(key)).update(canonical).digest('hex')
}

function response_signature (key, nonce, body) {
  const canonical = Buffer.concat([
    Buffer.from('SCID-GAME-RESPONSE-V1', 'utf-8'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(String(nonce), 'ascii'),
    Buffer.from('\n', 'utf-8'),
    Buffer.from(crypto.createHash('sha256').update(body).digest('hex'), 'ascii')
  ])
  return crypto.createHmac('sha256', key_bytes(key)).update(canonical).digest('hex')
}

function signatures_match (expected, received) {
  if (typeof expected !== 'string' || typeof received !== 'string') {
    return false
  }
  const lowered = received.toLowerCase()
  const a = Buffer.from(expected, 'utf-8')
  const b = Buffer.from(lowered, 'utf-8')
  if (a.length !== b.length) {
    return false
  }
  return crypto.timingSafeEqual(a, b)
}

function account_data (account) {
  if (account === null || account === undefined) {
    return null
  }
  return {
    id: Math.trunc(account.id),
    identity: account.identity,
    scid: account.scid,
    bind_token: account.bind_token,
    game_low_id: Math.trunc(account.game_low_id || 0),
    email_marketing_permission: Boolean(account.email_marketing_permission),
    marketing_consents: Object.assign({}, account.marketing_consents),
    avatar_image: account.avatar_image,
    profile_name: account.profile_name,
    block_incoming_friend_requests: Boolean(
      account.block_incoming_friend_requests
    )
  }
}

function account_from_data (data) {
  if (data === null || data === undefined) {
    return null
  }
  if (typeof data !== 'object' || Array.isArray(data)) {
    throw new ValueError('Conta SCID remota inválida')
  }
  const accountId = Math.trunc(Number(data.id))
  const gameLowId = Math.trunc(Number(data.game_low_id || 0))
  const identity = data.identity
  const scid = data.scid
  const bindToken = data.bind_token
  if (
    !(accountId > 0) || gameLowId < 0 ||
    ![identity, scid, bindToken].every(
      (value) => typeof value === 'string' && value
    )
  ) {
    throw new ValueError('Conta SCID remota inválida')
  }
  const consents = data.marketing_consents !== undefined ? data.marketing_consents : {}
  if (typeof consents !== 'object' || consents === null || Array.isArray(consents)) {
    throw new ValueError('Consentimentos SCID remotos inválidos')
  }
  return new SCIDAccount({
    id: accountId,
    identity,
    scid,
    bind_token: bindToken,
    game_low_id: gameLowId,
    email_marketing_permission: Boolean(
      data.email_marketing_permission !== undefined ? data.email_marketing_permission : false
    ),
    marketing_consents: Object.fromEntries(
      Object.entries(consents).map(([scope, consent]) => [String(scope), Boolean(consent)])
    ),
    avatar_image: data.avatar_image !== undefined ? data.avatar_image : null,
    profile_name: String(data.profile_name || 'Player'),
    block_incoming_friend_requests: Boolean(
      data.block_incoming_friend_requests !== undefined ? data.block_incoming_friend_requests : false
    )
  })
}

module.exports = {
  API_PREFIX,
  NONCE_TTL_SECONDS,
  MAX_TIMESTAMP_SKEW_SECONDS,
  key_bytes,
  new_nonce,
  request_signature,
  response_signature,
  signatures_match,
  account_data,
  account_from_data
}
