'use strict'
const fs = require('fs')

class Fingerprint {
  static loadFinger (path) {
    try {
      const fingerContent = JSON.parse(fs.readFileSync(path, 'utf-8'))
      return fingerContent.sha
    } catch (error) {
      console.log(`Could not load fingerprint: ${error.message}`)
      return null
    }
  }

  static loadFinger_full (path) {
    try {
      const fingerContent = JSON.parse(fs.readFileSync(path, 'utf-8'))
      return JSON.stringify(fingerContent)
    } catch (error) {
      console.log(`Could not load fingerprint: ${error.message}`)
      return null
    }
  }
}

module.exports = Fingerprint
