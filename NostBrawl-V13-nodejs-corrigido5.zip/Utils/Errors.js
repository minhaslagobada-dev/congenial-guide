'use strict'

class ValueError extends Error {
  constructor (message) {
    super(message)
    this.name = 'ValueError'
  }
}

class ConnectionError extends Error {
  constructor (message) {
    super(message)
    this.name = 'ConnectionError'
  }
}

module.exports = { ValueError, ConnectionError }
