'use strict'
const { AsyncLocalStorage } = require('async_hooks')

class AsyncLock {
  constructor () {
    this._tail = Promise.resolve()
  }

  run (fn) {
    const result = this._tail.then(() => fn())
    this._tail = result.then(() => undefined, () => undefined)
    return result
  }
}

class AccountLocks {
  constructor () {
    this._locks = new Map()
    this._storage = new AsyncLocalStorage()
  }

  _keyFor (lowId) {
    return Number.parseInt(lowId || 0, 10) || 0
  }

  acquire (lowId) {
    const key = this._keyFor(lowId)
    const manager = this
    return {
      key,
      run (fn) {
        return manager.run(key, fn)
      }
    }
  }

  run (lowIds, fn) {
    const input = Array.isArray(lowIds) ? lowIds : [lowIds]
    const keys = [...new Set(input.map((value) => this._keyFor(value)))].sort((a, b) => a - b)
    const held = this._storage.getStore() || new Set()

    const step = (index) => {
      if (index >= keys.length) return fn()
      const key = keys[index]
      if (held.has(key)) return step(index + 1)

      let lock = this._locks.get(key)
      if (!lock) {
        lock = { tail: Promise.resolve() }
        this._locks.set(key, lock)
      }

      let release
      const next = new Promise((resolve) => { release = resolve })
      const previous = lock.tail
      lock.tail = next

      return previous.then(() => {
        const nextHeld = new Set(held)
        nextHeld.add(key)
        return this._storage.run(nextHeld, () => step(index + 1))
      }).finally(() => {
        release()
      })
    }

    return step(0)
  }
}

module.exports = { AsyncLock, AccountLocks }
