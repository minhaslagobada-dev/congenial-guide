'use strict'
const Config = require('./Config')

const packet_settings = Config.GetValue()

class Writer {
  constructor (client, endian = 'big') {
    this.client = client
    this.endian = endian
    this.buffer = Buffer.alloc(0)
    this.native_v13 = false
    this._bit_index = 0
  }

  enable_native_v13 () {
    this.native_v13 = true
    this._bit_index = 0
    return this
  }

  _align_native () {
    this._bit_index = 0
  }

  static _native_vint_bytes (value) {
    value = Math.trunc(value)
    if (!(value >= -0x80000000 && value <= 0x7FFFFFFF)) {
      throw new Error('V13 VInt outside the signed 32-bit range')
    }
    let size
    if (value >= -63 && value <= 63) size = 1
    else if (value >= -8191 && value <= 8191) size = 2
    else if (value >= -1048575 && value <= 1048575) size = 3
    else if (value >= -134217727 && value <= 134217727) size = 4
    else size = 5

    const unsigned = value >>> 0
    let first = unsigned & 0x3F
    if (value < 0) {
      first |= 0x40
    }
    if (size > 1) {
      first |= 0x80
    }
    const encoded = [first]
    for (let group = 1; group < size - 1; group++) {
      const byte = (unsigned >>> (6 + (group - 1) * 7)) & 0x7F
      encoded.push(byte | 0x80)
    }
    if (size > 1) {
      if (size === 5) {
        encoded.push((unsigned >>> 27) & 0x0F)
      } else {
        encoded.push((unsigned >>> (6 + (size - 2) * 7)) & 0x7F)
      }
    }
    return Buffer.from(encoded)
  }

  size () {
    return this.buffer.length
  }

  getRaw () {
    return this.buffer
  }

  writeBytes (data) {
    if (this.native_v13) {
      this._align_native()
    }
    this.buffer = Buffer.concat([this.buffer, Buffer.from(data)])
  }

  writeInt (data, length = 4) {
    if (this.native_v13) {
      this._align_native()
    }
    let value = Math.trunc(data)
    if (value < 0) {
      value = 2 ** (length * 8) + value
    }
    const chunk = Buffer.alloc(length)
    chunk.writeUIntBE(value, 0, length)
    this.buffer = Buffer.concat([this.buffer, chunk])
  }

  writeUInteger (integer, length = 1) {
    if (this.native_v13) {
      this._align_native()
    }
    const chunk = Buffer.alloc(length)
    if (this.endian === 'little') {
      chunk.writeUIntLE(Math.trunc(integer), 0, length)
    } else {
      chunk.writeUIntBE(Math.trunc(integer), 0, length)
    }
    this.buffer = Buffer.concat([this.buffer, chunk])
  }

  writeArrayVint (data) {
    for (const x of data) {
      this.writeVint(x)
    }
  }

  writeUInt8 (integer) {
    this.writeUInteger(integer)
  }

  writeLong (high, low) {
    if (this.native_v13) {
      this._align_native()
    }
    const chunk = Buffer.alloc(8)
    chunk.writeUIntBE(Math.trunc(high), 0, 4)
    chunk.writeUIntBE(Math.trunc(low), 4, 4)
    this.buffer = Buffer.concat([this.buffer, chunk])
  }

  writeBoolean (boolean) {
    if (this.native_v13) {
      if (this._bit_index === 0) {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0])])
      }
      if (boolean) {
        this.buffer[this.buffer.length - 1] |= (1 << this._bit_index)
      }
      this._bit_index = (this._bit_index + 1) & 7
      return
    }
    if (boolean) {
      this.writeUInt8(1)
    } else {
      this.writeUInt8(0)
    }
  }

  writeHexa (data) {
    if (data) {
      if (this.native_v13) {
        this._align_native()
      }
      if (data.startsWith('0x')) {
        data = data.slice(2)
      }
      const hex = data.replace(/\s+/g, '').replace(/-/g, '')
      this.buffer = Buffer.concat([this.buffer, Buffer.from(hex, 'hex')])
    }
  }

  _encode_payload () {
    this.buffer = Buffer.alloc(0)
    this._bit_index = 0
    this.encode()
    return this.buffer
  }

  _send_payload (client, crypter, rawPacket) {
    const packet = crypter ? crypter.encrypt(this.id, rawPacket) : rawPacket
    const header = Buffer.alloc(7)
    header.writeInt16BE(this.id, 0)
    header.writeUIntBE(packet.length, 2, 3)
    header.writeUInt16BE(this.version || 0, 5)
    client.write(Buffer.concat([header, packet]))
    return packet.length
  }

  _log_sent (packetLength) {
    if (packet_settings.ShowPacketsInLog && this.id !== 24109) {
      console.log(
        `Server | ${this.constructor.name} sent! ` +
        `Id: ${this.id}. Payload length: ${packetLength}`
      )
    }
  }

  _can_deliver (lowId) {
    return true
  }

  send () {
    const player = this.player
    if (!this._can_deliver(player ? (player.low_id || 0) : 0)) {
      return false
    }
    const rawPacket = this._encode_payload()
    const crypter = player ? (player.crypto || null) : null
    const packetLength = this._send_payload(this.client, crypter, rawPacket)
    this._log_sent(packetLength)
  }

  sendToAll () {
    if (this.player.club_low_id !== 0) {
      this.encode()
      const packet = this.buffer
      const header = Buffer.alloc(2)
      header.writeInt16BE(this.id, 0)
      this.buffer = header
      this.writeInt(packet.length, 3)
      if (this.version !== undefined) {
        this.writeInt16(this.version)
      } else {
        this.writeInt16(0)
      }
      this.buffer = Buffer.concat([this.buffer, packet, Buffer.from([0xFF, 0xFF, 0, 0, 0, 0, 0])])
      const DataBase = require('../Database/DatabaseManager')
      const clientCounts = this.player.ClientDict.ClientCounts
      for (let clientIndex = 0; clientIndex < clientCounts; clientIndex++) {
        for (const clientId of Object.keys(this.player.ClientDict.Clients)) {
          DataBase.loadOtherAccount(this, parseInt(clientId, 10))
          if (this.ClubID === this.player.club_low_id) {
            this.player.ClientDict.Clients[String(clientId)].SocketInfo.write(this.buffer)
          }
        }
        break
      }
      if (packet_settings.ShowPacketsInLog === true) {
        console.log(`Server | ${this.constructor.name} was sended! Id: ${this.id}. Length: ${this.buffer.length}`)
      }
    }
  }

  sendToOthers () {
    this.encode()
    const packet = this.buffer
    const header = Buffer.alloc(2)
    header.writeInt16BE(this.id, 0)
    this.buffer = header
    this.writeInt(packet.length, 3)
    if (this.version !== undefined) {
      this.writeInt16(this.version)
    } else {
      this.writeInt16(0)
    }
    this.buffer = Buffer.concat([this.buffer, packet, Buffer.from([0xFF, 0xFF, 0, 0, 0, 0, 0])])
    const DataBase = require('../Database/DatabaseManager')
    const clientCounts = this.player.ClientDict.ClientCounts
    for (let clientIndex = 0; clientIndex < clientCounts; clientIndex++) {
      for (const clientId of Object.keys(this.player.ClientDict.Clients)) {
        DataBase.loadOtherAccount(this, parseInt(clientId, 10))
        if (parseInt(clientId, 10) !== this.player.low_id && this.ClubID === this.player.club_low_id) {
          this.player.ClientDict.Clients[String(clientId)].SocketInfo.write(this.buffer)
        }
      }
      break
    }
    if (packet_settings.ShowPacketsInLog === true) {
      console.log(`Server | ${this.constructor.name} was sended! Id: ${this.id}. Length: ${this.buffer.length}`)
    }
  }

  sendWithLowID (lowId) {
    const registry = this.player.ClientDict || {}
    const clients = registry.Clients || {}
    const key = String(lowId)
    const recipient = clients[key]
    if (recipient == null) {
      return false
    }

    if (clients[key] !== recipient) {
      return false
    }
    if (!this._can_deliver(lowId)) {
      return false
    }
    const rawPacket = this._encode_payload()
    let packetLength
    try {
      packetLength = this._send_payload(
        recipient.SocketInfo,
        recipient.Crypto || null,
        rawPacket
      )
    } catch (error) {
      return false
    }
    this._log_sent(packetLength)
    return true
  }

  writeVint (data, rotate = true) {
    if (this.native_v13) {
      this._align_native()
      this.buffer = Buffer.concat([this.buffer, Writer._native_vint_bytes(data)])
      return
    }

    const chunks = []
    if (data === 0) {
      this.writeByte(0)
    } else {
      let value = data >= 0 ? data * 2 : (-data) * 2 - 1
      while (value !== 0) {
        let b = value % 128

        if (value >= 0x80) {
          b |= 0x80
        }
        if (rotate) {
          rotate = false
          const lsb = b & 0x1
          const msb = (b & 0x80) >> 7
          b >>= 1
          b = b & ~0xC0
          b = b | (msb << 7) | (lsb << 6)
        }

        chunks.push(b)
        value = Math.floor(value / 128)
      }
      this.buffer = Buffer.concat([this.buffer, Buffer.from(chunks)])
    }
  }

  writeString (string = null) {
    if (string === null || string === undefined) {
      this.writeInt((2 ** 32) - 1)
    } else {
      const encoded = Buffer.from(string, 'utf-8')
      this.writeInt(encoded.length)
      this.buffer = Buffer.concat([this.buffer, encoded])
    }
  }

  writeCompressedString (value) {
    const { encode_compressed_string } = require('../SCIDClient/Protocol')
    if (this.native_v13) {
      this._align_native()
    }
    const compressed = encode_compressed_string(value)
    this.buffer = Buffer.concat([this.buffer, compressed])
  }

  writeIntLittleEndian (data, length = 4) {
    if (this.native_v13) {
      this._align_native()
    }
    const chunk = Buffer.alloc(length)
    chunk.writeUIntLE(Math.trunc(data), 0, length)
    this.buffer = Buffer.concat([this.buffer, chunk])
  }

  writeByte (data) {
    this.writeInt(data, 1)
  }

  writeInt16 (data) {
    this.writeInt(data, 2)
  }

  writeScId (x, y) {
    this.writeVint(x)
    if (!this.native_v13 || x !== 0) {
      this.writeVint(y)
    }
  }

  encode () {
  }
}

module.exports = Writer
