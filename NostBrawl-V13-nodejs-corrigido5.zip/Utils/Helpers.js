'use strict'

class Helpers {
  static randomStringDigits (self) {
    const lettersAndDigits = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let result = ''
    for (let index = 0; index < 40; index++) {
      result += lettersAndDigits[Math.floor(Math.random() * lettersAndDigits.length)]
    }
    return result
  }

  static randomID (self) {
    const DataBase = require('../Database/DatabaseManager')
    while (true) {
      const newId = Math.floor(Math.random() * 99999999) + 1
      if (DataBase.checkID(self, newId) === 1) {
        return newId
      }
    }
  }

  static randomClubID (self) {
    const length = 9
    let digits = ''
    for (let index = 0; index < length; index++) {
      digits += String(Math.floor(Math.random() * 10))
    }
    return parseInt(digits, 10)
  }

  static LeaderboardTimer (self) {
    const result = new Date()
    const day = (result.getSeconds() + (result.getMinutes() * 60) + (result.getHours() * 3600) + (result.getDate() * 86400))
    const month = result.getMonth() + 1
    let seconds
    if (month === 1) {
      seconds = 2764800
    } else if (month === 2) {
      seconds = 2505600
    } else if (month === 3) {
      seconds = 2764800
    } else if (month === 4) {
      seconds = 2678400
    } else if (month === 5) {
      seconds = 2764800
    } else if (month === 6) {
      seconds = 2678400
    } else if (month === 7) {
      seconds = 2764800
    } else if (month === 8) {
      seconds = 2764800
    } else if (month === 9) {
      seconds = 2678400
    } else if (month === 10) {
      seconds = 2764800
    } else if (month === 11) {
      seconds = 2678400
    } else if (month === 12) {
      seconds = 2764800
    }

    return (seconds - day)
  }

  static ShopTimer (self) {
    const result = new Date()

    return (86400 - (result.getSeconds() + (result.getMinutes() * 60) + (result.getHours() * 3600)))
  }

  static EventTimer (self) {
    const result = new Date()

    return (86400 - (result.getSeconds() + (result.getMinutes() * 60) + (result.getHours() * 3600)))
  }
}

Helpers.PlayersCount = 0

module.exports = Helpers
