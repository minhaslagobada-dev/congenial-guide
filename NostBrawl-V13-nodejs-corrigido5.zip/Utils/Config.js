'use strict'
const fs = require('fs')

class Config {
  static get DEFAULT_SETTINGS () {
    return {
      ServerIP: '0.0.0.0',
      ServerPort: 9339,
      MaxPacketSize: 1048576,
      ClientMajor: 13,
      ClientMinor: 283,
      ClientBuild: 1,
      Region: 'BR',
      Database: {
        Path: 'Database/players.sqlite'
      },
      Battle: {
        Enabled: true,
        BindIP: '0.0.0.0',
        Port: 9339,
        AdvertiseHost: '',
        SessionTimeoutMs: 30000
      },
      SCID: {
        Enabled: false,
        RemoteUrl: '',
        RemoteApiKey: '',
        RemoteTimeoutSeconds: 10
      },
      Crypto: {
        Enabled: true,
        ServerPublicKey: 'EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041',
        ClientPrivateKey: 'BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D'
      },
      Gems: 999,
      Gold: 100,
      Tickets: 0,
      Starpoints: 999999,
      BrawlBoxTokens: 999,
      BigBoxTokens: 0,
      ExperiencePoints: 0,
      Trophies: 999,
      ShowPacketsInLog: true,
      SendLobbyInfo: false,
      BrawlersBox: true,
      SkinsBox: false,
      UniqueSkinsBox: true,
      StarShelly: false,
      WizardBarley: false,
      ThemeID: 0,
      SupportedContentCreator: '',
      Maintenance: false,
      MaintenanceTime: 3600,
      SeasonDuration: '14d',
      Patch: false,
      PatchUrl: '',
      UpdateUrl: '',
      CoinEvent: false,
      TokenEvent: false,
      MapModifiers: {
        1: false,
        2: false,
        3: false,
        4: false,
        5: false
      },
      BrawlerTrophies: 0,
      BrawlerTrophiesForRank: 0,
      BrawlerPowerLevel: 1,
      BrawlerUpgradePoints: 0,
      UnlockedBrawlersOption: 'Off',
      UnlockedBrawler: [{ shelly: 1 }]
    }
  }

  static create_config () {
    fs.writeFileSync('config.json', JSON.stringify(Config.DEFAULT_SETTINGS, null, 2) + '\n', 'utf-8')
  }

  static GetValue () {
    const userSettings = JSON.parse(fs.readFileSync('config.json', 'utf-8'))

    const settings = structuredClone(Config.DEFAULT_SETTINGS)
    Object.assign(settings, userSettings)
    if ('Battle' in userSettings) {
      settings.Battle = Object.assign(structuredClone(Config.DEFAULT_SETTINGS.Battle), userSettings.Battle)
    }
    if ('SCID' in userSettings) {
      const scid = structuredClone(Config.DEFAULT_SETTINGS.SCID)
      Object.assign(scid, userSettings.SCID)
      settings.SCID = scid
    }
    return settings
  }
}

module.exports = Config
