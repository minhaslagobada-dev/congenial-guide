'use strict'

const crypto = require('crypto')

const StoreCatalog = require('./StoreCatalog')
const { StoreError } = require('./StoreService')

// Bot da Lakey Store — polling direto na API do Telegram, sem dependências.
//
// /gift      -> "Enter the number of stars:" -> invoice em Stars (XTR) ->
//               pagamento confirmado -> gift card único ($0.40 por estrela).
//               Admin gera direto, sem gastar estrelas (ilimitado).
// /addoffer  -> (admin) wizard de oferta paga (Type 4 / lakeystore.*).
// /deloffer  -> (admin) remove oferta do catálogo.
// /ofertas   -> (admin) lista catálogo ativo (SKU + preço).
// /gerar     -> (admin) gift card em dólar sem cobrança: /gerar 10 -> $10.00.

const API_BASE = 'https://api.telegram.org'

// Regras do Telegram: UM token = UM consumidor de getUpdates (ou um webhook).
// 409 Conflict = outro processo já está em polling com este token.
// Este motor garante: (1) no máximo UM loop por processo (start idempotente);
// (2) deleteWebhook + getMe ao assumir, com identidade logada; (3) 409 com
// retentativa limitada — persistindo, o bot encerra com instrução em vez de
// disputar para sempre; (4) stop() aborta o long-poll em voo.

const POLL_TIMEOUT_S = 25
const CONFLICT_LIMIT = 6 // 6 × 30s ≈ ~3 min disputando antes de ceder
const CONFLICT_BACKOFF_MS = 30000

class TelegramBot {
  constructor (store) {
    this.store = store
    this.config = store.config
    this.token = this.config.BotToken
    this.offset = 0
    this.stateByUser = new Map()
    // estado do motor de polling
    this.started = false
    this.stopped = false
    this.abortController = null
    this._loop = null
    this._conflicts = 0
    this._signalsHooked = false
    // ganchos de teste (smoke_bot injeta apiBase local e backoff curto)
    this.apiBase = API_BASE
    this.conflictBackoffMs = CONFLICT_BACKOFF_MS
    this.conflictLimit = CONFLICT_LIMIT
  }

  enabled () {
    return Boolean(this.token)
  }

  pollingWanted () {
    const pref = this.config.BotPolling
    if (pref === true || pref === false) {
      return pref
    }
    return this.config.Mode !== 'agent'
  }

  isAdmin (userId) {
    return this.config.AdminIds.includes(Math.trunc(userId || 0))
  }

  async _call (method, payload, timeoutMs = 15000) {
    const signals = [AbortSignal.timeout(timeoutMs)]
    if (this.abortController) {
      signals.push(this.abortController.signal)
    }
    let response
    try {
      response = await fetch(`${this.apiBase}/bot${this.token}/${method}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload || {}),
        signal: AbortSignal.any(signals)
      })
    } catch (error) {
      if (this.stopped) {
        const silent = new Error('polling interrompido (stop)')
        silent.silent = true
        throw silent
      }
      throw new Error(`Telegram ${method}: rede indisponível (${error.message})`)
    }
    const data = await response.json().catch(() => null)
    if (!data || data.ok !== true) {
      const description = data && data.description ? data.description : `HTTP ${response.status}`
      const error = new Error(`Telegram ${method}: ${description}`)
      error.status = response.status
      if (response.status === 409) {
        error.conflict = true
      }
      if (response.status === 401 || response.status === 404) {
        error.fatal = true // token inválido/revogado — retentar não adianta
      }
      throw error
    }
    return data.result
  }

  _send (chatId, text, extra = {}) {
    return this._call('sendMessage', Object.assign({
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: true
    }, extra)).catch((error) => {
      if (!error.silent) {
        console.warn('Store | sendMessage falhou:', error.message)
      }
    })
  }

  _sleep (ms) {
    return new Promise((resolve) => {
      const timer = setTimeout(resolve, ms)
      if (this.abortController) {
        this.abortController.signal.addEventListener('abort', () => {
          clearTimeout(timer)
          resolve()
        }, { once: true })
      }
    })
  }

  // Assume a propriedade do token: derruba webhook residual (que roubaria os
  // updates) e identifica o bot — a linha de log é a prova de quem pollou.
  async _claim () {
    await this._call('deleteWebhook', { drop_pending_updates: false })
    const me = await this._call('getMe')
    console.log(`Store | Bot do Telegram em polling como @${me.username || me.id} (pid ${process.pid})`)
  }

  start () {
    if (!this.enabled()) {
      console.log('Store | BotToken vazio — bot desligado (site continua ativo)')
      return
    }
    if (!this.pollingWanted()) {
      console.log('Store | BotPolling=auto + Modo=agent → o polling do bot fica com o site externo; este processo NÃO chama getUpdates (fim do conflito 409)')
      return
    }
    if (this.started && !this.stopped) {
      console.warn('Store | Bot já está em polling — start() duplicado ignorado')
      return
    }
    this.started = true
    this.stopped = false
    this.abortController = new AbortController()
    this._hookSignals()
    this._loop = this._run()
  }

  async _run () {
    try {
      await this._claim()
    } catch (error) {
      if (!error.silent) {
        console.error('Store | Bot do Telegram não iniciou:', error.message)
      }
      this.started = false
      this.stopped = true
      return
    }
    let backoffMs = 2000
    while (!this.stopped) {
      try {
        const updates = await this._call('getUpdates', {
          offset: this.offset,
          timeout: POLL_TIMEOUT_S,
          allowed_updates: ['message', 'callback_query', 'pre_checkout_query']
        }, (POLL_TIMEOUT_S + 10) * 1000)
        backoffMs = 2000
        this._conflicts = 0
        for (const update of updates) {
          this.offset = Math.max(this.offset, update.update_id + 1)
          try {
            await this._handle(update)
          } catch (error) {
            console.error('Store | Erro processando update:', error)
          }
        }
      } catch (error) {
        if (this.stopped || error.silent) {
          break
        }
        if (error.conflict) {
          this._conflicts += 1
          if (this._conflicts === 1) {
            console.warn(
              'Store | Telegram 409 Conflict: OUTRO processo já faz getUpdates com este token ' +
              '(o site da loja, uma cópia antiga deste servidor ou uma hospedagem externa). ' +
              `Disputando a cada ${Math.round(this.conflictBackoffMs / 1000)}s por até ${this.conflictLimit} tentativas; ` +
              'para nunca poll-lo aqui, defina Store.BotPolling=false no config.json.'
            )
          }
          if (this._conflicts >= this.conflictLimit) {
            console.error(
              `Store | Conflito de polling persistiu por ${this._conflicts} tentativas — ` +
              'este processo CEDE o token e para o bot (o jogo e a loja seguem normais). ' +
              'Elimine o outro poller e reinicie para que este assuma.'
            )
            break
          }
          await this._sleep(this.conflictBackoffMs)
          continue
        }
        if (error.fatal) {
          console.error('Store | Token do Telegram inválido ou revogado — bot desligado:', error.message)
          break
        }
        console.warn('Store | Polling do Telegram falhou:', error.message)
        await this._sleep(backoffMs)
        backoffMs = Math.min(backoffMs * 2, 60000)
      }
    }
    this.stopped = true
  }

  stop () {
    this.stopped = true
    if (this.abortController) {
      this.abortController.abort()
    }
    return this._loop || Promise.resolve()
  }

  _hookSignals () {
    if (this._signalsHooked) {
      return
    }
    this._signalsHooked = true
    // SIGINT já é tratado pelo main.js (process.exit) — aqui só abortamos o
    // long-poll para o término ser imediato. Como usamos `once`, o process.exit
    // do main segue intacto.
    const abort = () => {
      this.stopped = true
      if (this.abortController) {
        this.abortController.abort()
      }
    }
    // SIGINT continua encerrando pelo handler do main.js; aqui só liberamos
    // o long-poll para o término ser imediato. No SIGTERM, como QUALQUER
    // listener suprime o encerramento padrão, re-emitimos o sinal depois de
    // abortar (`once` já nos removeu → cai no comportamento default).
    process.once('SIGINT', abort)
    process.once('SIGTERM', () => {
      abort()
      process.kill(process.pid, 'SIGTERM')
    })
  }

  _state (userId) {
    return this.stateByUser.get(userId) || null
  }

  _setState (userId, state) {
    if (state === null) {
      this.stateByUser.delete(userId)
    } else {
      this.stateByUser.set(userId, state)
    }
  }

  async _handle (update) {
    if (update.pre_checkout_query) {
      return this._handlePreCheckout(update.pre_checkout_query)
    }
    if (update.callback_query) {
      return this._handleCallback(update.callback_query)
    }
    const message = update.message
    if (!message || !message.from) {
      return
    }
    if (message.successful_payment) {
      return this._handlePayment(message)
    }
    const text = String(message.text || '').trim()
    const userId = message.from.id
    const chatId = message.chat.id

    const pending = this._state(userId)
    if (pending && text && !text.startsWith('/')) {
      return this._continueState(message, pending, text)
    }

    if (text.startsWith('/start')) {
      this._setState(userId, null)
      return this._send(chatId,
        '<b>Lakey Store</b> 🛒\n\n' +
        '• /gift — trocar Estrelas por gift card de saldo ($0.40 por estrela)\n' +
        `• Resgate o código em: ${this.config.PublicUrl}\n\n` +
        'Para vincular sua conta do jogo, digite <b>/loja</b> no chat do clube.'
      )
    }
    if (text.startsWith('/gift')) {
      this._setState(userId, { kind: 'gift_amount' })
      return this._send(chatId, 'Enter the number of stars:', {
        reply_markup: { force_reply: true, selective: true }
      })
    }
    if (text.startsWith('/cancel')) {
      this._setState(userId, null)
      return this._send(chatId, 'Operação cancelada.')
    }
    if (text.startsWith('/addoffer')) {
      if (!this.isAdmin(userId)) {
        return this._send(chatId, 'Comando restrito ao administrador.')
      }
      return this._offerWizardStart(chatId, userId)
    }
    if (text.startsWith('/deloffer')) {
      if (!this.isAdmin(userId)) {
        return this._send(chatId, 'Comando restrito ao administrador.')
      }
      const sku = text.split(/\s+/)[1] || ''
      if (!sku) {
        return this._send(chatId, 'Use: /deloffer <sku>')
      }
      const removed = StoreCatalog.remove_offer(sku)
      return this._send(chatId, removed ? `Oferta <code>${sku}</code> removida.` : 'SKU não encontrado (ou não é lakeystore.*).')
    }
    if (text.startsWith('/ofertas')) {
      if (!this.isAdmin(userId)) {
        return this._send(chatId, 'Comando restrito ao administrador.')
      }
      const offers = StoreCatalog.list()
      const lines = offers.map((offer) =>
        `• <code>${offer.sku}</code> — ${offer.title} — ${(offer.priceCents / 100).toFixed(2)} USD`
      )
      return this._send(chatId, `<b>Catálogo (${offers.length}):</b>\n` + (lines.join('\n') || 'vazio'))
    }
    if (text.startsWith('/gerar')) {
      if (!this.isAdmin(userId)) {
        return this._send(chatId, 'Comando restrito ao administrador.')
      }
      const dollars = this._parseMoney(text.split(/\s+/)[1] || '')
      if (!dollars) {
        return this._send(chatId, 'Use: /gerar 10  (gera gift card de $10.00, sem gastar estrelas)')
      }
      const card = this.store.createGiftCardCents(userId, dollars)
      return this._sendCard(chatId, card, 0, true)
    }
    return this._send(chatId, 'Comandos: /gift para comprar saldo em Estrelas.')
  }

  async _continueState (message, pending, text) {
    const userId = message.from.id
    const chatId = message.chat.id

    if (pending.kind === 'gift_amount') {
      const stars = Number.parseInt(text, 10)
      if (Number.isNaN(stars) || stars < 1 || stars > 1000000 || String(stars) !== text.trim()) {
        return this._send(chatId, 'Valor inválido. Envie um número inteiro positivo, por exemplo: 25', {
          reply_markup: { force_reply: true, selective: true }
        })
      }
      this._setState(userId, null)
      if (this.isAdmin(userId)) {
        const card = this.store.createGiftCard(userId, stars)
        return this._sendCard(chatId, card, stars, true)
      }
      return this._sendInvoice(chatId, userId, stars)
    }

    if (pending.kind === 'offer_amount') {
      const amount = Number.parseInt(text, 10)
      if (Number.isNaN(amount) || amount < 1 || amount > 100000) {
        return this._send(chatId, 'Quantidade inválida (1 a 100000).')
      }
      pending.draft.amount = amount
      return this._offerWizardTitle(chatId, userId, pending)
    }
    if (pending.kind === 'offer_brawler') {
      const id = StoreCatalog.brawler_id_by_name(text)
      if (id === null) {
        const sample = StoreCatalog.brawler_names().slice(0, 8).join(', ')
        return this._send(chatId, `Brawler desconhecido. Exemplos: <code>${sample}</code>`)
      }
      pending.draft.brawler = [16, id]
      pending.draft.brawlerName = text
      return this._offerWizardTitle(chatId, userId, pending)
    }
    if (pending.kind === 'offer_title') {
      const title = text.trim()
      if (!title || title.length > 60) {
        return this._send(chatId, 'Título inválido (máx. 60 caracteres).')
      }
      pending.draft.title = title
      return this._offerWizardPrice(chatId, userId, pending)
    }
    if (pending.kind === 'offer_price') {
      const cents = this._parseMoney(text)
      if (!cents) {
        return this._send(chatId, 'Preço inválido. Exemplos: 5  |  9.99  |  12,50')
      }
      pending.draft.priceCents = cents
      return this._offerWizardConfirm(chatId, userId, pending)
    }
  }

  _parseMoney (value) {
    const normalized = String(value || '').trim().replace(',', '.').replace('$', '')
    const parsed = Number(normalized)
    if (Number.isNaN(parsed) || !Number.isFinite(parsed) || parsed <= 0 || parsed > 100000) {
      return null
    }
    return Math.round(parsed * 100)
  }

  async _sendCard (chatId, card, stars, free) {
    const value = (card.cents / 100).toFixed(2)
    const note = free
      ? ' (cortesia — sem cobrança de estrelas)'
      : ' (' + stars + ' estrelas)'
    return this._send(chatId,
      '🎁 <b>Gift card gerado!</b>\n\n' +
      `Código: <code>${card.code}</code>\n` +
      `Valor: <b>$${value}</b>${note}\n\n` +
      `Resgate em ${this.config.PublicUrl} tocando em <b>Add balance</b>.\n` +
      '⚠️ O código é de <b>uso único</b>.'
    )
  }

  // ---------- pagamento em Estrelas ----------

  _sendInvoice (chatId, userId, stars) {
    const cents = stars * this.config.StarCents
    const payload = `gift:${stars}:${crypto.randomBytes(6).toString('hex')}`
    return this._call('sendInvoice', {
      chat_id: chatId,
      title: 'Saldo Lakey Store',
      description: `Gift card de $${(cents / 100).toFixed(2)} em saldo da loja`,
      payload,
      currency: 'XTR',
      prices: [{ label: 'Estrelas', amount: stars }]
    }).then(() => {
      this._send(chatId, `Confirme o pagamento de ${stars}⭐ para receber o gift card de <b>$${(cents / 100).toFixed(2)}</b>.`)
      return null
    }).catch((error) => {
      console.error('Store | sendInvoice falhou:', error)
      this._send(chatId, 'Não consegui criar a cobrança. Tente novamente em instantes.')
    })
  }

  async _handlePreCheckout (query) {
    try {
      await this._call('answerPreCheckoutQuery', {
        pre_checkout_query_id: query.id,
        ok: true
      })
    } catch (error) {
      console.error('Store | answerPreCheckoutQuery falhou:', error)
    }
  }

  async _handlePayment (message) {
    const payment = message.successful_payment
    const userId = message.from.id
    const chatId = message.chat.id
    if (String(payment.currency) !== 'XTR') {
      return this._send(chatId, 'Pagamento recebido em moeda inesperada — contate o suporte.')
    }
    let stars = Math.trunc(payment.total_amount)
    const parts = String(payment.invoice_payload || '').split(':')
    if (parts[0] === 'gift') {
      const declared = Number.parseInt(parts[1], 10)
      if (!Number.isNaN(declared)) {
        stars = Math.min(stars, declared)
      }
    }
    if (stars < 1) {
      return this._send(chatId, 'Pagamento sem estrelas válidas — contate o suporte.')
    }
    try {
      const card = this.store.createGiftCard(userId, stars)
      this.store._audit(null, userId, 'stars_payment', `${stars}⭐ txn=${payment.telegram_payment_charge_id || ''}`)
      return this._sendCard(chatId, card, stars, false)
    } catch (error) {
      console.error('Store | Falha ao gerar gift card pós-pagamento:', error)
      return this._send(chatId,
        `Pagamento confirmado, mas houve erro ao gerar o código. ` +
        `Fale com o suporte informando: <code>${String(payment.telegram_payment_charge_id || '')}</code>`
      )
    }
  }

  // ---------- wizard /addoffer ----------

  _offerWizardStart (chatId, userId) {
    const kinds = StoreCatalog.KINDS
    const keyboard = Object.entries(kinds).map(([key, def]) => ([{
      text: def.label,
      callback_data: `of_kind:${key}`
    }]))
    this._setState(userId, { kind: 'offer_wait_kind', draft: {} })
    return this._send(chatId,
      '<b>Nova oferta paga</b> (tipo lakeystore — saldo do site)\nSelecione o tipo de recompensa:', {
        reply_markup: { inline_keyboard: keyboard }
      }
    )
  }

  _handleCallback (query) {
    const userId = query.from.id
    const chatId = query.message.chat.id
    const data = String(query.data || '')
    this._call('answerCallbackQuery', { callback_query_id: query.id }).catch(() => {})
    if (!this.isAdmin(userId)) {
      return this._send(chatId, 'Ação restrita ao administrador.')
    }
    const pending = this._state(userId)
    if (data.startsWith('of_kind:')) {
      const key = data.split(':')[1]
      if (!StoreCatalog.KINDS[key]) {
        return null
      }
      const def = StoreCatalog.KINDS[key]
      const draft = { kind: key, image: def.image }
      if (key === 'brawler' || key === 'power_points') {
        this._setState(userId, { kind: 'offer_brawler', draft })
        return this._send(chatId,
          'Nome interno do brawler (ex.: <code>Mechanic</code>, <code>ShotgunGirl</code>).\n' +
          'Use /cancel para abortar.')
      }
      this._setState(userId, { kind: 'offer_amount', draft })
      return this._send(chatId, `Quantidade de <b>${def.label}</b> por unidade:`)
    }
    if (data.startsWith('of_repeat:')) {
      if (!pending || pending.kind !== 'offer_wait_repeat') {
        return null
      }
      pending.draft.oneTime = data.split(':')[1] === 'no'
      return this._offerWizardCreate(chatId, userId, pending)
    }
    if (data === 'of_cancel') {
      this._setState(userId, null)
      return this._send(chatId, 'Criação de oferta cancelada.')
    }
    return null
  }

  _offerWizardTitle (chatId, userId, pending) {
    this._setState(userId, { kind: 'offer_title', draft: pending.draft })
    return this._send(chatId, 'Título exibido na loja (ex.: <code>170 Gemas</code>):')
  }

  _offerWizardPrice (chatId, userId, pending) {
    this._setState(userId, { kind: 'offer_price', draft: pending.draft })
    return this._send(chatId, 'Preço em dólar (ex.: <code>9.99</code>):')
  }

  async _offerWizardConfirm (chatId, userId, pending) {
    this._setState(userId, { kind: 'offer_wait_repeat', draft: pending.draft })
    return this._send(chatId,
      'Essa oferta pode ser comprada <b>várias vezes</b> pela mesma conta?', {
        reply_markup: {
          inline_keyboard: [[
            { text: 'Sim, repetível', callback_data: 'of_repeat:yes' },
            { text: 'Não — 1x por conta', callback_data: 'of_repeat:no' }
          ], [{ text: 'Cancelar', callback_data: 'of_cancel' }]]
        }
      }
    )
  }

  async _offerWizardCreate (chatId, userId, pending) {
    this._setState(userId, null)
    const draft = pending.draft
    try {
      const offer = StoreCatalog.create_offer(userId, {
        kind: draft.kind,
        amount: draft.amount || 1,
        brawler: draft.brawler || null,
        title: draft.title,
        priceCents: draft.priceCents,
        image: draft.image,
        oneTime: draft.oneTime
      })
      return this._send(chatId,
        '✅ <b>Oferta registrada!</b>\n\n' +
        `SKU: <code>${offer.sku}</code>\n` +
        `Título: ${offer.title}\n` +
        `Preço: <b>$${(offer.priceCents / 100).toFixed(2)}</b>\n` +
        `Itens: ${offer.items.map((item) => `${item.offerId}x${item.amount}`).join(', ')}\n\n` +
        'Já disponível no site. Para aparecer como tile novo no APK, inclua a linha Type 4 no rebuild (docs/LOJA.md).'
      )
    } catch (error) {
      const msg = error instanceof StoreError ? error.message : String(error.message || error)
      return this._send(chatId, `Falha ao criar oferta: ${msg}`)
    }
  }
}

module.exports = TelegramBot
