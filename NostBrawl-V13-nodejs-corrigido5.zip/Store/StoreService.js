'use strict'

const crypto = require('crypto')
const http = require('http')

const Hmac = require('./Hmac')

const StoreCatalog = require('./StoreCatalog')
const StoreConfig = require('./StoreConfig')
const StoreDB = require('./StoreDB')
const Delivery = require('./Delivery')
const { RewardError } = require('../Logic/Rewards')

class StoreError extends Error {
  constructor (message) {
    super(message)
    this.name = 'StoreError'
  }
}

const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'

function randomCode (groups) {
  const bytes = crypto.randomBytes(groups * 4)
  const parts = []
  for (let g = 0; g < groups; g++) {
    let part = ''
    for (let i = 0; i < 4; i++) {
      part += CODE_ALPHABET[bytes[g * 4 + i] % CODE_ALPHABET.length]
    }
    parts.push(part)
  }
  return parts.join('-')
}

function randomToken (length) {
  const bytes = crypto.randomBytes(length)
  let out = ''
  for (let i = 0; i < length; i++) {
    out += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length]
  }
  return out
}

class StoreService {
  constructor () {
    this.config = StoreConfig.load()
    this.store = new StoreDB(this.config.DatabasePath)
    this.server = null
  }

  attach (server) {
    this.server = server
    return this
  }

  _audit (lowId, tgId, action, detail) {
    try {
      this.store.db.prepare(
        'INSERT INTO audit (at, low_id, tg_id, action, detail) VALUES (?, ?, ?, ?, ?)'
      ).run(this.store.now(), lowId || null, tgId || null, String(action), String(detail || ''))
    } catch (error) {
      /* auditoria nunca derruba o fluxo */
    }
  }

  // ---------- identidade: intent -> ticket (sem digitar código) ----------
  //
  // createIntent é chamado pelo APK patcheado (patch C): o app envia u/t
  // (identidade do billing, campos A/B da classe `l`) + sku. A prova FORTE é
  // t == token da conta, ou IP do clique == IP da conexão ativa do protocolo.
  // Só então nasce o ticket (uso único, 5 min) que o site troca por sessão.
  // O jogador não digita nada.

  _online_ip (lowId) {
    try {
      const registry = this.server && this.server.Clients && this.server.Clients.Clients
      const entry = registry ? registry[String(lowId)] : null
      if (entry && entry.SocketInfo && entry.SocketInfo.remoteAddress) {
        return String(entry.SocketInfo.remoteAddress)
      }
    } catch (error) {
      /* offline */
    }
    return null
  }

  _account_row (lowId) {
    const DataBase = require('../Database/DatabaseManager')
    return DataBase._connection((connection) =>
      connection.prepare('SELECT token, name FROM players WHERE lowID = ?').get(lowId)
    ) || null
  }

  _parse_low_id (raw) {
    const text = String(raw === undefined || raw === null ? '' : raw).trim()
    if (!text) {
      return 0
    }
    const direct = Number.parseInt(text, 10)
    if (!Number.isNaN(direct) && String(direct) === text && direct > 0) {
      return direct
    }
    const pieces = text.split(/[^0-9]+/).filter((piece) => piece)
    for (const piece of pieces.reverse()) {
      const candidate = Number.parseInt(piece, 10)
      if (!Number.isNaN(candidate) && candidate > 0 && this._account_row(candidate)) {
        return candidate
      }
    }
    return 0
  }

  proofOf (accountToken) {
    return crypto.createHash('sha256')
      .update('lakeystore-link:' + String(accountToken))
      .digest('hex')
  }

  createIntent (body, ip) {
    const sku = String((body && body.sku) || '')
    const offer = sku ? StoreCatalog.find(sku) : null
    if (sku && !offer) {
      throw new StoreError('Oferta desconhecida')
    }
    // O patch do APK envia os campos A/B do objeto de billing — a ordem pode
    // variar entre builds, então aceitamos (u=id, t=token) OU (u=token, t=id).
    let lowId = this._parse_low_id(body && body.u)
    let tokenClaim = String((body && body.t) || '')
    let swapped = false
    if (lowId < 1 || !this._account_row(lowId)) {
      const alt = this._parse_low_id(body && body.t)
      if (alt > 0 && this._account_row(alt)) {
        lowId = alt
        tokenClaim = String((body && body.u) || '')
        swapped = true
      }
    }
    if (lowId < 1) {
      throw new StoreError('Conta não identificada')
    }
    const row = this._account_row(lowId)
    if (!row) {
      throw new StoreError('Conta não encontrada')
    }
    void swapped
    let strong = false
    if (tokenClaim && tokenClaim === String(row.token)) {
      strong = true
    } else if (this.proofOf(row.token) === tokenClaim.toLowerCase()) {
      strong = true
    }
    if (!strong && ip) {
      const onlineIp = this._online_ip(lowId)
      if (onlineIp && onlineIp === ip) {
        strong = true
      }
    }
    if (!strong) {
      this._audit(lowId, null, 'intent_rejected', `${sku} ip=${ip}`)
      throw new StoreError('Não foi possível confirmar sua conta. Feche, abra o jogo e toque no pacote de novo.')
    }
    const db = this.store.db
    const now = this.store.now()
    const expires = now + this.config.TicketMinutes * 60
    let ticket = crypto.randomBytes(24).toString('hex')
    while (true) {
      const inserted = db.prepare(
        'INSERT OR IGNORE INTO tickets (ticket, low_id, name, sku, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)'
      ).run(ticket, lowId, String(row.name || ''), sku, now, expires)
      if (inserted.changes === 1) {
        break
      }
      ticket = crypto.randomBytes(24).toString('hex')
    }
    this._audit(lowId, null, 'intent', `${sku} ip=${ip}`)
    this._push_ticket(ticket, lowId, String(row.name || ''), sku)
    const query = `?t=${ticket}` + (sku ? `&pack=${encodeURIComponent(sku)}` : '')
    return { ticket, url: this.config.PublicUrl + '/' + query, lowId }
  }

  // Disparado quando o jogador clica em um pacote na loja.
  // Pode vir via pacote 10160 (BuyBillingPackageMessage) ou via pacote
  // 10110 (AnalyticsEventMessage - InAppPurchase purchasing / transactionstarted).
  handleShopClick (client, player, rawSku, source = 'protocol') {
    const sku = String(rawSku || '').trim()
    if (!sku) {
      return
    }
    const lowId = player && (player.lowID ?? player.low_id)
    if (!lowId) {
      return
    }

    // Debounce de 2.5s por jogador para evitar duplicações quando
    // 10110 e 10160 chegam juntos ou 'purchasing' + 'transactionstarted' chegam em sequência.
    const now = Date.now()
    if (player._lastStoreClickTime && (now - player._lastStoreClickTime < 2500) && player._lastStoreSku === sku) {
      return
    }
    player._lastStoreClickTime = now
    player._lastStoreSku = sku

    const packages = require('../Logic/ShopCatalog').billing_packages()
    const info = packages[sku] && !packages[sku].disabled ? packages[sku] : null
    const finalSku = info ? info.name : sku
    const remoteIp = (client && (client.remoteAddress || (client.SocketInfo && client.SocketInfo.remoteAddress))) || null

    try {
      this.createGameIntent(lowId, finalSku, remoteIp)
      console.log(`Store | Pacote tocado [${source}]: ${finalSku} (conta ${lowId}, ip ${remoteIp || '?'}) — ticket enviado ao site`)
    } catch (error) {
      console.warn(`Store | Falha ao registrar intenção de compra [${source}]:`, error.message)
    }
  }

  // Intenção vinda do protocolo (mensagem 10160 — toque num pacote pago).
  // A conexão autenticada já é a prova de identidade: o ticket nasce ligado
  // ao lowId real e leva o IP da sessão para o resgate por IP no site.
  createGameIntent (lowId, sku, explicitIp) {
    lowId = Math.trunc(Number(lowId) || 0)
    if (lowId < 1) {
      throw new StoreError('Conta inválida')
    }
    sku = String(sku || '')
    const db = this.store.db
    const now = this.store.now()
    const expires = now + this.config.TicketMinutes * 60
    const name = String((this._account_row(lowId) || {}).name || '')
    let ticket = crypto.randomBytes(24).toString('hex')
    while (true) {
      const inserted = db.prepare(
        'INSERT OR IGNORE INTO tickets (ticket, low_id, name, sku, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)'
      ).run(ticket, lowId, name, sku, now, expires)
      if (inserted.changes === 1) {
        break
      }
      ticket = crypto.randomBytes(24).toString('hex')
    }
    const ip = explicitIp || this._online_ip(lowId)
    this._audit(lowId, null, 'game_intent', `${sku || '-'} ip=${ip}`)
    this._push_ticket(ticket, lowId, name, sku, ip)
    const query = `?t=${ticket}` + (sku ? `&pack=${encodeURIComponent(sku)}` : '')
    return { ticket, url: this.config.PublicUrl + '/' + query, lowId }
  }

  _push_ticket (ticket, lowId, name, sku, ip) {
    const target = this.config.SiteInternalUrl
    const key = this.config.InternalKey
    if (!target || !key) {
      return
    }
    const path = '/internal/store/v1/ticket'
    const body = Buffer.from(JSON.stringify({
      ticket, low_id: lowId, name, sku, ip: ip || '',
      expires_in: this.config.TicketMinutes * 60
    }), 'utf-8')
    const headers = Object.assign(Hmac.headers(key, 'POST', path, body), {
      'Content-Length': body.length
    })
    const request = http.request(target + path, { method: 'POST', headers, timeout: 8000 }, (res) => {
      res.resume()
      if (res.statusCode !== 200) {
        console.warn(`Store | Push de ticket ao site falhou: HTTP ${res.statusCode}`)
      }
    })
    request.on('timeout', () => request.destroy(new Error('timeout')))
    request.on('error', (error) => {
      console.warn(`Store | Push de ticket ao site falhou: ${error.message}`)
    })
    request.end(body)
  }

  consumeTicket (ticket) {
    ticket = String(ticket || '').toLowerCase()
    if (!/^[0-9a-f]{48}$/.test(ticket)) {
      throw new StoreError('Ticket inválido')
    }
    const db = this.store.db
    const now = this.store.now()
    db.exec('BEGIN IMMEDIATE')
    try {
      const row = db.prepare(
        'SELECT ticket, low_id, name, sku, expires_at, consumed_at FROM tickets WHERE ticket = ?'
      ).get(ticket)
      if (!row || row.consumed_at !== null || row.expires_at < now) {
        db.exec('ROLLBACK')
        throw new StoreError('Sessão expirada. Toque no pacote dentro do jogo novamente.')
      }
      db.prepare('UPDATE tickets SET consumed_at = ? WHERE ticket = ?').run(now, ticket)
      const token = crypto.randomBytes(32).toString('hex')
      const expires = now + this.config.SessionDays * 86400
      db.prepare(
        'INSERT INTO sessions (token, low_id, name, created_at, expires_at) VALUES (?, ?, ?, ?, ?)'
      ).run(token, row.low_id, row.name, now, expires)
      db.prepare(
        'INSERT OR IGNORE INTO wallets (low_id, balance_cents, created_at, updated_at) VALUES (?, 0, ?, ?)'
      ).run(row.low_id, now, now)
      db.exec('COMMIT')
      return { session: token, lowId: row.low_id, name: row.name, sku: row.sku }
    } catch (error) {
      try { db.exec('ROLLBACK') } catch (e) { /* já desfeito */ }
      if (error instanceof StoreError) {
        throw error
      }
      throw new StoreError('Falha ao abrir a sessão')
    }
  }

  // Entrega remota idempotente (site hospedado em outro host).
  deliverRemote (body) {
    const orderKey = String((body && body.order_key) || '')
    const lowId = Math.trunc(Number((body && body.low_id) || 0))
    const items = (body && Array.isArray(body.items)) ? body.items : null
    if (!orderKey || orderKey.length > 64 || lowId < 1 || !items || !items.length || items.length > 3) {
      throw new StoreError('Pedido de entrega inválido')
    }
    const db = this.store.db
    const seen = db.prepare('SELECT order_key FROM deliveries WHERE order_key = ?').get(orderKey)
    if (seen) {
      return { ok: true, replay: true }
    }
    const offer = { items: items.map((item) => ({
      offerId: Math.trunc(Number(item.offerId)),
      amount: Math.trunc(Number(item.amount)),
      value: Math.trunc(Number(item.value || 0)),
      target: Array.isArray(item.target) ? [Math.trunc(item.target[0]), Math.trunc(item.target[1])] : null
    })) }
    const result = Delivery.deliver(this.server, lowId, offer)
    db.prepare(
      'INSERT INTO deliveries (order_key, low_id, items_json, delivered_at) VALUES (?, ?, ?, ?)'
    ).run(orderKey, lowId, JSON.stringify(offer.items), this.store.now())
    this._audit(lowId, null, 'deliver_remote', orderKey)
    return { ok: true, replay: false, online: result.online === true }
  }

  getSession (token) {
    token = String(token || '')
    if (!token) {
      return null
    }
    const row = this.store.db.prepare(
      'SELECT token, low_id, name, expires_at FROM sessions WHERE token = ?'
    ).get(token)
    if (!row || row.expires_at < this.store.now()) {
      return null
    }
    return { lowId: row.low_id, name: row.name }
  }

  logout (token) {
    this.store.db.prepare('DELETE FROM sessions WHERE token = ?').run(String(token || ''))
  }

  // ---------- carteira ----------

  getBalanceCents (lowId) {
    const row = this.store.db.prepare(
      'SELECT balance_cents FROM wallets WHERE low_id = ?'
    ).get(Math.trunc(lowId))
    return row ? row.balance_cents : 0
  }

  // ---------- gift cards ----------

  createGiftCard (byTgId, stars) {
    stars = Math.trunc(Number(stars))
    if (!Number.isFinite(stars) || stars < 1 || stars > 1000000) {
      throw new StoreError('Quantidade de estrelas inválida')
    }
    const cents = stars * this.config.StarCents
    return this.createGiftCardCents(byTgId, cents, stars)
  }

  createGiftCardCents (byTgId, cents, stars = 0) {
    cents = Math.trunc(Number(cents))
    if (!Number.isFinite(cents) || cents < 1 || cents > 100000000) {
      throw new StoreError('Valor de gift card inválido')
    }
    const db = this.store.db
    const now = this.store.now()
    let code = randomCode(3)
    while (true) {
      const inserted = db.prepare(
        'INSERT OR IGNORE INTO giftcards (code, cents, stars, created_by, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(code, cents, Math.trunc(stars) || 0, Math.trunc(byTgId) || 0, now)
      if (inserted.changes === 1) {
        break
      }
      code = randomCode(3)
    }
    this._audit(null, byTgId, 'giftcard_created', `${code}=${cents}¢`)
    return { code, cents }
  }

  redeemGiftCard (lowId, code) {
    lowId = Math.trunc(lowId)
    code = String(code || '').trim().toUpperCase()
    const db = this.store.db
    const now = this.store.now()
    db.exec('BEGIN IMMEDIATE')
    try {
      const update = db.prepare(
        'UPDATE giftcards SET redeemed_by = ?, redeemed_at = ? WHERE code = ? AND redeemed_by IS NULL'
      ).run(lowId, now, code)
      if (update.changes !== 1) {
        db.exec('ROLLBACK')
        throw new StoreError('Código inválido ou já resgatado')
      }
      const card = db.prepare('SELECT cents FROM giftcards WHERE code = ?').get(code)
      db.prepare(
        'INSERT INTO wallets (low_id, balance_cents, created_at, updated_at) VALUES (?, 0, ?, ?) ' +
        'ON CONFLICT(low_id) DO NOTHING'
      ).run(lowId, now, now)
      db.prepare(
        'UPDATE wallets SET balance_cents = balance_cents + ?, updated_at = ? WHERE low_id = ?'
      ).run(card.cents, now, lowId)
      const balance = this.getBalanceCents(lowId)
      db.exec('COMMIT')
      this._audit(lowId, null, 'giftcard_redeemed', `${code}=+${card.cents}¢`)
      return { creditedCents: card.cents, balanceCents: balance }
    } catch (error) {
      try { db.exec('ROLLBACK') } catch (e) { /* já desfeito */ }
      if (error instanceof StoreError) {
        throw error
      }
      throw error
    }
  }

  // ---------- compras ----------

  purchase (lowId, sku, orderKey) {
    lowId = Math.trunc(lowId)
    sku = String(sku || '')
    orderKey = String(orderKey || '')
    if (!orderKey || orderKey.length > 64) {
      throw new StoreError('Pedido inválido')
    }
    const offer = StoreCatalog.find(sku)
    if (!offer) {
      throw new StoreError('Oferta não encontrada')
    }
    const db = this.store.db
    const now = this.store.now()

    // Replay idempotente: mesma order_key devolve o mesmo resultado.
    const existing = db.prepare(
      'SELECT order_key, status, error FROM orders WHERE order_key = ?'
    ).get(orderKey)
    if (existing) {
      if (existing.status === 'delivered') {
        return {
          orderKey,
          sku,
          balanceCents: this.getBalanceCents(lowId),
          delivered: true,
          replay: true
        }
      }
      if (existing.status === 'pending') {
        throw new StoreError('Pedido em processamento. Aguarde alguns segundos e recarregue.')
      }
      throw new StoreError(`Pedido falhou: ${existing.error || 'erro desconhecido'}`)
    }

    db.exec('BEGIN IMMEDIATE')
    try {
      if (offer.oneTime) {
        const already = db.prepare(
          "SELECT COUNT(*) AS total FROM orders WHERE low_id = ? AND sku = ? AND status = 'delivered'"
        ).get(lowId, sku)
        if (already.total > 0) {
          db.exec('ROLLBACK')
          throw new StoreError('Esse pacote já foi adquirido nesta conta')
        }
      }
      const inserted = db.prepare(
        "INSERT INTO orders (order_key, low_id, sku, cents, items_json, status, created_at) " +
        "VALUES (?, ?, ?, ?, ?, 'pending', ?)"
      ).run(orderKey, lowId, sku, offer.priceCents, JSON.stringify(offer.items), now)
      if (inserted.changes !== 1) {
        db.exec('ROLLBACK')
        throw new StoreError('Pedido duplicado')
      }
      const debited = db.prepare(
        'UPDATE wallets SET balance_cents = balance_cents - ?, updated_at = ? ' +
        'WHERE low_id = ? AND balance_cents >= ?'
      ).run(offer.priceCents, now, lowId, offer.priceCents)
      if (debited.changes !== 1) {
        db.exec('ROLLBACK')
        throw new StoreError('Saldo insuficiente. Toque em "Add balance" para adicionar saldo.')
      }
      db.exec('COMMIT')
    } catch (error) {
      try { db.exec('ROLLBACK') } catch (e) { /* já desfeito */ }
      if (error instanceof StoreError) {
        throw error
      }
      throw error
    }

    try {
      const delivered = Delivery.deliver(this.server, lowId, offer)
      db.prepare(
        "UPDATE orders SET status = 'delivered', delivered_at = ? WHERE order_key = ?"
      ).run(this.store.now(), orderKey)
      this._audit(lowId, null, 'purchase', `${sku} -${offer.priceCents}¢ online=${delivered.online}`)
      return {
        orderKey,
        sku,
        title: offer.title,
        balanceCents: this.getBalanceCents(lowId),
        delivered: true,
        online: delivered.online,
        replay: false
      }
    } catch (error) {
      const message = (error instanceof RewardError) ? error.message : 'Falha na entrega'
      db.prepare(
        "UPDATE orders SET status = 'failed', error = ?, delivered_at = ? WHERE order_key = ?"
      ).run(String(message), this.store.now(), orderKey)
      // estorno: entrega falhou, devolve o valor
      db.prepare(
        'UPDATE wallets SET balance_cents = balance_cents + ?, updated_at = ? WHERE low_id = ?'
      ).run(offer.priceCents, this.store.now(), lowId)
      this._audit(lowId, null, 'purchase_failed', `${sku}: ${message} (estornado)`)
      throw new StoreError(`Compra falhou (${message}). Valor estornado no seu saldo.`)
    }
  }

  // Reconciliação de boot: pedidos 'pending' travados (crash entre débito e
  // entrega) são reentregues uma única vez.
  reconcile () {
    const db = this.store.db
    let rows
    try {
      rows = db.prepare("SELECT order_key, low_id, sku FROM orders WHERE status = 'pending'").all()
    } catch (error) {
      return 0
    }
    let recovered = 0
    for (const row of rows) {
      try {
        const offer = StoreCatalog.find(row.sku)
        if (!offer) {
          db.prepare("UPDATE orders SET status = 'failed', error = 'oferta removida' WHERE order_key = ?")
            .run(row.order_key)
          continue
        }
        Delivery.deliver(this.server, row.low_id, offer)
        db.prepare(
          "UPDATE orders SET status = 'delivered', delivered_at = ? WHERE order_key = ?"
        ).run(this.store.now(), row.order_key)
        recovered += 1
      } catch (error) {
        db.prepare(
          "UPDATE orders SET status = 'failed', error = ? WHERE order_key = ?"
        ).run(String(error.message || error), row.order_key)
      }
    }
    if (recovered) {
      console.log(`Store | ${recovered} pedido(s) pendente(s) reentregue(s)`)
    }
    return recovered
  }

  ordersOf (lowId, limit = 10) {
    return this.store.db.prepare(
      'SELECT order_key, sku, cents, status, created_at FROM orders WHERE low_id = ? ORDER BY created_at DESC LIMIT ?'
    ).all(Math.trunc(lowId), Math.min(50, Math.max(1, Math.trunc(limit))))
  }
}

module.exports = { StoreService, StoreError }
