'use strict'

const fs = require('fs')

const ShopCatalog = require('../Logic/ShopCatalog')
const { readDictRows } = require('../Files/CsvLogic/CsvRows')
const StoreConfig = require('./StoreConfig')

// Catálogo da loja web.
//
// Fontes (mesma identidade SKU nas duas):
//   1. billing_packages.csv — pacotes reais da v13 (Type 1 gema, 2/3 bundle).
//   2. JSON/store_catalog.json — ofertas do admin via bot (`lakeystore.*`).
//      Espelhadas como Type 4 no CSV do servidor (ver ANALISE-OFERTAS-PAGAS.md).
//
// Todo item de oferta passa por ShopCatalog.validate_item() — a mesma
// validação usada pelas ofertas em jogo.

const KIND_TO_ITEM = {
  gems: { offerId: 16, image: 'gems.png', needsAmount: true, label: 'Gemas' },
  brawl_box: { offerId: 6, image: 'brawl_box.png', needsAmount: true, label: 'Brawl Box' },
  big_box: { offerId: 10, image: 'brawl_box.png', needsAmount: true, label: 'Big Box' },
  mega_box: { offerId: 14, image: 'brawl_box.png', needsAmount: true, label: 'MEGA Box' },
  brawler: { offerId: 3, image: 'mystery.png', needsAmount: false, label: 'Brawler' },
  power_points: { offerId: 12, image: 'mystery.png', needsAmount: true, label: 'Power Points' }
}

class StoreCatalog {
  static get KINDS () { return KIND_TO_ITEM }

  static catalogPath () {
    return StoreConfig.load().CatalogPath
  }

  static _load_custom () {
    let raw = { offers: [] }
    try {
      if (fs.existsSync(StoreCatalog.catalogPath())) {
        raw = JSON.parse(fs.readFileSync(StoreCatalog.catalogPath(), 'utf-8'))
      }
    } catch (error) {
      console.warn('Store | store_catalog.json inválido, usando catálogo vazio', error)
      raw = { offers: [] }
    }
    if (!Array.isArray(raw.offers)) {
      raw.offers = []
    }
    return raw
  }

  static _save_custom (data) {
    fs.writeFileSync(
      StoreCatalog.catalogPath(),
      JSON.stringify({ offers: data.offers }, null, 2) + '\n'
    )
  }

  static slugify (value) {
    const slug = String(value || '')
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
    return slug || 'offer'
  }

  // Pacotes 1..3 do billing real -> ofertas do site mesmo SKU/USD
  static _billing_offers (now) {
    let packages
    try {
      packages = ShopCatalog.billing_packages()
    } catch (error) {
      packages = {}
    }
    const offers = []
    for (const pkg of Object.values(packages)) {
      if (pkg.disabled || !pkg.android) {
        continue
      }
      const row = StoreCatalog._csv_row(pkg.name)
      const usd = row ? StoreCatalog._int(row[7], 0) : 0
      if (usd < 1) {
        continue
      }
      const items = [{ offerId: 16, amount: pkg.diamonds, value: 0, target: null }]
      if (pkg.bigBoxCount > 0) {
        items.push({ offerId: 10, amount: pkg.bigBoxCount, value: 0, target: null })
      }
      offers.push({
        sku: pkg.name,
        title: pkg.bigBoxCount > 0
          ? `${pkg.diamonds} Gemas + ${pkg.bigBoxCount} BIGBOX`
          : `${pkg.diamonds} Gemas`,
        subtitle: pkg.bigBoxCount > 0 ? 'Pacote' : 'Gemas',
        image: pkg.bigBoxCount > 0 ? 'brawl_box.png' : 'gems.png',
        priceCents: usd,
        items,
        oneTime: [2, 3].includes(pkg.type),
        source: 'billing',
        order: StoreCatalog._int(pkg.order, 0)
      })
    }
    return offers
  }

  static _csv_row (name) {
    try {
      const rows = readDictRows('GameAssets/csv_client/billing_packages.csv').slice(1)
      for (const row of rows) {
        if ((row.Name || '') === name) {
          return StoreCatalog._row_values(row)
        }
      }
    } catch (error) {
      return null
    }
    return null
  }

  static _row_values (row) {
    const keys = [
      'Name', 'TID', 'Type', 'Disabled', 'ExistsApple', 'ExistsAndroid',
      'Diamonds', 'USD', 'Order', 'IconExportName', 'StarterPackNumber',
      'BigBoxCount', 'XpLevelReq', 'ValueFactor', 'Bg', 'Decor'
    ]
    return keys.map((key) => (row[key] !== undefined ? row[key] : ''))
  }

  static _custom_offers () {
    const data = StoreCatalog._load_custom()
    const offers = []
    for (const offer of data.offers) {
      try {
        offers.push(StoreCatalog._validate_custom(offer))
      } catch (error) {
        continue
      }
    }
    return offers
  }

  static _validate_custom (offer) {
    const sku = String(offer.sku || '')
    if (!sku.startsWith('lakeystore.')) {
      throw new Error('sku fora do namespace lakeystore')
    }
    const items = (offer.items || []).map((item) => ShopCatalog.validate_item(item))
    if (!items.length || items.length > 3) {
      throw new Error('oferta precisa de 1 a 3 itens')
    }
    const priceCents = StoreCatalog._int(offer.priceCents, -1)
    if (priceCents < 1) {
      throw new Error('preço inválido')
    }
    return {
      sku,
      title: String(offer.title || sku),
      subtitle: String(offer.subtitle || ''),
      image: String(offer.image || 'mystery.png'),
      priceCents,
      items,
      oneTime: offer.oneTime === true,
      source: 'lakeystore',
      order: StoreCatalog._int(offer.order, 1000)
    }
  }

  static list () {
    const offers = StoreCatalog._billing_offers().concat(StoreCatalog._custom_offers())
    offers.sort((a, b) => (a.order - b.order) || (a.priceCents - b.priceCents))
    return offers
  }

  static find (sku) {
    sku = String(sku || '')
    for (const offer of StoreCatalog.list()) {
      if (offer.sku === sku) {
        return offer
      }
    }
    return null
  }

  static create_offer (adminId, spec) {
    const kind = KIND_TO_ITEM[spec.kind]
    if (!kind) {
      throw new Error('Tipo de oferta desconhecido')
    }
    const amount = StoreCatalog._int(spec.amount, 0)
    const priceCents = StoreCatalog._int(spec.priceCents, 0)
    if (priceCents < 1) {
      throw new Error('Preço inválido')
    }
    const title = String(spec.title || '').trim()
    if (!title || title.length > 60) {
      throw new Error('Título inválido')
    }
    const item = { offerId: kind.offerId, amount: 1, value: 0, target: null }
    if (kind.needsAmount) {
      if (amount < 1 || amount > 100000) {
        throw new Error('Quantidade inválida')
      }
      item.amount = amount
    }
    if (kind.offerId === 3) {
      const brawlerRef = spec.brawler
      if (!Array.isArray(brawlerRef) || brawlerRef.length !== 2) {
        throw new Error('Brawler inválido')
      }
      item.target = [16, Math.trunc(brawlerRef[1])]
    }
    if (kind.offerId === 12) {
      const brawlerRef = spec.brawler
      if (!Array.isArray(brawlerRef) || brawlerRef.length !== 2) {
        throw new Error('Brawler inválido')
      }
      item.target = [16, Math.trunc(brawlerRef[1])]
    }
    const validated = ShopCatalog.validate_item(item)
    const data = StoreCatalog._load_custom()
    const skuBase = `lakeystore.${StoreCatalog.slugify(title)}`
    let sku = skuBase
    let suffix = 1
    const existing = new Set(
      StoreCatalog.list().map((offer) => offer.sku).concat(data.offers.map((offer) => offer.sku))
    )
    while (existing.has(sku)) {
      suffix += 1
      sku = `${skuBase}_${suffix}`
    }
    const entry = {
      sku,
      title,
      subtitle: kind.label,
      image: String(spec.image || kind.image),
      priceCents,
      order: 1000,
      oneTime: spec.oneTime === true,
      items: [validated],
      createdBy: Math.trunc(adminId) || 0,
      createdAt: Math.trunc(Date.now() / 1000)
    }
    data.offers.push(entry)
    StoreCatalog._save_custom(data)
    StoreCatalog._register_type4(entry)
    return StoreCatalog._validate_custom(entry)
  }

  static remove_offer (sku) {
    const data = StoreCatalog._load_custom()
    const before = data.offers.length
    data.offers = data.offers.filter((offer) => offer.sku !== sku)
    if (data.offers.length === before) {
      return false
    }
    StoreCatalog._save_custom(data)
    return true
  }

  // Registro Type 4 no billing_packages.csv do SERVIDOR (linha de registro,
  // invisível ao fulfillment Google por design — ver análise).
  static _register_type4 (offer) {
    try {
      const path = require('path')
      const csvPath = path.resolve('GameAssets/csv_client/billing_packages.csv')
      if (!fs.existsSync(csvPath)) {
        return false
      }
      const content = fs.readFileSync(csvPath, 'utf-8')
      if (content.includes(`"${offer.sku}"`)) {
        return true
      }
      const gemsItem = offer.items.find((item) => item.offerId === 16)
      const boxItem = offer.items.find((item) => item.offerId === 10)
      const diamonds = gemsItem ? gemsItem.amount : 1
      const bigBoxes = boxItem ? boxItem.amount : ''
      const columns = [
        offer.sku, '', 4, 'TRUE', '', '', diamonds || 1, offer.priceCents,
        900, '', '', bigBoxes, '', '', '', ''
      ]
      const line = '"' + columns.join('","') + '"'
      const newline = content.endsWith('\n') ? '' : '\n'
      fs.writeFileSync(csvPath, content + newline + line + '\n')
      return true
    } catch (error) {
      console.error('Store | Falha ao registrar Type 4 no CSV:', error)
      return false
    }
  }

  static brawler_id_by_name (name) {
    const wanted = String(name || '').trim()
    if (!wanted) {
      return null
    }
    const Characters = require('../Files/CsvLogic/Characters')
    try {
      return Characters.get_brawler_id_by_name(wanted)
    } catch (error) {
      /* tenta case-insensitive abaixo */
    }
    const lowered = wanted.toLowerCase()
    const { readRows } = require('../Files/CsvLogic/CsvRows')
    const rows = readRows('GameAssets/csv_logic/characters.csv')
    for (let id = 0; id < rows.length; id++) {
      const row = rows[id]
      if (
        row.length > 20 && row[20] === 'Hero' &&
        String(row[0]).toLowerCase() === lowered &&
        row[2].toLowerCase() !== 'true' && row[1].toLowerCase() !== 'true'
      ) {
        return id
      }
    }
    return null
  }

  static brawler_names () {
    const { readRows } = require('../Files/CsvLogic/CsvRows')
    const rows = readRows('GameAssets/csv_logic/characters.csv')
    const names = []
    for (let id = 0; id < rows.length; id++) {
      const row = rows[id]
      if (
        row.length > 20 && row[20] === 'Hero' &&
        row[2].toLowerCase() !== 'true' && row[1].toLowerCase() !== 'true'
      ) {
        names.push(row[0])
      }
    }
    return names
  }

  static _int (value, fallback) {
    const parsed = Number(value)
    if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
      return fallback
    }
    return Math.trunc(parsed)
  }
}

module.exports = StoreCatalog
