'use strict'

const fs = require('fs')
const path = require('path')

const { openDatabase } = require('../Database/SqliteDriver')

// Armazém da loja: carteiras, gift cards, pedidos, sessões e códigos de vínculo.
// Banco separado do players.sqlite; cada operação sensível roda dentro de
// transações IMMEDIATE com atualizações condicionais (ver StoreService).

const SCHEMA = `
CREATE TABLE IF NOT EXISTS wallets (
  low_id INTEGER PRIMARY KEY,
  balance_cents INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS giftcards (
  code TEXT PRIMARY KEY,
  cents INTEGER NOT NULL,
  stars INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  redeemed_by INTEGER,
  redeemed_at INTEGER
);
CREATE TABLE IF NOT EXISTS orders (
  order_key TEXT PRIMARY KEY,
  low_id INTEGER NOT NULL,
  sku TEXT NOT NULL,
  cents INTEGER NOT NULL,
  items_json TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  delivered_at INTEGER,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_orders_account ON orders (low_id, sku, status);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  low_id INTEGER NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_account ON sessions (low_id);
CREATE TABLE IF NOT EXISTS tickets (
  ticket TEXT PRIMARY KEY,
  low_id INTEGER NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  sku TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  consumed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_tickets_account ON tickets (low_id);
CREATE TABLE IF NOT EXISTS deliveries (
  order_key TEXT PRIMARY KEY,
  low_id INTEGER NOT NULL,
  items_json TEXT NOT NULL,
  delivered_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_state (
  tg_id INTEGER PRIMARY KEY,
  state TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at INTEGER NOT NULL,
  low_id INTEGER,
  tg_id INTEGER,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT ''
);
`

class StoreDB {
  constructor (databasePath) {
    fs.mkdirSync(path.dirname(path.resolve(databasePath)), { recursive: true })
    this.db = openDatabase(databasePath)
    this.db.exec('PRAGMA busy_timeout = 10000')
    this.db.exec('PRAGMA journal_mode = WAL')
    this.db.exec(SCHEMA)
  }

  now () {
    return Math.trunc(Date.now() / 1000)
  }

  close () {
    try {
      this.db.close()
    } catch (error) {
      /* noop */
    }
  }
}

module.exports = StoreDB
