'use strict'

const fs = require('fs')
const http = require('http')
const path = require('path')

const StoreCatalog = require('./StoreCatalog')
const { StoreError } = require('./StoreService')

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.json': 'application/json',
  '.ico': 'image/x-icon'
}

class WebServer {
  constructor (store) {
    this.store = store
    this.config = store.config
    this.webRoot = path.resolve(__dirname, 'web')
    this.server = http.createServer((req, res) => this._handle(req, res))
  }

  start () {
    return new Promise((resolve, reject) => {
      this.server.once('error', reject)
      this.server.listen(this.config.Port, '0.0.0.0', () => {
        resolve(this.config.Port)
      })
    })
  }

  stop () {
    try {
      this.server.close()
    } catch (error) {
      /* noop */
    }
  }

  _json (res, status, payload) {
    const body = Buffer.from(JSON.stringify(payload), 'utf-8')
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': body.length,
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, X-Store-Session',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    })
    res.end(body)
  }

  _error (res, error) {
    const message = error instanceof StoreError
      ? error.message
      : 'Erro interno da loja'
    if (!(error instanceof StoreError)) {
      console.error('Store | Erro na requisição:', error)
    }
    this._json(res, 400, { error: message })
  }

  _session (req) {
    const token = req.headers['x-store-session'] || ''
    return token ? this.store.getSession(token) : null
  }

  _body (req) {
    return new Promise((resolve, reject) => {
      const chunks = []
      let size = 0
      req.on('data', (chunk) => {
        size += chunk.length
        if (size > 64 * 1024) {
          req.destroy()
          reject(new StoreError('Requisição grande demais'))
          return
        }
        chunks.push(chunk)
      })
      req.on('end', () => {
        try {
          resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf-8')) : {})
        } catch (error) {
          reject(new StoreError('JSON inválido'))
        }
      })
      req.on('error', reject)
    })
  }

  static price (cents) {
    return `$${(cents / 100).toFixed(2)}`
  }

  _offerPayload (offer) {
    return {
      sku: offer.sku,
      title: offer.title,
      subtitle: offer.subtitle,
      image: `/assets/img/${offer.image}`,
      price: WebServer.price(offer.priceCents),
      priceCents: offer.priceCents,
      oneTime: offer.oneTime,
      contents: Delivery_describe(offer)
    }
  }

  _pricesPayload () {
    const prices = {}
    for (const offer of StoreCatalog.list()) {
      prices[offer.sku] = {
        price: WebServer.price(offer.priceCents),
        micros: offer.priceCents * 10000,
        currency: 'USD'
      }
    }
    return prices
  }

  _route_api (pathname, query, req, res) {
    if (pathname === '/health') {
      this._json(res, 200, { ok: true, service: 'lakeystore', ts: this.store.store.now() })
      return true
    }
    if (pathname === '/api/prices' && req.method === 'GET') {
      this._json(res, 200, this._pricesPayload())
      return true
    }
    if (pathname === '/api/offers' && req.method === 'GET') {
      this._json(res, 200, {
        offers: StoreCatalog.list().map((offer) => this._offerPayload(offer))
      })
      return true
    }
    return false
  }

  async _route (req, res, pathname) {
    if (req.method === 'OPTIONS') {
      this._json(res, 204, {})
      return
    }
    if (pathname === '/health' || pathname === '/api/prices' ||
        (pathname === '/api/offers' && req.method === 'GET')) {
      this._route_api(pathname, null, req, res)
      return
    }
    if (pathname === '/api/ticket' && req.method === 'POST') {
      const body = await this._body(req)
      const result = this.store.consumeTicket(body.ticket)
      this._json(res, 200, {
        session: result.session,
        name: result.name,
        sku: result.sku,
        balance: WebServer.price(this.store.getBalanceCents(result.lowId))
      })
      return
    }
    if (pathname === '/api/wallet' && req.method === 'GET') {
      const session = this._session(req)
      if (!session) {
        this._json(res, 401, { error: 'not_linked' })
        return
      }
      this._json(res, 200, {
        name: session.name,
        balance: WebServer.price(this.store.getBalanceCents(session.lowId)),
        balanceCents: this.store.getBalanceCents(session.lowId),
        orders: this.store.ordersOf(session.lowId).map((order) => ({
          sku: order.sku,
          price: WebServer.price(order.cents),
          status: order.status,
          at: order.created_at
        }))
      })
      return
    }
    if (pathname === '/api/redeem' && req.method === 'POST') {
      const session = this._session(req)
      if (!session) {
        this._json(res, 401, { error: 'not_linked' })
        return
      }
      const body = await this._body(req)
      const result = this.store.redeemGiftCard(session.lowId, body.code)
      this._json(res, 200, {
        credited: WebServer.price(result.creditedCents),
        balance: WebServer.price(result.balanceCents),
        balanceCents: result.balanceCents
      })
      return
    }
    if (pathname === '/api/purchase' && req.method === 'POST') {
      const session = this._session(req)
      if (!session) {
        this._json(res, 401, { error: 'not_linked' })
        return
      }
      const body = await this._body(req)
      const result = this.store.purchase(session.lowId, body.sku, body.orderKey)
      this._json(res, 200, {
        balance: WebServer.price(result.balanceCents),
        balanceCents: result.balanceCents,
        title: result.title || body.sku,
        delivered: result.delivered,
        online: result.online === true,
        replay: result.replay === true
      })
      return
    }
    if (pathname === '/api/logout' && req.method === 'POST') {
      const token = req.headers['x-store-session']
      if (token) {
        this.store.logout(token)
      }
      this._json(res, 200, { ok: true })
      return
    }
    this._static(res, pathname)
  }

  _static (res, pathname) {
    let filePath
    if (pathname === '/' || pathname === '/index.html') {
      filePath = path.join(this.webRoot, 'index.html')
    } else {
      const safe = path.normalize(pathname).replace(/^(\.\.[/\\])+/, '')
      filePath = path.join(this.webRoot, safe)
    }
    if (!filePath.startsWith(this.webRoot)) {
      res.writeHead(403)
      res.end('forbidden')
      return
    }
    fs.readFile(filePath, (error, data) => {
      if (error) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('not found')
        return
      }
      const ext = path.extname(filePath).toLowerCase()
      res.writeHead(200, {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600'
      })
      res.end(data)
    })
  }

  _handle (req, res) {
    let pathname
    try {
      pathname = new URL(req.url, 'http://store.local').pathname
    } catch (error) {
      this._json(res, 400, { error: 'URL inválida' })
      return
    }
    this._route(req, res, pathname).catch((error) => this._error(res, error))
  }
}

function Delivery_describe (offer) {
  const Delivery = require('./Delivery')
  return Delivery.describe(offer)
}

module.exports = WebServer
