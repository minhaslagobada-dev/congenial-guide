'use strict'

const DataBase = require('../Database/DatabaseManager')
const { Players } = require('../Logic/Player')
const Random = require('../Utils/Random')
const RewardDelivery = require('../Logic/RewardDelivery')
const { RewardError, RewardTransaction } = require('../Logic/Rewards')
const ShopService = require('../Logic/ShopService')
const StoreCatalog = require('./StoreCatalog')

// Entrega de compras da loja para contas do jogo v13.
//
// Reutiliza ShopService._deliver_item + RewardTransaction — exatamente a
// mesma lógica (e validação) das compras dentro do jogo. Jogador online
// recebe push imediato via RewardDelivery; offline recebe no próximo login
// (a transação já escreveu no players.sqlite).

class Delivery {
  static _online_entry (server, lowId) {
    try {
      const registry = server && server.Clients && server.Clients.Clients
      if (!registry) {
        return null
      }
      return registry[String(lowId)] || null
    } catch (error) {
      return null
    }
  }

  static _load_offline_player (lowId) {
    const token = DataBase._connection((connection) => {
      const row = connection.prepare('SELECT token FROM players WHERE lowID = ?').get(lowId)
      return row ? String(row.token) : null
    })
    if (!token) {
      throw new RewardError('Conta do jogador não encontrada')
    }
    const player = new Players(null)
    player.token = token
    player.low_id = Math.trunc(lowId)
    const loaded = DataBase.loadAccount({ player })
    if (!loaded) {
      throw new RewardError('Conta do jogador não encontrada')
    }
    return player
  }

  static _apply (player, items) {
    const transaction = new RewardTransaction(player)
    const rewards = []
    const storedBoxes = []
    for (const rawItem of items) {
      const delivered = ShopService._deliver_item(
        transaction,
        {
          offerId: rawItem.offerId,
          amount: rawItem.amount,
          value: rawItem.value,
          target: rawItem.target || null
        },
        0,
        Random,
        false,
        false
      )
      if ('display' in delivered) {
        rewards.push(delivered.display)
      } else if ('boxType' in delivered) {
        storedBoxes.push({ boxType: delivered.boxType, amount: delivered.amount })
      } else if ('openedBox' in delivered) {
        rewards.push({ type: 100, amount: delivered.openedBox.boxCount })
      }
    }
    transaction.commit()
    return {
      rewards,
      storedBoxes,
      details: structuredClone(transaction.reward_details)
    }
  }

  static deliver (server, lowId, offer) {
    lowId = Math.trunc(lowId)
    const items = (offer.items || []).map((item) => ({
      offerId: item.offerId,
      amount: item.amount,
      value: item.value,
      target: item.target || null
    }))
    if (!items.length) {
      throw new RewardError('Oferta sem itens para entrega')
    }
    const entry = Delivery._online_entry(server, lowId)
    if (entry && entry.Player) {
      const player = entry.Player
      const applied = Delivery._apply(player, items)
      try {
        const responses = RewardDelivery.responses(applied.rewards, applied.storedBoxes)
        if (responses.length && entry.SocketInfo) {
          RewardDelivery.send_many(entry.SocketInfo, player, responses)
        }
      } catch (error) {
        console.warn('Store | Push de entrega falhou (entrega aplicada no servidor):', error.message)
      }
      return { online: true, details: applied.details }
    }
    const player = Delivery._load_offline_player(lowId)
    const applied = Delivery._apply(player, items)
    return { online: false, details: applied.details }
  }

  static describe (offer) {
    const parts = []
    for (const item of offer.items || []) {
      const kind = Object.entries(StoreCatalog.KINDS).find(
        ([, def]) => def.offerId === item.offerId
      )
      if (item.offerId === 16) {
        parts.push(`${item.amount} Gemas`)
      } else if (kind) {
        parts.push(`${item.amount}x ${kind[1].label}`)
      } else {
        parts.push(`Item ${item.offerId} x${item.amount}`)
      }
    }
    return parts.join(' + ')
  }
}

module.exports = Delivery
