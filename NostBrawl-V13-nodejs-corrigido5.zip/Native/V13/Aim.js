'use strict'
const table = require('./AngleTable.json')
const yes = value => value === true || value === 'true'
// Native LogicMath::getAngle 0x1cd630. The bound ensures the native <<7
// ratio calculation stays in range; all decoded v13 map coordinates fit.
function angle (x, y) {
  if (![x, y].every(v => Number.isInteger(v) && Math.abs(v) < 16777216)) throw new RangeError('Aim delta outside supported native coordinate range')
  if ((x | y) === 0) return 0
  const ax = Math.abs(x); const ay = Math.abs(y)
  const lookup = (a, b) => table[Math.trunc(a * 128 / b)]
  if (x > 0 && y >= 0) return y < x ? lookup(y, x) : 90 - lookup(x, y)
  if (x <= 0 && y > 0) return ax < y ? 90 + lookup(ax, y) : 180 - lookup(y, ax)
  if (x < 0 && y <= 0) return ay < ax ? 180 + lookup(ay, ax) : 270 - lookup(ax, ay)
  return ax < ay ? 270 + lookup(ax, ay) : (360 - lookup(ay, ax)) % 360
}
// Native 0x310710: the first eligible skill controls movement orientation.
function activeSkillDefinition (skills) {
  for (const skill of skills) {
    if ((skill.executing && Number(skill.definition.CastingTime) > 0) || skill.activeMs >= 1) return skill.definition
  }
  return null
}
// Native CharacterServer::turnTo 0x200010. Target coordinates are absolute.
function turnToward (owner, target) {
  owner.attackAngle = angle((target[0] - owner.x) | 0, (target[1] - owner.y) | 0)
  const definition = activeSkillDefinition(owner.skills)
  if (definition && !yes(definition.CanMoveAtSameTime)) owner.moveAngle = owner.attackAngle
  return owner
}
module.exports = { angle, activeSkillDefinition, turnToward }
