'use strict'
const { sqrt } = require('./Math')
// Transcription of 0x203258..0x2032d0 in the supplied v13 ARM64 library.
// Inputs are the final clamped launch position and spread-adjusted target.
// Origin selection, spread, spawning and collisions belong to other routines.
function timing ({ start, target, speed, speedReduction = 0, constantFlyTime, launch }) {
  const dx = (target[0] - start[0]) | 0
  const dy = (target[1] - start[1]) | 0
  const distance = sqrt((Math.imul(dx, dx) + Math.imul(dy, dy)) | 0)
  const numerator = constantFlyTime ? 18000 : Math.imul(distance, 20)
  const divisor = (speed - speedReduction) | 0
  // ARM64 SDIV returns zero for division by zero.
  const quotient = divisor === 0 ? 0 : Math.trunc(numerator / divisor) | 0
  const duration = Math.max(1, quotient)
  return { launch: launch | 0, finish: ((launch | 0) + duration) | 0, progressStep: Math.trunc(1000 / duration) | 0 }
}
module.exports = { timing }
