'use strict'
const f = Math.fround
const mul = Math.imul
const sub = (a, b) => (a - b) | 0
const fcvtzs = v => Number.isNaN(v) ? 0 : v >= 2147483647 ? 2147483647 : v <= -2147483648 ? -2147483648 : Math.trunc(v)
// Native 0x2ea134. Native FMADD rounds once after product + addition.
function segment (v) {
  const [x0, y0, x1, y1, x2, y2, x3, y3] = v
  const dy = sub(y1, y0); const dx = sub(x1, x0)
  const sx = sub(x3, x2); const sy = sub(y3, y2)
  const px = sub(x0, x2); const py = sub(y0, y2)
  const denominator = (mul(sy, dx) - mul(sx, dy)) | 0
  const t = f(f((mul(sx, py) - mul(sy, px)) | 0) / f(denominator))
  if (!(t >= 0 && t <= 1)) return null
  const u = f(f((mul(py, dx) - mul(px, dy)) | 0) / f(denominator))
  if (!(u >= 0 && u <= 1)) return null
  return [fcvtzs(f(t * f(dx) + f(x0))), fcvtzs(f(t * f(dy) + f(y0)))]
}
// Native 0x4413ac. Edge order and strict tie handling determine bounce side.
function rectangle (v) {
  const [x0, y0, x1, y1, left, top, right, bottom] = v
  const edges = [[left, top, right, top, 1], [left, top, left, bottom, 3], [right, bottom, left, bottom, 4], [right, bottom, right, top, 2]]
  let best = 999999999; let result = 0; let point = [-1, -1]
  for (let i = 0; i < edges.length; i++) {
    const edge = edges[i]
    const hit = segment([x0, y0, x1, y1, ...edge.slice(0, 4)])
    if (!hit) continue
    const dx = sub(hit[0], x0); const dy = sub(hit[1], y0)
    const distance = (mul(dx, dx) + mul(dy, dy)) | 0
    const closer = i < 2 ? (distance >>> 0) < (best >>> 0) : distance < best
    if (closer) { best = distance; result = edge[4]; point = hit }
  }
  return { result, point }
}
// Native 0x462288. Float32 quadratic coefficients followed by double sqrt.
function circle (v) {
  const [x0, y0, x1, y1, cx, cy, radius] = v
  const scale = f(0.01)
  const dx = f(f(sub(x1, x0)) * scale); const dy = f(f(sub(y1, y0)) * scale)
  const ox = f(f(sub(x0, cx)) * scale); const oy = f(f(sub(y0, cy)) * scale)
  const r = f(f(radius) * scale)
  const dot = f(oy * dy + f(ox * dx))
  const c = f(f(oy * oy + f(ox * ox)) - r * r)
  const a = f(dy * dy + f(dx * dx))
  const b = f(dot + dot)
  const discriminant = f(b * b + f(a * f(-4 * c)))
  if (!(discriminant >= 0)) return null
  const root = Math.sqrt(discriminant)
  const denominator = f(a + a)
  let t = (-b - root) / denominator
  if (!(t >= 0 && t <= 1)) t = (root - b) / denominator
  if (!(t >= 0 && t <= 1)) return null
  return [(x0 + fcvtzs(dx * 100 * t)) | 0, (y0 + fcvtzs(dy * 100 * t)) | 0]
}
module.exports = { segment, rectangle, circle }
