'use strict'
// Original CharacterServer attack interval selection at0x14ad30.
// cachedInterval is the native CharacterData +0x130 value, not assumed ms.
function intervalTicks (owner) {
  if (owner.skills.some(s => s.definition.BehaviorType === 'Attack' && s.activeMs > 0) && owner.attackIntervalMs >= 1) {
    return Math.trunc((owner.attackIntervalMs >>> 0) / 50)
  }
  if (owner.castingMs >= 1) {
    for (const skill of owner.skills) {
      if (skill.executing && Number(skill.definition.CastingTime) > 0) return Math.trunc(Number(skill.definition.CastingTime) / 50) | 0
    }
  }
  if (owner.characterType !== 1 && owner.mainDefinition && owner.mainDefinition.BehaviorType === 'Attack') {
    return Math.trunc((Number(owner.mainDefinition.MsBetweenAttacks) || 0) / 50) | 0
  }
  return Math.max(1, owner.cachedInterval | 0)
}
// The actual fire routine writes this before checking whether a shot is due.
function dueAtTick (lastShotTick, interval, tick) {
  const next = ((lastShotTick | 0) + (interval | 0)) | 0
  return { due: next <= (tick | 0), attackingTicks: Math.max(0, Math.min(63, (next - tick) | 0)) }
}
module.exports = { intervalTicks, dueAtTick }
