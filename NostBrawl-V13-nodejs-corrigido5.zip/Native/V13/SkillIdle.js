'use strict'

// Transcription of the inactive branch in v13 SkillServer::tick.
// ELF 782ca3ed...e87db, entry 0xec2a8, branch 0xeca90..0xecbb8.
// This function deliberately rejects an executing skill. Attack/charge logic
// belongs to other native branches and must not be replaced by this branch.
function stepIdleSkill (state, definition, owner, context, elapsedMs = 50) {
  if (state.executing) throw new Error('Executing skill requires the native active branch')
  const previousActive = state.activeMs
  state.pending = 0
  state.activeMs = Math.max(0, state.activeMs - elapsedMs)
  if (state.cooldownMs >= 1) state.cooldownMs = Math.max(0, state.cooldownMs - elapsedMs)

  let recharge = definition.rechargeTime
  if (owner.berserk) recharge = Math.trunc(recharge / 2)
  if (context.mode === 7 && context.team === 1) recharge = Math.trunc(recharge * 10 / context.bossReloadDivisor)
  if (recharge >= 1 && state.cooldownMs <= 0) {
    let gain = Math.trunc(elapsedMs * 1000 / recharge)
    if (context.debugFastReload) gain *= 16
    state.ammo = Math.min(Math.max(1000, definition.maxCharge * 1000), state.ammo + gain)
  }
  if (previousActive >= 1 && definition.behavior === 0 && state.activeMs <= 0) {
    owner.ownerAttack = 0
    owner.ownerSlot = -1
  }
  return state
}

module.exports = { stepIdleSkill }
