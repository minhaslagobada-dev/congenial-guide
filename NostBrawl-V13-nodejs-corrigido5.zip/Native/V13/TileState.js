'use strict'
const FULL_MASK = 0x7fffffffffff
const yes = value => value === true || value === 'true'
// Native Tile::setData 0x226b4c. Masks are exact integers below 2^53.
function setData (state, definition) {
  state.data = definition.Name
  state.movementMask = yes(definition.BlocksMovement) ? 0 : FULL_MASK
  state.projectileMask = yes(definition.BlocksMovement) && yes(definition.BlocksProjectiles) ? 0 : FULL_MASK
  return state
}
function construct (definition) {
  return setData({ timer: 0, seconds: 0 }, definition)
}
// Native 0x39a128 is unconditional. Its callers decide whether destruction
// is permitted; this routine must not be used as that permission check.
function destroy (state, original, open) {
  setData(state, open)
  const seconds = Number(original.RespawnSeconds) || 0
  state.timer = Math.imul(seconds, 20)
  state.seconds = Math.fround(seconds)
  return state
}
// Map initialization at 0xf2248..0xf2260 registers only these tiles for ticks.
const shouldUpdateRespawn = original => (Number(original.RespawnSeconds) || 0) >= 1
const squared = (x, y) => (Math.imul(x, x) + Math.imul(y, y)) >>> 0
// Native 0x12fa44. byte148/byte149 deliberately retain their offset names:
// their broader character semantics have not yet been established here.
function tickRespawn (state, original, tileX, tileY, characters) {
  if (state.data !== 'Open') return state
  state.timer = (state.timer - 1) | 0
  if (state.timer > 0) return state
  if (yes(original.BlocksMovement)) {
    const x = (Math.imul(tileX, 300) + 150) | 0
    const y = (Math.imul(tileY, 300) + 150) | 0
    for (const actor of characters) {
      if (actor.type !== 0 || actor.hp <= 0) continue
      if (actor.byte148 || actor.byte149) return state
      if (squared((actor.x - x) | 0, (actor.y - y) | 0) < 90001) return state
      if (actor.path && squared((actor.path[0] - x) | 0, (actor.path[1] - y) | 0) < 90001) return state
    }
  }
  return setData(state, original)
}
module.exports = { construct, setData, destroy, shouldUpdateRespawn, tickRespawn }
