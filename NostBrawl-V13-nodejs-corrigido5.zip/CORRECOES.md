# Ajuste — vitórias menores a partir de 350 troféus + conta nova zerada

## 1. Troféus por vitória conforme os troféus do brawler

Os valores contam os troféus do brawler **antes** da partida:

| Troféus do brawler | Vitória 3v3 | 1º no Combate solo | 1º no Combate em dupla |
|---|---|---|---|
| 0–349 | +10 | +15 | +15 |
| **350 ou mais** | **+6** | **+9** | **+9** |

- Derrotas, empates e as outras colocações seguem as tabelas originais. Por exemplo, a derrota no 3v3 tira −5 entre 300 e 499.
- Na dupla, cada membro recebe conforme o próprio brawler. Se um está com 100 e o outro com 350, um ganha +15 e o outro +9.
- **Configuração opcional** (estes já são os padrões), numa chave própria:
  ```json
  "TrophyRewards": { "Win3v3": 10, "WinShowdown": 15, "ReducedFrom": 350, "Win3v3Reduced": 6, "WinShowdownReduced": 9 }
  ```
- **Correção da documentação anterior:** a versão anterior deste documento sugeria `"Trophies": { ... }`. Só que `Trophies` (número) é a quantidade de troféus de uma conta nova. Seguir aquela sugestão teria quebrado as contas novas. Por isso a configuração foi para `TrophyRewards`; o formato antigo ainda é lido se for um objeto.

## 2. Valores iniciais de uma conta nova (`config.json`)

`Trophies` 0, `Gems` 0, `Tickets` 0, `Starpoints` 0, `BrawlBoxTokens` 0, `BigBoxTokens` 0, `ExperiencePoints` 0, **`Gold` 100**. Contas que já existem não mudam: os valores valem só para as contas criadas daqui em diante.

## 3. Testes

- **`battle_trophies_e2e`** (partidas reais):
  - 3v3: 340→350 (+10), 350→356 (+6), derrota em 356 (−5), 400→406 (+6);
  - Combate: 349→364 (+15), 350→359 (+9), 400→409 (+9), 2º lugar em 360 (+6, tabela original).
- **`battle_log_e2e`:** dupla com um brawler em 100 (+15) e outro em 350 (+9) na mesma partida.

# Histórico de batalhas + ordem dos brawlers no perfil

Base: commit `bc44332` (pacote `NostBrawl-V13-nodejs-corrigido3.zip`). A física, o movimento, o matchmaking, as equipes, as recompensas e as otimizações não mudaram. Nenhum ID, pacote ou tela foi inventado: só são usados a 14114 `GetBattleLogMessage`, a 23458 `BattleLogMessage`, a 14113 e a 24113, todas já existentes no cliente v13.

## 1. Histórico de batalhas

**Como o cliente original funciona** (engenharia reversa da `libg.so` v13):
- O botão do histórico (`BattleLogPopup`) envia a 14114 (corpo vazio) **só na primeira vez em cada sessão** (`0xd7588` testa uma flag única). Depois disso, o cliente mantém a lista em memória.
- A 23458 tem o formato `bool replace`, `vint count` e, para cada item, `LogicBattleLogEntry` (`0x47f288`) com uma lista de `LogicBattleLogPlayer` (`0x21b324`):
  - com `replace = true`, a lista do cliente é substituída e a ordem da mensagem é a ordem exibida;
  - com `replace = false`, cada item é inserido no topo.
- Por isso, o servidor responde à 14114 com a lista completa (mais recentes primeiro). As partidas terminadas depois disso são **empurradas** com `replace = false` logo depois do 24101 da volta ao menu, na mesma sessão. Sem isso, o histórico aberto uma vez nunca mostraria as partidas novas.

**Gravação** (`Logic/BattleHistory.js`, nova tabela `battle_history` no SQLite existente):
- **Campos gravados:**
  - id único da partida (`world.id`), data e hora, modo, mapa e duração;
  - resultado (vitória/derrota/empate) e colocação no Combate;
  - time, brawler usado e se foi a estrela da partida;
  - troféus do brawler antes e depois, e a variação;
  - se foi partida amistosa;
  - todos os participantes: conta ou bot, id, nome, time, brawler, troféus, nível e colocação.
- **Chave primária `(player_id, battle_id)` com `INSERT OR IGNORE`.** Fim ou resultado processado duas vezes, replay do outbox no login, ou queda do servidor no meio: nunca duplica.
- **Fora do loop do jogo.** O resultado só monta um snapshot em memória. A inserção acontece em `setImmediate`, em lote, numa única transação, e `close()` grava o que estiver pendente.
- **Proteção contra queda.** O snapshot é salvo junto com o resultado no `battle_result_outbox`. Se o processo cair antes da inserção, `ResultOutbox.restore` grava o histórico no próximo login (idempotente).
- **Resultado:**
  - 3v3: vitória, derrota ou empate pelo time vencedor.
  - Combate solo: 1º–3º vitória, 4º–7º empate, 8º+ derrota.
  - Combate em dupla: 1º–2º vitória, 3º empate, 4º+ derrota.
  - A cor e o texto "RANK n" vêm do próprio cliente.
- **Quantidade enviada.** O banco guarda o histórico inteiro. O cliente recebe as **25** mais recentes (opcional no `config.json`: `"BattleLog": { "Limit": 25 }`, máximo 100).

## 2. Perfil: brawlers ordenados por raridade

- **Causa:** o popup de perfil do cliente (`0x336b1c`) desenha os brawlers **na ordem em que chegam** na 24113, sem reordenar. O servidor enviava na ordem de desbloqueio/CSV, que é a ordem de raridade.
- **Correção** (`PlayerProfileMessage`): ordenação por **troféus atuais** do brawler (decrescente, nunca pelo recorde), com desempate estável pelo id do brawler. Os dados de cada brawler (troféus, recorde, nível, star power) são os mesmos de antes. Agora a leitura é segura contra valores ausentes.

## 3. Testes

- **`tests/battle_log_e2e.test.js`** (novo; clientes reais criptografados, 14114/23458/14113/24113 decodificados campo a campo). Cobre:
  - vitória e derrota 3v3;
  - Combate em 4º (colocações 1–10);
  - 3v3 em equipe, gravado para os dois membros, no mesmo lado e com os brawlers certos;
  - Combate em dupla (+15);
  - participantes, troféus antes e depois e id único;
  - ordem decrescente;
  - sem duplicação (resultado processado de novo, `record_now` repetido, GoHome repetido);
  - jogo fechado durante a partida (outbox + login: grava 1 vez, paga 1 vez);
  - muitas partidas (34 no banco, 25 no cliente);
  - persistência após novo login e após **reinício do servidor**;
  - perfil de outro jogador e o próprio ordenados por troféus atuais, com o recorde ignorado e a ordem mudando depois de uma partida real;
  - 24 brawlers.
- **`scripts/native_v13/validate_battle_log_native.js`** (novo): executa o **decodificador original do cliente** (`0x3fb954`) emulado sobre as 23458 geradas pelo servidor. Confere todos os campos e o consumo total do pacote: 4 pacotes, 242 participantes, nomes unicode.
- **Regressão completa** aprovada (`work/run_one.js --regression` + novo teste).

## 4. Limitações reais do cliente v13

- **Replays não existem** no servidor. O cliente mostra "sem replay disponível".
- Campos da 23458 que o v13 não usa vão como 0.
- Partidas de antes desta versão não têm histórico.
- A lista no cliente só é atualizada por empurrão, enquanto a sessão estiver ativa. Num novo login, ela é pedida inteira de novo.

# Correção final — sincronização dos troféus e novas recompensas

Base: commit `27ee197` (pacote `NostBrawl-V13-nodejs-corrigido2.zip`). Nada de física, movimento, matchmaking, equipes ou otimizações foi alterado. Não há delays, troca automática de brawler nem mensagens novas: o servidor só reenvia uma mensagem que o cliente original já recebe hoje.

## 1. Troféus antigos no menu após a partida

**Causa real (reproduzida em teste):**
- O badge de troféus acima do brawler no lobby é desenhado a partir do último `TeamGameroomData` (24124) recebido. Isso vale para a equipe e também para o Play solo feito numa sala de um membro só.
- O servidor guardava os troféus de cada membro numa **cópia** feita quando o jogador entrava na sala. Essa cópia só era atualizada em `set_member_settings`, ou seja, quando o jogador escolhia um brawler (14354). É exatamente o sintoma: o menu só atualizava quando o mesmo brawler era selecionado de novo.
- Depois da batalha, os troféus eram salvos corretamente no banco e no jogador. O `OwnHomeData` (24101) já levava o valor novo. Mas a sala continuava com o valor antigo, e nenhuma 24124 nova era enviada ao voltar ao menu.
- No teste, com a cópia antiga o badge mostrava 0 em vez de 10 (o teste falha). Com a correção, mostra 10.

**Correção:**
- **`GameRoomService._snapshot`**: os troféus e o nível de poder de cada membro passam a ser lidos do jogador vivo no servidor toda vez que a sala é serializada. A cópia desatualizada deixou de existir, e o servidor é a fonte autoritativa.
- **Retorno ao menu** (14101, 14108 e 14109, em `returnHome`): depois do 24101, se o jogador está numa sala, o servidor envia a 24124 com os troféus já gravados para ele e para os colegas. É o mesmo pacote que o cliente recebe ao trocar de brawler. A ordem é: recompensa salva → 23456 → 24101 → 24124.

## 2. 3v3: +10 troféus por vitória

- Vale para Pique-Gema, Recompensa, Roubo e Futebol (modo 0), em qualquer faixa de troféus, aplicado ao brawler que jogou.
- Derrota e empate seguem as tabelas originais.
- Vale para o Play solo e para equipes. O ledger da partida impede pagar duas vezes.

## 3. Combate: +15 troféus por vitória

- **Combate solo:** +15 só para o 1º lugar.
- **Combate em dupla:** +15 só para a dupla em 1º lugar.
- As outras colocações seguem as tabelas originais.
- **Inconsistência corrigida:** uma entrada de Combate sem colocação era tratada como rank 1, ou seja, como vitória. Agora, quem não é do lado vencedor recebe a última colocação, e a vitória nunca é paga por engano. Nas partidas normais, a simulação sempre define todas as colocações.
- **Configuração opcional** no `config.json` (os padrões já são 10 e 15):
  ```json
  "TrophyRewards": { "Win3v3": 10, "WinShowdown": 15 }
  ```

## 4. Testes

**`tests/battle_trophies_e2e.test.js`** (novo; clientes reais com Play solo 14103 → matchmaking → partida):

| Situação | Troféus |
|---|---|
| Vitória no 3v3 | 100 → 110 |
| Derrota no 3v3 | 110 → 108 |
| Empate no 3v3 | 108 → 108 |
| Vitória no Combate | 100 → 115 |
| 4º lugar no Combate | +3 |
| 10º lugar no Combate | −4 |
| Combate sem colocação | −4, último lugar |

Em todos os casos, o valor da tela de resultado é igual ao do 24101 (brawler e total da conta) e ao do banco. Um segundo GoHome, a repetição do resultado e um novo login (reiniciar o jogo) não concedem nada duas vezes.

**`tests/battle_team_full_cycle_e2e.test.js`** (equipe, começando com 100 troféus):

| Mapa | Resultado | Troféus |
|---|---|---|
| Recompensa | vitória | 100 → 110 para os dois |
| Combate em dupla | vitória | +15 para os dois |
| Pique-Gema, Assalto, Futebol, Combate em dupla | derrota | perdem troféus |

A 24124 enviada depois do 24101 já mostra o valor novo, tanto o do próprio jogador quanto o do colega.

**`tests/battle_return_e2e.test.js`**: ajustado para +10 e +15. Também confere o badge da sala e os troféus do 24101 em duas partidas seguidas.

**`smoke_gameroom`**: ajustado para +10.

---

# Correção definitiva — equipe, brawlers duplicados, código da sala, derrota e salas persistentes

Base de comparação: commit `acde645` (pacote `NostBrawl-V13-nodejs-corrigido.zip`). Física, movimento, dano e otimizações anteriores não foram alterados. Nenhum ID de mensagem ou estrutura foi inventado: tudo abaixo usa mensagens e textos que já existem no cliente V13 original (confirmados na `libg.so` e no `texts.csv`).

## 1. Equipe: os dois apertam PRONTO e nada acontece

**Causa (log do usuário: 14355 ×2 → 20405 por ~15 s → 20406 → 24131 → queda):**
- O cliente V13 só reage a `MatchMakingStatus` (20405) enquanto o popup de busca está aberto. Esse popup é aberto por `TeamGameStarting` (**24130**), handler `0xd65f4` da libg.
- O servidor nunca enviava 24130 na busca em equipe. O cliente ignorava a contagem, a busca expirava, vinha o 20406 e a sessão terminava.

**Correção (`BattleCoordinator.readyRoom`):**
- Quando todos os membros **online** estão prontos, cada membro recebe 24130 (com o mapa do evento) **antes** do 20405.
- Depois disso, a equipe entra em **um único ticket** de matchmaking. Os membros caem na mesma partida, no mesmo time, sem divisão, sem partidas duplicadas e sem desconexões.

## 2. Brawlers repetidos na mesma equipe

O aviso nativo do cliente é `TeamErrorMessage` (24129) com código **17**, que mostra `TID_TEAM_ERROR_17`: *"Cannot start game. Duplicate Brawlers are not allowed."*

- **PRONTO com brawler repetido (14355):** o servidor envia o erro 17, o PRONTO não é confirmado e o jogador continua na sala. Quando alguém troca de brawler, o PRONTO volta a funcionar.
- **Troca de brawler depois do PRONTO (14354):** o servidor revalida.
  - Se a troca cria uma repetição, o PRONTO é invalidado, a busca é cancelada (20406) e o erro 17 é enviado.
  - Se a equipe já está na fila e a troca é válida, o ticket é atualizado com o novo brawler, skin e nível.
- **Proteção no servidor:** `readyRoom` também recusa duplicatas. Pacotes forjados não conseguem iniciar uma partida com brawlers repetidos.

## 3. Código da equipe com 4 caracteres

- **Geração:** o id da sala é sorteado entre os ids livres de 117 a 3607. Essa faixa dá exatamente 4 caracteres no alfabeto original do cliente (`QWERTYUPASDFGHJKLZCVBNM23456789`), por exemplo `2QGR` ou `ACGE`.
- **Como aparece no cliente:** o cliente original mostra o código com o prefixo `X` (ex.: `X2QGR`).
- **Entrada:** tanto `2QGR` quanto `X2QGR` funcionam, com qualquer combinação de maiúsculas e minúsculas, espaços ou `#`.
- **Unicidade e estabilidade:**
  - nunca há dois códigos iguais entre as salas ativas;
  - o código não muda durante a vida da sala, inclusive com desconexões e reconexões.
- **Erros nativos:** código inválido → erro 5, equipe não encontrada → erro 6, equipe cheia → erro 2.

## 4. O perdedor travava ao voltar ao menu

**Análise:**
- Comparei o `BattleResult` (23456) e o `OwnHomeData` (24101) do vencedor e do perdedor, com 0 e com 400 troféus. Os dois pacotes foram decodificados **pelos decodificadores originais da libg** e consumidos por inteiro: 859/859 bytes no 24101.
- Os campos que mudam entre vencedor e perdedor são os esperados:

  | | Resultado | Tokens | Troféus |
  |---|---|---|---|
  | Vencedor | 0 | 20 | +5 |
  | Perdedor | 1 | 10 | −5 |

- A eliminação antecipada no Showdown também gera um 23456 válido para cada jogador eliminado.

**Causa provável:** o fluxo de equipe descrito no item 1, e não o resultado. A busca sem 24130 levava a 20406 → 24131 → queda da conexão (EOF), e quem perdia e voltava para a sala caía nesse caminho.

**Validação:** em 6 partidas seguidas, perdedores e vencedores voltaram ao menu, permaneceram conectados e iniciaram novas partidas.

**Resultados não foram mexidos:** nenhuma derrota virou vitória, e troféus e recompensas continuam iguais.

## 5. A sala era desfeita quando um jogador fechava o jogo

- **Fechar o jogo ou perder a conexão não é sair da sala:**
  - o membro fica na sala com status "offline";
  - o código e a liderança são mantidos, mesmo quando é o líder que desconecta;
  - os PRONTOs de todos são desmarcados.
- **Volta automática:** no login, o jogador volta sozinho para a mesma sala, sem duplicar membros e sem criar uma sala nova. O PRONTO precisa ser confirmado de novo e passa pela validação de duplicatas.
- **Quando a sala termina:**
  - quando alguém sai ou desfaz a sala explicitamente;
  - quando **todos** os membros ficam offline por mais tempo que `Team.OfflineRoomExpirySeconds` (padrão: **600** s). Nesse caso a sala é apagada e não sobra sala fantasma.
- **Configuração opcional** no `config.json`:
  ```json
  "Team": { "OfflineRoomExpirySeconds": 600 }
  ```

## 6. Testes

Novo teste com clientes reais do protocolo: `tests/battle_team_full_cycle_e2e.test.js` (incluído em `npm run test:battle`). Ele cobre:

1. Criação da equipe com código de 4 caracteres e entrada por `CODE`, `XCODE` e ` xcode ` (14358 e 14371). Códigos inválidos e inexistentes recebem os erros 5 e 6.
2. Brawler repetido → aviso nativo 17 → troca de brawler → os dois prontos → 24130 → uma única partida, os dois como aliados.
3. Seis mapas e modos seguidos:

   | Mapa | Modo | Resultado testado |
   |---|---|---|
   | 7 | Gem Grab | derrota |
   | 0 | Recompensa | vitória |
   | 17 | Assalto | derrota |
   | 24 | Futebol | derrota |
   | 48 | Gem Grab | derrota |
   | 34 | Showdown em dupla | derrota |

   Em todas as partidas, vencedor e perdedor recebem o resultado (23456) e a home (24101), continuam conectados e a sala é mantida.
4. Troca de brawler com a equipe junta: depois do PRONTO, na fila com repetição (cancela) e na fila sem repetição (atualiza o ticket).
5. Um membro fecha o jogo: a sala continua, ele aparece offline e volta sozinho.
6. O líder fecha o jogo: continua líder, volta para a sala e o código não muda. A equipe joga de novo.
7. Todos ficam offline: a sala expira e não sobra sala fantasma.

O teste antigo `battle_team_e2e` foi ajustado para a nova regra: o colega escolhe outro brawler antes do PRONTO, e quem reconecta volta automaticamente para a sala. `smoke_gameroom`: 54/0.

---

# Correções anteriores

# Correção definitiva dos bugs restantes

Base de comparação: commit `d06964e` (pacote "otimizado"). Nenhuma otimização de lag anterior foi desfeita. Física, velocidades, dano, colisões, cooldowns e animações continuam no motor original.

## 1. Equipe: apertar "Jogar" desconectava e tirava o jogador da sala

**Causa real (reproduzida no código antigo pelo teste `tests/battle_team_e2e.test.js`):**

1. **Recusa tratada como "pacote malformado".**
   - `TeamSetMemberReady` (14355) e `OnPlay` (14103) deixavam passar qualquer `ValueError` do coordenador. Exemplos: "Jogador já está em batalha", "Motor indisponível", "Membro da sala desconectado", "Seleção de brawler divergente".
   - `main.js/_fail_dispatch` trata esses erros como pacote malformado e chama `_finish`. Resultado: o socket caía e `_release_game_room` removia o jogador da equipe.
   - Log do código antigo: `disconnected; reason: malformed packet: Jogador já está em batalha ou sala privada`.
2. **Conta presa em partida antiga.**
   - Quem saía da partida (GoHome) enquanto o colega ainda jogava continuava em `coordinator.accounts` até o fim daquela partida.
   - O próximo "Jogar" lançava "Jogador já está em batalha", que desconectava o jogador (ver item 1).
3. **Resultado pendente que nunca saía.**
   - O resultado restaurado no login nunca era reenviado. `ResultOutbox.acknowledge` exigia `pendingBattleResultSent`, então o resultado ficava pendente para sempre.
   - `enqueue` reenviava o resultado e retornava `null` em silêncio, por isso a contagem de busca nunca começava ("Jogar não faz nada").
   - Em equipe, `readyRoom` fazia `ticket.roomId = …` sobre `null`, o que gerava um TypeError e também desconectava.

**Correções:**

- **`BattleCoordinator.refuse()`**: uma busca recusada envia `MatchMakingCancelled` (20406) a todos os membros conectados, limpa os "pronto" da sala e retransmite o estado da sala. Ninguém é desconectado nem removido da equipe. O mesmo vale para `OnPlay` solo.
- **Saída explícita (GoHome)**: libera a conta na hora (`accounts.delete`). Quando aquela partida termina:
  - o estado mais novo do jogador (fila, sala ou outra partida) não é tocado;
  - não aparece tela de resultado atrasada;
  - se o jogador estiver ocioso, a recompensa é liquidada pelo ledger, sem duplicar.
- **Resultado pendente** é encerrado quando o jogador está comprovadamente no lobby: GoHome, OwnHomeData do login ou novo "Jogar". As recompensas já tinham sido aplicadas uma única vez.
- **`readyRoom`** protege o ticket nulo.
- **`cancel`** não bloqueia mais por causa de uma partida antiga.
- **Cancelamento por queda de membro** retransmite a sala aos que ficaram.
- **`GameRoomService.begin_battle`**: um `battle_started` antigo não impede mais que a próxima partida reinicie pronto/status.

## 2. ~3 s congelado no início e 4. atraso de comando

**Causa:**

- O servidor já aceita movimento no tick 1. A sonda `intro_probe` em Survival1 e Gemgrab1 confirmou isso.
- O congelamento vinha do **transporte**:
  - Sem `Battle.AdvertiseHost`, o 24112 anunciava o IP local do socket TCP. Em hospedagem com contêiner/NAT (Wispbyte/Pterodactyl/Docker), esse IP é privado (por exemplo 172.18.x.x) e o celular não consegue alcançá-lo.
  - O cliente v13 envia os inputs por UDP enquanto o socket UDP existe e não estourou o tempo limite. Engenharia reversa do `libg.so`:
    - `0x4e6500` é o emissor de input;
    - `0x425688` testa `[sock+0x5b0] < [sock+0x5b8]`, e o limite `[sock+0x5b8]` vale **10,0 s**.
  - Ou seja: todos os comandos iam para um endereço inalcançável até completar 10 s sem receber UDP. Só então o cliente passava ao TCP. Descontado o carregamento, sobravam cerca de 3 s sem controle.
  - Isso também explica o ícone de lag aos ~10–11 s no vídeo de Gem Grab.
- Além disso, o limite de fila TCP de 256 KB deixava acumular centenas de snapshots antigos (300–1300 B cada) em link congestionado. Isso aparece como comandos e ataques chegando atrasados.

**Correções:**

- **`Battle.Transport`**: `auto` (padrão), `udp` ou `tcp`. No modo `auto` sem `AdvertiseHost`, se o socket tem IP privado e o cliente vem de IP público, o 24112 vai com **host nulo**.
  - O handler do cliente para 24112 (`0x478fb4`) não cria socket UDP quando o host é nulo.
  - Assim o emissor usa o caminho TCP oficial do cliente ("Sending input with TCP!") desde o primeiro frame. O servidor já envia os snapshots por TCP quando não há endpoint UDP.
  - Rede local, IP público e `AdvertiseHost` explícito continuam usando UDP.
- **Fila de snapshots TCP** limitada a 8 KB: com o buffer do kernel cheio, o snapshot velho é descartado e o próximo tick, que é completo, o substitui.
- Nenhum timer, contagem ou mecânica original foi alterado. O tick continua em 50 ms.

## 3. Loading infinito em 92% ao voltar ao menu

**Causa:**

- O emissor de retorno do cliente (`0xb3c6c`) envia **14109** só em partida offline/treino. Em partida online envia **14108** ou **14101**.
- O servidor só tratava o 14109. Os outros dois eram ignorados, nunca vinha OwnHomeData e a tela parava em 92%.
- Isso vale para todos os mapas e modos, porque a mensagem não depende do mapa.

**Correção:**

- Novos handlers `GoHomeMessage` (14101, 1 booleano, layout do encode `0x343ea8`) e `GoHomeFromSpectateMessage` (14108, sem payload, `0x464bfc`).
- Ambos usam a mesma transição batalha→lobby do 14109, extraída para `returnHome()`. Ela confirma o resultado, libera a sessão e a partida, marca o retorno e envia OwnHomeData.
- Um layout inesperado nesses retornos nunca desconecta.

## 5. Limite de 200

**Origem:** `Battle.MaxPlayers = 200`, que veio do `package_battles.py` original e foi mantido no port.

**Onde era aplicado:**
- `UdpGateway.createSession` ("Battle player capacity reached");
- `BattleCoordinator.enqueue` ("Servidor de batalhas cheio");
- `PrivateRooms` (mesma mensagem);
- `Matchmaker.enqueue` ("Capacidade do matchmaking atingida").

Era um teto global de jogadores em batalha/fila. Não era limite de protocolo nem de segurança.

**Removido** da configuração, do padrão e do código. Um `MaxPlayers` antigo no config é ignorado.

**Mantidos, porque são limites reais:**
- capacidade de cada modo (dados originais);
- uma sessão UDP por conta;
- tamanho de datagrama de 12–1400 B;
- vínculo ao IP do TCP;
- 120 pacotes/s por sessão;
- buffer de input de 128;
- expiração por inatividade.

Os outros "200" do projeto (constantes de jogo, HTTP 200, limites de clube e de ranking) não foram tocados.

## Arquivos modificados

| Arquivo | Mudança |
|---|---|
| `Logic/Battle/BattleCoordinator.js` | refuse, liberação no GoHome, guards no `finished`/`result`, ticket nulo, `cancel`, sem teto, fila TCP de 8 KB |
| `Logic/Battle/PrivateRooms.js` | resultado pendente; sem teto |
| `Logic/Battle/Matchmaker.js` | sem teto |
| `Logic/Battle/ResultOutbox.js` | `acknowledge` sem exigir reenvio |
| `Logic/Battle/Network/BattleTransport.js` | `Battle.Transport`, host nulo, `isPrivateIPv4` |
| `Logic/Battle/Network/UdpGateway.js` | sem teto |
| `Logic/GameRoomService.js` | `begin_battle` |
| `Packets/LogicMessageFactory.js` | 14101 e 14108 |
| `Packets/Messages/Client/Home/GoHomeMessage.js` | novo |
| `Packets/Messages/Client/Home/GoHomeFromSpectateMessage.js` | novo |
| `Packets/Messages/Client/Home/GoHomeFromOfflinePractiseMessage.js` | `returnHome()` |
| `Packets/Messages/Client/Battle/OnPlay.js` | recusa sem desconectar |
| `Packets/Messages/Client/Gameroom/TeamSetMemberReadyMessage.js` | recusa sem desconectar |
| `Packets/Messages/Client/Login/LoginMessage.js` | encerra resultado restaurado |
| `main.js` | log do modo de transporte |
| `Utils/Config.js`, `config.json` | sem `MaxPlayers` |
| Scripts | `test_battles.js`, `package_battles.js`, `load_battle_*.js`, `package.json` |
| Testes | `tests/battle_result_outbox.test.js`, `tests/battle_transport.test.js` |
| Documentação | `BATTLES.md`, `README.md`, `VERIFICACAO-BATALHAS.txt` |
| Testes novos | `tests/helpers/v13_client.js`, `tests/battle_team_e2e.test.js`, `tests/battle_start_latency_e2e.test.js`, `tests/battle_no_player_cap.test.js` |

## Testes executados

Todos os testes usam clientes reais com protocolo criptografado e banco descartável.

**`node scripts/test_battles.js --regression`: EXIT 0.** Cobre login, criptografia, economia, social, gameroom, loja, bot, TCP, retorno, mapas, matchmaking, objetivos, combate, projéteis, corpos, bots, salas privadas, outbox, transporte, conexão, online com 6 clientes, bots UDP, reconexão, somente TCP, além dos testes novos abaixo.

**Equipe (`battle_team_e2e`)**, todos os passos passam:
- Play da equipe com um único ticket;
- cancelar e buscar de novo;
- partida compartilhada;
- resultado, retorno por **14101/14108** e nova busca;
- queda de membro na fila;
- sobrevivente busca de novo;
- amigo relogado busca com a equipe;
- recusa (motor indisponível) sem desconexão e com "pronto" limpo;
- quem sai no meio da partida busca imediatamente, sem resultado atrasado;
- resultado pendente não bloqueia o Play;
- brawler divergente é recusado sem desconexão.

**Mesmo teste no código antigo** (antes → depois):

| Situação | Antes | Depois |
|---|---|---|
| Retorno por 14101 | sem 24101 (92%) | passa |
| Recusa em equipe | `malformed packet`, os dois desconectados | passa |
| Play após sair da partida | `Jogador já está em batalha`, desconectado | passa |

**Início e latência (`battle_start_latency_e2e`):**

| Transporte | 1º input confirmado | Movimento aplicado | Ataque confirmado |
|---|---|---|---|
| UDP | 15 ms | 2º tick | 23–33 ms |
| Somente TCP | 16–17 ms | 2º tick | 49–54 ms |

O teste também cobre a seleção automática do transporte: contêiner, NAT, LAN, loopback, IP público, `AdvertiseHost` e `tcp`.

**Sem teto (`battle_no_player_cap`):** 260 jogadores no matchmaker, no coordenador e no gateway UDP. No código antigo falha com "Capacidade do matchmaking atingida". A regra de uma sessão por conta continua valendo.

**Carga:**
- `load_battle_udp 260`: entrega de 100%, p99 do event loop em 11,7 ms.
- Stress com 130 clientes (13 partidas de 10): intervalo entre snapshots p50 de 49,9 ms, atraso em relação ao relógio de tick p50 de 3,96 ms, nenhum snapshot velho. Equivalente ao pacote anterior.

## O que não pôde ser validado aqui

- Nada foi testado com o APK num celular real nem na rede da Wispbyte. A conclusão de que o IP anunciado era inalcançável vem do código (anúncio de `localAddress`) somado à engenharia reversa do cliente. Se a hospedagem tiver UDP realmente encaminhado, configure `Battle.AdvertiseHost` com o IP público e a porta UDP liberada. Se o início continuar travado mesmo assim, use `"Transport": "tcp"`.
- A percepção de atraso de ataque no aparelho depende também do RTT da rede móvel. Do lado do servidor, o comando é aplicado no tick seguinte.
- Os 36 testes `tests/native_*` continuam dependendo de dados oráculo que não estão disponíveis.
