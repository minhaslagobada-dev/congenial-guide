'use strict'
const crypto = require('crypto')
const { blake2b } = require('blakejs')
const NaCl19 = require('./NaCl19')
const Config = require('../Utils/Config')

const DEFAULT_SERVER_PUBLIC_KEY = 'EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041'
const DEFAULT_CLIENT_PRIVATE_KEY = 'BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D'

class CryptoError extends Error {
  constructor (message) {
    super(message)
    this.name = 'CryptoError'
  }
}

function safeEqual (a, b) {
  if (a.length !== b.length) return false
  return crypto.timingSafeEqual(a, b)
}

class Nonce {
  constructor (nonce = null, clientKey = null, serverKey = null) {
    if (nonce instanceof Nonce) nonce = nonce.toBuffer()
    if (!clientKey) {
      this._nonce = nonce ? Buffer.from(nonce) : crypto.randomBytes(24)
    } else {
      const parts = []
      if (nonce) parts.push(Buffer.from(nonce))
      parts.push(Buffer.from(clientKey))
      parts.push(Buffer.from(serverKey))
      this._nonce = Buffer.from(blake2b(Buffer.concat(parts), null, 24))
    }

    if (this._nonce.length !== 24) {
      throw new Error('A V13 nonce must contain exactly 24 bytes')
    }
  }

  get length () {
    return this._nonce.length
  }

  toBuffer () {
    return Buffer.from(this._nonce)
  }

  increment () {
    let value = 0n
    for (let index = 23; index >= 0; index--) {
      value = (value << 8n) | BigInt(this._nonce[index])
    }
    value = (value + 2n) % (1n << 192n)
    for (let index = 0; index < 24; index++) {
      this._nonce[index] = Number(value & 0xFFn)
      value >>= 8n
    }
  }
}

class Crypto {
  constructor (settings = null) {
    if (settings == null) {
      settings = Config.GetValue().Crypto || {}
    }

    this.enabled = settings.Enabled === undefined ? true : !!settings.Enabled
    this.decryptNonce = null
    this.encryptNonce = null
    this.public_key = null
    this.login_completed = false

    if (!this.enabled) {
      this.server_key = Buffer.alloc(0)
      this.client_sk = Buffer.alloc(0)
      this.client_pk = Buffer.alloc(0)
      this.shared_key = Buffer.alloc(0)
      this.shared_en = Buffer.alloc(0)
      return
    }

    this.server_key = Buffer.from(settings.ServerPublicKey || DEFAULT_SERVER_PUBLIC_KEY, 'hex')
    this.client_sk = Buffer.from(settings.ClientPrivateKey || DEFAULT_CLIENT_PRIVATE_KEY, 'hex')
    if (this.server_key.length !== 32 || this.client_sk.length !== 32) {
      throw new Error('V13 public/private keys must contain 32 bytes')
    }

    this.client_pk = NaCl19.scalarmultBase(this.client_sk)
    this.shared_key = NaCl19.boxBeforenm(this.server_key, this.client_sk)
    this.encryptNonce = new Nonce(crypto.randomBytes(24))
    this.shared_en = crypto.randomBytes(32)
  }

  decrypt (packetId, payload) {
    if (!this.enabled || packetId === 10100) return payload

    try {
      if (packetId === 10101) {
        if (payload.length < 96) {
          throw new CryptoError('LoginMessage is too short for V13 crypto')
        }

        this.public_key = payload.subarray(0, 32)
        if (!safeEqual(this.public_key, this.client_pk)) {
          throw new CryptoError('The client public key does not match the configured V13 patch')
        }

        const nonce = new Nonce(null, this.client_pk, this.server_key)
        const decrypted = NaCl19.secretboxOpen(payload.subarray(32), nonce.toBuffer(), this.shared_key)
        if (decrypted.length < 48) {
          throw new CryptoError('Decrypted LoginMessage has no session header')
        }

        this.session_key = decrypted.subarray(0, 24)
        this.decryptNonce = new Nonce(decrypted.subarray(24, 48))
        return decrypted.subarray(48)
      }

      if (this.decryptNonce === null) {
        return payload
      }

      this.decryptNonce.increment()
      return NaCl19.secretboxOpen(payload, this.decryptNonce.toBuffer(), this.shared_en)
    } catch (error) {
      if (error instanceof NaCl19.VerificationError) {
        throw new CryptoError(`Could not decrypt packet ${packetId}`)
      }
      throw error
    }
  }

  encrypt (packetId, payload) {
    if (!this.enabled || packetId === 20100 || packetId === 20103) return payload

    if (packetId === 20104) {
      if (this.decryptNonce === null) {
        throw new CryptoError('LoginOk cannot be sent before LoginMessage')
      }

      const nonce = new Nonce(this.decryptNonce, this.client_pk, this.server_key)
      const sessionPayload = Buffer.concat([this.encryptNonce.toBuffer(), this.shared_en, payload])
      const encrypted = NaCl19.secretbox(sessionPayload, nonce.toBuffer(), this.shared_key)
      this.login_completed = true
      return encrypted
    }

    if (this.decryptNonce === null || !this.login_completed) {
      throw new CryptoError(`Packet ${packetId} cannot use the session before LoginOk`)
    }

    this.encryptNonce.increment()
    return NaCl19.secretbox(payload, this.encryptNonce.toBuffer(), this.shared_en)
  }
}

module.exports = { Crypto, CryptoError, Nonce, DEFAULT_SERVER_PUBLIC_KEY, DEFAULT_CLIENT_PRIVATE_KEY }
