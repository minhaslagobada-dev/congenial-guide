'use strict'
const fs = require('fs')

function parseCsv (text) {
  const rows = []
  let row = []
  let field = ''
  let inQuotes = false
  let index = 0

  while (index < text.length) {
    const char = text[index]
    if (inQuotes) {
      if (char === '"') {
        if (text[index + 1] === '"') {
          field += '"'
          index += 1
        } else {
          inQuotes = false
        }
      } else {
        field += char
      }
    } else if (char === '"') {
      inQuotes = true
    } else if (char === ',') {
      row.push(field)
      field = ''
    } else if (char === '\r') {
      row.push(field)
      rows.push(row)
      row = []
      field = ''
      if (text[index + 1] === '\n') index += 1
    } else if (char === '\n') {
      row.push(field)
      rows.push(row)
      row = []
      field = ''
    } else {
      field += char
    }
    index += 1
  }

  if (field !== '' || row.length !== 0) {
    row.push(field)
    rows.push(row)
  }
  return rows
}

function readRows (path) {
  return parseCsv(fs.readFileSync(path, 'utf-8')).slice(2)
}

function readDictRows (path) {
  let text = fs.readFileSync(path, 'utf-8')
  if (text.charCodeAt(0) === 0xFEFF) {
    text = text.slice(1)
  }
  const rows = parseCsv(text)
  const header = rows.length ? rows[0] : []
  const dicts = []
  for (let index = 1; index < rows.length; index++) {
    const row = rows[index]
    const dict = {}
    for (let column = 0; column < header.length; column++) {
      dict[header[column]] = row[column] !== undefined ? row[column] : ''
    }
    dicts.push(dict)
  }
  return dicts
}

module.exports = { parseCsv, readRows, readDictRows }
