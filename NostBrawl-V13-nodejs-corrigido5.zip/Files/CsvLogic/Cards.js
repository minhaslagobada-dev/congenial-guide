'use strict'
const { readRows } = require('./CsvRows')

class Cards {
  static _rows (path) {
    return readRows(path)
  }

  static _brawler_name (brawlerId) {
    let parsed
    try {
      parsed = Number.parseInt(brawlerId, 10)
      if (Number.isNaN(parsed)) return null
    } catch (error) {
      return null
    }

    const rows = Cards._rows('GameAssets/csv_logic/characters.csv')
    if (parsed < 0 || parsed >= rows.length) {
      return null
    }
    return rows[parsed][0]
  }

  get_spg_id () {
    const ids = []
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    for (let cardId = 0; cardId < rows.length; cardId++) {
      const row = rows[cardId]
      if (row.length > 4 && (row[4] === '4' || row[4] === '5')) {
        ids.push(cardId)
      }
    }
    return ids
  }

  get_spg_by_brawler_id (brawlerId, type) {
    const brawlerName = Cards._brawler_name(brawlerId)
    if (brawlerName == null) {
      return null
    }

    const expectedType = String(type)
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    for (let cardId = 0; cardId < rows.length; cardId++) {
      const row = rows[cardId]
      if (
        row.length > 4 &&
        row[3] === brawlerName &&
        row[4] === expectedType
      ) {
        return cardId
      }
    }
    return null
  }

  get_unlocked_spg (brawlerId) {
    const brawlerName = Cards._brawler_name(brawlerId)
    if (brawlerName == null) {
      return []
    }

    const unlocked = []
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    for (let cardId = 0; cardId < rows.length; cardId++) {
      const row = rows[cardId]
      if (
        row.length > 5 &&
        row[3] === brawlerName &&
        (row[4] === '4' || row[4] === '5') &&
        row[5].toLowerCase() !== 'true'
      ) {
        unlocked.push(cardId)
      }
    }
    return unlocked
  }

  get_brawler_unlock () {
    const ids = []
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    for (let cardId = 0; cardId < rows.length; cardId++) {
      const row = rows[cardId]
      if (row.length > 4 && row[4] === '0') {
        ids.push(cardId)
      }
    }
    return ids
  }

  static get_brawler_unlock_by_character (brawlerId) {
    const brawlerName = Cards._brawler_name(brawlerId)
    if (brawlerName == null) {
      return 0
    }
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    for (let cardId = 0; cardId < rows.length; cardId++) {
      const row = rows[cardId]
      if (row.length > 4 && row[3] === brawlerName && row[4] === '0') {
        return cardId
      }
    }
    return 0
  }

  static get_brawler_star_power (brawlerId) {
    const brawlerName = Cards._brawler_name(brawlerId)
    if (brawlerName == null) {
      return 0
    }
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    for (let cardId = 0; cardId < rows.length; cardId++) {
      const row = rows[cardId]
      if (row.length > 4 && row[3] === brawlerName && row[4] === '4') {
        return cardId
      }
    }
    return 0
  }

  static get_brawler_rarity (cardId) {
    let parsed
    try {
      parsed = Number.parseInt(cardId, 10)
      if (Number.isNaN(parsed)) return null
    } catch (error) {
      return null
    }
    const rows = Cards._rows('GameAssets/csv_logic/cards.csv')
    if (parsed < 0 || parsed >= rows.length) {
      return null
    }
    const row = rows[parsed]
    return row.length > 10 ? row[10] : null
  }
}

module.exports = Cards
