'use strict'
const { spawnSync } = require('node:child_process')
const path = require('node:path')
const root = path.resolve(__dirname, '..')
const destination = path.join(root, '.venv-native')
const python = process.env.PYTHON || 'python3'
function run (binary, args) {
  const result = spawnSync(binary, args, { cwd: root, stdio: 'inherit' })
  if (result.error) throw result.error
  if (result.status !== 0) throw new Error(`Native dependency setup failed (${result.status})`)
}
run(python, ['-m', 'venv', destination])
run(path.join(destination, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python'), ['-m', 'pip', 'install', '-r', path.join(root, 'scripts/native_v13/requirements.txt')])
console.log('Native v13 dependencies installed. npm start will use .venv-native automatically.')
