"""A controlled open terrain fixture, read by original v13 tile/collision code.

Not a game mode or replacement pathfinder: this constructs a known obstacle-free
input map so target clipping can be measured inside the native implementation.
"""
from pathlib import Path
from native_csv import NativeCsv
class NativeOpenMap:
    def __init__(self,native,root,width=21,height=33):
        t=NativeCsv(native,Path(root)/'GameAssets/csv_logic/tiles.csv')
        t.initialize_schema(0x4478e4)
        self.csv=t
        self.width=width
        self.height=height
        self.tiles={}
        self.metadata={}
        self.pointer=t.alloc(0x100)
        t.word(self.pointer+0x40,width);t.word(self.pointer+0x44,height)
        t.word(self.pointer+0x48,width*300);t.word(self.pointer+0x4c,height*300)
        # Original TileMap constructor f1f88 uses three fine cells per tile.
        t.word(self.pointer+0x50,width*3);t.word(self.pointer+0x54,height*3)
        cells=t.alloc(width*height*8);t.ptr(self.pointer,cells)
        meta=t.alloc(0x100);t.ptr(meta+8,t.find('Open'))
        self.metadata['Open']=meta
        for y in range(height):
            for x in range(width):
                tile=t.alloc(0x40)
                native.call(0x39f9bc,tile,meta,x,y)
                t.ptr(cells+(y*width+x)*8,tile)
                self.tiles[x,y]=tile

    def set_tile(self,x,y,name):
        """Change controlled terrain input; all collision readers stay native."""
        if (x,y) not in self.tiles:
            raise ValueError('Tile outside controlled map')
        t=self.csv
        if name not in self.metadata:
            meta=t.alloc(0x100);t.ptr(meta+8,t.find(name))
            self.metadata[name]=meta
        tile=self.tiles[x,y]
        t.native.call(0x39f9bc,tile,self.metadata[name],x,y)
        return tile
