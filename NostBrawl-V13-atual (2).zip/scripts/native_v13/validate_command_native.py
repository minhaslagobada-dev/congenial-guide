from emulate_v13 import *
import json, os
n=NativeV13();n.decrypt()
def put(a,v): n.uc.mem_write(a,struct.pack('<I',v&0xffffffff))
def pp(a,v): n.uc.mem_write(a,struct.pack('<Q',v))
def word(a): return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
def reg(i): return n.uc.reg_read(UC_ARM64_REG_X0+i)
state={}
# These hooks supply actor/CSV lookups and capture the final activation. The
# original v13 input-entry decoder and action/coordinate consumer execute.
n.uc.mem_map(0x40001000,4096)
n.hooks[0x40001000]=lambda:1
n.hooks[0x40001004]=lambda:0
n.hooks[0x3afbc8]=lambda:state['own'] if reg(1)==1000001 else state['target'] if reg(1)==1000002 else 0
n.hooks[0x31cde4]=lambda:state['skill']
n.hooks[0x469228]=lambda:int(state['v']['skills'][state['v']['slot']].get('ChargeType') or 0)
n.hooks[0x3ec52c]=lambda:int((state['v'].get('projectile') or {}).get('AttractsPet')=='true')
n.hooks[0x4bd7ac]=lambda:3100
n.hooks[0x2599ec]=lambda:5100
n.hooks[0x4dff44]=lambda:5300
n.hooks[0x4ff8f4]=lambda:5800
for address,value in [(0x1f2a54,3100),(0x4ee3f0,5100),(0x1f1d14,26900),(0x33ff28,24900)]: n.hooks[address]=lambda value=value:value
n.hooks[0x3b7d84]=lambda:state['ulti']
n.hooks[0x36f164]=lambda:state['weapon']
n.hooks[0x11bdc4]=lambda:state['v']['skills'][1 if reg(0)==state['ulti'] else 0]['id']
n.hooks[0x16c94c]=lambda:1
for address in [0x38fec4,0x19292c,0x13b0b4]:n.hooks[address]=lambda:0
def activate():state['actual']=(int(reg(1)),int(reg(2)),int(reg(3)));return 0
n.hooks[0x267b98]=activate
if os.environ.get('V13_TRACE'):
 from unicorn import UC_HOOK_CODE
 def trace(uc,address,size,data):
  if address in [0xcd75c,0xcd7dc,0xcd8e0,0xcd900,0xcd99c]:print(hex(address),[uc.reg_read(UC_ARM64_REG_W0+i) for i in [0,20,21,24,25]])
 n.uc.hook_add(UC_HOOK_CODE,trace)
vectors=json.load(open(os.path.join(os.environ['V13_VECTOR_DIR'],'command-vectors.json')))
for v in vectors:
 state.clear();n.heap=0x10000000
 owner=n.alloc(0x400);target=n.alloc(0x400);world=n.alloc(0x200);vt=n.alloc(0x100);skill=n.alloc(0x200);projectile=n.alloc(0x200);weapon=n.alloc(16);ulti=n.alloc(16)
 for a,size in [(owner,0x400),(target,0x400),(world,0x200),(vt,0x100),(skill,0x200),(projectile,0x200)]:n.uc.mem_write(a,b'\0'*size)
 pp(owner,vt);pp(target,vt);pp(vt+0x58,0x40001000);pp(vt+0x38,0x40001004)
 state.update(v=v,own=owner,target=target,skill=skill,weapon=weapon,ulti=ulti)
 sk=v['skills'][v['slot']];pr=v.get('projectile')
 put(skill+0xb8,2 if sk['BehaviorType']=='Charge' else 0)
 if pr:
  pp(skill+0x68,projectile);n.uc.mem_write(projectile+0x90,bytes([pr.get('Indirect')=='true']))
  pp(projectile+0xa8,1 if pr.get('SpawnAreaEffectObject') else 0)
 pp(skill+0x88,1 if sk.get('SpawnedItem') else 0);pp(skill+0x70,1 if sk.get('SummonedCharacter') else 0)
 message=n.alloc(0x98);n.uc.mem_write(message,b'\0'*0x98);n.call(0x18efc4,message)
 stream=message+16;raw=bytes.fromhex(v['packet']);buf=n.alloc(len(raw));n.uc.mem_write(buf,raw);pp(stream+0x20,buf);put(stream+0x14,4);put(stream+0x18,len(raw))
 command=n.alloc(32);n.call(0x3f9fcc,command,stream)
 expected=v['input'];assert [word(command+i*4) for i in range(6)]==[expected[k] for k in ['counter','category','code','x','y','targetId']]
 assert bool(n.uc.mem_read(command+24,1)[0])==expected['flag']
 n.call(0xcd610,world,command,1000001)
 out=v['output'];assert state.get('actual')==(expected['code'],out['x'],out['y']),(sk['Name'],expected,state.get('actual'),out)
print('Native v13 command entry + action/aim handler passed:',len(vectors),'cases')
