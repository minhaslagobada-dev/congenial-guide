"""Populate every non-tutorial location with the original engine, then tick it.

Disabled rotation entries are included as data coverage, not enabled publicly.
The actual constructed map grid is captured, including generated Robo maps.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from native_tile_map import NativeTileMap
from pathlib import Path
import os,json
n=NativeV13(heap_bytes=0x8000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000)
n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
records=[];out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
for row in data.csv[15].records:
    location=dict(zip(data.csv[15].names,row));mode=location['GameMode']
    if not location['AllowedMaps'] or mode=='Tutorial':continue
    kind={'BattleRoyale':0,'BattleRoyaleTeam':6,'Survival':3,'Raid':7}.get(mode,1)
    record=dict(location=location['Name'],gameMode=mode,disabled=location['Disabled']=='true',map=location['AllowedMaps']);battle=None
    try:
        battle=NativeBattle(data,location['Name'],kind=kind);battle.add_player('ShotgunGirl',0);battle.setup()
        terrain=NativeTileMap.__new__(NativeTileMap);terrain.data=data;terrain.pointer=data.ptr(battle.pointer+0x70)
        record['terrain']=terrain.describe();record['initial']=battle.describe()
        for _ in range(40):vision=battle.frame()
        state=battle.describe();state['vision']=vision;record['final']=state
        assert all(0<=obj['x']<record['terrain']['logicWidth'] and 0<=obj['y']<record['terrain']['logicHeight'] for obj in record['initial']['objects'] if 16000000<=obj['dataId']<17000000), 'Unplaced native character'
    except Exception as error:record['error']=str(error)
    finally:
        if battle:
            try:battle.close()
            except Exception as error:record['cleanupError']=str(error)
    records.append(record);(out/'native-locations.json').write_text(json.dumps(records))
    print('Original location',location['Name'],'map',record['map'],'error',record.get('error'),flush=True)
assert records and not any('error' in record or 'cleanupError' in record for record in records)
print('Original populated locations:',len(records),'with 40 complete frames each',flush=True)
