"""Exercise original hero skill activation and character updates with client data.

This is a controlled world, with full ammo/charge as explicit input. By default
other objects are counted but not ticked. V13_ADVANCE_OBJECTS=1 invokes the
original manager update as well. A complete game mode and networking are not
certified here. Failures are reported, never replaced by game hooks.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_tile_map import NativeTileMap
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json
n=NativeV13(heap_bytes=0x4000000);n.decrypt();root=Path(__file__).resolve().parents[2]
advance_objects=os.environ.get('V13_ADVANCE_OBJECTS')=='1'
enemy_name=os.environ.get('V13_ENEMY')
enemy_hp=int(os.environ['V13_ENEMY_HP']) if os.environ.get('V13_ENEMY_HP') else None
if enemy_name and not advance_objects:raise ValueError('Enemy collision exercise requires original manager updates')
if enemy_hp is not None and not enemy_name:raise ValueError('Injured target input requires V13_ENEMY')
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
terrain=NativeTileMap(data,'Tutorial');t=data.csv[16];w=t.word;p=t.ptr;records=[]
for row in t.records:
 hero=dict(zip(t.names,row))
 if hero['Type']!='Hero' or hero['Disabled']=='true' or hero['LockedForChronos']=='true':continue
 for slot,key in [(0,'WeaponSkill'),(1,'UltimateSkill')]:
  manager=t.alloc(0x100);battle=t.alloc(0x400);p(manager+0x50,battle);p(battle,manager);p(battle+0x70,terrain.pointer)
  players=t.alloc(6*8);p(battle+0x78,players)
  for i in range(6):
   player=t.alloc(0x200);p(players+i*8,player);w(player+0x60,1000)
  player_list=t.alloc(16);p(player_list,players);w(player_list+8,6);w(player_list+12,6)
  obj=t.alloc(0x400);n.call(0x14de30,obj,data.named(16,hero['Name']));w(obj+0x3c,0);w(obj+0x40,0);n.call(0x253b18,manager,obj);n.call(0x465f38,obj,2550,3450,0)
  enemy=0
  if enemy_name:
   enemy=t.alloc(0x400);n.call(0x14de30,enemy,data.named(16,enemy_name));w(enemy+0x3c,-1);w(enemy+0x40,1);n.call(0x253b18,manager,enemy);n.call(0x465f38,enemy,3150,3450,0)
   if enemy_hp is not None:
    assert 0<enemy_hp<=data.word(enemy+0xb0),'Injured target input must be within native maximum HP'
    w(enemy+0xb0,enemy_hp)
  w(battle+0x18,150);n.call(0x18ff68,obj,count=3000000)
  state=data.ptr(data.ptr(obj+0x130)+slot*8);w(state+0x14,3000);w(state+0x10,0)
  record=dict(hero=hero['Name'],skill=hero[key],slot=slot,frames=[])
  try:
   n.call(0x4a3f3c,state,obj,3150,3450,terrain.pointer,150,count=3000000)
   for tick in range(150,190):
    w(battle+0x18,tick)
    if advance_objects:n.call(0x18572c,manager,player_list,count=10000000)
    else:n.call(0x18ff68,obj,count=3000000)
    object_ids=[]
    for index in range(data.word(manager+0xc)):
     current=data.ptr(data.ptr(manager)+index*8);metadata=data.ptr(current+0x10)
     object_ids.append(data.word(metadata+0x20) if metadata else None)
    record['frames'].append(dict(tick=tick,x=data.word(obj+0x30),y=data.word(obj+0x34),hp=data.word(obj+0xb0),objects=data.word(manager+0xc),objectDataIds=object_ids,activeMs=data.word(state+0xc),ammo=data.word(state+0x14),enemyHp=data.word(enemy+0xb0) if enemy else None))
   print('skill',hero['Name'],hero[key],'objects',record['frames'][-1]['objects'],flush=True)
  except Exception as e:
   record['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
   print('blocked',hero['Name'],hero[key],record['error'],flush=True)
  records.append(record)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
filename='hero-death-vectors.json' if enemy_hp is not None else 'hero-enemy-vectors.json' if enemy_name else 'hero-world-vectors.json' if advance_objects else 'hero-skills-vectors.json'
(out/filename).write_text(json.dumps(records))
failed=[r for r in records if 'error' in r]
scope='native manager updates' if advance_objects else 'other objects not advanced'
print('Original hero skill exercise:',len(records),'skills;',len(failed),'blocked; controlled input;',scope)
if failed:raise SystemExit(1)
