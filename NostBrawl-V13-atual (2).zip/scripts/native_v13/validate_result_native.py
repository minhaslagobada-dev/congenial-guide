"""Original 23456 factory, decoder and own-player selector; no game/CSV hooks."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from pathlib import Path
import os,json
n=NativeV13(heap_bytes=0x4000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000);n.decrypt()
data=NativeDataRegistry(n,Path(__file__).resolve().parents[2]/'GameAssets')
t=data.csv[15];factory=t.alloc(16);n.uc.mem_write(factory+8,b'\x01')
baseline=sum(capacity for _,capacity in n.guest_heap.live.values());initial=set(n.guest_heap.live);n.guest_heap.trace_allocations=True
vectors=json.loads((Path(os.environ['V13_RESEARCH_DIR'])/'result-vectors.json').read_text())
for index,vector in enumerate(vectors):
    message=n.call(0x473738,factory,23456)
    assert message and data.ptr(message)==0x7460d8
    assert n.call(0xb4fc0,message)==27
    payload=bytes.fromhex(vector['hex']);buffer=t.alloc(len(payload));n.uc.mem_write(buffer,payload)
    stream=message+0x10;previous=data.ptr(stream+0x20)
    if previous:n.free(previous)
    t.ptr(stream+0x20,buffer);t.word(stream+0x10,len(payload));t.word(stream+0x14,0);t.word(stream+0x18,len(payload))
    n.call(0x2395f4,message,count=3000000)
    assert data.word(stream+0x14)==len(payload),('Trailing result bytes',index,data.word(stream+0x14),len(payload))
    assert data.word(message+0x4c)==vector['mode'] and data.word(message+0x50)==vector['result']
    listing=data.ptr(message+0x70);assert data.word(listing+0xc)==len(vector['participants'])
    own=n.call(0x2ded88,message)
    for player_index,expected in enumerate(vector['participants']):
        player=data.ptr(data.ptr(listing)+player_index*8)
        assert data.string(data.ptr(player))==expected['name']
        assert bool(n.uc.mem_read(player+8,1)[0])==(player_index==vector['localIndex'])
        assert bool(n.uc.mem_read(player+0xa,1)[0])==(player_index==vector['mvpIndex'])
        assert data.word(data.ptr(player+0x10)+0x20)==16000000+expected['brawler_id']
        assert data.word(data.ptr(player+0x18)+0x20)==29000000+expected['skin_id']
        if expected['is_player']:assert data.word(data.ptr(player+0x28)+4)==expected['low_id']
        else:assert data.ptr(player+0x28)==0
        if player_index==vector['localIndex']:assert own==player,('Wrong native local-player selection',index)
    assert data.word(data.ptr(message+0x90)+0x20)==28000000+vector['profile']
    n.call(0x4ec310,message);n.call(0x53e5e8,message)
    outstanding=[(hex(p),n.guest_heap.live[p],n.guest_heap.origins.get(p)) for p in n.guest_heap.live.keys()-initial]
    assert sum(capacity for _,capacity in n.guest_heap.live.values())==baseline,('Result decoder retained memory',index,outstanding)
print('Original v13 result decode passed:',len(vectors),'packets; own identity, human IDs, MVP, references, full consumption and destruction')
