"""Execute original shoot routine including factory and manager registration, with a non-character origin fixture.
No gameplay hooks. Hero muzzle offsets are excluded by the controlled origin type.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root)
w=t.word;p=t.ptr
battle=t.alloc(0x400);p(battle+0x70,terrain.pointer);w(battle+0x18,100);w(battle+0x20,17)
manager=t.alloc(0x80);p(manager+0x50,battle);p(battle,manager)
table=t.alloc(0x40);w(table+0x28,6)
origin=t.alloc(0x400)
# Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
p(origin,0x74e558);w(origin+0x30,3000);w(origin+0x34,4500)
w(origin+0x3c,1);w(origin+0x40,2)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i]);p(meta+0x10,table)
 n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true'),int(d['ConstantFlyTime']=='true')]))
 w(meta+0x94,int(d['Speed'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 for target in [(5317,8429),(3100,4500),(3000,4500),(6200,9800)]:
  for spread in [0,30,-30,100]:
   for deterministic in [0,1]:
    for pattern in range(6):
     stack=0x201ff000
     n.uc.mem_write(stack,struct.pack('<7Q',456,spread&0xffffffff,deterministic,0,battle,pattern,0))
     before=get(manager+0xc);rng_before=get(battle+0x20)
     obj=n.call(0x4a0228,3000,4500,0,origin,meta,target[0],target[1],123)
     assert get(manager+0xc)==before+1
     assert int.from_bytes(n.uc.mem_read(obj+0x18,8),'little')==manager
     assert get(obj+0x3c)==1 and get(obj+0x40)==2
     assert get(obj+0x74)==123 and get(obj+0x78)==456
     points=[];point=t.alloc(8)
     for tick in [100,(100+get(obj+0x24))//2,get(obj+0x24)]:
      z=n.call(0x350c04,obj,tick,point)
      points.append(dict(tick=tick,output=dict(x=get(point),y=get(point+4),z=z)))
     records.append({'name':d['Name'],'aim':target,'spread':spread,'deterministic':deterministic,'pattern':pattern,
      'launch':get(obj+0x20),'finish':get(obj+0x24),'target':[get(obj+0x68),get(obj+0x6c)],
      'start':[get(obj+0x60),get(obj+0x64)],'rngState':get(battle+0x20),'rngBefore':rng_before,
      'progressStep':get(obj+0xcc),'z':get(obj+0x70),'points':points,
      'data':{'indirect':d['Indirect']=='true','speed':int(d['Speed'] or 0),'constantFlyTime':d['ConstantFlyTime']=='true','gravity':int(d['Gravity'] or 0),'bounce':int(d['BouncePercent'] or 0)}})

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-shoot-vectors.json').write_text(json.dumps(records))
print('Original projectile creation + spread + launch:',len(records),'cases; controlled non-character origin; no gameplay hooks')
