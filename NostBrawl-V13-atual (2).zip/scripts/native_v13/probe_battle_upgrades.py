"""Original upgraded character registration and skin-specific primary firing."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json
n=NativeV13(heap_bytes=0x4000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
record={}
try:
 battle=NativeBattle(data,'Gemgrab1')
 battle.add_player('ShotgunGirl',0,power_level=9,star_card='ShotgunGirl_unique',skin='BanditGirlPrereg')
 battle.setup();record['initial']=battle.describe();record['frames']=[]
 # A valid v13 direct-shot entry: tick=0, latency=0, sequence=1, count=1;
 # counter=1, category=1, skill=0, relative X=0, relative Y=-1000,
 # target=0, auto-aim=false. Packet bytes are supplied by the JS encoder.
 schedule=json.loads(Path(os.environ['V13_INPUT_SCHEDULE']).read_text())
 for tick in range(20):
  if tick==2:battle.input_packet(0,bytes.fromhex(schedule[0]['packet']))
  vision=battle.frame();frame=battle.describe();frame['vision']=vision;record['frames'].append(frame)
 print('Native upgraded registration + skin firing completed:',len(record['frames']),'frames',flush=True)
except Exception as e:
 record['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
 print('blocked',record['error'],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'battle-upgrades-vectors.json').write_text(json.dumps(record))
if 'error' in record:raise SystemExit(1)
