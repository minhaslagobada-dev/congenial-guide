"""Oracle for the actual v13 SkillServer::tick idle branch (0xeca90).
The complete function at0xec2a8 is invoked. No gameplay function is hooked.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import struct,json,os
n=NativeV13();n.decrypt()
def alloc(s):p=n.alloc(s);n.uc.mem_write(p,b'\0'*s);return p
def w(a,v):n.uc.mem_write(a,struct.pack('<I',v&0xffffffff))
def p(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
manager=alloc(0x100);battle=alloc(0x400);owner=alloc(0x400);globals_=alloc(0x200)
p(owner+0x18,manager);p(manager+0x50,battle);p(0xabb9b8,globals_);w(globals_+0xb4,20)
result=[]
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=alloc(0x200);p(meta+8,t.rows[i])
 behavior={'Attack':0,'Blink':1,'Charge':2,'Invisibility':3,'TransformMinion':4,'BuffMinion':5,'Rage':6,'Shield':7}[d['BehaviorType']]
 w(meta+0xb8,behavior)
 for active,cooldown,ammo in [(0,0,0),(0,25,0),(0,50,0),(0,51,0),(25,100,2990),(50,50,0),(51,0,0),(100,0,0)]:
  for berserk in [False,True]:
   for mode,team in [(0,0),(7,0),(7,1)]:
    state=alloc(0x30);n.call(0x248d70,state,meta)
    w(state+0xc,active);w(state+0x10,cooldown);w(state+0x14,ammo)
    n.uc.mem_write(state+0x21,b'\1')
    n.uc.mem_write(owner+0x205,bytes([int(berserk)]));n.uc.mem_write(owner+0x188,b'\1');w(owner+0x2fc,1)
    w(battle+0xe8,mode);w(owner+0x40,team)
    n.call(0xec2a8,state,owner,50)
    result.append({'skill':d['Name'],'definition':{'maxCharge':int(d['MaxCharge'] or 0),'rechargeTime':int(d['RechargeTime'] or 0),'behavior':behavior},
      'before':{'activeMs':active,'cooldownMs':cooldown,'ammo':ammo,'berserk':berserk,'mode':mode,'team':team},
      'after':{'activeMs':get(state+0xc),'cooldownMs':get(state+0x10),'ammo':get(state+0x14),
      'pending':n.uc.mem_read(state+0x21,1)[0],'ownerAttack':n.uc.mem_read(owner+0x188,1)[0],'ownerSlot':get(owner+0x2fc)}})
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'skill-idle-vectors.json').write_text(json.dumps(result))
print('Original v13 SkillServer::tick idle oracle:',len(result),'cases; native schema/readers; no gameplay substitutions')
