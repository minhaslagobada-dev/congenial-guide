"""Execute the original v13 activation + terrain target resolver.

CSV/cache references are input data. No native gameplay function is replaced.
This measures activation only; it does not claim that attacks have simulated.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native_open_map import NativeOpenMap
from pathlib import Path
import struct,json,csv,os
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
terrain=NativeOpenMap(n,root)
def alloc(s):return t.alloc(s)
def w(a,v):t.word(a,v)
def p(a,v):t.ptr(a,v)
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
behavior={'Attack':0,'Blink':1,'Charge':2,'Invisibility':3,'TransformMinion':4,'BuffMinion':5,'Rage':6,'Shield':7}
manager=alloc(0x100);battle=alloc(0x400);p(manager+0x50,battle);w(battle+0x18,150)
records=[]
with (root/'GameAssets/csv_logic/characters.csv').open() as f: chars=list(csv.DictReader(f))[1:]
selected=set()
for char in chars:
 if char['Type']=='Hero' and char['Disabled']!='true':selected.update([char['WeaponSkill'],char['UltimateSkill']])
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row))
 if d['Name'] not in selected:continue
 meta=alloc(0x200);p(meta+8,t.rows[i]);w(meta+0xb8,behavior[d['BehaviorType']]);w(meta+0x20,20000000+i)
 # Target resolver tests only the existence of these resolved references.
 for field,key in [(0x70,'SummonedCharacter'),(0x88,'SpawnedItem')]:
  if d[key]:p(meta+field,alloc(0x200))
 for x,y in [(3500,5000),(3000,4500),(-1000,-1000),(20000,20000)]:
  for cooldown,ammo in [(0,3000),(50,3000),(0,999)]:
   owner=alloc(0x400);p(owner+0x18,manager);w(owner+0x30,3000);w(owner+0x34,4500);w(owner+0x2fc,-1)
   state=alloc(0x30);n.call(0x248d70,state,meta);w(state+0x10,cooldown);w(state+0x14,ammo)
   try:n.call(0x4a3f3c,state,owner,x,y,terrain.pointer,150,count=3000000)
   except Exception as e:raise RuntimeError((d['Name'],x,y,cooldown,ammo,str(e))) from e
   result={'skill':d['Name'],'input':{'x':x,'y':y,'cooldown':cooldown,'ammo':ammo},'after':
    {'activeMs':get(state+0xc),'cooldownMs':get(state+0x10),'ammo':get(state+0x14),'target':[get(state+0x18),get(state+0x1c)],
     'executing':n.uc.mem_read(state+0x20,1)[0],'pending':n.uc.mem_read(state+0x21,1)[0],'castingMs':get(owner+0x198)}}
   after=result['after']
   if cooldown or ammo<1000:
    assert after['executing']==0 and after['activeMs']==0
    assert after['cooldownMs']==cooldown and after['ammo']==ammo
   else:
    assert after['executing']==1 and after['pending']==1 and after['activeMs']>=1
    assert after['cooldownMs']==0 and after['ammo']==ammo, 'The native activation does not spend ammo or start cooldown here'
    assert after['castingMs']==int(d['CastingTime'] or 0)
    assert 1<=after['target'][0]<=6298 and 1<=after['target'][1]<=9898
   records.append(result)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'skill-activation-vectors.json').write_text(json.dumps(records))
print('Original v13 activation + target/terrain resolver:',len(records),'cases;',len({r['skill'] for r in records}),'hero skills; no gameplay hooks')
