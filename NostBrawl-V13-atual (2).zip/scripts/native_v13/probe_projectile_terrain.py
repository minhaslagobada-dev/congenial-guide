"""Execute original projectile collision on controlled terrain.
No gameplay hooks. No characters are registered in the object manager.
Native terrain destruction executes; fine movement-grid rebuilding is outside this fixture.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root)
# Native global is looked up by the literal Open at 0x45ac54..0x45ac84.
terrain.csv.ptr(0xab42d0,terrain.metadata['Open'])
w=t.word;p=t.ptr
battle=t.alloc(0x400);p(battle+0x70,terrain.pointer);w(battle+0x18,100);w(battle+0x20,17)
manager=t.alloc(0x80);p(manager+0x50,battle);p(battle,manager)
table=t.alloc(0x40);w(table+0x28,6)
origin=t.alloc(0x400)
# Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
p(origin,0x74e558);w(origin+0x30,3000);w(origin+0x34,4500)
w(origin+0x3c,1);w(origin+0x40,2)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row))
 if d['Indirect']=='true':continue
 meta=t.alloc(0x200);p(meta+8,t.rows[i]);p(meta+0x10,table)
 w(meta+0x94,int(d['Speed'] or 0));w(meta+0x98,int(d['Radius'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 for tile_name in ['Open','Indestructible','Water','Blocking1','Forest']:
  for previous,current in [([2500,4650],[3500,4650]),([3500,4650],[2500,4650]),([3150,4000],[3150,5200]),([2500,4000],[3500,5200])]:
   tile=terrain.set_tile(10,15,tile_name)
   obj=t.alloc(0x120);n.call(0x4d30d0,obj,meta);p(obj+0x18,manager)
   w(obj+0x90,previous[0]);w(obj+0x94,previous[1]);w(obj+0x30,current[0]);w(obj+0x34,current[1]);w(obj+0x3c,1)
   result=n.call(0x373994,obj)
   records.append(dict(name=d['Name'],tile=tile_name,previous=previous,current=current,result=result,
    position=[get(obj+0x30),get(obj+0x34)],contact=[get(obj+0x58),get(obj+0x5c)],tileIndex=get(obj+0xc4),side=get(obj+0xc0),destroyed=int.from_bytes(n.uc.mem_read(tile,8),'little')==terrain.metadata['Open'] and tile_name!='Open',properties={k:d[k] for k in ['PassesEnvironment','PiercesEnvironment','PiercesEnvironmentLikeButter','Radius']}))

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-terrain-vectors.json').write_text(json.dumps(records))
print('Original projectile terrain collision:',len(records),'cases; no gameplay hooks')
