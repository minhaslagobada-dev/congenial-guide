from emulate_v13 import *
from unicorn import UC_HOOK_CODE
import json, os
n=NativeV13();state={}
def word(a):return struct.unpack('<I',n.uc.mem_read(a,4))[0]
def put(a,v):n.uc.mem_write(a,struct.pack('<I',v))
def pp(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
n.hooks[0x2966c8]=lambda:state['tileMap']
n.hooks[0x3226e8]=lambda:0
n.hooks[0x11997c]=lambda:int(state['tile']['IsDestructible']=='true')
n.hooks[0x53de84]=lambda:int(state['tile']['IsDestructibleNormalWeapon']=='true' and (state['tile']['BlocksMovement']=='true' or state['tile']['BlocksProjectiles']=='true'))
def tile():
 x=n.uc.reg_read(UC_ARM64_REG_W1);y=n.uc.reg_read(UC_ARM64_REG_W2);v=state['v'];state['tile']=state['defs'].get(v['grid'][y][x],state['defs']['.']);return state['tilePtr']
n.hooks[0x14c61c]=tile

def stop(uc,a,size,d):uc.emu_stop()
n.uc.hook_add(UC_HOOK_CODE,stop,begin=0x139888,end=0x139888)
n.prepare_hooks()
vectors=json.load(open(os.path.join(os.environ['V13_VECTOR_DIR'], 'header-vectors.json')))
for v in vectors:
 n.heap=0x10000000;manager=n.alloc(0x100);battle=n.alloc(0x200);mapMeta=n.alloc(0x100);tiles=n.alloc(0x80);tileptr=n.alloc(16);stream=n.alloc(0x30);payload=n.alloc(4096);players=n.alloc(16);parray=n.alloc(v['capacity']*8);extra=n.alloc(16)
 for a,size in [(manager,0x100),(battle,0x200),(mapMeta,0x100),(stream,0x30),(extra,16)]:n.uc.mem_write(a,b'\0'*size)
 pp(battle+0xc8,mapMeta);put(battle+0xfc,v['mode']);put(mapMeta+0x40,len(v['grid'][0]));pp(tileptr+8,mapMeta)
 pp(players,parray);put(players+0xc,v['capacity'])
 for i in range(v['capacity']):p=n.alloc(0x100);n.uc.mem_write(p,b'\0'*0x100);put(p+0x20,i);pp(parray+i*8,p)
 data=bytes.fromhex(v['hex']);n.uc.mem_write(payload,data);pp(stream+24,payload);put(stream+12,len(data));state.update(v=v,defs={t['TileCode']:t for t in v['tiles']},tileMap=tiles,tilePtr=tileptr)
 n.uc.reg_write(UC_ARM64_REG_SP,0x201ff000);n.uc.reg_write(UC_ARM64_REG_LR,0x40000000)
 for i,arg in enumerate([manager,stream,players,0,battle,extra]):n.uc.reg_write(UC_ARM64_REG_X0+i,arg)
 try:
  n.uc.emu_start(0x139398,0x40000000,count=300000)
  consumed=word(stream+8)*8+word(stream+16)
  assert n.uc.reg_read(UC_ARM64_REG_PC)==0x139888,hex(n.uc.reg_read(UC_ARM64_REG_PC))
  assert consumed==v['bits'],(consumed,v['bits'])
  assert n.uc.reg_read(UC_ARM64_REG_W0)==0,'Native object count misaligned'
 except Exception as e:print(v['name'],v['mode'],'FAIL',e);raise
print('Native v13 world header decode passed:',len(vectors),'locations')
