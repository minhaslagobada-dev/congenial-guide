"""Single-thread guest heap for original C/C++ allocation imports.

The guest never observes allocator headers. Allocations are aligned to 16 bytes,
freed intervals coalesce, and realloc preserves bytes before releasing a block.
"""
class GuestHeap:
    def __init__(self,native):
        self.native=native;self.live={};self.free_ranges=[];self.peak=0
        self.trace_allocations=False;self.origins={}

    def allocate(self,size):
        requested=max(1,int(size));capacity=(max(16,requested)+15)&~15
        for index,(address,length) in enumerate(self.free_ranges):
            if length<capacity:continue
            if length==capacity:self.free_ranges.pop(index)
            else:self.free_ranges[index]=(address+capacity,length-capacity)
            break
        else:
            address=self.native.heap
            if address+capacity>self.native.heap_limit:raise RuntimeError('Guest heap exhausted')
            self.native.heap+=capacity
            self.peak=max(self.peak,self.native.heap-0x10000000)
        if address in self.live:raise RuntimeError('Overlapping live guest allocation')
        self.live[address]=(requested,capacity)
        if self.trace_allocations:
            from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
            self.origins[address]=(self.native.uc.reg_read(UC_ARM64_REG_PC),self.native.uc.reg_read(UC_ARM64_REG_LR))
        return address

    def release(self,address):
        if not address:return
        allocation=self.live.pop(address,None)
        if allocation is None:raise RuntimeError('Invalid or repeated guest free: '+hex(address))
        self.origins.pop(address,None)
        self.free_ranges.append((address,allocation[1]));self.free_ranges.sort()
        merged=[]
        for pointer,length in self.free_ranges:
            if merged and merged[-1][0]+merged[-1][1]==pointer:
                previous,previous_length=merged[-1];merged[-1]=(previous,previous_length+length)
            else:merged.append((pointer,length))
        self.free_ranges=merged

    def resize(self,address,size):
        if not address:return self.allocate(size)
        if address not in self.live:raise RuntimeError('Unknown guest realloc pointer: '+hex(address))
        if not size:self.release(address);return 0
        previous_size=self.live[address][0]
        replacement=self.allocate(size)
        self.native.uc.mem_write(replacement,bytes(self.native.uc.mem_read(address,min(previous_size,size))))
        self.release(address)
        return replacement
