"""Original projectile scale and flight-dependent damage, no gameplay hooks."""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
w=t.word;p=t.ptr;records=[]
def signed(v):return v-0x100000000 if v&0x80000000 else v
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i]);obj=t.alloc(0x120);n.call(0x4d30d0,obj,meta)
 for progress in [-1,0,1,149,150,499,500,850,999,1000,1001]:
  w(obj+0xc8,progress)
  scale=signed(n.call(0x3009c8,obj,progress&0xffffffff)&0xffffffff)
  damages=[]
  for damage in [0,1,300,999,50000]:damages.append(dict(input=damage,output=signed(n.call(0x474ed4,obj,damage)&0xffffffff)))
  records.append(dict(definition=d,progress=progress,scale=scale,damages=damages))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-scale-vectors.json').write_text(json.dumps(records))
print('Original projectile scale/damage:',len(records),'scale cases;',sum(len(r['damages']) for r in records),'damage cases')
