"""Execute original projectile tick including collision, with a non-character origin fixture.
No gameplay hooks. Hero muzzle offsets are excluded by the controlled origin type.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root)
w=t.word;p=t.ptr
battle=t.alloc(0x400);p(battle+0x70,terrain.pointer);w(battle+0x18,100);w(battle+0x20,17)
manager=t.alloc(0x80);p(manager+0x50,battle);p(battle,manager)
table=t.alloc(0x40);w(table+0x28,6)
origin=t.alloc(0x400)
# Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
p(origin,0x74e558);w(origin+0x30,3000);w(origin+0x34,4500)
w(origin+0x3c,1);w(origin+0x40,2)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i]);p(meta+0x10,table)
 n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true'),int(d['ConstantFlyTime']=='true')]))
 w(meta+0x94,int(d['Speed'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 w(battle+0x18,100)
 stack=0x201ff000
 n.uc.mem_write(stack,struct.pack('<7Q',456,0,0,0,battle,0,0))
 obj=n.call(0x4a0228,3000,4500,0,origin,meta,5317,8429,123)
 flight=dict(start=[get(obj+0x60),get(obj+0x64)],end=[get(obj+0x68),get(obj+0x6c)],z=get(obj+0x70),launch=get(obj+0x20),finish=get(obj+0x24))
 data=dict(speed=int(d['Speed'] or 0),constantFlyTime=d['ConstantFlyTime']=='true',gravity=int(d['Gravity'] or 0),bounce=int(d['BouncePercent'] or 0))
 for tick in [100,101,102,103]:
  w(battle+0x18,tick)
  n.call(0x3bf1d0,obj)
  records.append({'name':d['Name'],'flight':flight,'data':data,'tick':tick,'x':get(obj+0x30),'y':get(obj+0x34),'z':get(obj+0x38),'state':get(obj+0x48)})

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-tick-vectors.json').write_text(json.dumps(records))
print('Original projectile full tick:',len(records),'cases; controlled open map; no gameplay hooks')
