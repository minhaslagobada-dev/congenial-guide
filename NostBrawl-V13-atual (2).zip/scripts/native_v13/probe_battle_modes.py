"""Populate each enabled mode with original players/bots and run native frames.

These short scenarios verify startup/encoding, not complete mode objectives,
late waves, all interactions, UDP transport or match results.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json
n=NativeV13(heap_bytes=0x8000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
assert data.word(data.tables[3]+0xb4)==20,'Original boss reload cache differs from client globals'
t=data.csv[15];records=[];seen=set()
for row in t.records:
 location=dict(zip(t.names,row));mode=location['GameMode']
 if not location['AllowedMaps'] or location['Disabled']=='true' or mode in seen:continue
 seen.add(mode)
 kind={'BattleRoyale':0,'BattleRoyaleTeam':6,'Survival':3,'Raid':7}.get(mode,1)
 record=dict(location=location['Name'],gameMode=mode,kind=kind)
 try:
  battle=NativeBattle(data,location['Name'],kind=kind)
  battle.add_player('ShotgunGirl',0)
  battle.setup();record['afterSetup']=battle.describe();record['frames']=[]
  for tick in range(40):
   vision=battle.frame();frame=battle.describe();frame['vision']=vision;record['frames'].append(frame)
  print('populated-mode',mode,len(record['afterSetup']['players']),'players;',len(record['afterSetup']['objects']),'initial objects;',len(record['frames']),'original frames',flush=True)
 except Exception as e:
  record['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
  print('blocked',mode,record['error'],flush=True)
 records.append(record)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'battle-modes-vectors.json').write_text(json.dumps(records))
failed=sum('error' in record for record in records)
print('Original populated mode startup:',len(records),'modes;',failed,'blocked; short startup scenarios, no full match-end claim')
if failed:raise SystemExit(1)
