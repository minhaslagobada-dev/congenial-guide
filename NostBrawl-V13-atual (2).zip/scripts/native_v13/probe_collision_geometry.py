"""Original v13 segment intersection and rectangle contact, no gameplay hooks."""
from emulate_v13 import NativeV13
from pathlib import Path
import json,os,struct
n=NativeV13();point=n.alloc(8);records=[]
state=17
def random(limit):
 global state
 state=(state*1664525+1013904223)&0xffffffff
 return state%limit
def signed(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
def run(kind,values):
 n.uc.mem_write(point,struct.pack('<ii',-12345,-12345))
 n.uc.mem_write(0x201ff000,struct.pack('<Q',point))
 result=n.call(0x462288,*[v&0xffffffff for v in values],point) if kind=='circle' else n.call(0x2ea134 if kind=='segment' else 0x4413ac,*[v&0xffffffff for v in values])
 records.append(dict(kind=kind,input=values,result=result,point=[signed(point),signed(point+4)]))
for values in [[0,0,100,100,0,100,100,0],[0,0,100,0,50,-50,50,50],[0,0,100,0,50,0,150,0],
 [0,0,0,0,0,0,0,0],[0,0,100,100,100,100,200,0],[3500,4650,2500,4650,3000,4500,3300,4800]]:
 run('segment',values)
for start,end in [([2500,4650],[3500,4650]),([3500,4650],[2500,4650]),([3150,4000],[3150,5200]),([2500,4000],[3500,5200]),([3150,4650],[3150,4650]),([3000,4500],[3300,4800])]:
 run('rectangle',start+end+[3000,4500,3300,4800])
for values in [[0,0,1000,0,500,0,100],[0,0,50,0,0,0,100],[0,0,0,0,0,0,100],[0,0,100,0,50,100,100],[1000,1000,10000,10000,5000,5000,0]]:
 run('circle',values)
for _ in range(4000):
 run('circle',[random(20001)-10000 for _ in range(6)]+[random(1000)])
 run('segment',[random(20001)-10000 for _ in range(8)])
 x=random(9000);y=random(9000)
 run('rectangle',[random(10000),random(10000),random(10000),random(10000),x,y,x+random(1000),y+random(1000)])
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'collision-geometry-vectors.json').write_text(json.dumps(records))
print('Original v13 collision geometry:',len(records),'segment/rectangle cases')
