"""Measure native-frame CPU cost and imported runtime callback overhead."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
import cProfile,pstats,time,os,json
n=NativeV13(heap_bytes=0x4000000,reclaim_memory=True);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
battle=NativeBattle(data,'Gemgrab1');battle.add_player('ShotgunGirl',0);battle.setup()
data.csv[15].word(battle.pointer+0x18,300)
profile=cProfile.Profile();start=time.perf_counter();cpu=time.process_time();profile.enable()
for _ in range(20):battle.frame()
profile.disable();result=dict(frames=20,wallSeconds=time.perf_counter()-start,cpuSeconds=time.process_time()-cpu)
n.instruction_counting=False;n.call_timeout_us=2000000
start=time.perf_counter();cpu=time.process_time()
for _ in range(20):battle.frame()
result['withoutInstructionCounter']=dict(frames=20,wallSeconds=time.perf_counter()-start,cpuSeconds=time.process_time()-cpu)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
profile.dump_stats(str(out/'native-frame-profile.pstats'));(out/'native-frame-profile.json').write_text(json.dumps(result))
print('Native frame cost:',result,flush=True)
pstats.Stats(profile).sort_stats('cumulative').print_stats(12)
