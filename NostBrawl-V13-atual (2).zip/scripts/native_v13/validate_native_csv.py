from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import json,os,csv
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_LR
n=NativeV13();n.decrypt()
last_column=[]
def inspect(uc,address,size,data):
    if address==0x3fd61c:
        p=uc.reg_read(UC_ARM64_REG_X1)
        length=int.from_bytes(uc.mem_read(p+4,4),'little')
        text=p+8 if length<8 else int.from_bytes(uc.mem_read(p+8,8),'little')
        last_column[:]=[bytes(uc.mem_read(text,length)).decode()]
    elif not uc.reg_read(UC_ARM64_REG_X0):
        raise RuntimeError(('Original v13 schema assertion',last_column,hex(uc.reg_read(UC_ARM64_REG_LR))))
n.uc.hook_add(UC_HOOK_CODE,inspect,begin=0x3fd61c,end=0x3fd61c)
n.uc.hook_add(UC_HOOK_CODE,inspect,begin=0x1dca94,end=0x1dca94)
root=Path(__file__).resolve().parents[2]
checks=[]
for name, initializer in [('characters',0x1fbfa4),('skills',0x13da8c)]:
    filename=root/'GameAssets/csv_logic'/f'{name}.csv'
    with filename.open() as source: raw=list(csv.reader(source))
    rejected=[]
    for row in raw[2:]:
        for i,kind in enumerate(raw[1]):
            value=row[i] if i<len(row) else ''
            if kind.lower()=='int' and value:
                try: int(value)
                except ValueError: rejected.append({'row':row[0],'column':raw[0][i],'value':value})
    excluded=sorted({r['row'] for r in rejected})
    table=NativeCsv(n, filename, excluded_rows=excluded)
    try: table.initialize_schema(initializer)
    except RuntimeError as error:
        if 'Original v13 schema assertion' not in str(error): raise
        checks.append({'table':name,'schema':'rejected by original v13','firstFailedColumn':last_column[0],'rejected':rejected})
        continue
    for index,row in enumerate(table.records):
        for column,kind in enumerate(table.types):
            value=row[column] if column<len(row) else ''
            if kind.lower() == 'int':
                actual=n.call(0x469228,table.rows[index],column)
                expected=(int(value) if value else 0) & 0xffffffffffffffff
                # X0 returns a 32-bit result; compare the exact 32 bits.
                assert actual & 0xffffffff == expected & 0xffffffff,(name,index,column,value,actual)
            elif kind.lower() == 'boolean':
                actual=n.call(0x24f974,table.rows[index],column)
                assert actual == int(value.lower()=='true'),(name,index,column,value,actual)
    checks.append({'table':name,'rows':len(table.rows),'columns':len(table.names),'rejected':rejected})
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'csv-validation.json').write_text(json.dumps(checks,indent=2))
print('Native CSV audit completed:',json.dumps(checks))
