"""Full original CharacterServer attack configuration; no gameplay hooks."""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
w=t.word;p=t.ptr
manager=t.alloc(0x80);battle=t.alloc(0x400);p(manager+0x50,battle);w(battle+0x18,100)
records=[]
player=t.alloc(0x100);skin=t.alloc(0x100);players=t.alloc(8);p(players,player);p(player+0x30,skin);p(battle+0x78,players)
override=t.alloc(0x200);p(override+8,t.rows[0]);p(skin+0xe0,override)
override_definition=dict(zip(t.names,t.records[0]))
invis_meta=t.alloc(0x200);w(invis_meta+0xb8,3)
ints=[0x7c,0xbc,0xc0,0xc4,0xc8,0xcc,0xd0,0xd4,0xe0,0xe4,0xe8,0xf0,0xf4,0xf8,0x180,0x184,0x1dc,0x2fc]
bytes_=[0x140,0x188,0x1d5,0x206]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i]);n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true')]))
 for target in [(3500,5000),(3000,4500),(3000,2000),(5317,8429)]:
  for immediate in [0,1]:
   for two_guns in [0,1]:
    for super_ in [0,1]:
     for variant in ['base','interruptInvisibility','skinOverride']:
      owner=t.alloc(0x400);p(owner,0x72dc10);p(owner+0x18,manager);w(owner+0x3c,0 if variant=='skinOverride' else -1);w(owner+0x30,3000);w(owner+0x34,4500);w(owner+0x7c,17)
      invis=t.alloc(0x30);p(invis,invis_meta);w(invis+0xc,50)
      if variant=='interruptInvisibility':
       n.uc.mem_write(owner+0x1cc,b'\x01');n.uc.mem_write(owner+0x3a0,b'\x01')
       skills=t.alloc(8);p(skills,invis);p(owner+0x130,skills);w(owner+0x13c,1)
      n.uc.mem_write(0x201ff000,struct.pack('<8Q',60,2,5,meta,immediate,two_guns,37,super_))
      n.call(0x3fdff8,owner,target[0],target[1],30,22,3,300,100)
      records.append(dict(projectile=d,variant=variant,override=override_definition,afterInvisibilityMs=get(invis+0xc),resolvedProjectileIsOverride=int.from_bytes(n.uc.mem_read(owner+0xd8,8),'little')==override,input=dict(target=target,bonusDamage=30,range=22,attackCount=3,damage=300,attackIntervalMs=100,spread=60,pattern=2,bullets=5,executeFirstImmediately=bool(immediate),twoGuns=bool(two_guns),rangeBonus=37,isSuper=bool(super_)),
       output=dict(i32={hex(off):get(owner+off) for off in ints},u8={hex(off):n.uc.mem_read(owner+off,1)[0] for off in bytes_})))

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'attack-configuration-vectors.json').write_text(json.dumps(records))
print('Original full attack configuration:',len(records),'cases; no gameplay hooks')
