"""Original moveTo, pathfinder and character updates on a real client map.

Battle/player structures remain controlled input. No movement, terrain, metadata
reader or character update function is replaced.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_tile_map import NativeTileMap
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
terrain=NativeTileMap(data,'Tutorial');description=terrain.describe()
t=data.csv[19];w=t.word;p=t.ptr;records=[]
# Select a four-tile unobstructed corridor from the actual native source grid.
open_code=next(row[tile.names.index('TileCode')] for tile in [data.csv[27]] for row in tile.records if row[0]=='Open')
corridors=[(x,y) for y,line in enumerate(description['grid']) for x in range(1,len(line)-4) if line[x:x+4]==open_code*4]
assert corridors,'No open test corridor in Tutorial'
x,y=corridors[len(corridors)//2];origin=(x*300+150,y*300+150);target=(origin[0]+600,origin[1])
scenario=os.environ.get('V13_MOVEMENT_SCENARIO','corridor')
if scenario not in ('corridor','obstacle'):raise ValueError('Unknown movement scenario')
if scenario=='obstacle':
 origin=(2550,6450);target=(2550,7050)
 assert description['grid'][22][8:11]=='YYY'
ticks=100 if scenario=='obstacle' else 30
for row in data.csv[16].records:
 d=dict(zip(data.csv[16].names,row))
 if d['Type']!='Hero' or d['Disabled']=='true' or d['LockedForChronos']=='true':continue
 manager=t.alloc(0x100);battle=t.alloc(0x400);p(manager+0x50,battle);p(battle,manager);p(battle+0x70,terrain.pointer)
 players=t.alloc(6*8);p(battle+0x78,players)
 for i in range(6):p(players+i*8,t.alloc(0x200))
 obj=t.alloc(0x400);n.call(0x14de30,obj,data.named(16,d['Name']));w(obj+0x3c,0);w(obj+0x40,0);n.call(0x253b18,manager,obj);n.call(0x465f38,obj,*origin,0)
 w(battle+0x18,150)
 try:
  n.call(0x3921f4,obj,*target,0,0,count=3000000)
  for tick in range(150,150+ticks):
   w(battle+0x18,tick);n.call(0x18ff68,obj,count=3000000)
   records.append(dict(name=d['Name'],tick=tick,x=data.word(obj+0x30),y=data.word(obj+0x34),origin=origin,target=target,hp=data.word(obj+0xb0)))
 except Exception as e:raise RuntimeError((d['Name'],str(e))) from e
 print('moved',d['Name'],records[-1]['x'],records[-1]['y'],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/('character-obstacle-vectors.json' if scenario=='obstacle' else 'character-movement-vectors.json')).write_text(json.dumps(records))
print('Original character movement:',len(records),'frames; real native map/pathfinder and controlled battle/player structures')
