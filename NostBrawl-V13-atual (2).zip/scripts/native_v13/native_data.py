"""Original v13 data-table construction and gameplay reference resolution.

CSV bytes are inputs. Native table/metadata constructors, lookups and all
reference-initialization instructions execute unchanged inside the ELF.
Client visual tables are constructed for named references, not rendered.
"""
from pathlib import Path
from native_csv import NativeCsv
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X19,UC_ARM64_REG_X20,UC_ARM64_REG_X21,UC_ARM64_REG_LR,UC_ARM64_REG_PC

class NativeDataRegistry:
    SPECS=[(3,'csv_logic/globals.csv'),(4,'csv_client/sounds.csv'),(5,'csv_logic/resources.csv'),(6,'csv_logic/projectiles.csv'),(7,'csv_client/effects.csv'),
           (11,'csv_client/health_bars.csv'),(12,'csv_client/music.csv'),(15,'csv_logic/locations.csv'),(16,'csv_logic/characters.csv'),(17,'csv_logic/area_effects.csv'),
           (18,'csv_logic/items.csv'),(19,'csv_logic/maps.csv'),(23,'csv_logic/cards.csv'),(37,'csv_logic/map_blocks.csv'),(20,'csv_logic/skills.csv'),
           (27,'csv_logic/tiles.csv'),(29,'csv_logic/skins.csv'),(28,'csv_logic/player_thumbnails.csv')]
    GAMEPLAY=[3,6,15,16,17,18,20,27,23,29]
    def __init__(self,native,assets,progress=None,extra_references=()):
        self.native=native;self.tables={};self.csv={};self.entries={}
        # The library provides its own disabled live-tuning service for normal
        # gameplay. Skin references register texture strings through it even
        # when no editor/tuning UI is active. Execute that initializer intact.
        native.call(0x3f991c,0)
        self._diagnostics=[]
        native.uc.hook_add(UC_HOOK_CODE,self._reference_check,begin=0x435bbc,end=0x435bbc)
        native.uc.hook_add(UC_HOOK_CODE,self._assertion_check,begin=0x1dca94,end=0x1dca94)
        for type_id,filename in self.SPECS:
            source=NativeCsv(native,Path(assets)/filename,grouped_rows=True)
            table=source.alloc(0x108 if type_id==3 else 0x40)
            native.call(0x295a64 if type_id==3 else 0x3b1b68,table,source.table,type_id,count=5000000)
            self.tables[type_id]=table;self.csv[type_id]=source
            source.ptr(0xabb9a0+type_id*8,table)
            size=self.word(table+0x14);assert size==len(source.records),(filename,size,len(source.records))
            array=self.ptr(table+8)
            self.entries[type_id]={row[0]:self.ptr(array+i*8) for i,row in enumerate(source.records)}
            for i,row in enumerate(source.records):
                assert self.word(self.entries[type_id][row[0]]+0x20)==type_id*1000000+i,(filename,row[0])
            if progress:progress('constructed',type_id,len(source.records))
        for type_id in dict.fromkeys([*self.GAMEPLAY,*extra_references]):
            if type_id not in self.tables:raise ValueError('Native reference table is not loaded: '+str(type_id))
            try:native.call(0x2245e4 if type_id==3 else 0x1ee9e4,self.tables[type_id],count=12000000)
            except Exception as e:raise RuntimeError(('Native gameplay reference initialization',type_id,hex(native.uc.reg_read(UC_ARM64_REG_PC)),hex(native.uc.reg_read(UC_ARM64_REG_LR)),str(e))) from e
            if progress:progress('references',type_id,len(self.entries[type_id]))
    def ptr(self,address):return int.from_bytes(self.native.uc.mem_read(address,8),'little')
    def word(self,address):return int.from_bytes(self.native.uc.mem_read(address,4),'little',signed=True)
    def string(self,address):
        length=self.word(address+4);data=address+8 if length<8 else self.ptr(address+8)
        return bytes(self.native.uc.mem_read(data,length)).decode()
    def _reference_check(self,uc,address,size,data):
        if uc.reg_read(UC_ARM64_REG_X0)==0 and uc.reg_read(UC_ARM64_REG_X19):
            table=uc.reg_read(UC_ARM64_REG_X21);name=self.string(uc.reg_read(UC_ARM64_REG_X20))
            raise RuntimeError(('Missing native data reference',self.word(table+0x28),name,hex(uc.reg_read(UC_ARM64_REG_LR))))
    def _assertion_check(self,uc,address,size,data):
        if uc.reg_read(UC_ARM64_REG_X0)==0:
            raise RuntimeError(('Native data assertion',hex(uc.reg_read(UC_ARM64_REG_LR))))
    def named(self,type_id,name):return self.entries[type_id][name]
