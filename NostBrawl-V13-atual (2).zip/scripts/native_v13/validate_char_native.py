from emulate_v13 import *
from native_data import NativeDataRegistry
from pathlib import Path
from unicorn import UC_HOOK_CODE
import json, os
n=NativeV13();n.decrypt()
# Use complete client metadata and original schema/readers. In particular,
# RaidBoss uses its actual AreaEffect reference, never a sentinel pointer.
registry=NativeDataRegistry(n,Path(__file__).resolve().parents[2]/'GameAssets')
vector_heap=n.heap
def word(a):return struct.unpack('<I',n.uc.mem_read(a,4))[0]
def put(a,v):n.uc.mem_write(a,struct.pack('<I',v))
def ptrput(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
state={}
def bounds(uc,a,size,d):
 p=uc.reg_read(UC_ARM64_REG_X0);bits=uc.reg_read(UC_ARM64_REG_W1);pos=word(p+8)*8+word(p+16)
 if pos+bits>state['bits']:raise RuntimeError(f'Native overread {pos}+{bits}>{state["bits"]}, lr={uc.reg_read(UC_ARM64_REG_LR):#x}')
n.uc.hook_add(UC_HOOK_CODE,bounds,begin=0x4f4518,end=0x4f4518)
vectors=json.load(open(os.path.join(os.environ['V13_VECTOR_DIR'], 'char-vectors.json')))
for v in vectors:
 n.heap=vector_heap
 obj=n.alloc(0x200);meta=registry.named(16,v['name']);stream=n.alloc(0x30);payload=n.alloc(512);array=n.alloc(16)
 n.uc.mem_write(obj,b'\0'*0x200);n.uc.mem_write(stream,b'\0'*0x30)
 ptrput(obj,0x75e938);ptrput(obj+0x10,meta);ptrput(obj+0x68,array);put(obj+0x74,len(v['skills']))
 for i,s in enumerate(v['skills']):
  sk=n.alloc(0x30);data=registry.named(20,s['Name'])
  n.uc.mem_write(sk,b'\0'*0x30)
  ptrput(sk,data);ptrput(array+i*8,sk)
 data=bytes.fromhex(v['hex']);n.uc.mem_write(payload,data);ptrput(stream+24,payload);put(stream+12,len(data));state['bits']=v['bits']
 try:
  n.call(0x45768c,obj,stream,int(v['own']),v['mode'],int(v['large']))
  consumed=word(stream+8)*8+word(stream+16)
  assert consumed==v['bits'],(consumed,v['bits'])
  assert word(obj+0x30)==v['object']['x']
  assert word(obj+0x34)==v['object']['y']
  assert word(obj+0x58)==v['object']['hp'],word(obj+0x58)
  assert word(obj+0x5c)==v['object']['maxHp']
  assert word(obj+0x94)==int(bool(v['object']['statuses']))
  assert bool(n.uc.mem_read(obj+0x88,1)[0])==v['object']['invisible']
 except Exception as e:
  print(v['name'],v['mode'],v['own'],'FAIL',e);raise
print('Native v13 character decode passed:',len(vectors),'vectors; real client metadata and CSV readers')
