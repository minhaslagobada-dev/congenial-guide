"""Natural original-mode endings, including native AI, objectives and clocks.

One idle human per match, no assignment to HP, scores, positions, clocks, ranks
or end flags. A cap is reported as incomplete, never converted into a victory.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json,time
n=NativeV13(heap_bytes=0x8000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000)
n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
records=[];seen=set();table=data.csv[15]
for row in table.records:
    location=dict(zip(table.names,row));mode=location['GameMode']
    if not location['AllowedMaps'] or location['Disabled']=='true' or mode in seen:continue
    seen.add(mode);kind={'BattleRoyale':0,'BattleRoyaleTeam':6,'Survival':3,'Raid':7}.get(mode,1)
    record=dict(location=location['Name'],gameMode=mode,kind=kind,checkpoints=[],finished=False)
    battle=None;start=time.monotonic()
    try:
        battle=NativeBattle(data,location['Name'],kind=kind);battle.add_player('ShotgunGirl',0);battle.setup()
        record['initial']=battle.describe()
        for index in range(int(os.environ.get('V13_LIFECYCLE_TICKS','6500'))):
            vision=battle.frame();ended=bool(n.uc.mem_read(battle.pointer+0xa3,1)[0])
            if (index+1)%100==0 or ended:
                state=battle.describe();state['vision']=vision;record['checkpoints'].append(state)
            if ended:record['finished']=True;break
        record['framesProcessed']=index+1
    except Exception as error:
        record['error']=dict(message=str(error),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
    finally:
        if battle is not None:
            try:battle.close()
            except Exception as error:record['cleanupError']=str(error)
    record['elapsedSeconds']=time.monotonic()-start;records.append(record)
    (out/'mode-lifecycles.json').write_text(json.dumps(records))
    print('Original lifecycle',mode,'finished',record['finished'],'frames',record.get('framesProcessed'),'error',record.get('error'),flush=True)
if any(not r['finished'] or 'error' in r or 'cleanupError' in r for r in records):raise SystemExit(1)
print('All original mode lifecycles ended naturally',flush=True)
