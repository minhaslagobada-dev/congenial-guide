"""Marshal ARM64 va_list arguments to host libc's snprintf.

Only the ABI is adapted. C formatting runs in libc; game routines stay native.
"""
import ctypes,re,struct
from unicorn.arm64_const import UC_ARM64_REG_X3
_TOKEN=re.compile(rb'%([-+ #0]*)(\*|[0-9]*)(?:\.(\*|[0-9]*))?(hh|ll|[hljztL])?([diuoxXfFeEgGaAcspn%])')
_HOST=ctypes.CDLL(None).snprintf
_HOST.restype=ctypes.c_int
_HOST.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_char_p]

def vsnprintf(native,destination,size,format_pointer):
    uc=native.uc;va=uc.reg_read(UC_ARM64_REG_X3);fmt=native.string(format_pointer);args=[];writebacks=[]
    def ptr(a):return int.from_bytes(uc.mem_read(a,8),'little')
    def offset(a):return int.from_bytes(uc.mem_read(a,4),'little',signed=True)
    def take(fp=False):
        address=va+(28 if fp else 24);off=offset(address)
        if off<0:
            location=ptr(va+(16 if fp else 8))+off
            uc.mem_write(address,struct.pack('<i',off+(16 if fp else 8)))
        else:
            location=ptr(va);uc.mem_write(va,struct.pack('<Q',location+8))
        return bytes(uc.mem_read(location,8))
    position=0
    while position<len(fmt):
        if fmt[position]!=37:position+=1;continue
        match=_TOKEN.match(fmt,position)
        if not match:raise RuntimeError('Unsupported native printf format: '+repr(fmt))
        position=match.end();flags,width,precision,length,spec=match.groups();length=length or b''
        for field in [width,precision]:
            if field==b'*':args.append(ctypes.c_int(int.from_bytes(take()[:4],'little',signed=True)))
        if spec==b'%':continue
        if spec in b'fFeEgGaA':
            if length==b'L':raise RuntimeError('Native long-double formatting requires an ARM64 long-double adapter')
            args.append(ctypes.c_double(struct.unpack('<d',take(True))[0]));continue
        raw=int.from_bytes(take(),'little')
        if spec==b's':
            if length:raise RuntimeError('Native wide-string formatting is not implemented')
            args.append(ctypes.c_char_p(native.string(raw) if raw else None))
        elif spec==b'p':args.append(ctypes.c_void_p(raw))
        elif spec==b'n':
            kind=ctypes.c_longlong if length in [b'll',b'j',b'z',b't',b'l'] else ctypes.c_short if length==b'h' else ctypes.c_byte if length==b'hh' else ctypes.c_int
            value=kind();args.append(ctypes.byref(value));writebacks.append((raw,value))
        elif spec in b'dic':
            args.append(ctypes.c_longlong(raw) if length in [b'll',b'j',b'z',b't',b'l'] else ctypes.c_int(raw&0xffffffff))
        else:args.append(ctypes.c_ulonglong(raw) if length in [b'll',b'j',b'z',b't',b'l'] else ctypes.c_uint(raw&0xffffffff))
    if size>1048576:raise RuntimeError('Native formatting buffer exceeds harness limit')
    buffer=ctypes.create_string_buffer(size) if size else None
    result=_HOST(buffer,size,fmt,*args)
    if buffer is not None:uc.mem_write(destination,buffer.raw[:min(size,max(0,result)+1)])
    for guest,value in writebacks:uc.mem_write(guest,ctypes.string_at(ctypes.byref(value),ctypes.sizeof(value)))
    return result
