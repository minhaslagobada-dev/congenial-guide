"""Observe native eliminations and execute original offline placement readers.

The offline readers require an Android scene/current-viewer context. This small
read-only view supplies that context and area metadata; gameplay objects stay
owned by the original server. No health, alive, spawn or rank state is written
back to the match. The client area vtable is used only for its original type
getter, because server/client virtual method offsets differ.
"""
class NativePlacements:
    def __init__(self,battle):
        self.battle=battle;self.data=battle.data;self.native=battle.native
        self.ranks={};self.buffers=[]
        def allocate(size):
            pointer=self.native.alloc(size);self.native.uc.mem_write(pointer,b'\0'*size);self.buffers.append(pointer);return pointer
        self.mode=allocate(0x40);self.scene=allocate(0x38);self.client=allocate(0xc0)
        self.data.csv[15].ptr(self.mode+0x38,battle.pointer)
        self.data.csv[15].ptr(self.scene+0x30,self.client)

    def rank(self,index,team,duo):
        data=self.data;n=self.native;t=data.csv[15];temporary=[]
        def allocate(size):
            pointer=n.alloc(max(size,16));n.uc.mem_write(pointer,b'\0'*max(size,16));temporary.append(pointer);return pointer
        t.word(self.client+0xb0,index);t.word(self.client+0xb4,team)
        if duo:
            areas=[]
            manager=self.battle.manager
            for i in range(data.word(manager+0xc)):
                obj=data.ptr(data.ptr(manager)+i*8);meta=data.ptr(obj+0x10)
                if 17000000<=data.word(meta+0x20)<18000000:areas.append((meta,data.word(obj+0x40)))
            items=allocate(len(areas)*8);listing=allocate(16)
            t.ptr(listing,items);t.word(listing+0xc,len(areas));t.ptr(self.client+0x18,listing)
            for i,(meta,owner_team) in enumerate(areas):
                view=allocate(0x48);t.ptr(view,0x750f78);t.ptr(view+0x10,meta);t.word(view+0x40,owner_team);t.ptr(items+i*8,view)
        previous=n.hooks.get(0x4d2560)
        n.hooks[0x4d2560]=lambda:self.scene
        try:return n.call(0x3b0078 if duo else 0x2558e4,self.mode)
        finally:
            if previous is None:del n.hooks[0x4d2560]
            else:n.hooks[0x4d2560]=previous
            for pointer in temporary:n.free(pointer)

    def observe(self,state):
        mode=state['nativeMode']
        if mode not in (6,9):return
        if mode==6:
            for player in state['players']:
                if player['index'] not in self.ranks and (not player['alive'] or state['ended']):
                    self.ranks[player['index']]=self.rank(player['index'],player['team'],False)
        else:
            alive={player['team'] for player in state['players'] if player['alive']}
            manager=self.battle.manager;data=self.data
            for i in range(data.word(manager+0xc)):
                obj=data.ptr(data.ptr(manager)+i*8);meta=data.ptr(obj+0x10)
                if 17000000<=data.word(meta+0x20)<18000000 and data.word(meta+0x80)==9:alive.add(data.word(obj+0x40))
            for player in state['players']:
                if player['index'] not in self.ranks and (player['team'] not in alive or state['ended']):
                    self.ranks[player['index']]=self.rank(player['index'],player['team'],True)

    def close(self):
        for pointer in self.buffers:self.native.free(pointer)
        self.buffers=[]
