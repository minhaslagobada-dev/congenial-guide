"""Earn and cast each enabled hero's Super via original encoded human inputs.

The driver chooses destinations/targets only. Native AI, damage, charge, death,
respawn, cooldowns, skill execution and game-over rules are never overwritten.
Unfinished scenarios are recorded as such, not counted as a working Super.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1
from unicorn import UC_HOOK_CODE
import os,json,math,time
n=NativeV13(heap_bytes=0x8000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000)
n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
skills={row[0]:dict(zip(data.csv[20].names,row)) for row in data.csv[20].records}
location=next(row[0] for row in data.csv[15].records if dict(zip(data.csv[15].names,row))['GameMode']=='BountyHunter')
records=[]
observing={}
def activated(uc,address,size,unused):
    skill=uc.reg_read(UC_ARM64_REG_X0);character=uc.reg_read(UC_ARM64_REG_X1)
    if data.ptr(skill)==observing.get('super') and data.word(character+0x3c)==0:
        observing['record']['activations'].append(dict(tick=data.word(observing['battle'].pointer+0x18),characterId=data.word(character+8)))
n.uc.hook_add(UC_HOOK_CODE,activated,begin=0x4a3f3c,end=0x4a3f3c)
for row in data.csv[16].records:
    hero=dict(zip(data.csv[16].names,row))
    if hero['Type']!='Hero' or hero['Disabled']=='true' or hero['LockedForChronos']=='true':continue
    record=dict(hero=hero['Name'],earned=False,cast=False,checkpoints=[],superCommands=[],activations=[]);battle=None;start=time.monotonic()
    weapon=skills[hero['WeaponSkill']];reach=int(weapon['CastingRange'] or '10')*100
    desired=max(250,min(1400,int(reach*.6)))
    weapon_code=data.word(data.named(20,hero['WeaponSkill'])+0x20)-20000000
    super_code=data.word(data.named(20,hero['UltimateSkill'])+0x20)-20000000
    try:
        battle=NativeBattle(data,location);battle.add_player(hero['Name'],0);battle.setup();counter=1
        observing.update(record=record,battle=battle,super=data.named(20,hero['UltimateSkill']))
        for index in range(int(os.environ.get('V13_EARNED_SUPER_TICKS','3121'))):
            state=battle.describe();human=state['players'][0]
            own=next((obj for obj in state['objects'] if obj['id']==human['characterId']),None)
            if human['superCharge']==4000:record['earned']=True
            if index%10==2 and not record['cast'] and own and own.get('hp',0)>0:
                enemies=[obj for obj in state['objects'] if obj.get('hp',0)>0 and any(p['team']!=human['team'] and p['characterId']==obj['id'] for p in state['players'])]
                if enemies:
                    target=min(enemies,key=lambda obj:(obj['x']-own['x'])**2+(obj['y']-own['y'])**2)
                    dx=own['x']-target['x'];dy=own['y']-target['y'];distance=max(1,math.hypot(dx,dy));commands=[]
                    if distance>desired*1.15:
                        commands.append(dict(code=100,x=int(target['x']+dx*desired/distance),y=int(target['y']+dy*desired/distance)))
                    if distance<=max(desired*1.5,reach):
                        if human['superCharge']==4000:
                            commands.extend([dict(code=107),dict(code=super_code,targetId=target['id'],flag=True)])
                            record['superCommands'].append(dict(tick=state['tick'],charge=4000))
                        else:commands.extend([dict(code=108),dict(code=weapon_code,targetId=target['id'],flag=True)])
                    if commands:
                        packet=battle.encode_input_packet(commands,counter);counter+=len(commands);battle.input_packet(0,packet)
            vision=battle.frame();state=battle.describe()
            if record['superCommands'] and record['activations'] and state['players'][0]['superCharge']<4000:
                if not record['cast']:record['castTick']=state['tick']
                record['cast']=True
            after_cast=state['tick']-record.get('castTick',state['tick'])
            if (index+1)%200==0 or (record['cast'] and after_cast in (0,20,40)) or state['ended']:
                state['vision']=vision;record['checkpoints'].append(state)
            if (record['cast'] and after_cast>=40) or state['ended']:break
        record['framesProcessed']=index+1
        record['postCastFrames']=after_cast
    except Exception as error:
        record['error']=dict(message=str(error),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
    finally:
        if battle:
            try:battle.close()
            except Exception as error:record['cleanupError']=str(error)
    record['elapsedSeconds']=time.monotonic()-start;records.append(record)
    (out/'earned-supers.json').write_text(json.dumps(records))
    print('Original earned Super',record['hero'],'earned',record['earned'],'cast',record['cast'],'ticks',record.get('framesProcessed'),'error',record.get('error'),flush=True)
if any(not record['cast'] or 'error' in record or 'cleanupError' in record for record in records):raise SystemExit(1)
print('All enabled heroes earned and cast Supers through original inputs',flush=True)
