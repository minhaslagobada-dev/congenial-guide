"""Original location, random map selection and empty mode/container update.

No players or match objectives are initialized. This isolates original map
selection and location-to-mode decoding, not a playable or completed match.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_tile_map import NativeTileMap
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json
n=NativeV13(heap_bytes=0x4000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
t=data.csv[15];w=t.word;p=t.ptr;p(0xab42d0,data.named(27,'Open'))
records=[];seen=set()
for row in t.records:
 location=dict(zip(t.names,row))
 if not location['AllowedMaps'] or location['Disabled']=='true' or location['GameMode'] in seen:continue
 seen.add(location['GameMode'])
 battle=t.alloc(0x400);n.call(0x4328f8,battle,1);manager=data.ptr(battle);n.call(0x201398,manager,battle)
 n.call(0x425ef8,battle,data.named(15,location['Name']));n.call(0x13a028,battle,17)
 record=dict(location=location['Name'],gameMode=location['GameMode'],nativeMode=data.word(battle+0xe8))
 try:
  n.call(0x1e7b14,battle,0,1,0,count=20000000)
  map_=data.ptr(battle+0x70)
  record.update(width=data.word(map_+0x40),height=data.word(map_+0x44))
  n.call(0x4cba34,battle,count=20000000)
  record['emptyUpdateCompleted']=True
  print('mode-container',record,flush=True)
 except Exception as e:
  record['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
  print('blocked',record,flush=True)
 records.append(record)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'mode-initialization-vectors.json').write_text(json.dumps(records))
failed=sum('error' in record for record in records)
print('Original empty mode/location exercise:',len(records),'names;',failed,'blocked; no player setup, objectives or match-end claim')
if failed:raise SystemExit(1)
