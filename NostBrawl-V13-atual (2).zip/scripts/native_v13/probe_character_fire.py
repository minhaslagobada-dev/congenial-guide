"""Execute original Skill::tick and Character fire; controlled owner fixture.
Full native Skill::tick for Attack setup without attached spawns.
Controlled character memory; no character CSV/constructor claim and no hooks.
This measures attack scheduling, not projectile damage or complete hero combat.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native import md,read
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
proj=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');proj.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root);w=t.word;p=t.ptr
getters={}
for address in [0x287418,0xc0178,0x2a545c,0x1f1e5c,0x428410,0x4cb730,0x161534,0x2820dc,0x350abc,0x2ea740,0x4f0ed0,0x28f610]:
 page=None
 for ins in md.disasm(read(address,48),address):
  if ins.mnemonic=='adrp' and ins.op_str.startswith('x8, '):page=int(ins.op_str.split('#')[1],0)
  if page is not None and ins.mnemonic=='ldr' and ins.op_str.startswith('w1, [x8, #'):
   offset=int(ins.op_str.split('#')[1].split(']')[0],0)
   index=int.from_bytes(n.uc.mem_read(page+offset,4),'little',signed=True)
   getters[hex(address)]=t.names[index];break
projectile_table=t.alloc(0x40);w(projectile_table+0x28,6)
projectiles={}
for i,row in enumerate(proj.records):
 d=dict(zip(proj.names,row));meta=t.alloc(0x200);p(meta+8,proj.rows[i]);p(meta+0x10,projectile_table);w(meta+0x94,int(d['Speed'] or 0));w(meta+0x98,int(d['Radius'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true'),int(d['ConstantFlyTime']=='true')]))
 projectiles[d['Name']]=meta
manager=t.alloc(0x100);battle=t.alloc(0x400);p(manager+0x50,battle);p(battle,manager);p(battle+0x70,terrain.pointer);w(battle+0x18,100)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
# Only this existing character column is bound for the controlled muzzle fixture.
# This is not initialization or validation of the incomplete character schema.
chars=NativeCsv(n,root/'GameAssets/csv_logic/characters.csv',excluded_rows=('HookDude','ClusterBombDude','Ninja'))
w(0x9aabfc,chars.names.index('TwoWeaponAttackEffectOffset'))
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1
char_rows=set(chars.rows)
def observe(uc,address,size,data):
 if address==0x469228 and uc.reg_read(UC_ARM64_REG_X0) in char_rows:
  assert uc.reg_read(UC_ARM64_REG_X1)==chars.names.index('TwoWeaponAttackEffectOffset'),'Unexpected character column: incomplete schema cannot be assumed'
n.uc.hook_add(UC_HOOK_CODE,observe,begin=0x469228,end=0x469228)
for row in t.records:
 d=dict(zip(t.names,row))
 if d['BehaviorType']!='Attack' or not d['Projectile'] or any(d[k] for k in ['SummonedCharacter','AreaEffectObject','AreaEffectObject2','SpawnedItem']):continue
 manager=t.alloc(0x100);p(manager+0x50,battle);p(battle,manager)
 meta=t.alloc(0x200);p(meta+8,t.find(d['Name']));p(meta+0x68,projectiles[d['Projectile']])
 owner=t.alloc(0x400);charmeta=t.alloc(0x200);p(charmeta+8,chars.rows[0]);p(owner,0x72dc10);p(owner+0x10,charmeta);p(owner+0x18,manager);p(charmeta+0x198,meta)
 w(owner+0x30,3000);w(owner+0x34,4500);w(owner+0x3c,-1);w(owner+0x2fc,-1)
 state=t.alloc(0x30);n.call(0x248d70,state,meta);w(state+0x14,3000);w(state+0xc,max(1,int(d['ActiveTime'] or 0)));w(state+0x18,3500);w(state+0x1c,5000);w(state+0x28,1);n.uc.mem_write(state+0x20,b'\x01\x01')
 skills=t.alloc(8);p(skills,state);p(owner+0x130,skills);w(owner+0x13c,1)
 n.call(0xec2a8,state,owner,50)
 first_interval=n.call(0x14ad30,owner)&0xffffffff
 frames=[];all_shots=[]
 for tick in [100,101,100+max(2,first_interval)]:
  w(battle+0x18,tick)
  interval=n.call(0x14ad30,owner)&0xffffffff;before=get(manager+0xc);last=get(owner+0x7c);counter=get(owner+0xc4)
  n.uc.mem_write(0x201ff000,struct.pack('<3Q',0,1,0))
  n.call(0x1e048c,owner,0,get(owner+0x180),get(owner+0x184),int(d['Damage'] or 0),int(d['Damage'] or 0),projectiles[d['Projectile']],get(owner+0xe0))
  array=int.from_bytes(n.uc.mem_read(manager,8),'little');shots=[]
  for index in range(before,get(manager+0xc)):
   obj=int.from_bytes(n.uc.mem_read(array+index*8,8),'little')
   shots.append(dict(start=[get(obj+0x60),get(obj+0x64)],end=[get(obj+0x68),get(obj+0x6c)],launch=get(obj+0x20),finish=get(obj+0x24),damage=get(obj+0x74),earlyTicks=get(obj+0x10c)))
  frames.append(dict(tick=tick,lastShot=last,interval=interval,beforeCounter=counter,afterCounter=get(owner+0xc4),attackingTicks=get(owner+0x12c),shots=shots))
  all_shots.extend(shots)
 records.append(dict(skill=d['Name'],definition=d,shots=all_shots,frames=frames))
 w(battle+0x18,100)

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'character-fire-vectors.json').write_text(json.dumps(records))
print('Original Skill tick + Character fire:',len(records),'attack definitions;',sum(len(r['shots']) for r in records),'projectiles; controlled muzzle metadata, no gameplay substitutions')
