"""Execute the client's complete map constructor on registered client CSV data."""
class NativeTileMap:
    def __init__(self, data, name, seed=17, mode=0):
        self.data=data
        t=data.csv[19]
        t.ptr(0xab42d0,data.named(27,'Open'))
        native_name=t.alloc(24);t.string(native_name,name)
        rng=t.alloc(16);t.word(rng,seed)
        self.pointer=t.alloc(0x100)
        data.native.call(0xf1f88,self.pointer,rng,0,native_name,mode,count=20000000)

    def describe(self):
        d=self.data;p=self.pointer
        result={name:d.word(p+offset) for name,offset in [('width',0x40),('height',0x44),('logicWidth',0x48),('logicHeight',0x4c),('fineWidth',0x50),('fineHeight',0x54),('tiles',0x58),('respawningTiles',0x60)]}
        cells=d.ptr(d.ptr(p+0x20)+0x10)
        result['grid']=[''.join(chr(d.word(cells+(y*result['width']+x)*4)) for x in range(result['width'])) for y in range(result['height'])]
        return result
