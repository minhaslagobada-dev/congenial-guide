"""Original applyDamage under controlled nonlethal LootBox metadata.
This does not validate hero passives, death effects, rewards or HP asset values.
"""
from emulate_v13 import NativeV13
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt()
def w(a,v):n.uc.mem_write(a,struct.pack('<I',v&0xffffffff))
def p(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
manager=n.alloc(0x100);battle=n.alloc(0x400);p(manager+0x50,battle);w(battle+0x18,100)
meta=n.alloc(0x200);w(meta+0x184,10)
records=[]
for damage in [0,1,300,999]:
 actor=n.alloc(0x400);p(actor,0x72dc10);p(actor+0x10,meta);p(actor+0x18,manager);w(actor+0xb0,1000);w(actor+0xb4,1000);w(actor+0x3c,-1);w(actor+0x338,-1)
 n.uc.mem_write(0x201ff000,struct.pack('<5Q',0,0,0,0,1))
 result=n.call(0x1df258,actor,0,damage,0,0,0,3000,4500)
 records.append(dict(damage=damage,result=result,hp=get(actor+0xb0),lastDamageTick=get(actor+0x2b8)))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'damage-nonlethal-vectors.json').write_text(json.dumps(records))
print('Original applyDamage nonlethal controlled input:',records)
