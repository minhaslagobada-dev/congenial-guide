"""CSV memory adapter for v13's actual table/row/column readers.

This provides asset data, not gameplay callbacks. Native schema initializers,
column lookup, type checks and value readers execute inside the supplied ELF.
"""
from pathlib import Path
import csv, struct

class NativeCsv:
    TYPES = {'string': 0, 'int': 1, 'boolean': 2}
    def __init__(self, native, filename, excluded_rows=(), grouped_rows=False):
        self.native = native
        with Path(filename).open(newline='') as source:
            raw = list(csv.reader(source))
        self.names, self.types = raw[0], raw[1]
        self.records = [row for row in raw[2:] if row[0] not in excluded_rows]
        entry_indices = [i for i,row in enumerate(self.records) if not grouped_rows or row[0]]
        self.rows = []
        self.table = self.alloc(0x40)
        headers = self.alloc(len(self.names) * 24)
        columns = self.alloc(len(self.names) * 8)
        row_array = self.alloc(len(self.records) * 8)
        self.ptr(self.table, headers)
        self.word(self.table + 8, len(self.names))
        self.word(self.table + 12, len(self.names))
        self.ptr(self.table + 16, columns)
        self.ptr(self.table + 32, row_array)
        self.word(self.table + 40, len(entry_indices))
        self.word(self.table + 44, len(entry_indices))
        for i, name in enumerate(self.names):
            self.string(headers + i * 24, name)
            column = self.alloc(0x60)
            self.ptr(columns + i * 8, column)
            kind = self.TYPES[self.types[i].lower()]
            self.word(column, kind)
            self.word(column + 0x10, len(self.records))
            self.word(column + 0x14, len(self.records))
            if kind == 0:
                array = self.alloc(len(self.records) * 24)
                self.ptr(column + 8, array)
            elif kind == 1:
                array = self.alloc(len(self.records) * 4)
                self.ptr(column + 24, array)
                self.word(column + 32, len(self.records))
                self.word(column + 36, len(self.records))
            else:
                array = self.alloc(len(self.records))
                self.ptr(column + 40, array)
                self.word(column + 48, len(self.records))
                self.word(column + 52, len(self.records))
            for j, record in enumerate(self.records):
                value = record[i] if i < len(record) else ''
                if kind == 0: self.string(array + j * 24, value)
                elif kind == 1: self.word(array + j * 4, int(value) if value else 0x7fffffff)
                else: native.uc.mem_write(array + j, bytes([1 if value.lower() == 'true' else 0 if value else 2]))
        for entry_index,i in enumerate(entry_indices):
            row = self.alloc(16)
            self.ptr(row, self.table); self.word(row + 8, i)
            self.ptr(row_array + entry_index * 8, row); self.rows.append(row)
        self.physical_records = self.records
        self.records = [self.physical_records[i] for i in entry_indices]

    def alloc(self, size):
        size = max(1, size)
        address = self.native.alloc(size)
        self.native.uc.mem_write(address, b'\0' * size)
        return address
    def ptr(self, address, value): self.native.uc.mem_write(address, struct.pack('<Q', value))
    def word(self, address, value): self.native.uc.mem_write(address, struct.pack('<I', value & 0xffffffff))
    def string(self, address, value):
        if not value: return
        raw = value.encode() + b'\0'; memory = self.alloc(len(raw))
        self.native.uc.mem_write(memory, raw)
        self.native.call(0x12d868, address, memory)
        self.native.free(memory)
    def initialize_schema(self, function):
        self.native.call(function, self.table, count=3000000)
    def find(self, name):
        index = next(i for i, row in enumerate(self.records) if row[0] == name)
        return self.rows[index]
