"""Run original populated frames until natural completion or an explicit cap.

No score, timer, position, health or end flag is forced. One human is idle;
the remaining players use the original bot AI. This is not a UDP load test.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json,time
n=NativeV13(heap_bytes=0x8000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
location=os.environ.get('V13_LOCATION','Gemgrab1');kind=int(os.environ.get('V13_BATTLE_KIND','1'))
limit=int(os.environ.get('V13_LIFECYCLE_TICKS','6000'));result=dict(location=location,kind=kind,limit=limit,checkpoints=[])
try:
 battle=NativeBattle(data,location,kind=kind);battle.add_player('ShotgunGirl',0);battle.setup()
 result['initial']=battle.describe();started=time.monotonic()
 for index in range(limit):
  vision=battle.frame()
  ended=bool(n.uc.mem_read(battle.pointer+0xa3,1)[0])
  if (index+1)%100==0 or ended:
   frame=battle.describe();frame['vision']=vision;result['checkpoints'].append(frame)
   print('lifecycle',location,'tick',frame['tick'],'score',frame['teamScores'],'countdown',frame['countdown'],'objects',len(frame['objects']),'ended',ended,flush=True)
  if ended:break
 result.update(framesProcessed=index+1,finished=ended,elapsedSeconds=time.monotonic()-started,heapBytes=n.heap-0x10000000)
 print('Original lifecycle result:',result['framesProcessed'],'frames; natural completion',ended,flush=True)
except Exception as e:
 result['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
 print('blocked',result['error'],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/('battle-lifecycle-'+location+'.json')).write_text(json.dumps(result))
if 'error' in result:raise SystemExit(1)
