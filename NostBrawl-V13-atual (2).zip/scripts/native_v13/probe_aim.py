"""Original turning and active-skill selection, with real native skill readers."""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
w=t.word;p=t.ptr
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i])
 for active,executing in [(0,0),(50,0),(0,1),(50,1)]:
  for target in [(3500,5000),(3000,4500),(1000,4500),(5317,8429)]:
   actor=t.alloc(0x400);w(actor+0x30,3000);w(actor+0x34,4500);w(actor+0x48,90);w(actor+0x4c,90)
   skill=t.alloc(0x30);p(skill,meta);w(skill+0xc,active);n.uc.mem_write(skill+0x20,bytes([executing]))
   skills=t.alloc(8);p(skills,skill);p(actor+0x130,skills);w(actor+0x13c,1)
   n.call(0x200010,actor,*target)
   records.append(dict(definition=d,activeMs=active,executing=executing,target=target,attackAngle=get(actor+0x4c),moveAngle=get(actor+0x48)))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'aim-vectors.json').write_text(json.dumps(records))
print('Original aim and active-skill selection:',len(records),'cases; no gameplay hooks')
