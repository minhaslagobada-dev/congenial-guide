"""Run v13 character construction and event reset, not a JS simulation.

Only CSV row access and libc imports are supplied by the harness. Entity
constructors and all server encoding instructions are the original ARM64.
"""
from emulate_v13 import NativeV13
from native import md, read
from unicorn.arm64_const import *
from pathlib import Path
import csv, json, struct, os
n=NativeV13();n.decrypt();rows={};events=[]
def reg(i):return n.uc.reg_read(UC_ARM64_REG_X0+i)
def word(a):return int.from_bytes(n.uc.mem_read(a,4),'little')
def ptr(a):return int.from_bytes(n.uc.mem_read(a,8),'little')
def put(a,v):n.uc.mem_write(a,struct.pack('<I',v&0xffffffff))
def pp(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
def alloc(size):p=n.alloc(size);n.uc.mem_write(p,b'\0'*size);return p
def row_value():
 if reg(1) not in rows[reg(0)]: raise RuntimeError(('Unknown fixture column',reg(0),reg(1)))
 return rows[reg(0)][reg(1)]
n.hooks[0x469228]=row_value
n.hooks[0x24f974]=n.hooks[0x469228]
n.hooks[0x1dca94]=lambda:0 if reg(0) else (_ for _ in ()).throw(RuntimeError('Native assertion'))
for a,col in [(0x82675c,1),(0x8112a4,2),(0xa9d214,3),(0x945404,4),(0xaa77d4,5)]:put(a,col)
root=Path(__file__).resolve().parents[2]
def table(name):
 with (root/'GameAssets/csv_logic'/f'{name}.csv').open() as f:return list(csv.DictReader(f))[1:]
characters=table('characters');skills={s['Name']:s for s in table('skills')}
types={'Hero':0,'Npc_Boss':1,'Minion_FollowOwner':2,'Minion_FindEnemies':3,'Minion_Building':4,'Campaign_DefendTarget':5,'Pvp_Base':6,'Minion_Building_charges_ulti':7,'Minion_Dog':8,'LaserBall':9,'LootBox':10,'Minion_FindEnemies2':11}
records=[]
for idx,data in enumerate(characters):
 if data['Type'] not in types:continue
 meta=alloc(0x200);row=alloc(16);pp(meta+8,row)
 put(meta+0x128,int(data['Speed'] or 0));put(meta+0x184,types[data['Type']])
 rows[row]={4:int(data['Hitpoints'] or 0),5:int(data['AutoAttackDamage'] or 0)}
 for off,key in [(0x198,'WeaponSkill'),(0x1a0,'UltimateSkill')]:
  if not data[key]:continue
  s=skills[data[key]];m=alloc(0x200);r=alloc(16);pp(m+8,r)
  rows[r]={1:int(s['ActiveTime'] or 0),2:int(s['MaxCharge'] or 0),3:int(s['SkillCanChange']=='true')}
  behavior={'Attack':0,'Blink':1,'Charge':2,'Invisibility':3,'TransformMinion':4,'BuffMinion':5,'Rage':6,'Shield':7}
  put(m+0xb8,behavior[s['BehaviorType']]);pp(meta+off,m)
 obj=alloc(0x400)
 n.call(0x14de30,obj,meta)
 assert ptr(obj)==0x72dc10
 assert word(obj+0xb0)==int(data['Hitpoints'] or 0)
 assert word(obj+0xb4)==int(data['Hitpoints'] or 0)
 record={'id':idx,'name':data['Name'],'constructor':{'state':word(obj+0x78),'hp':word(obj+0xb0),'maxHp':word(obj+0xb4),'attackAngle':word(obj+0x4c),'moveAngle':word(obj+0x48),'attackingTicks':struct.unpack('<i',n.uc.mem_read(obj+0x12c,4))[0]},'skillCount':word(obj+0x13c)}
 # Verify genuine resetEventsOnTick with two controlled timer entries.
 for off,values in [(0x270,[70,71]),(0x280,[0,1]),(0x290,[0,3])]:
  a=alloc(8);n.uc.mem_write(a,struct.pack('<ii',*values));pp(obj+off,a);put(obj+off+12,2)
 n.call(0x39c038,obj)
 record['eventTick']={hex(off):{'count':word(obj+off+12),'values':list(struct.unpack('<ii',n.uc.mem_read(ptr(obj+off),8)))} for off in [0x270,0x280,0x290]}
 assert all(record['eventTick'][hex(off)]['count']==1 for off in [0x270,0x280,0x290])
 assert record['eventTick']['0x290']['values'][0]==2
 records.append(record)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'character-constructor.json').write_text(json.dumps(records,indent=2))
print('Native server construction + event reset passed:',len(records),'character definitions; no JS engine invoked')
