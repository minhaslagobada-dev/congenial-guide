# Executes the supplied ARM64 v13 StartLoading decoder, including its actual
# BattlePlayer/LogicLong/String/ByteStream decoders. Only the CSV lookup and
# libc imports are provided by the harness; no packet reads are replaced.
from emulate_v13 import *
from unicorn import UC_HOOK_MEM_READ
import json, os

class NativeWireError(RuntimeError):
 pass

n = NativeV13()
n.decrypt()
state = {}
metadata = {}
def word(address): return struct.unpack('<I', n.uc.mem_read(address, 4))[0]
def pointer(address): return struct.unpack('<Q', n.uc.mem_read(address, 8))[0]
def put(address, value): n.uc.mem_write(address, struct.pack('<I', value))
def pp(address, value): n.uc.mem_write(address, struct.pack('<Q', value))
def bounds(uc, access, address, size, value, data):
 start = state.get('payload', -65536)
 if start <= address < start + 65536 and address + size > start + state['length']:
  raise NativeWireError('Native decoder read beyond the packet')
n.uc.hook_add(UC_HOOK_MEM_READ, bounds)
def lookup():
 gid = n.uc.reg_read(UC_ARM64_REG_W0)
 if gid not in state['references']:
  raise NativeWireError('Unexpected native data reference %d' % gid)
 if gid not in metadata:
  metadata[gid] = n.alloc(0x200)
  n.uc.mem_write(metadata[gid], b'\0' * 0x200)
 return metadata[gid]
n.hooks[0xda924] = lookup
def invalid_string():
 raise NativeWireError('Native string decoder rejected length %d (maximum %d)' % (n.uc.reg_read(UC_ARM64_REG_W1), n.uc.reg_read(UC_ARM64_REG_W2)))
n.hooks[0x25ee8c] = invalid_string

vectors = json.load(open(os.path.join(os.environ['V13_VECTOR_DIR'], 'loading-vectors.json')))
passed = rejected = 0
for vector in vectors:
 state.clear(); metadata.clear(); n.heap = 0x10000000
 obj = n.alloc(0x98); n.uc.mem_write(obj, b'\0' * 0x98)
 n.call(0x18efc4, obj)
 stream = obj + 0x10
 raw = bytes.fromhex(vector['hex']); payload = n.alloc(65536)
 n.uc.mem_write(payload, raw)
 pp(stream + 0x20, payload); put(stream + 0x14, 0); put(stream + 0x18, len(raw)); put(stream + 0x10, len(raw))
 references = {15000000 + vector['mapId']}
 for entry in vector['entries']:
  references.add(16000000 + entry['brawler_id']); references.add(29000000 + entry['skin_id'])
 state.update(payload=payload, length=len(raw), references=references)
 try:
  n.call(0x20fe1c, obj)

  assert word(stream + 0x14) == len(raw), 'Native decoder left trailing bytes'
  assert word(obj + 0x4c) == len(vector['entries'])
  assert word(obj + 0x50) == vector['ownIndex']
  assert word(obj + 0x54) == vector['ownTeam']
  assert word(obj + 0x5c) == vector['loadingType']
  players = pointer(obj + 0x80)
  assert word(players + 0xc) == len(vector['entries'])
  for index, entry in enumerate(vector['entries']):
   player = pointer(pointer(players) + index * 8)
   assert word(player) == entry['high_id'], 'Wrong LogicLong high ID'
   assert word(player + 4) == entry['low_id'], 'Wrong LogicLong low ID'
   name = player + 8; length = word(name + 4)
   text = bytes(n.uc.mem_read(name + 8 if length <= 7 else pointer(name + 8), length)).decode('utf8')
   assert text == entry['name'], 'Name was read at the wrong offset'
   assert word(player + 0x20) == entry['index']
   assert word(player + 0x24) == entry['team']
   assert pointer(player + 0x50) == metadata[16000000 + entry['brawler_id']]
   assert pointer(player + 0x30) == metadata[29000000 + entry['skin_id']]
  assert pointer(obj + 0x78) == metadata[15000000 + vector['mapId']]
  client = n.alloc(0x200); n.uc.mem_write(client, b'\0' * 0x200)
  n.call(0xcf5c4, client, word(obj + 0x5c))
  if word(client + 12) != len(vector['entries']): raise NativeWireError('Loading category allocates the wrong number of native slots')
  if vector.get('invalid'): raise AssertionError('Broken loading packet was accepted')
  passed += 1
 except NativeWireError:
  if not vector.get('invalid'): print('FAILED:', vector['name']); raise
  rejected += 1
print('Native v13 StartLoading decode passed:', passed, 'vectors;', rejected, 'malformed/legacy packets rejected')
