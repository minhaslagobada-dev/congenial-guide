"""Original match destruction with a reclaiming guest heap and shared metadata."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json
n=NativeV13(heap_bytes=0x4000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
def live_bytes():return sum(capacity for _,capacity in n.guest_heap.live.values())
result=dict(baselineBytes=live_bytes(),matches=[])
n.guest_heap.trace_allocations=True
try:
 for index in range(5):
  previous=set(n.guest_heap.live)
  battle=NativeBattle(data,'Gemgrab1',seed=17+index)
  battle.add_player('ShotgunGirl',0,power_level=9,star_card='ShotgunGirl_unique',skin='BanditGirlPrereg')
  battle.setup()
  for tick in range(40):
   if tick in (2,20):
    command=dict(code=100,x=3150,y=6150) if tick==2 else dict(code=0,targetId=1000003,flag=True)
    battle.input_packet(0,battle.encode_input_packet([command],tick+1))
   battle.frame()
  battle.close();battle.close()
  outstanding=[dict(address=hex(address),size=n.guest_heap.live[address][0],capacity=n.guest_heap.live[address][1],origin=[hex(value) for value in n.guest_heap.origins.get(address,())]) for address in n.guest_heap.live.keys()-previous]
  record=dict(index=index,liveBytes=live_bytes(),peakBytes=n.guest_heap.peak,outstanding=outstanding)
  result['matches'].append(record);print('native match destroyed',record,flush=True)
except Exception as e:
 result['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
 print('blocked',result['error'],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'battle-cleanup-vectors.json').write_text(json.dumps(result))
if 'error' in result:raise SystemExit(1)
print('Original match destruction completed:',len(result['matches']),'matches; measured live guest allocations')
