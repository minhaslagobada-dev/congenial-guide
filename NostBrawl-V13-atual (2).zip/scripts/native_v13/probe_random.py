"""Original v13 random integer generator used by projectile spread."""
from emulate_v13 import NativeV13
from pathlib import Path
import os,json,struct
n=NativeV13();state=n.alloc(4);records=[]
def signed(v):return v-0x100000000 if v&0x80000000 else v
for seed in [0,1,-1,17,2147483647,-2147483648,123456789]:
 for bound in [-1,0,1,2,3,7,100,300,2147483647]:
  n.uc.mem_write(state,struct.pack('<i',seed))
  for index in range(64):
   before=int.from_bytes(n.uc.mem_read(state,4),'little',signed=True)
   value=signed(n.call(0x2880b8,state,bound&0xffffffff)&0xffffffff)
   after=int.from_bytes(n.uc.mem_read(state,4),'little',signed=True)
   records.append(dict(state=before,bound=bound,value=value,nextState=after))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'random-vectors.json').write_text(json.dumps(records))
print('Original v13 spread RNG:',len(records),'state transitions')
