from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN
import struct, sys, os, hashlib
f=open(os.environ['LIBG_V13'],'rb')
elf_sha256=hashlib.sha256(f.read()).hexdigest()
KNOWN_LIBRARIES={
 '782ca3ed0a404cb1a28a9b65808c5ef5a40e57d5ada5ead54ae01540bbeb87db':'reference-v13',
 '8d7a7f463f68edb6f4618c706670477ea18730eacfd788ebd17f9734b5f8c578':'supplied-client-apk',
}
if elf_sha256 not in KNOWN_LIBRARIES: raise RuntimeError('Unexpected v13 library: offsets are specific to the supplied reference/client libg.so')
f.seek(0); elf=ELFFile(f)
md=Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
secs=[(s['sh_addr'],s.data()) for s in elf.iter_sections() if s['sh_type']!='SHT_NOBITS' and s['sh_flags']&2]
t=elf.get_section_by_name('.text'); code=t.data(); base=t['sh_addr']
relocs={r['r_offset']:r['r_addend'] for s in elf.iter_sections() if s['sh_type']=='SHT_RELA' for r in s.iter_relocations()}
def read(a,n):
 for st,d in secs:
  if st<=a and a+n<=st+len(d):return d[a-st:a-st+n]
 return b''
def ptr(a):return relocs.get(a,struct.unpack('<Q',read(a,8))[0])
def dump(a,n=256):
 for i in md.disasm(read(a,n),a):print(f'{i.address:#x}: {i.mnemonic:8} {i.op_str}')
def calls(target):
 out=[]
 for offset in range(0,len(code),4):
  word=struct.unpack_from('<I',code,offset)[0]
  if word&0x7c000000==0x14000000:
   imm=word&0x3ffffff; imm=imm-0x4000000 if imm&0x2000000 else imm
   if base+offset+imm*4==target:out.append(base+offset)
 return out
def adrrefs(target):
 page=target&~4095; out=[]
 for off in range(0,len(code)-32,4):
  w=struct.unpack_from('<I',code,off)[0]
  if w&0x9f000000 != 0x90000000:continue
  imm=((w>>29)&3)|(((w>>5)&0x7ffff)<<2)
  if imm&0x100000:imm-=0x200000
  if ((base+off)&~4095)+(imm<<12)!=page:continue
  reg=w&31
  for j in range(4,32,4):
   ins=struct.unpack_from('<I',code,off+j)[0]
   if ins&0xffc00000==0x91000000 and ((ins>>5)&31)==reg and ((ins>>10)&0xfff)==target&4095:
    out.append(base+off);break
 return out
if __name__=='__main__':
 mode=sys.argv[1]; a=int(sys.argv[2],0)
 if mode=='dump':dump(a,int(sys.argv[3],0) if len(sys.argv)>3 else 256)
 elif mode=='calls':print([hex(x) for x in calls(a)])
 elif mode=='refs':print([hex(x) for x in adrrefs(a)]);print('relocs',[(hex(k),hex(v)) for k,v in relocs.items() if v==a])
 elif mode=='ptr':print([hex(ptr(a+i*8)) for i in range(int(sys.argv[3]))])
