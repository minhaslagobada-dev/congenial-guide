from emulate_v13 import *
from unicorn import UC_HOOK_CODE
import json, os
n=NativeV13();rows={}
n.hooks[0x469228]=lambda:rows[n.uc.reg_read(UC_ARM64_REG_X0)].get(n.uc.reg_read(UC_ARM64_REG_W1),0)
n.hooks[0x24f974]=lambda:rows[n.uc.reg_read(UC_ARM64_REG_X0)].get(n.uc.reg_read(UC_ARM64_REG_W1),0)
n.hooks[0x1dca94]=lambda:0 if n.uc.reg_read(UC_ARM64_REG_X0) else (_ for _ in ()).throw(RuntimeError('Native assertion failed'))
for addr,col in [(0x9778d8,1),(0x9a9644,2),(0x91bc30,3),(0x94cbdc,4)]:n.uc.mem_write(addr,struct.pack('<I',col))
def put(a,v):n.uc.mem_write(a,struct.pack('<I',v))
def pp(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
def word(a):return struct.unpack('<I',n.uc.mem_read(a,4))[0]
state={}
def bounds(uc,a,size,d):
 p=uc.reg_read(UC_ARM64_REG_X0);bits=uc.reg_read(UC_ARM64_REG_W1);pos=word(p+8)*8+word(p+16)
 if pos+bits>state['bits']:raise RuntimeError(f'Native overread {pos}+{bits}>{state["bits"]}, lr={uc.reg_read(UC_ARM64_REG_LR):#x}')
n.uc.hook_add(UC_HOOK_CODE,bounds,begin=0x4f4518,end=0x4f4518)
vectors=json.load(open(os.path.join(os.environ['V13_VECTOR_DIR'], 'object-vectors.json')))
for v in vectors:
 n.heap=0x10000000
 obj=n.alloc(0x200);meta=n.alloc(0x200);row=n.alloc(16);stream=n.alloc(0x30);payload=n.alloc(512)
 for a,size in [(obj,0x200),(meta,0x200),(stream,0x30)]:n.uc.mem_write(a,b'\0'*size)
 d=v['data'];rows[row]={1:int(d.get('IsBouncing')=='true'),2:int(d.get('TriggerWithDelayMs') or 0),3:int(d.get('PreExplosionTimeMs') or 0),4:int(d.get('SyncAnimWithServer')=='true')}
 pp(meta+8,row);pp(obj+0x10,meta)
 if v['cls']==6:
  pp(obj,0x746260);put(meta+0x9c,{'Use360Frames':1,'UseZFrames':2,'DoNotRotateClip':3}.get(d.get('Rendering'),0));fn=0x387814
 elif v['cls']==17:pp(obj,0x750f78);put(meta+0x80,8 if d['Type']=='DelayedDamage' else 0);fn=0x469f7c
 else:pp(obj,0x737da8);put(meta+0x64,d['id']);fn=0x41c734
 data=bytes.fromhex(v['hex']);n.uc.mem_write(payload,data);pp(stream+24,payload);put(stream+12,len(data));state['bits']=v['bits']
 try:
  n.call(fn,obj,stream,v['mode'],int(v['large']))
  consumed=word(stream+8)*8+word(stream+16)
  assert consumed==v['bits'],(consumed,v['bits'])
  assert word(obj+0x30)==v['object']['x']
  assert word(obj+0x34)==v['object']['y']
  if v['cls']==6:
   source=v['object']
   assert word(obj+0x48)==source['state']
   assert word(obj+0x64)==625
   if d.get('TriggerWithDelayMs') or d.get('PreExplosionTimeMs'):assert word(obj+0x60)==411
   if int(d.get('PreExplosionTimeMs') or 0):assert (word(obj+0x58),word(obj+0x5c))==(3500,5700)
   if source['indirect']:
    assert n.uc.mem_read(obj+0x69,1)==b'\1'
    assert (word(obj+0x74),word(obj+0x78))==(3500,5700)
   if d.get('IsBouncing')=='true' and source['bounceTileIndex'] is not None:assert word(obj+0x6c)==718
 except Exception as e:print(v['table'],d['Name'],v['mode'],v['large'],'FAIL',e);raise
print('Native v13 projectile/area/item decode passed:',len(vectors),'vectors')
