"""Fail if a documented routine starts inside another native function."""
from native import elf
from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
manifest=json.loads((root/'Native/V13/manifest.json').read_text())
ranges={e.header.initial_location:e.header.initial_location+e.header.address_range for e in elf.get_dwarf_info().EH_CFI_entries() if hasattr(e,'header') and 'initial_location' in e.header}
for f in manifest['functions']:
 start=int(f['start'],16);end=int(f['end'],16)
 assert ranges.get(start)==end,(f['name'],hex(start),hex(ranges.get(start,0)),hex(end))
 assert end-start==f['size'],f['name']
print('Native function boundaries verified against ELF unwind metadata:',len(manifest['functions']))
