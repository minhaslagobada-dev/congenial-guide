"""Construct actual metadata from client CSVs, not numeric metadata fixtures."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
records=[]
for name,meta in data.entries[16].items():
 obj=n.alloc(0x400);n.call(0x14de30,obj,meta)
 records.append(dict(name=name,dataId=data.word(meta+0x20),hp=data.word(obj+0xb0),maxHp=data.word(obj+0xb4),state=data.word(obj+0x78),
  radius=n.call(0x3305dc,obj),projectileStartZ=data.word(meta+0x118),speed=data.word(meta+0x128),type=data.word(meta+0x184),skills=data.word(obj+0x13c)))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'data-registry-vectors.json').write_text(json.dumps(records))
print('Original data tables + gameplay references + character constructors:',len(records),'client characters;',len(data.tables),'tables; no gameplay substitutions or character CSV hooks')
