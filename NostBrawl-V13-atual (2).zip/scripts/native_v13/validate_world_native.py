# The complete native world reader plus actual entity/skill bit readers run.
# Client CSV metadata/readers are original; entity allocation and graphical
# callbacks remain controlled inputs because Android rendering is not running.
from emulate_v13 import *
from native_data import NativeDataRegistry
from pathlib import Path
from unicorn import UC_HOOK_CODE
import json, os
n=NativeV13();n.decrypt();state={};definitions={}
registry=NativeDataRegistry(n,Path(__file__).resolve().parents[2]/'GameAssets')
vector_heap=n.heap
def w(a):return int.from_bytes(n.uc.mem_read(a,4),'little')
def p(a):return int.from_bytes(n.uc.mem_read(a,8),'little')
def put(a,v):n.uc.mem_write(a,struct.pack('<I',v&0xffffffff))
def pp(a,v):n.uc.mem_write(a,struct.pack('<Q',v))
def alloc(size):a=n.alloc(size);n.uc.mem_write(a,b'\0'*size);return a
def reg(i):return n.uc.reg_read(UC_ARM64_REG_X0+i)
n.uc.mem_map(0x40001000,4096);n.hooks[0x40001000]=lambda:0
n.hooks[0x2966c8]=lambda:state['tileMap']
n.hooks[0x3226e8]=lambda:state['v']['ownIndex']
n.hooks[0x11997c]=lambda:int(state['tile']['IsDestructible']=='true')
n.hooks[0x53de84]=lambda:int(state['tile']['IsDestructibleNormalWeapon']=='true' and (state['tile']['BlocksMovement']=='true' or state['tile']['BlocksProjectiles']=='true'))
def tile():
 x,y=reg(1),reg(2);state['tile']=state['tileDefs'].get(state['v']['grid'][y][x],state['tileDefs']['.']);return state['tilePtr']
n.hooks[0x14c61c]=tile
n.hooks[0x433050]=lambda:0

types={'Hero':0,'Npc_Boss':1,'Minion_FollowOwner':2,'Minion_FindEnemies':3,'Minion_Building':4,'Campaign_DefendTarget':5,'Pvp_Base':6,'Minion_Building_charges_ulti':7,'Minion_Dog':8,'LaserBall':9,'LootBox':10,'Minion_FindEnemies2':11}
classes={16:('characters',0x75e938),6:('projectiles',0x746260),17:('area_effects',0x750f78),18:('items',0x737da8)}
for cls in classes:
 table=registry.csv[cls]
 for row in table.records:
  definitions[registry.named(cls,row[0])]=(cls,dict(zip(table.names,row)))

def initObject(obj,meta):
 cls,d=definitions[meta];vt=alloc(0x60);base=classes[cls][1]
 for offset in range(0,0x60,8):pp(vt+offset,p(base+offset))
 pp(vt+0x10,0x40001000);pp(obj,vt);pp(obj+0x10,meta)
 if cls==16:
  skills=[p(meta+off) for off in [0x198,0x1a0] if p(meta+off)]
  array=alloc(16);pp(obj+0x68,array);put(obj+0x74,len(skills))
  for i,definition in enumerate(skills):skill=alloc(0x30);pp(skill,definition);pp(array+i*8,skill)
 return obj
n.hooks[0x2dd210]=lambda:initObject(alloc(0x200),reg(0))
n.hooks[0x380970]=lambda:initObject(reg(0),reg(1))

def stop(uc,a,size,data):uc.emu_stop()
n.uc.hook_add(UC_HOOK_CODE,stop,begin=0x139db8,end=0x139db8)
def bounds(uc,a,size,data):
 stream=reg(0);bits=reg(1);position=w(stream+8)*8+w(stream+16)
 if position+bits>state['maxBits']:raise RuntimeError('Native world bit overread')
n.uc.hook_add(UC_HOOK_CODE,bounds,begin=0x4f4518,end=0x4f4518)
n.prepare_hooks()
fixture=json.load(open(os.path.join(os.environ['V13_VECTOR_DIR'],'world-vectors.json')))
for v in fixture['vectors']:
 state.clear();n.heap=vector_heap
 manager=alloc(0x100);battle=alloc(0x200);mapMeta=alloc(0x100);tiles=alloc(0x80);tilePtr=alloc(0x80);stream=alloc(0x30);players=alloc(16);parray=alloc(v['capacity']*8);extra=alloc(16);root=alloc(0x100);rootvt=alloc(0x100)
 pp(root,rootvt);pp(rootvt+0x18,0x40001000);pp(manager+0x10,root)
 pp(battle+0xc8,mapMeta);put(battle+0xfc,v['mode']);put(mapMeta+0x40,len(v['grid'][0]));pp(tilePtr+8,mapMeta)
 pp(players,parray);put(players+12,v['capacity'])
 for i in range(v['capacity']):player=alloc(0x100);put(player+0x20,i);pp(parray+i*8,player)
 raw=bytes.fromhex(v['hex']);payload=alloc(len(raw));n.uc.mem_write(payload,raw);pp(stream+24,payload);put(stream+12,len(raw))
 state.update(v=v,tables=fixture['tables'],names={key:{d['Name']:d for d in table} for key,table in fixture['tables'].items()},tileMap=tiles,tilePtr=tilePtr,tileDefs={d['TileCode']:d for d in fixture['tables']['tiles']},maxBits=len(raw)*8)
 n.uc.reg_write(UC_ARM64_REG_SP,0x201ff000);n.uc.reg_write(UC_ARM64_REG_LR,0x40000000)
 for i,arg in enumerate([manager,stream,players,0,battle,extra]):n.uc.reg_write(UC_ARM64_REG_X0+i,arg)
 try:
  n.uc.emu_start(0x139398,0x40000000,count=3000000)
  assert n.uc.reg_read(UC_ARM64_REG_PC)==0x139db8
  consumed=w(stream+8)*8+w(stream+16)
  assert 0<=len(raw)*8-consumed<=7,('Trailing bits',consumed,len(raw)*8)
  if v.get('nativeSnapshot'):
   # Original vision may omit objects outside this player's visibility.
   expected_by_id={o['nativeId']:o for o in v['objects']}
   assert 0<w(manager+12)<=len(expected_by_id)
   pairs=[]
   for i in range(w(manager+12)):
    obj=p(p(manager)+i*8);gid=w(obj+8)
    assert gid in expected_by_id,('Unknown original object',gid)
    expected=expected_by_id[gid];assert w(p(obj+0x10)+0x20)==expected['fullDataId']
    pairs.append((obj,expected))
  else:
   assert w(manager+12)==len(v['objects'])
   pairs=[(p(p(manager)+i*8),expected) for i,expected in enumerate(v['objects'])]
  for obj,expected in pairs:
   if not v.get('nativeSnapshot'):assert w(obj+8)=={16:1,6:2,17:3,18:4}[expected['dataClass']]*1000000+expected['id']
   assert w(obj+0x30)==expected['x'] and w(obj+0x34)==expected['y'], (expected, w(obj+0x30), w(obj+0x34))
 except Exception as error:print('FULL WORLD FAILED:',v['name'],error);raise
print('Native complete-world decode passed:',len(fixture['vectors']),'initial/combat map views')
