"""Persistent original ARM64 battle engine; JSON-lines IPC, never gameplay JS.

Native failures terminate the worker: resuming a half-executed C++ call could
corrupt every match sharing its allocator. The parent must abort those sessions.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from native_battle_results import NativePlacements
from pathlib import Path
import json,sys,re

MAX_LINE=131072
def send(value):
    print(json.dumps(value,separators=(',',':')),flush=True)
def integer(value,low,high):
    if type(value) is not int or not low<=value<=high:raise ValueError('Integer outside allowed range')
    return value
def identity(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',value):raise ValueError('Invalid match ID')
    return value

n=NativeV13(heap_bytes=0x8000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000)
n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets');matches={};placements={}
send(dict(event='ready',engine='original-v13-arm64'))
for raw in sys.stdin.buffer:
    request_id=None
    try:
        if len(raw)>MAX_LINE:raise ValueError('IPC request too large')
        request=json.loads(raw);request_id=integer(request['requestId'],1,2147483647)
        command=request['command']
        if command=='shutdown':
            for observer in placements.values():observer.close()
            for battle in matches.values():battle.close()
            send(dict(requestId=request_id,result=True));break
        match_id=identity(request['matchId'])
        if command=='create':
            if match_id in matches:raise ValueError('Duplicate match ID')
            location=request['location'];players=request['players'];seed=integer(request['seed'],0,2147483647)
            if location not in data.entries[15]:raise ValueError('Unknown native location')
            table=data.csv[15];row=table.records[list(data.entries[15]).index(location)]
            definition=dict(zip(table.names,row));mode=definition['GameMode']
            if definition['Disabled']=='true' or (not definition['AllowedMaps'] and mode!='Tutorial'):raise ValueError('Disabled native location')
            kind={'BattleRoyale':0,'BattleRoyaleTeam':6,'Survival':3,'Raid':7,'Tutorial':5}.get(mode,1)
            capacity=1 if kind==5 else 10 if kind in (0,6) else 3 if kind in (3,7) else 6
            if not isinstance(players,list) or not 1<=len(players)<=capacity:raise ValueError('Invalid human roster')
            teams=[1] if kind==5 else [1]*10 if kind==0 else [2]*5 if kind==6 else [3] if kind in (3,7) else [5,1] if mode=='BossFight' else [3,3]
            occupied=[0]*len(teams)
            # Validate all external values before invoking constructors.
            for player in players:
                if player['hero'] not in data.entries[16]:raise ValueError('Unknown native hero')
                team=integer(player['team'],0,len(teams)-1);occupied[team]+=1
                if occupied[team]>teams[team]:raise ValueError('Native team capacity exceeded')
                integer(player['accountId'],1,2147483647)
                integer(player.get('powerLevel',1),1,9)
                if not isinstance(player['name'],str) or not 1<=len(player['name'].encode())<=128:raise ValueError('Invalid player name')
                for key,type_id,target_column in [('skin',29,'Character'),('starCard',23,'Target')]:
                    name=player.get(key)
                    if name:
                        if name not in data.entries[type_id]:raise ValueError('Unknown '+key)
                        source=data.csv[type_id];values=dict(zip(source.names,source.records[list(data.entries[type_id]).index(name)]))
                        if values[target_column]!=player['hero'] or (key=='starCard' and values['MetaType']!='4'):raise ValueError('Invalid hero '+key)
            # The original Solo filler assigns each appended bot its roster
            # index as team ID. Human Solo teams must use the same canonical
            # IDs, including private rooms whose original seats have gaps.
            if kind==0:players=[dict(player,team=index) for index,player in enumerate(players)]
            battle=NativeBattle(data,location,kind=kind,seed=seed)
            # Native functions own registered objects; destruction releases them.
            try:
                for player in players:
                    battle.add_player(player['hero'],player['team'],name=player['name'],account_id=player['accountId'],power_level=player.get('powerLevel',1),star_card=player.get('starCard'),skin=player.get('skin'))
                battle.setup();matches[match_id]=battle
                if mode in ('BattleRoyale','BattleRoyaleTeam'):placements[match_id]=NativePlacements(battle)
                result=dict(kind=kind,state=battle.describe())
            except Exception:
                battle.close();raise
        else:
            if match_id not in matches:raise ValueError('Unknown native match')
            battle=matches[match_id]
            if command=='frame':
                snapshots=battle.frame();state=battle.describe()
                if match_id in placements:
                    observer=placements[match_id];observer.observe(state)
                    for player in state['players']:player['rank']=observer.ranks.get(player['index'])
                result=dict(state=state,vision=snapshots)
            elif command=='input':
                index=integer(request['playerIndex'],0,len(battle.describe()['players'])-1)
                value=request['hex']
                if not isinstance(value,str) or not 0<len(value)<=16384 or len(value)%2 or not re.fullmatch('[0-9a-fA-F]+',value):raise ValueError('Invalid input bytes')
                battle.input_packet(index,bytes.fromhex(value));result=True
            elif command=='destroy':
                if match_id in placements:placements.pop(match_id).close()
                battle.close();del matches[match_id];result=True
            else:raise ValueError('Unknown native command')
        send(dict(requestId=request_id,result=result))
    except (ValueError,KeyError,TypeError) as error:
        send(dict(requestId=request_id,error=str(error)))
    except Exception as error:
        send(dict(requestId=request_id,error=str(error),fatal=True));sys.exit(1)
