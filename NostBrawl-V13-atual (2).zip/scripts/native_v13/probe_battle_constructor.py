"""Original battle/container constructor; not full match initialization."""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/globals.csv')
def word(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
def pointer(a):return int.from_bytes(n.uc.mem_read(a,8),'little')
records=[]
for kind in range(12):
 battle=t.alloc(0x400);n.call(0x4328f8,battle,kind,count=3000000)
 manager=pointer(battle);terrain=pointer(battle+0x70)
 n.call(0x201398,manager,battle)
 players=word(battle+0x84)
 record=dict(kind=kind,storedKind=word(battle+0xa4),playerSlots=players,expectedSlots=n.call(0xda014,kind),tick=word(battle+0x18),managerObjects=word(manager+0xc),managerFlags=list(n.uc.mem_read(manager+0x60,5)),managerBattleMatches=pointer(manager+0x50)==battle,emptyPlayerSlots=all(pointer(pointer(battle+0x78)+i*8)==0 for i in range(players)),mapPointerPresent=terrain!=0)
 assert record['storedKind']==kind and record['playerSlots']==record['expectedSlots']
 assert record['managerBattleMatches'] and record['emptyPlayerSlots'] and record['mapPointerPresent']
 records.append(record)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'battle-constructor-vectors.json').write_text(json.dumps(records))
print('Original battle/container constructors:',len(records),'kind inputs; player slots, manager flags/binding and map container; no players/maps/modes initialized')
