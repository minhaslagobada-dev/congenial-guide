"""Original v13 ProjectileServer::getPosAtTick, including original math.
No gameplay function or CSV access is replaced. Input actor fields are fixtures.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import json,os,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
def w(a,v):t.word(a,v)
def p(a,v):t.ptr(a,v)
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
records=[]
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i])
 n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true'),int(d['ConstantFlyTime']=='true')]))
 w(meta+0x94,int(d['Speed'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 for start,end,duration in [([3000,4500],[3500,5000],20),([5200,8000],[1200,1200],20),([3500,5000],[3000,4500],20),
  ([3101,5157],[5317,8429],7),([5317,8429],[3101,5157],37),([3001,4503],[3001,4503],20),([2,2],[6298,9898],37)]:
  for z in [0,350]:
   obj=t.alloc(0x120);n.call(0x4d30d0,obj,meta)
   w(obj+0x20,100);w(obj+0x24,100+duration);w(obj+0x60,start[0]);w(obj+0x64,start[1]);w(obj+0x68,end[0]);w(obj+0x6c,end[1]);w(obj+0x70,z)
   point=t.alloc(8)
   for tick in [99,100,101,100+duration//4,100+duration//2,100+duration-1,100+duration,101+duration]:
    height=n.call(0x350c04,obj,tick,point)
    assert 0<=height<=3000
    records.append({'name':d['Name'],'data':{'gravity':int(d['Gravity'] or 0),'constantFlyTime':d['ConstantFlyTime']=='true','speed':int(d['Speed'] or 0),'bounce':int(d['BouncePercent'] or 0)},
      'input':{'start':start,'end':end,'z':z,'launch':100,'finish':100+duration,'tick':tick},'output':{'x':get(point),'y':get(point+4),'z':height}})
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-position-vectors.json').write_text(json.dumps(records))
# The decrypted original table is part of LogicMath, not generated with host sqrt.
table=[int.from_bytes(n.uc.mem_read(0x95b110+i*4,4),'little',signed=True) for i in range(256)]
(out/'math-tables.json').write_text(json.dumps({'sqrt':table}))
values=[-1,-2147483648,0,1,2,255,256,257,1023,1024,4095,4096,16383,16384,65535,65536,262143,262144,1048575,1048576,4194303,4194304,16777215,16777216,67108863,67108864,268435455,268435456,1073741823,1073741824,2147483646,2147483647]
seed=17
for _ in range(500):
 seed=(seed*1664525+1013904223)&0xffffffff;values.append(seed&0x7fffffff)
results=[]
for value in values:
 actual=n.call(0x28fc2c,value&0xffffffff)
 actual=actual&0xffffffff;actual=actual-0x100000000 if actual&0x80000000 else actual
 results.append({'input':value,'output':actual})
(out/'sqrt-vectors.json').write_text(json.dumps(results))
print('Original v13 projectile position oracle:',len(records),'cases;',len(t.records),'definitions; full bounce/height branches')
