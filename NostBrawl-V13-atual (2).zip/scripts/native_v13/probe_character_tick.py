"""Original full character tick with real client metadata.
Battle/player memory is controlled input, not a complete battle-mode runtime.
No character CSV reader or gameplay routine is replaced.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
terrain=NativeOpenMap(n,root);t=terrain.csv;w=t.word;p=t.ptr;records=[]
for row in data.csv[16].records:
 d=dict(zip(data.csv[16].names,row))
 if d['Type']!='Hero' or d['Disabled']=='true' or d['LockedForChronos']=='true':continue
 manager=t.alloc(0x100);battle=t.alloc(0x400);p(manager+0x50,battle);p(battle,manager);p(battle+0x70,terrain.pointer)
 players=t.alloc(6*8);p(battle+0x78,players)
 for i in range(6):p(players+i*8,t.alloc(0x200))
 obj=t.alloc(0x400);n.call(0x14de30,obj,data.named(16,d['Name']));w(obj+0x3c,0);w(obj+0x40,0);n.call(0x253b18,manager,obj);n.call(0x465f38,obj,3000,4500,0)
 for tick in range(150,155):
  w(battle+0x18,tick)
  try:n.call(0x18ff68,obj,count=3000000)
  except Exception as e:raise RuntimeError((d['Name'],tick,str(e))) from e
  records.append(dict(name=d['Name'],tick=tick,hp=data.word(obj+0xb0),state=data.word(obj+0x78),x=data.word(obj+0x30),y=data.word(obj+0x34),attackingTicks=data.word(obj+0x12c)))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'character-tick-vectors.json').write_text(json.dumps(records))
print('Original full character idle tick:',len(records),'frames;',len({r['name'] for r in records}),'real client heroes; controlled battle/player structures')
