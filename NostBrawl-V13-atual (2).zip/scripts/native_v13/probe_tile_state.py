"""Original tile constructor, destruction and isolated respawn update.
The update caller's eligibility filter is separately identified, not invented.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/tiles.csv');t.initialize_schema(0x4478e4)
w=t.word;p=t.ptr
meta_by_name={}
for i,row in enumerate(t.records):
 meta=t.alloc(0x100);p(meta+8,t.rows[i]);meta_by_name[row[0]]=meta
p(0xab42d0,meta_by_name['Open'])
manager=t.alloc(0x80);array=t.alloc(8);p(manager,array)
actor=t.alloc(0x400);p(actor,0x72dc10);p(array,actor)
pathx=t.alloc(4);pathy=t.alloc(4);p(actor+0x90,pathx);p(actor+0xa0,pathy)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
def state(obj):
 data=int.from_bytes(n.uc.mem_read(obj,8),'little')
 return dict(data=next(k for k,v in meta_by_name.items() if v==data),timer=get(obj+0x20),seconds=struct.unpack('<f',n.uc.mem_read(obj+0x24,4))[0],
  movementMask=int.from_bytes(n.uc.mem_read(obj+0x10,8),'little'),projectileMask=int.from_bytes(n.uc.mem_read(obj+0x18,8),'little'))
for row in t.records:
 d=dict(zip(t.names,row));name=d['Name']
 for timer in [-1,0,1,2,700]:
  for scenario in ['none','near','far','dead','flag148far','flag149far','pathNear','pathFar','at300','at301','diagonal300','diagonal301','projectileNear']:
   obj=t.alloc(0x40);n.call(0x39f9bc,obj,meta_by_name[name],10,15)
   constructed=state(obj)
   n.call(0x39a128,obj);destroyed=state(obj)
   w(obj+0x20,timer)
   w(manager+0xc,0 if scenario=='none' else 1)
   p(actor,0x74e558 if scenario=='projectileNear' else 0x72dc10)
   w(actor+0xb0,0 if scenario=='dead' else 100)
   w(actor+0x30,3150 if scenario in ['near','dead'] else 5000);w(actor+0x34,4650 if scenario in ['near','dead'] else 8000)
   if scenario in ['at300','at301','diagonal300','diagonal301','projectileNear']:
    dx,dy={'at300':(300,0),'at301':(301,0),'diagonal300':(180,240),'diagonal301':(180,241),'projectileNear':(0,0)}[scenario]
    w(actor+0x30,3150+dx);w(actor+0x34,4650+dy)
   n.uc.mem_write(actor+0x148,bytes([int(scenario=='flag148far'),int(scenario=='flag149far')]))
   w(actor+0x9c,int(scenario in ['pathNear','pathFar']))
   w(pathx,3150 if scenario=='pathNear' else 5000);w(pathy,4650 if scenario=='pathNear' else 8000)
   n.call(0x12fa44,obj,manager)
   records.append(dict(name=name,definition=d,timer=timer,scenario=scenario,constructed=constructed,destroyed=destroyed,after=state(obj),actors=[] if scenario=='none' else [dict(type=1 if scenario=='projectileNear' else 0,hp=get(actor+0xb0),x=get(actor+0x30),y=get(actor+0x34),byte148=scenario=='flag148far',byte149=scenario=='flag149far',path=[get(pathx),get(pathy)] if scenario in ['pathNear','pathFar'] else None)]))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'tile-state-vectors.json').write_text(json.dumps(records))
print('Original tile state:',len(records),'constructor/destruction/isolated respawn cases')
