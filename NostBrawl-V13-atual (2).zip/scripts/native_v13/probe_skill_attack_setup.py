"""Execute full native Skill::tick for Attack setup without attached spawns.
Controlled character memory; no character CSV/constructor claim and no hooks.
This measures attack scheduling, not projectile damage or complete hero combat.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native import md,read
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
proj=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');proj.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root);w=t.word;p=t.ptr
getters={}
for address in [0x287418,0xc0178,0x2a545c,0x1f1e5c,0x428410,0x4cb730,0x161534,0x2820dc,0x350abc,0x2ea740,0x4f0ed0,0x28f610]:
 page=None
 for ins in md.disasm(read(address,48),address):
  if ins.mnemonic=='adrp' and ins.op_str.startswith('x8, '):page=int(ins.op_str.split('#')[1],0)
  if page is not None and ins.mnemonic=='ldr' and ins.op_str.startswith('w1, [x8, #'):
   offset=int(ins.op_str.split('#')[1].split(']')[0],0)
   index=int.from_bytes(n.uc.mem_read(page+offset,4),'little',signed=True)
   getters[hex(address)]=t.names[index];break
projectiles={}
for i,row in enumerate(proj.records):
 d=dict(zip(proj.names,row));meta=t.alloc(0x200);p(meta+8,proj.rows[i]);w(meta+0x94,int(d['Speed'] or 0));w(meta+0x98,int(d['Radius'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true'),int(d['ConstantFlyTime']=='true')]))
 projectiles[d['Name']]=meta
manager=t.alloc(0x100);battle=t.alloc(0x400);p(manager+0x50,battle);p(battle,manager);p(battle+0x70,terrain.pointer);w(battle+0x18,100)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row))
 if d['BehaviorType']!='Attack' or any(d[k] for k in ['SummonedCharacter','AreaEffectObject','AreaEffectObject2','SpawnedItem']):continue
 meta=t.alloc(0x200);p(meta+8,t.rows[i]);p(meta+0x68,projectiles[d['Projectile']] if d['Projectile'] else 0);w(meta+0xb8,0)
 for role in ['main','super']:
  for casting in [0,50]:
   for level in [0,9]:
    for consumed in [1,2]:
     for ammo in [1000,3000]:
      for aim_ticks in ([-1,0,20,40,80] if d['Name']=='Bow' else [-1]):
       for has_player in [False,True]:
        owner=t.alloc(0x400);charmeta=t.alloc(0x200);p(owner,0x72dc10);p(owner+0x10,charmeta);p(owner+0x18,manager)
        other_meta=t.alloc(0x200);p(other_meta+8,t.find('ShotgunGirlWeapon'))
        p(charmeta+0x198,meta if role=='main' else other_meta);p(charmeta+0x1a0,meta if role=='super' else other_meta)
        w(owner+0x30,3000);w(owner+0x34,4500);w(owner+0x3c,0 if has_player else -1);w(owner+0x2fc,-1 if aim_ticks<0 else 100-aim_ticks)
        player=t.alloc(0x100);players=t.alloc(8);p(players,player);p(battle+0x78,players);w(player+0x60,1000);n.uc.mem_write(owner+0x2f9,b'\x01')
        state=t.alloc(0x30);n.call(0x248d70,state,meta);w(state+0x14,ammo);w(state+0xc,max(1,int(d['ActiveTime'] or 0)));w(state+0x18,3500);w(state+0x1c,5000);w(state+0x28,consumed);w(state+0x24,level)
        other=t.alloc(0x30);n.call(0x248d70,other,other_meta)
        n.uc.mem_write(state+0x20,b'\x01\x01');w(owner+0x198,casting)
        skills=t.alloc(16);p(skills,state if role=='main' else other);p(skills+8,state if role=='super' else other);p(owner+0x130,skills);w(owner+0x13c,2)
        try:n.call(0xec2a8,state,owner,50,count=3000000)
        except Exception as e:raise RuntimeError((d['Name'],role,casting,level,consumed,ammo,str(e))) from e
        records.append(dict(name=d['Name'],definition=d,otherDefinition=dict(zip(t.names,t.records[next(j for j,row in enumerate(t.records) if row[0]=='ShotgunGirlWeapon')])),projectile=dict(zip(proj.names,proj.records[next(j for j,row in enumerate(proj.records) if row[0]==d['Projectile'])])) if d['Projectile'] else None,role=role,hasPlayer=has_player,playerCharge=get(player+0x60),aimTicks=aim_ticks,casting=casting,level=level,consumed=consumed,ammo=ammo,skill=dict(activeMs=get(state+0xc),cooldownMs=get(state+0x10),ammo=get(state+0x14),executing=n.uc.mem_read(state+0x20,1)[0],pending=n.uc.mem_read(state+0x21,1)[0]),otherCooldownMs=get(other+0x10),
         attack=dict(target=[get(owner+0x180),get(owner+0x184)],delta=[get(owner+0xf0),get(owner+0xf4)],active=n.uc.mem_read(owner+0x188,1)[0],damage=get(owner+0xcc),spread=get(owner+0xe0),pattern=get(owner+0xd0),bullets=get(owner+0xd4),attackIntervalMs=get(owner+0xe4),range=get(owner+0xe8),i32={hex(off):get(owner+off) for off in [0xbc,0xc0,0xc4,0xc8,0xcc,0xd0,0xd4,0xe0,0xe4,0xe8,0xf0,0xf4,0xf8,0x180,0x184,0x1dc,0x2fc]},u8={hex(off):n.uc.mem_read(owner+off,1)[0] for off in [0x140,0x188,0x1d5,0x206,0x2f9,0x2fb]},attackAngle=get(owner+0x4c),moveAngle=get(owner+0x48))))

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'skill-getters.json').write_text(json.dumps(getters,indent=2))
(out/'skill-attack-setup-vectors.json').write_text(json.dumps(records))
print('Original active skill attack setup:',len(records),'cases; controlled owner; full native Skill::tick; no gameplay hooks')
