"""Original v13 angle lookup, with original decrypted arctangent table."""
from emulate_v13 import NativeV13
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();records=[]
table=[int.from_bytes(n.uc.mem_read(0x9aadfc+4*i,4),'little',signed=True) for i in range(129)]
def run(x,y):records.append(dict(x=x,y=y,angle=n.call(0x1cd630,x&0xffffffff,y&0xffffffff)))
for x in [-65535,-10000,-300,-1,0,1,300,10000,65535]:
 for y in [-65535,-10000,-300,-1,0,1,300,10000,65535]:run(x,y)
seed=17
for _ in range(6000):
 seed=(seed*1664525+1013904223)&0xffffffff;x=seed%131071-65535
 seed=(seed*1664525+1013904223)&0xffffffff;y=seed%131071-65535
 run(x,y)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'angle-table.json').write_text(json.dumps(table))
(out/'angle-vectors.json').write_text(json.dumps(records))
print('Original v13 integer angle:',len(records),'cases; original 129-entry table')
