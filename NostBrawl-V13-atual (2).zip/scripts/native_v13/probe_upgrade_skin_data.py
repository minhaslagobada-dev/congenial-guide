"""Original card/skin metadata reference initialization from client assets."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True),extra_references=(23,29))
records={str(kind):[dict(name=name,id=data.word(pointer+0x20)) for name,pointer in data.entries[kind].items()] for kind in [23,29]}
for record in records['29']:
 pointer=data.named(29,record['name'])
 for key,offset in [('mainProjectile',0xd8),('superProjectile',0xe0)]:
  projectile=data.ptr(pointer+offset);record[key]=data.word(projectile+0x20) if projectile else None
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'upgrade-skin-data-vectors.json').write_text(json.dumps(records))
print('Original card and skin references:',len(records['23']),'cards;',len(records['29']),'skins; rendering and upgraded combat excluded')
