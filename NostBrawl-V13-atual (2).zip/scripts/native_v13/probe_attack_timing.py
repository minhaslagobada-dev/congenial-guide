"""Original attack interval function, native skill readers, controlled cache."""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
w=t.word;p=t.ptr;records=[]
behaviors={'Attack':0,'Blink':1,'Charge':2,'Invisibility':3,'TransformMinion':4,'BuffMinion':5,'Rage':6,'Shield':7}
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i]);w(meta+0xb8,behaviors[d['BehaviorType']])
 for active in [0,150]:
  for executing in [0,1]:
   for casting in [0,50]:
    for character_type in [0,1]:
     for cached in [0,3,40]:
      actor=t.alloc(0x400);data=t.alloc(0x200);p(actor+0x10,data);w(data+0x184,character_type);w(data+0x130,cached);p(data+0x198,meta)
      w(actor+0x198,casting);w(actor+0xe4,int(d['MsBetweenAttacks'] or 0))
      skill=t.alloc(0x30);p(skill,meta);w(skill+0xc,active);n.uc.mem_write(skill+0x20,bytes([executing]))
      skills=t.alloc(8);p(skills,skill);p(actor+0x130,skills);w(actor+0x13c,1)
      result=n.call(0x14ad30,actor)&0xffffffff;result=result-0x100000000 if result&0x80000000 else result
      records.append(dict(definition=d,activeMs=active,executing=executing,castingMs=casting,characterType=character_type,cachedInterval=cached,result=result))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'attack-timing-vectors.json').write_text(json.dumps(records))
print('Original attack timing:',len(records),'cases; no gameplay hooks')
