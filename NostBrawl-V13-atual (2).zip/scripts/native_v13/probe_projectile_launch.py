"""Execute original launch initializer, with a non-character origin fixture.
No gameplay hooks. This isolates timing from hero CSV data and spread RNG.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json,struct
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root)
w=t.word;p=t.ptr
battle=t.alloc(0x100);p(battle+0x70,terrain.pointer)
manager=t.alloc(0x80);p(manager+0x50,battle)
origin=t.alloc(0x400)
# Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
p(origin,0x74e558);w(origin+0x30,3000);w(origin+0x34,4500)
w(origin+0x3c,1);w(origin+0x40,2)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for i,row in enumerate(t.records):
 d=dict(zip(t.names,row));meta=t.alloc(0x200);p(meta+8,t.rows[i])
 n.uc.mem_write(meta+0x90,bytes([int(d['Indirect']=='true'),int(d['ConstantFlyTime']=='true')]))
 w(meta+0x94,int(d['Speed'] or 0));w(meta+0xa0,int(d['Gravity'] or 0))
 for start in [(3000,4500),(0,12000)]:
  for end in [(3500,5000),(3000,4500),(5317,8429)]:
   for reduction in [0,100,int(d['Speed'] or 0),int(d['Speed'] or 0)+100]:
    obj=t.alloc(0x120);n.call(0x4d30d0,obj,meta);p(obj+0x18,manager)
    # Arguments beyond x7 occupy the original caller's stack.
    stack=0x201ff000
    n.uc.mem_write(stack,struct.pack('<7Q',0,100,123,456,reduction,0,0))
    n.call(0x20308c,obj,start[0],start[1],0,origin,end[0],end[1],0)
    records.append({'name':d['Name'],'speed':int(d['Speed'] or 0),'constantFlyTime':d['ConstantFlyTime']=='true',
     'start':start,'target':end,'speedReduction':reduction,'launch':get(obj+0x20),'finish':get(obj+0x24),
     'progressStep':get(obj+0xcc),'actualStart':[get(obj+0x60),get(obj+0x64)],'initialZ':get(obj+0x70)})
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-launch-vectors.json').write_text(json.dumps(records))
print('Original projectile launch initializer:',len(records),'cases; controlled non-character origin, no gameplay hooks')
