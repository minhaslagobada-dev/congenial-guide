"""Original full map construction and movement-grid setup from client CSVs."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from pathlib import Path
import os,json
from unicorn.arm64_const import UC_ARM64_REG_PC, UC_ARM64_REG_LR
# This sweep retains all allocations; free() is a no-op in the harness.
n=NativeV13(heap_bytes=0x4000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
t=data.csv[19];w=t.word;p=t.ptr
# Global Open tile lookup is initialized by the client's data-table registry.
p(0xab42d0,data.named(27,'Open'))
records=[]
names=[]
for row in t.physical_records:
 if row[1] and row[1]!='end' and row[1] not in names:names.append(row[1])
for name in names:
 if os.environ.get('V13_MAP') and name!=os.environ['V13_MAP']:continue
 map_name=t.alloc(24);t.string(map_name,name)
 rng=t.alloc(16);w(rng,17)
 map_=t.alloc(0x100)
 try:n.call(0xf1f88,map_,rng,0,map_name,0,count=20000000)
 except Exception as e:raise RuntimeError((name,str(e),hex(n.uc.reg_read(UC_ARM64_REG_PC)),hex(n.uc.reg_read(UC_ARM64_REG_LR)))) from e
 record=dict(name=name,width=data.word(map_+0x40),height=data.word(map_+0x44),logicWidth=data.word(map_+0x48),logicHeight=data.word(map_+0x4c),fineWidth=data.word(map_+0x50),fineHeight=data.word(map_+0x54),tiles=data.word(map_+0x58),respawningTiles=data.word(map_+0x60))
 assert record['width']>0 and record['height']>0
 source=data.ptr(map_+0x20);cells=data.ptr(source+0x10)
 record['grid']=[''.join(chr(data.word(cells+(y*record['width']+x)*4)) for x in range(record['width'])) for y in range(record['height'])]
 records.append(record)
 print('map',name,record['width'],record['height'],'heap',n.heap-0x10000000,flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'tile-map-vectors.json').write_text(json.dumps(records))
print('Original full tile maps:',len(records),'groups; native layout and movement-grid setup')
