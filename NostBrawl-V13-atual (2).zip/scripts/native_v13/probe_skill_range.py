"""Original charged-aim casting range bonus, actual native skill CSV."""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from pathlib import Path
import os,json
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/skills.csv');t.initialize_schema(0x13da8c)
assert int.from_bytes(n.uc.mem_read(0x82bc7c,4),'little',signed=True)==40
records=[]
for i,row in enumerate(t.records):
 meta=t.alloc(0x200);t.ptr(meta+8,t.rows[i])
 for elapsed in [-1,0,1,19,20,39,40,80]:
  value=n.call(0x378534,meta,elapsed&0xffffffff)&0xffffffff
  records.append(dict(definition=dict(zip(t.names,row)),elapsed=elapsed,bonus=value-0x100000000 if value&0x80000000 else value))
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'skill-range-vectors.json').write_text(json.dumps(records))
print('Original skill casting range bonus:',len(records),'cases')
