"""Execute original projectile collision and damage, controlled LootBox target.
No gameplay hooks. One controlled non-hero target is registered using the original manager.
Native terrain destruction executes; fine movement-grid rebuilding is outside this fixture.
"""
from emulate_v13 import NativeV13
from native_csv import NativeCsv
from native_open_map import NativeOpenMap
from pathlib import Path
import os,json,struct
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2]
t=NativeCsv(n,root/'GameAssets/csv_logic/projectiles.csv');t.initialize_schema(0x449b0c)
terrain=NativeOpenMap(n,root)
# Native global is looked up by the literal Open at 0x45ac54..0x45ac84.
terrain.csv.ptr(0xab42d0,terrain.metadata['Open'])
w=t.word;p=t.ptr
battle=t.alloc(0x400);p(battle+0x70,terrain.pointer);w(battle+0x18,100);w(battle+0x20,17)
manager=t.alloc(0x80);p(manager+0x50,battle);p(battle,manager)
player=t.alloc(0x100);players=t.alloc(8);p(players,player);p(battle+0x78,players)
table=t.alloc(0x40);w(table+0x28,6)
origin=t.alloc(0x400)
# Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
p(origin,0x74e558);w(origin+0x30,3000);w(origin+0x34,4500)
w(origin+0x3c,1);w(origin+0x40,2)
records=[]
def get(a):return int.from_bytes(n.uc.mem_read(a,4),'little',signed=True)
for name in ['ShotgunGirlProjectile','ShotgunGirlUltiProjectile','SniperProjectile','CrowProjectile','UndertakerUltiProjectile','DeadMariachiUltiProjectile']:
 d=dict(zip(t.names,next(row for row in t.records if row[0]==name)))
 meta=t.alloc(0x200);p(meta+8,t.find(d['Name']));p(meta+0x10,table);w(meta+0x94,int(d['Speed'] or 0));w(meta+0x98,int(d['Radius'] or 0))
 for progress in [0,500,1000]:
  for team in [0,1]:
   for alive in [False,True]:
    for target_y in [4650,4900]:
     manager=t.alloc(0x100);p(manager+0x50,battle);p(battle,manager)
     target=t.alloc(0x400);target_meta=t.alloc(0x200);p(target,0x72dc10);p(target+0x10,target_meta);w(target_meta+0x184,10);w(target_meta+0x14c,150)
     w(target+0xb0,10000 if alive else 0);w(target+0xb4,10000);w(target+0x3c,-1);w(target+0x40,team);w(target+0x30,3150);w(target+0x34,target_y);w(target+0x338,-1)
     n.call(0x253b18,manager,target)
     obj=t.alloc(0x120);n.call(0x4d30d0,obj,meta);p(obj+0x18,manager)
     w(obj+0x90,2500);w(obj+0x94,4650);w(obj+0x30,3500);w(obj+0x34,4650);w(obj+0x3c,0);w(obj+0x40,0);w(obj+0x74,300);w(obj+0x78,300);w(obj+0xc8,progress)
     try:result=n.call(0x373994,obj)
     except Exception as e:raise RuntimeError((name,progress,team,alive,target_y,hex(n.uc.reg_read(UC_ARM64_REG_PC)),hex(n.uc.reg_read(UC_ARM64_REG_LR)),str(e))) from e
     records.append(dict(name=name,definition=d,progress=progress,team=team,alive=alive,targetY=target_y,result=result,hp=get(target+0xb0),projectilePosition=[get(obj+0x30),get(obj+0x34)],lastDamageTick=get(target+0x2b8)))

out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'projectile-hit-vectors.json').write_text(json.dumps(records))
print('Original projectile collision + applyDamage:',len(records),'cases; controlled non-hero target, no gameplay substitutions')
