from native import elf, relocs, read
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE, UC_HOOK_MEM_INVALID
from unicorn.arm64_const import *
import struct

class NativeV13:
 def __init__(self,heap_bytes=0x1000000,reclaim_memory=False,instruction_counting=True,timeout_us=0):
  self.instruction_counting=instruction_counting;self.call_timeout_us=timeout_us
  self.uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
  self.uc.mem_map(0,0xc00000)
  for seg in elf.iter_segments():
   if seg['p_type']=='PT_LOAD':self.uc.mem_write(seg['p_vaddr'],seg.data())
  for address,value in relocs.items():self.uc.mem_write(address,struct.pack('<Q',value))
  if heap_bytes<0x1000000 or heap_bytes%4096 or heap_bytes>0x10000000:raise ValueError('Invalid research heap size')
  self.heap_limit=0x10000000+heap_bytes
  self.uc.mem_map(0x10000000,heap_bytes);self.heap=0x10000000
  self.guest_heap=None
  if reclaim_memory:
   from native_memory import GuestHeap
   self.guest_heap=GuestHeap(self)
  self.uc.mem_map(0x20000000,0x200000);self.uc.mem_map(0x30000000,0x1000);self.uc.mem_map(0x40000000,0x1000)
  self.uc.reg_write(UC_ARM64_REG_TPIDR_EL0,0x30000000)
  self.hooks={};self.calls=[];self.trace=[]
  sym=elf.get_section_by_name('.dynsym');plt=elf.get_section_by_name('.plt')
  for i,r in enumerate(elf.get_section_by_name('.rela.plt').iter_relocations()):
   name=sym.get_symbol(r['r_info_sym']).name
   address=plt['sh_addr']+32+i*16
   self.hooks[address]=lambda name=name:self.external(name)
  # Trap only registered external/fixture addresses. A global instruction
  # callback needlessly returns to Python for every original ARM64 instruction.
  self._hooked_addresses=set()
  self.uc.hook_add(UC_HOOK_CODE,self.on_code,begin=0x40000000,end=0x40000000)
  self.uc.hook_add(UC_HOOK_MEM_INVALID,self.invalid)
 def alloc(self,n):
  if self.guest_heap is not None:return self.guest_heap.allocate(n)
  n=max(16,int(n));out=self.heap;self.heap+=(n+15)&~15
  if self.heap>self.heap_limit:raise RuntimeError('Emulation heap exhausted')
  return out
 def free(self,pointer):
  if self.guest_heap is not None:self.guest_heap.release(pointer)
 def string(self,a):
  out=b''
  while True:
   b=bytes(self.uc.mem_read(a,256));i=b.find(b'\0')
   if i>=0:return out+b[:i]
   out+=b;a+=256
   if len(out)>1000000:raise RuntimeError('Invalid native string')
 def external(self,name):
  a,b,c=[self.uc.reg_read(x) for x in (UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2)]
  if name=='realloc' and self.guest_heap is not None:return self.guest_heap.resize(a,b)
  if name in ('malloc','calloc','_Znwm','_Znam','realloc'):
   length=a*b if name=='calloc' else b if name=='realloc' else a
   pointer=self.alloc(length)
   if name=='calloc':self.uc.mem_write(pointer,b'\0'*length)
   return pointer
  if name in ('free','_ZdlPv','_ZdaPv'):
   self.free(a)
   return 0
  if name in ('__cxa_atexit','__cxa_finalize','pthread_mutex_lock','pthread_mutex_unlock','__android_log_print'):return 0
  if name=='__cxa_guard_acquire':return int(self.uc.mem_read(a,1)[0]==0)
  if name=='__cxa_guard_release':self.uc.mem_write(a,b'\x01');return 0
  if name=='__cxa_guard_abort':self.uc.mem_write(a,b'\x00');return 0
  if name=='strlen':return len(self.string(a))
  if name=='strnlen':
   data=bytes(self.uc.mem_read(a,b));end=data.find(b'\0');return len(data) if end<0 else end
  if name in ('strcpy','__strcpy_chk'):
   self.uc.mem_write(a,self.string(b)+b'\0');return a
  if name in ('strncpy','__strncpy_chk'):
   data=bytes(self.uc.mem_read(b,c));end=data.find(b'\0')
   if end>=0:data=data[:end]+b'\0'*(c-end)
   self.uc.mem_write(a,data);return a
  if name in ('memcpy','memmove','__memcpy_chk','__memmove_chk'):self.uc.mem_write(a,bytes(self.uc.mem_read(b,c)));return a
  if name in ('memset','__memset_chk'):self.uc.mem_write(a,bytes([b&255])*c);return a
  if name=='memcmp':return (bytes(self.uc.mem_read(a,c))>bytes(self.uc.mem_read(b,c)))-(bytes(self.uc.mem_read(a,c))<bytes(self.uc.mem_read(b,c)))
  if name=='strcmp':return (self.string(a)>self.string(b))-(self.string(a)<self.string(b))
  if name in ('strcasecmp','strncasecmp'):
   left=self.string(a).lower();right=self.string(b).lower()
   if name=='strncasecmp':left=left[:c];right=right[:c]
   return (left>right)-(left<right)
  if name=='vsnprintf':
   from native_libc import vsnprintf
   return vsnprintf(self,a,b,c)
  raise RuntimeError('Unimplemented native import '+name)
 def ret(self,value):
  if value is not None:self.uc.reg_write(UC_ARM64_REG_X0,value&0xffffffffffffffff)
  self.uc.reg_write(UC_ARM64_REG_PC,self.uc.reg_read(UC_ARM64_REG_LR))
 def on_code(self,uc,address,size,data):
  if address==0x40000000:uc.emu_stop();return
  if address in self.hooks:self.ret(self.hooks[address]())
 def invalid(self,uc,access,address,size,value,data):
  raise RuntimeError(f'Unmapped memory {address:#x} pc={uc.reg_read(UC_ARM64_REG_PC):#x} lr={uc.reg_read(UC_ARM64_REG_LR):#x}')
 def prepare_hooks(self):
  for address in self.hooks.keys()-self._hooked_addresses:
   self.uc.hook_add(UC_HOOK_CODE,self.on_code,begin=address,end=address)
   self._hooked_addresses.add(address)
 def call(self,addr,*args,count=1000000):
  self.prepare_hooks()
  self.uc.reg_write(UC_ARM64_REG_SP,0x201ff000);self.uc.reg_write(UC_ARM64_REG_LR,0x40000000)
  for i,v in enumerate(args):self.uc.reg_write(UC_ARM64_REG_X0+i,v)
  self.uc.emu_start(addr,0x40000000,count=count if self.instruction_counting else 0,timeout=self.call_timeout_us)
  if self.uc.reg_read(UC_ARM64_REG_PC)!=0x40000000:raise RuntimeError(f'Native execution stopped before return at {self.uc.reg_read(UC_ARM64_REG_PC):#x}')
  return self.uc.reg_read(UC_ARM64_REG_X0)
 def decrypt(self):self.call(0x104518,count=30000000)

if __name__=='__main__':
 n=NativeV13();n.decrypt()
 print('column',n.string(0x97478b))
