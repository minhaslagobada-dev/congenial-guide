"""Original player registration, bot fill, map setup and populated updates.

This does not transmit UDP, initialize a renderer or invoke a match-end callback.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json
n=NativeV13(heap_bytes=0x4000000,reclaim_memory=os.environ.get('V13_RECLAIM_MEMORY')=='1');n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
result={}
full_frame=os.environ.get('V13_NATIVE_FRAME')=='1'
schedule=json.loads(Path(os.environ['V13_INPUT_SCHEDULE']).read_text()) if os.environ.get('V13_INPUT_SCHEDULE') else []
try:
 battle=NativeBattle(data,'Gemgrab1')
 battle.add_player('ShotgunGirl',0)
 result['beforeSetup']=battle.describe();print('human registered',result['beforeSetup'],flush=True)
 battle.setup();result['afterSetup']=battle.describe();print('populated',len(result['afterSetup']['players']),'players',len(result['afterSetup']['objects']),'objects',flush=True)
 result['frames']=[]
 for tick in range(int(os.environ.get('V13_BATTLE_TICKS','40'))):
  for entry in schedule:
   if entry['step']==tick:battle.input_packet(entry.get('player',0),bytes.fromhex(entry['packet']))
  if full_frame:
   vision=battle.frame();record=battle.describe();record['vision']=vision
  else:
   battle.step(150+tick);record=battle.describe()
  result['frames'].append(record)
  if (tick+1)%100==0:print('native frame',record['tick'],'objects',len(record['objects']),'ended',record['ended'],flush=True)
 print('Original populated battle updates:',len(result['frames']),'frames; original players, bot fill, map setup and object/mode updates',flush=True)
except Exception as e:
 result['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
 print('blocked',result['error'],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/('battle-input-frame-vectors.json' if schedule else 'battle-frame-vectors.json' if full_frame else 'battle-setup-vectors.json')).write_text(json.dumps(result))
if 'error' in result:raise SystemExit(1)
