"""Check guest allocator/libc lifetime semantics without running game logic."""
from emulate_v13 import NativeV13
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2
n=NativeV13(reclaim_memory=True);heap=n.guest_heap
a=n.alloc(32);b=n.alloc(48);n.uc.mem_write(b,b'B'*48)
heap.release(a);small=n.alloc(16);assert small==a
n.uc.mem_write(small,b'A'*16);assert bytes(n.uc.mem_read(b,48))==b'B'*48
heap.release(small);heap.release(b);merged=n.alloc(80);assert merged==a
n.uc.mem_write(merged,bytes(range(80)));grown=heap.resize(merged,160)
assert bytes(n.uc.mem_read(grown,80))==bytes(range(80))
try:heap.release(merged)
except RuntimeError:pass
else:raise AssertionError('Repeated free was not rejected')
heap.release(grown)
def external(name,*args):
 for register,value in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2],args):n.uc.reg_write(register,value)
 return n.external(name)
dirty=n.alloc(64);n.uc.mem_write(dirty,b'\xff'*64);heap.release(dirty)
zeroed=external('calloc',4,16);assert bytes(n.uc.mem_read(zeroed,64))==b'\0'*64
replacement=external('realloc',zeroed,128);assert bytes(n.uc.mem_read(replacement,64))==b'\0'*64
assert external('realloc',replacement,0)==0
guard=n.alloc(8);n.uc.mem_write(guard,b'\0'*8)
assert external('__cxa_guard_acquire',guard)==1
external('__cxa_guard_release',guard)
assert external('__cxa_guard_acquire',guard)==0
external('__cxa_guard_abort',guard)
assert external('__cxa_guard_acquire',guard)==1
assert heap.peak<1024
print('Guest heap: reuse/coalescing, realloc preservation, calloc zeroing, repeated-free rejection and single-thread C++ guards passed')
