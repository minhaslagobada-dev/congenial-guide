"""Original battle constructor, location/map selection and player registration.

These are research bindings to original functions, not a complete online server.
No character, player or mode structure is synthesized in this binding.
"""
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X22

class NativeBattle:
    def __init__(self,data,location,kind=1,seed=17):
        self.data=data;self.native=data.native;self.csv=data.csv[15]
        self.pointer=self.csv.alloc(0x400)
        self.native.call(0x4328f8,self.pointer,kind)
        self.manager=data.ptr(self.pointer)
        self.native.call(0x201398,self.manager,self.pointer)
        self.native.call(0x425ef8,self.pointer,data.named(15,location))
        self.native.call(0x13a028,self.pointer,seed)
        self.csv.ptr(0xab42d0,data.named(27,'Open'))
        self.native.call(0x1e7b14,self.pointer,0,1,0,count=20000000)

    def add_player(self,hero,team,name='Native player',account_id=1,bot=False,power_level=None,star_card=None,skin=None):
        identity=self.csv.alloc(8);self.csv.word(identity,0);self.csv.word(identity+4,account_id)
        display=self.csv.alloc(24);self.csv.string(display,name)
        upgrades=0;star=0;skin_pointer=0
        if star_card:
            table=self.data.csv[23];definition=dict(zip(table.names,table.records[next(i for i,row in enumerate(table.records) if row[0]==star_card)]))
            if definition['Target']!=hero or definition['MetaType']!='4':raise ValueError('Star card does not belong to this hero')
            star=self.data.named(23,star_card)
        if power_level is not None or star:
            if not isinstance(power_level,int) or not 1<=power_level<=9:raise ValueError('Native upgrade level must be 1..9')
            upgrades=self.csv.alloc(16);self.native.call(0x4c1b14,upgrades,power_level,star)
        if skin:
            table=self.data.csv[29];definition=dict(zip(table.names,table.records[next(i for i,row in enumerate(table.records) if row[0]==skin)]))
            if definition['Character']!=hero:raise ValueError('Skin does not belong to this hero')
            skin_pointer=self.data.named(29,skin)
        player=self.native.call(0x2021bc,self.pointer,identity,self.data.named(16,hero),upgrades,team,display,int(bot),skin_pointer,count=3000000)
        self.native.call(0x467ef4,display);self.native.free(display);self.native.free(identity)
        return player

    def setup(self,fill_bots=True):
        self.native.call(0x3e0cfc,self.pointer,0,int(fill_bots),count=20000000)

    def input_packet(self,player_index,payload):
        """Decode and dispatch an original v13 ClientInputMessage payload."""
        if not 0<=player_index<self.data.word(self.pointer+0x68):raise ValueError('Unknown native player index')
        if not payload or len(payload)>8192:raise ValueError('Invalid native input packet length')
        player=self.data.ptr(self.data.ptr(self.pointer+0x78)+player_index*8)
        if self.native.uc.mem_read(player+0x59,1)[0]:raise ValueError('External input cannot control a native bot')
        message=self.csv.alloc(0x60);self.native.call(0x3a50ac,message)
        stream=message+0x10
        # The native constructor owns an initial (possibly zero-length) array.
        # Release it before installing the network payload's owned buffer.
        previous=self.data.ptr(stream+0x20)
        if previous:self.native.free(previous)
        buffer=self.csv.alloc(len(payload));self.native.uc.mem_write(buffer,payload)
        self.csv.ptr(stream+0x20,buffer);self.csv.word(stream+0x10,len(payload));self.csv.word(stream+0x14,0);self.csv.word(stream+0x18,len(payload))
        self._decode_input_message(message)
        if self.data.word(stream+0x14)!=len(payload):
            self._destroy_input_message(message)
            raise ValueError('Native input decoder left trailing bytes')
        self.native.call(0x118500,self.pointer,message,self.data.word(player+0x28),count=3000000)
        self._destroy_input_message(message)

    def _destroy_input_message(self,message):
        # As with other Piranha messages, the last virtual method performs
        # explicit content destruction; the deleting destructor frees self.
        self.native.call(0x3c414c,message)
        self.native.call(0x540200,message)

    def _decode_input_message(self,message):
        n=self.native
        if not hasattr(n,'_input_scratch_capture'):
            n._input_scratch_capture=None
            def observe(uc,address,size,unused):
                if n._input_scratch_capture is not None:n._input_scratch_capture.append(uc.reg_read(UC_ARM64_REG_X22))
            n._input_scratch_hook=n.uc.hook_add(UC_HOOK_CODE,observe,begin=0x31831c,end=0x31831c)
        scratch=[];n._input_scratch_capture=scratch
        try:n.call(0x31828c,message,count=3000000)
        finally:
            n._input_scratch_capture=None
            # The original decoder allocates a temporary entry, then addInput
            # copies it (0x14e040). Reclaim only those observed temporaries;
            # message destruction separately owns the retained copies.
            for entry in scratch:n.free(entry)

    def encode_input_packet(self,commands,counter=1):
        """Use the original client-message writer for automated client tests."""
        message=self.csv.alloc(0x60);self.native.call(0x3a50ac,message)
        self.csv.word(message+0x4c,self.data.word(self.pointer+0x18))
        self.csv.word(message+0x50,0);self.csv.word(message+0x54,counter)
        for index,command in enumerate(commands):
            entry=self.csv.alloc(0x1c);self.native.call(0x1d2a68,entry)
            for offset,value in enumerate([counter+index,1,command['code'],command.get('x',0),command.get('y',0),command.get('targetId',0)]):self.csv.word(entry+offset*4,value)
            self.native.uc.mem_write(entry+24,bytes([int(bool(command.get('flag',False)))]))
            self.native.call(0x14e040,message,entry)
            self.native.free(entry)
        self.native.call(0x287328,message,count=3000000)
        stream=message+0x10;length=self.data.word(stream+0x14)
        if not 0<length<=8192:raise RuntimeError('Invalid original encoded input length')
        payload=bytes(self.native.uc.mem_read(self.data.ptr(stream+0x20),length))
        self._destroy_input_message(message)
        return payload

    def step(self,tick):
        # Time is an explicit oracle input; all gameplay/object updates stay native.
        self.csv.word(self.pointer+0x18,tick)
        self.native.call(0x4cba34,self.pointer,count=20000000)

    def frame(self):
        """Original game-over check, update, vision encoding and tick increment."""
        if not hasattr(self,'streams'):
            count=self.data.word(self.pointer+0x6c)
            self.streams=[];array=self.csv.alloc(max(8,count*8));self.stream_array=array;self.stream_list=self.csv.alloc(16)
            self.csv.ptr(self.stream_list,array);self.csv.word(self.stream_list+8,count);self.csv.word(self.stream_list+12,count)
            for i in range(count):
                stream=self.csv.alloc(0x28);self.native.call(0x23aec8,stream,10)
                self.csv.ptr(array+i*8,stream);self.streams.append(stream)
        frame_tick=self.data.word(self.pointer+0x18)
        self.native.call(0x42f218,self.pointer,self.stream_list,0,count=20000000)
        snapshots=[]
        for stream in self.streams:
            bits=self.data.word(stream+8)*8+self.data.word(stream+0x10)
            if bits<0 or bits>1000000:raise RuntimeError('Invalid native snapshot bit cursor')
            snapshots.append(dict(tick=frame_tick,bits=bits,hex=bytes(self.native.uc.mem_read(self.data.ptr(stream+0x18),(bits+7)//8)).hex()))
        return snapshots

    def close(self):
        if getattr(self,'closed',False):return
        self.native.call(0x110958,self.pointer,count=20000000)
        self.native.call(0x56671c,self.pointer,count=20000000)
        self.native.free(self.pointer)
        if hasattr(self,'streams'):
            for stream in self.streams:
                # BitStream owns its buffer through explicit destruct(), not its
                # virtual deleting destructor. Follow the native caller order.
                self.native.call(0x16806c,stream)
                self.native.call(0x54193c,stream)
            self.native.free(self.stream_array);self.native.free(self.stream_list)
        self.closed=True

    def describe(self):
        d=self.data;p=self.pointer
        objects=[]
        for i in range(d.word(self.manager+0xc)):
            obj=d.ptr(d.ptr(self.manager)+i*8);meta=d.ptr(obj+0x10)
            data_id=d.word(meta+0x20)
            record=dict(id=d.word(obj+8),dataId=data_id,team=d.word(obj+0x40),x=d.word(obj+0x30),y=d.word(obj+0x34))
            if 16000000<=data_id<17000000:record.update(hp=d.word(obj+0xb0),state=d.word(obj+0x78))
            objects.append(record)
        players=[]
        for i in range(d.word(p+0x68)):
            player=d.ptr(d.ptr(p+0x78)+i*8)
            skin=d.ptr(player+0x30);upgrades=d.ptr(player+0xc0)
            players.append(dict(index=d.word(player+0x20),team=d.word(player+0x24),characterId=d.word(player+0x28),bot=bool(self.native.uc.mem_read(player+0x59,1)[0]),alive=bool(self.native.uc.mem_read(player+0x58,1)[0]),lastKillerIndex=d.word(player+0xd8),score=d.word(player+0x40),superCharge=d.word(player+0x60),name=d.string(player+8),skinDataId=d.word(skin+0x20) if skin else None,powerLevel=d.word(upgrades) if upgrades else None))
        mode=d.word(p+0xe8)
        ended=bool(self.native.uc.mem_read(p+0xa3,1)[0]);mvp=-1
        if ended and mode in (0,2,3,5):
            mvp=self.native.call(0x2250bc,p)&0xffffffff
            if mvp>=0x80000000:mvp-=0x100000000
        scores=[self.native.call(0x395ae0,p,team)&0xffffffff for team in range(2)] if mode in [0,2,3,5] else None
        return dict(tick=d.word(p+0x18),headerSlots=d.word(p+0x84),mvpIndex=mvp,nativeMode=mode,ended=bool(self.native.uc.mem_read(p+0xa3,1)[0]),forcedWinner=d.word(p+0x10c),countdown=d.word(p+0xd8),teamScores=scores,players=players,objects=objects)
