"""Natural Solo/Duo placement observations; original offline rank readers."""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from native_battle_results import NativePlacements
from pathlib import Path
import json,os
n=NativeV13(heap_bytes=0x8000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000)
n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
results=[]
for mode,kind in [('BattleRoyale',0),('BattleRoyaleTeam',6)]:
    location=next(row[0] for row in data.csv[15].records if dict(zip(data.csv[15].names,row))['GameMode']==mode)
    battle=NativeBattle(data,location,kind=kind);battle.add_player('ShotgunGirl',0);battle.setup();placements=NativePlacements(battle)
    events=[];previous={}
    for _ in range(6500):
        battle.frame();state=battle.describe();placements.observe(state)
        if placements.ranks!=previous:
            events.append(dict(tick=state['tick'],ranks=dict(placements.ranks)));previous=dict(placements.ranks)
        if state['ended']:break
    record=dict(mode=mode,finished=state['ended'],ticks=state['tick'],ranks=placements.ranks,players=state['players'],events=events)
    print('Original placements',record,flush=True);results.append(record)
    placements.close();battle.close()
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'native-placements.json').write_text(json.dumps(results))
assert all(record['finished'] and len(record['ranks'])==10 for record in results)
