"""Automated human input only; all movement/damage/charge/Super rules are native.

The test client chooses a nearby enemy, moves into range, and presses attack or
Super through original client encoding and server decoding. HP/charge/positions
are never assigned by the driver. This policy is not a runtime bot replacement.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
from unicorn.arm64_const import UC_ARM64_REG_PC,UC_ARM64_REG_LR
import os,json,math
n=NativeV13(heap_bytes=0x8000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000);n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
result=dict(checkpoints=[],inputPackets=0,superObserved=False,superInputs=[])
try:
 battle=NativeBattle(data,'Gemgrab1');battle.add_player('ShotgunGirl',0);battle.setup();counter=1
 for index in range(int(os.environ.get('V13_EARNED_SUPER_TICKS','1800'))):
  state=battle.describe();human=state['players'][0];own=next((o for o in state['objects'] if o['id']==human['characterId']),None)
  if index%10==2 and own and own.get('hp',0)>0:
   enemies=[o for o in state['objects'] if any(p['characterId']==o['id'] and p['team']!=human['team'] for p in state['players']) and o.get('hp',0)>0]
   if enemies:
    target=min(enemies,key=lambda o:(o['x']-own['x'])**2+(o['y']-own['y'])**2)
    dx=own['x']-target['x'];dy=own['y']-target['y'];distance=max(1,math.hypot(dx,dy));commands=[]
    if distance>1400:
     commands.append(dict(code=100,x=int(target['x']+dx*1200/distance),y=int(target['y']+dy*1200/distance)))
    if distance<=2200:
     if human['superCharge']==4000:
      commands.extend([dict(code=107),dict(code=1,targetId=target['id'],flag=True)])
      result['superInputs'].append(dict(tick=state['tick'],charge=human['superCharge'],characterId=own['id'],targetId=target['id']))
     else:commands.extend([dict(code=108),dict(code=0,targetId=target['id'],flag=True)])
    if commands:
     packet=battle.encode_input_packet(commands,counter);counter+=len(commands);battle.input_packet(0,packet);result['inputPackets']+=1
  vision=battle.frame();state=battle.describe()
  if any(o['dataId']==6000001 for o in state['objects']):
   assert result['superInputs'], 'Super projectile appeared before a charged human command'
   assert state['players'][0]['superCharge']<4000, 'Super command did not consume charge'
   assert all(o['dataId']!=16000000 for o in state['objects'] if any(p['bot'] and p['characterId']==o['id'] for p in state['players'])), 'Another Shelly could produce this projectile'
   result['superObserved']=True;state['vision']=vision;result['checkpoints'].append(state);break
  if (index+1)%100==0:
   state['vision']=vision;result['checkpoints'].append(state)
   print('earned-super tick',state['tick'],'charge',state['players'][0]['superCharge'],'packets',result['inputPackets'],flush=True)
 result['framesProcessed']=index+1
 print('Original earned Super observed:',result['superObserved'],'after',result['framesProcessed'],'frames',flush=True)
except Exception as e:
 result['error']=dict(message=str(e),pc=hex(n.uc.reg_read(UC_ARM64_REG_PC)),lr=hex(n.uc.reg_read(UC_ARM64_REG_LR)))
 print('blocked',result['error'],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'battle-earned-super-vectors.json').write_text(json.dumps(result))
if 'error' in result:raise SystemExit(1)
