"""Recover CSV column requirements from the v13 initializers themselves."""
from native import md,read
from emulate_v13 import NativeV13
from pathlib import Path
import csv,json,os
SCHEMAS={'characters':(0x1fbfa4,0x1fda2c),'skills':(0x13da8c,0x13e5e0),
 'projectiles':(0x449b0c,0x44ae40),'area_effects':(0x370430,0x3709e4),'tiles':(0x4478e4,0x448000)}
def recover(native,start,end):
    records=[];page=None;target=None;recent=None
    for instruction in md.disasm(read(start,end-start),start):
        m,o=instruction.mnemonic,instruction.op_str
        if m=='adrp' and o.startswith('x1, #'):page=int(o.split('#')[1],16)
        elif m=='add' and o.startswith('x1, x1, #') and page is not None:target=page+int(o.split('#')[1],16)
        elif m=='bl' and o=='#0x12d868' and target is not None:
            recent={'name':native.string(target).decode(),'stringRva':hex(target),'callRva':hex(instruction.address)}
            records.append(recent);target=None
        elif m=='bl' and o=='#0x1f2eac' and recent:recent['typeCheckRva']=hex(instruction.address)
        elif m=='cmp' and o.startswith('w0, #') and recent and 'typeCheckRva' in recent and 'nativeType' not in recent:
            recent['nativeType']=int(o.split('#')[1],0)
    return records
if __name__=='__main__':
    n=NativeV13();n.decrypt();root=Path(__file__).resolve().parents[2];report={}
    for name,(start,end) in SCHEMAS.items():
        with (root/'GameAssets/csv_logic'/f'{name}.csv').open() as source: raw=list(csv.reader(source))
        required=recover(n,start,end);missing=[r['name'] for r in required if r['name'] not in raw[0]]
        invalid=[]
        for row in raw[2:]:
            for index,kind in enumerate(raw[1]):
                value=row[index] if index<len(row) else ''
                if kind.lower()=='int' and value:
                    try:int(value)
                    except ValueError:invalid.append({'row':row[0],'column':raw[0][index],'value':value})
        report[name]={'initializer':hex(start),'required':required,'missing':missing,'invalidIntegers':invalid}
        print(name+':',len(required),'native columns;',len(missing),'missing;',len(invalid),'invalid integer cells')
    out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
    (out/'required-csv-schema.json').write_text(json.dumps(report,indent=2))
