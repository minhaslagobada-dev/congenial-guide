"""Compare complete original frames with instruction budgets and wall time budgets.

Only the execution watchdog changes. Both runs use original constructors, bot AI,
physics, encoders and destructors. No gameplay state is replaced by Python.
"""
from emulate_v13 import NativeV13
from native_data import NativeDataRegistry
from native_battle import NativeBattle
from pathlib import Path
import json,os,time
n=NativeV13(heap_bytes=0x4000000,reclaim_memory=True,instruction_counting=False,timeout_us=2000000)
n.decrypt();root=Path(__file__).resolve().parents[2]
data=NativeDataRegistry(n,root/'GameAssets',progress=lambda *parts:print(*parts,flush=True))
results=[];reference=None
for counted in (True,False):
    n.instruction_counting=False
    battle=NativeBattle(data,'Gemgrab1');battle.add_player('ShotgunGirl',0);battle.setup()
    data.csv[15].word(battle.pointer+0x18,300)
    frames=[];start=time.monotonic();n.instruction_counting=counted
    n.call_timeout_us=0 if counted else 2000000
    for index in range(40):
        snapshots=battle.frame();state=battle.describe()
        frames.append(dict(state=state,vision=snapshots))
    elapsed=time.monotonic()-start;n.instruction_counting=False;n.call_timeout_us=2000000
    battle.close()
    if reference is None:reference=frames
    else:
        for index,(expected,actual) in enumerate(zip(reference,frames)):
            assert actual==expected, f'Execution watchdog changed native frame {index}'
    results.append(dict(instructionCounting=counted,frames=len(frames),elapsedSeconds=elapsed))
    print('Execution mode',results[-1],flush=True)
out=Path(os.environ.get('V13_RESEARCH_DIR','/workspace/analysis/native-server'));out.mkdir(parents=True,exist_ok=True)
(out/'battle-execution-modes.json').write_text(json.dumps(dict(identical=True,runs=results)))
print('Original complete frames and vision bytes identical with both execution watchdogs',flush=True)
