"""Package source without owner credentials, accounts, dependencies or logs."""
import json, sys, zipfile
from pathlib import Path
root = Path(__file__).resolve().parent.parent
out = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'NostBrawl-V13-servidor-em-validacao.zip'
config = {
 'ServerIP':'0.0.0.0','ServerPort':9339,'ClientMajor':13,'ClientMinor':0,'ClientBuild':283,
 'UnlockedBrawlersOption':'StarterOnly',
 'Database':{'Path':'Database/players.sqlite'},
 'SCID':{'Enabled':False,'RemoteUrl':'','RemoteApiKey':''},'Store':{'Enabled':False},
 'Battle':{'Enabled':True,'BindIP':'0.0.0.0','Port':9339,'AdvertiseHost':'','MaxPlayers':200,'SessionTimeoutMs':30000}
}
readme = '''SERVIDOR V13 EM VALIDACAO - NAO E UMA DECLARACAO DE PROJETO CONCLUIDO

ATUALIZACAO: preserve seu config.json e toda a pasta Database. O config.json
incluido e generico para instalacao nova: nao substitua suas configuracoes
de loja, SCID, rede e contas pelas genericas.

INSTALACAO NOVA: Node18+; npm ci; npm start. No servidor atras de NAT, ajuste
Battle.AdvertiseHost para o IPv4 que o celular alcanca e libere a porta UDP.
A loja e SCID estao desabilitados na configuracao generica.

Contem o codigo integral e os assets do servidor. Nao contem seus bancos,
credenciais particulares nem node_modules. Leia BATTLES.md para os testes
executados e as pendencias reais, incluindo APK e poderes de estrela.
'''
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(root.rglob('*')):
  relative=path.relative_to(root)
  if not path.is_file() or path.is_symlink() or set(relative.parts)&{'node_modules','.git','__pycache__','.pytest_cache'}:continue
  if path.name=='config.json' or any(s in path.name for s in ['.sqlite','.db-wal','.db-shm']) or path.suffix in {'.db','.log','.pyc','.zip'}:continue
  z.write(path,Path('NostBrawl-V13')/relative)
 z.writestr('NostBrawl-V13/config.json',json.dumps(config,indent=2)+'\n')
 z.writestr('NostBrawl-V13/LEIA-ANTES-DE-INSTALAR.txt',readme)
with zipfile.ZipFile(out) as z:
 assert json.loads(z.read('NostBrawl-V13/config.json'))==config
 assert not any('.sqlite' in n or '/node_modules/' in n for n in z.namelist())
 assert z.testzip() is None
 print(out.name, len(z.namelist()), 'files;', out.stat().st_size,'bytes; generic config only, no owner databases')
