'use strict'
const path = require('path')
process.chdir(path.resolve(__dirname, '..'))
const fs = require('fs')
fs.rmSync(path.resolve('Database/players.sqlite'), { force: true })

const DataBase = require('../Database/DatabaseManager')
const { GameRoomService, GameRoomFullError, GameRoomInviteError } = require('../Logic/GameRoomService')
const { BattleInstanceService } = require('../Logic/BattleInstances')
const { BattleRewardsManager } = require('../Logic/BattleRewardsManager')
const { apply_battle_result_rewards } = require('../Logic/BattleResultAdapter')
const TeamCode = require('../Logic/TeamCode')

let passed = 0
let failed = 0

function check (name, condition) {
  if (condition) {
    passed += 1
    console.log('ok', name)
  } else {
    failed += 1
    console.error('FAIL', name)
  }
}

function expectError (ErrorType, name, fn) {
  try {
    fn()
    failed += 1
    console.error('FAIL', name, '(expected ' + ErrorType.name + ')')
  } catch (error) {
    if (error instanceof ErrorType) {
      passed += 1
      console.log('ok', name)
    } else {
      failed += 1
      console.error('FAIL', name, '(wrong error: ' + String(error).split('\n')[0] + ')')
    }
  }
}

GameRoomService.init()

let nextLowId = 910000
function makeAccount (name) {
  nextLowId += 1
  const player = {
    token: 'gameroom_smoke_' + nextLowId,
    low_id: nextLowId,
    high_id: 0,
    name,
    trophies: 100,
    highest_trophies: 100,
    brawler_id: 0,
    skin_id: 0,
    Brawler_level: { 0: 2 },
    brawlers_trophies: { 0: 50 },
    brawlers_trophies_in_rank: { 0: 50 },
    brawlers_skins: {},
    battle_tokens: 40,
    tokensdoubler: 20,
    player_experience: 1000,
    tutorial: 2,
    online: 1
  }
  DataBase.createAccount({ player })
  return player
}

const host = makeAccount('Host')
const guest = makeAccount('Guest')
const third = makeAccount('Third')

// --- TeamCode -------------------------------------------------------------
const code = TeamCode.to_code(0, 1234567)
check('TeamCode prefix', code.startsWith('X'))
const [decHigh, decLow] = TeamCode.to_id(code)
check('TeamCode round-trip', decHigh === 0 && decLow === 1234567)
expectError(Error, 'TeamCode rejects bad prefix', () => TeamCode.to_id('Z123'))
expectError(Error, 'TeamCode rejects bad id', () => TeamCode.to_code(300, 1))

// --- create ---------------------------------------------------------------
const [room, previous, departed] = GameRoomService.create_transition(host, 0, -64, 0, false)
check('create_transition room fields', room.id === 1 && room.type === 0 && previous === null && !departed)
check('create() host is member', room.members.length === 1 && room.members[0].host === true)
check('create() snapshot hides private keys', !('_player' in room.members[0]) && !('stream_from' in room.members[0]))
check('player bound to room', host.room_id === 1 && host.map_id === room.map_id)
check('for_player returns room', GameRoomService.for_player(host).id === 1)
check('room stream has create event 101', GameRoomService.stream(1).length === 1 && GameRoomService.stream(1)[0].event === 101)
check('roomID persisted', DataBase._update_value('lowID', host.low_id, 'roomID', 1) === true)

// --- invites ---------------------------------------------------------------
// invite requires friendship entry — wire via friend_relations state 4 (done through FriendService)
const { FriendService } = require('../Logic/FriendService')
FriendService.add(host, guest.low_id, 0)
FriendService.accept(guest, host.low_id)
const [inviteRoom, invite] = GameRoomService.invite(host, guest.low_id, 0)
check('invite() creates pending invite', invite.room_id === 1 && invite.status === 1 && invite.invite_type === 0)
check('invite() snapshot includes invite', inviteRoom.invites.length === 1)
const [dupRoom, dupInvite] = GameRoomService.invite(host, guest.low_id, 0)
check('invite duplicate returns [null, null]', dupRoom === null && dupInvite === null)

const [markedRoom, markedInvite] = GameRoomService.mark_invite(host, guest.low_id, GameRoomService.INVITE_OFFLINE)
check('mark_invite sets offline', markedInvite.status === GameRoomService.INVITE_OFFLINE)
GameRoomService.init() // reset for invite accept path

// fresh room for invite accept
const [room2] = GameRoomService.create_transition(host, 0, -64, 0, false)
const [, invite2] = GameRoomService.invite(host, guest.low_id, 0)
const [acceptRoom, acceptedInvite] = GameRoomService.accept_invite(guest, room2.id)
check('accept_invite joins room', acceptRoom.id === room2.id && acceptRoom.members.length === 2)
check('accept_invite consumes invite', acceptRoom.invites.length === 0)
check('accept_invite binds guest', guest.room_id === room2.id)
check('guest is not host', acceptRoom.members.find((m) => m.low_id === guest.low_id).host === false)

// --- request / respond join -----------------------------------------------
FriendService.add(third, host.low_id, 0)
FriendService.accept(host, third.low_id)
const [reqRoom, reqEntry] = GameRoomService.request_join_request(third, host.low_id, room2.id)
check('request_join_request pending key', reqEntry.key > 0 && reqEntry.requester_id === third.low_id)
const outcome = GameRoomService.respond_join_request(host, reqEntry.key, true, false)
check('respond_join_request accepted', outcome.accepted && outcome.joined)
check('third joined room', outcome.room.members.length === 3)
check('third room binding', third.room_id === room2.id)
// decline path: request then decline
const [reqRoom2, reqEntry2] = GameRoomService.request_join_request(third, host.low_id, room2.id)
// third is already member => request returns null
check('request from existing member rejected', reqRoom2 === null && reqEntry2 === null)

// --- chat / stream ----------------------------------------------------------
const [, chatEntry] = GameRoomService.add_chat(host, 'vamos jogar')
check('add_chat kind 2', chatEntry.kind === 2 && chatEntry.message === 'vamos jogar')
check('stream_for filters by stream_from', GameRoomService.stream_for(room2, guest.low_id).every((e) => e.id > 0))
check('chats() filters kind 2', GameRoomService.chats(room2.id).every((e) => e.kind === 2))

// --- ready / status / settings ----------------------------------------------
GameRoomService.set_ready(guest, true)
check('set_ready marks member', GameRoomService.get(room2.id).members.find((m) => m.low_id === guest.low_id).ready === true)
GameRoomService.set_status(guest, 5)
check('set_status updates member', GameRoomService.get(room2.id).members.find((m) => m.low_id === guest.low_id).status === 5)
const afterSettings = GameRoomService.set_member_settings(guest, sqlBrawlerSkin(), 7)
function sqlBrawlerSkin () {
  return guest.brawler_id // use same brawler to keep CSV-free
}
check('set_member_settings updates skin', afterSettings !== null)

// --- teams -------------------------------------------------------------------
const teamed = GameRoomService.set_teams(host, [[0, guest.low_id]], 4)
check('set_teams side >= 3 sets 1', teamed.members.find((m) => m.low_id === guest.low_id).team === 1)
const teamedBack = GameRoomService.set_teams(host, [[0, guest.low_id]], 0)
check('set_teams side < 3 sets 0', teamedBack.members.find((m) => m.low_id === guest.low_id).team === 0)

// --- kick ---------------------------------------------------------------------
const kickOutcome = GameRoomService.kick_transition(host, third.low_id)
check('kick removes member', kickOutcome.target_id === third.low_id && kickOutcome.room.members.length === 2)
check('kick host only', GameRoomService.kick_transition(guest, host.low_id).target_id === 0)

// --- leave disband on host exit ------------------------------------------------
const leaveResult = GameRoomService.leave_transition(host)
check('host leave disbands room', leaveResult.departed && leaveResult.host && leaveResult.disbanded.length === 1)
check('disbanded member room cleared', DataBase._update_value && GameRoomService.get(room2.id) === null)
check('host room cleared', host.room_id === 0)

// --- battle instances ------------------------------------------------------------
const battleId1 = BattleInstanceService.begin(host)
check('begin returns id', typeof battleId1 === 'string' && battleId1.length === 32)
const battleId2 = BattleInstanceService.begin(host)
check('begin reuses open instance', battleId2 === battleId1)

// --- battle rewards (3v3 victory) -------------------------------------------------
const fields = {
  GameMode: 0,
  MapID: 7,
  MapSlot: 1,
  Rank: 1,
  Victory: 0,
  result: 16,
  Heroes: [{ IsPlayer: true, Brawler: { ID: [16, 0] } }]
}
const rewards1 = apply_battle_result_rewards(host, 0, battleId1)
check('3v3 victory trophies +6 (index -1)', rewards1.brawler_trophies === 50 && rewards1.rewards.trophies_gain === 6)
check('3v3 tokens (victory index -1 = 20 tokens)', rewards1.token === 20 && rewards1.doubledtokens === 20)
check('3v3 starplayer 5 (result 17 > 15)', rewards1.starplayer === 5 && rewards1.rewards.hasStarKey === true)
check('rewards persisted to player', host.brawlers_trophies['0'] === 56 && host.trophies === 106)

// replay returns stored result, no double-apply
const rewards2 = apply_battle_result_rewards(host, 0, battleId1)
check('replay same rewards (from ledger)', rewards2.rewards._replayed === true && rewards2.brawler_trophies === 50)
check('replay does not double apply', host.brawlers_trophies['0'] === 56 && host.trophies === 106)

// resolve_result flow: payload_hash binds the open ledger instance
const battleId3 = BattleInstanceService.begin(host)
check('begin new instance after completed', battleId3 !== battleId1)
const hash = 'a'.repeat(64)
const resolved = BattleInstanceService.resolve_result(host, hash, 0)
check('resolve_result binds open instance', resolved === battleId3)
const resolvedAgain = BattleInstanceService.resolve_result(host, hash, 0)
check('resolve_result idempotent for same hash', resolvedAgain === battleId3)

// --- solo showdown modifiers ------------------------------------------------------
function applyShowdown (trophies, rank) {
  return BattleRewardsManager.get_solo_trophy_modifiers(trophies)[rank - 1]
}
check('solo mod rank1 low trophies', applyShowdown(10, 1) === 8)
check('solo mod rank10 high trophies', applyShowdown(800, 10) === -7)
check('3v3 modifiers victory idx -1', (() => { const m = BattleRewardsManager.get_trophy_modifiers(100); return m[m.length - 1] === 5 })())
check('duo modifiers rank2 (idx 1)', BattleRewardsManager.get_duo_trophy_modifiers(450)[1] === 3)

// --- GameRoomService.count ---------------------------------------------------------
const [roomX] = GameRoomService.create_transition(third, 0, -64, 0, false)
check('count tracks rooms', GameRoomService.count() === 1)
GameRoomService.leave_transition(third)
check('count drops when empty', GameRoomService.count() === 0)

console.log('')
console.log('GAMEROOM/BATTLE SMOKE ' + (failed ? 'FAILED' : 'OK') + ': ' + passed + ' passed, ' + failed + ' failed')
if (failed) {
  process.exit(1)
}
