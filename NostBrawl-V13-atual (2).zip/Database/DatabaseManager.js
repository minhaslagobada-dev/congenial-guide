'use strict'
const fs = require('fs')
const path = require('path')
const { openDatabase: sqlite3 } = require('./SqliteDriver')

const { Players } = require('../Logic/Player')
const RelationalState = require('./RelationalState')
const Config = require('../Utils/Config')

function deepEqual (a, b) {
  if (a === b) return true
  if (typeof a !== typeof b) return false
  if (a === null || b === null) return false
  if (typeof a !== 'object') return a === b
  if (Array.isArray(a) !== Array.isArray(b)) return false
  if (Array.isArray(a)) {
    if (a.length !== b.length) return false
    for (let index = 0; index < a.length; index++) {
      if (!deepEqual(a[index], b[index])) return false
    }
    return true
  }
  const aKeys = Object.keys(a)
  const bKeys = Object.keys(b)
  if (aKeys.length !== bKeys.length) return false
  for (const key of aKeys) {
    if (!(key in b)) return false
    if (!deepEqual(a[key], b[key])) return false
  }
  return true
}

class DataBase {
  static _database_path () {
    const database = Config.GetValue().Database || {}
    return String(database.Path !== undefined ? database.Path : DataBase.DATABASE_PATH)
  }

  static _migrate_legacy_database (databasePath) {
    const canonical = path.resolve(DataBase.DATABASE_PATH)
    if (databasePath !== canonical) {
      return
    }
    const legacy = path.resolve(DataBase.LEGACY_DATABASE_PATH)
    if (legacy === canonical || fs.existsSync(canonical) || !fs.existsSync(legacy) || !fs.statSync(legacy).isFile()) {
      return
    }
    if (fs.existsSync(canonical) || !fs.existsSync(legacy)) {
      return
    }
    const temporary = path.join(
      path.dirname(canonical),
      `.${path.basename(canonical)}.migration-${process.pid}-0`
    )
    try {
      if (fs.existsSync(temporary)) {
        fs.unlinkSync(temporary)
      }
      const source = new sqlite3(legacy)
      try {
        source.exec('PRAGMA busy_timeout = 10000')
        source.exec(`VACUUM INTO '${temporary.replace(/'/g, "''")}'`)
        const destination = new sqlite3(temporary, { readonly: true })
        try {
          const integrity = destination.prepare('PRAGMA integrity_check').get()
          if (!integrity || integrity.integrity_check !== 'ok') {
            throw new Error('Falha de integridade na migração SQLite')
          }
        } finally {
          destination.close()
        }
      } finally {
        source.close()
      }
      fs.renameSync(temporary, canonical)
    } finally {
      if (fs.existsSync(temporary)) {
        fs.unlinkSync(temporary)
      }
    }
  }

  static _state_default (column) {
    if (column === 'UnlockedSkins') {
      return { Skins: [] }
    }
    return {}
  }

  static _decode_legacy_json (value, column) {
    const defaultValue = DataBase._state_default(column)
    if (value === null || value === undefined) {
      return structuredClone(defaultValue)
    }
    if (typeof value === 'object') {
      return value
    }
    let decoded
    try {
      decoded = JSON.parse(value)
    } catch (error) {
      return structuredClone(defaultValue)
    }
    return decoded === null || decoded === undefined ? structuredClone(defaultValue) : decoded
  }

  static _state_value (value, column) {
    if (value === null || value === undefined) {
      return structuredClone(DataBase._state_default(column))
    }
    if (typeof value === 'string') {
      try {
        return JSON.parse(value)
      } catch (error) {
      }
    }
    return value
  }

  static _read_state (connection, lowId, column) {
    if (!DataBase.STATE_COLUMN_SET.has(column)) {
      throw new Error(`Unsupported relational state: ${column}`)
    }
    return RelationalState.read(
      connection, lowId, column, DataBase._state_default(column)
    )
  }

  static _write_state (connection, lowId, column, value) {
    if (!DataBase.STATE_COLUMN_SET.has(column)) {
      throw new Error(`Unsupported relational state: ${column}`)
    }
    RelationalState.write(
      connection,
      lowId,
      column,
      DataBase._state_value(value, column)
    )
  }

  static _select_player (connection, whereColumn, whereValue) {
    if (whereColumn !== 'token' && whereColumn !== 'lowID') {
      throw new Error(`Unsupported lookup column: ${whereColumn}`)
    }
    const columns = DataBase.PLAYER_STORAGE_COLUMNS
    const quoted = columns.map((column) => `"${column}"`).join(', ')
    const raw = connection.prepare(
      `SELECT ${quoted} FROM players WHERE "${whereColumn}" = ?`
    ).get(whereValue)
    if (raw === undefined) {
      return null
    }
    const record = raw
    for (const column of DataBase.STATE_COLUMNS) {
      record[column] = DataBase._read_state(
        connection, record.lowID, column
      )
    }
    return DataBase.PLAYER_COLUMNS.map((column) => record[column])
  }

  static _migrate_json_columns (connection, existingColumns) {
    connection.exec('PRAGMA foreign_keys = OFF')
    try {
      connection.exec('BEGIN IMMEDIATE')
      const newTable = DataBase.PLAYER_TABLE_SCHEMA.replace(
        'CREATE TABLE IF NOT EXISTS players (',
        'CREATE TABLE players_new ('
      )
      connection.exec(newTable)
      const available = DataBase.PLAYER_STORAGE_COLUMNS.filter(
        (column) => existingColumns.includes(column)
      )
      const quoted = available.map((column) => `"${column}"`).join(', ')
      connection.exec(
        `INSERT INTO players_new (${quoted}) SELECT ${quoted} FROM players`
      )
      connection.exec(`
                CREATE TEMP TABLE player_state_migration (
                    player_id INTEGER NOT NULL,
                    domain TEXT NOT NULL,
                    path TEXT NOT NULL,
                    parent_path TEXT,
                    segment TEXT,
                    position INTEGER NOT NULL,
                    node_type TEXT NOT NULL,
                    value_integer INTEGER,
                    value_real REAL,
                    value_text TEXT,
                    PRIMARY KEY (player_id, domain, path)
                )
            `)
      const rows = connection.prepare('SELECT * FROM players').all()
      const temporaryInsert = RelationalState.INSERT.replace(
        'player_state_entries', 'temp.player_state_migration'
      )
      const insertStatement = connection.prepare(temporaryInsert)
      for (const rawRow of rows) {
        const record = {}
        for (let index = 0; index < existingColumns.length; index++) {
          record[existingColumns[index]] = rawRow[existingColumns[index]]
        }
        const lowId = Number.parseInt(record.lowID, 10)
        for (const column of DataBase.STATE_COLUMNS) {
          if (!(column in record)) {
            continue
          }
          const value = DataBase._decode_legacy_json(record[column], column)
          for (const stateRow of RelationalState.rows(lowId, column, value)) {
            insertStatement.run(...stateRow)
          }
        }
      }
      connection.exec('DROP TABLE players')
      connection.exec('ALTER TABLE players_new RENAME TO players')
      connection.exec(DataBase.PLAYER_STATE_TABLE)
      connection.exec(DataBase.PLAYER_STATE_INDEX)
      const stateColumns =
                'player_id, domain, path, parent_path, segment, position, ' +
                'node_type, value_integer, value_real, value_text'
      connection.exec(
        `INSERT INTO player_state_entries (${stateColumns}) ` +
        `SELECT ${stateColumns} FROM temp.player_state_migration`
      )
      connection.exec('DROP TABLE temp.player_state_migration')
      const violations = connection.prepare('PRAGMA foreign_key_check').all()
      if (violations.length) {
        throw new Error('Falha de chave estrangeira na migração relacional')
      }
      const integrity = connection.prepare('PRAGMA integrity_check').get()
      if (!integrity || integrity.integrity_check !== 'ok') {
        throw new Error('Falha de integridade na migração relacional')
      }
      connection.exec('COMMIT')
    } catch (error) {
      try {
        connection.exec('ROLLBACK')
      } catch (ignored) {
      }
      throw error
    } finally {
      connection.exec('PRAGMA foreign_keys = ON')
    }
  }

  static _initialize_schema (connection, databasePath) {
    if (databasePath !== ':memory:') {
      connection.exec('PRAGMA journal_mode = WAL')
    }
    connection.exec('PRAGMA synchronous = NORMAL')
    const columnRows = connection.prepare('PRAGMA table_info(players)').all()
    const columns = columnRows.map((row) => row.name)
    const unexpectedColumns = columns.filter(
      (column) => !DataBase.PLAYER_STORAGE_COLUMN_SET.has(column)
    )
    const expectedColumns = DataBase.PLAYER_STORAGE_COLUMN_SET
    const intersectsState = columns.some((column) => DataBase.STATE_COLUMN_SET.has(column))
    if (columns.length && (
      intersectsState ||
      unexpectedColumns.length ||
      columns.length !== expectedColumns.size || columns.some((column) => !expectedColumns.has(column))
    )) {
      DataBase._migrate_json_columns(connection, columns)
    } else {
      connection.exec(DataBase.PLAYER_SCHEMA)
    }
    connection.exec(DataBase.CLUB_SCHEMA)
    connection.exec(DataBase.SOCIAL_SCHEMA)
    const friendColumns = new Set(
      connection.prepare('PRAGMA table_info(friend_relations)').all().map((row) => row.name)
    )
    if (!friendColumns.has('origin')) {
      connection.exec(
        'ALTER TABLE friend_relations ADD COLUMN origin INTEGER NOT NULL DEFAULT 0'
      )
    }
    connection.exec(DataBase.BATTLE_SCHEMA)
    connection.exec(DataBase.DAILY_REWARD_SCHEMA)
    const schemaVersion = connection.prepare('PRAGMA user_version').get().user_version
    if (schemaVersion < DataBase.EXPERIENCE_MIGRATION_VERSION) {
      connection.prepare(
        'UPDATE players SET playerExp = ? WHERE playerExp <> ?'
      ).run(DataBase.PLAYER_EXPERIENCE, DataBase.PLAYER_EXPERIENCE)
    }
    if (schemaVersion < DataBase.RELATIONAL_SCHEMA_VERSION) {
      connection.exec(
        `PRAGMA user_version = ${DataBase.RELATIONAL_SCHEMA_VERSION}`
      )
    }
    if (connection.inTransaction) {
      connection.exec('COMMIT')
    }
  }

  static _connect () {
    const configuredPath = DataBase._database_path()
    let databasePath
    if (configuredPath === ':memory:') {
      databasePath = configuredPath
    } else {
      const resolved = path.resolve(configuredPath)
      fs.mkdirSync(path.dirname(resolved), { recursive: true })
      DataBase._migrate_legacy_database(resolved)
      databasePath = resolved
    }

    const connection = new sqlite3(databasePath)
    connection.exec('PRAGMA foreign_keys = ON')
    connection.exec('PRAGMA busy_timeout = 10000')

    if (!DataBase._initialized_paths.has(databasePath)) {
      if (!DataBase._initialized_paths.has(databasePath)) {
        DataBase._initialize_schema(connection, databasePath)
        DataBase._initialized_paths.add(databasePath)
      }
    }
    return connection
  }

  static _connection (fn, explicitTransaction = false) {
    const connection = DataBase._connect()
    try {
      if (!explicitTransaction) {
        connection.exec('BEGIN')
      }
      const result = fn(connection)
      if (connection.inTransaction) {
        connection.exec('COMMIT')
      }
      return result
    } catch (error) {
      if (connection.inTransaction) {
        try {
          connection.exec('ROLLBACK')
        } catch (ignored) {
        }
      }
      throw error
    } finally {
      connection.close()
    }
  }

  static _number (value, defaultValue = 0) {
    try {
      const parsed = Number.parseInt(value, 10)
      if (Number.isNaN(parsed)) return defaultValue
      return parsed
    } catch (error) {
      return defaultValue
    }
  }

  static _apply_row (player, row) {
    player.id = row[0]
    player.token = row[1] || ''
    player.name = row[2] || 'Guest'

    const numericFields = [
      ['trophy_road', 3],
      ['low_id', 4],
      ['tgid', 5],
      ['club_low_id', 6],
      ['club_role', 7],
      ['player_experience', 8],
      ['solo_wins', 9],
      ['duo_wins', 10],
      ['ThreeVSThree_wins', 11],
      ['gems', 12],
      ['gold', 13],
      ['tokensdoubler', 14],
      ['battle_tokens', 15],
      ['tickets', 16],
      ['brawler_id', 17],
      ['skin_id', 18],
      ['trophies', 19],
      ['highest_trophies', 20],
      ['profile_icon', 21],
      ['name_color', 22],
      ['brawl_boxes', 23],
      ['big_boxes', 24],
      ['starpower', 25],
      ['do_not_distrub', 26],
      ['online', 36],
      ['room_id', 39]
    ]
    for (const [attribute, index] of numericFields) {
      player[attribute] = DataBase._number(row[index])
    }

    const stateFields = [
      ['brawlers_skins', 27, 'brawlersSkins'],
      ['brawlers_trophies', 28, 'brawlersTrophies'],
      ['brawlers_trophies_in_rank', 29, 'brawlersTrophiesForRank'],
      ['brawlers_upgradium', 30, 'brawlersUpgradePoints'],
      ['Brawler_level', 31, 'brawlerPowerLevel'],
      ['Brawler_starPower', 32, 'brawlerStarPower'],
      ['BrawlersUnlockedState', 33, 'UnlockedBrawlers'],
      ['UnlockedSkins', 34, 'UnlockedSkins'],
      ['Friends', 35, 'Friends'],
      ['Notifications', 37, 'Notifications'],
      ['progression', 38, 'progression']
    ]
    for (const [attribute, index, column] of stateFields) {
      player[attribute] = DataBase._decode_legacy_json(row[index], column)
    }

    let progression = player.progression || {}
    if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
      progression = {}
      player.progression = progression
    }
    player.tokensAnim = DataBase._number(progression.keyReward !== undefined ? progression.keyReward : 0)
    player.trophiesAnim = DataBase._number(progression.trophyReward !== undefined ? progression.trophyReward : 0)
    player.bigTokensAnim = DataBase._number(progression.starKeyReward !== undefined ? progression.starKeyReward : 0)
    player.star_points = DataBase._number(
      progression.starPoints !== undefined ? progression.starPoints : (player.star_points || 0)
    )
    player.IsFacebookLinked = (progression.isFBLinked || false) ? 1 : 0
    player.FacebookID = String(progression.facebookID || '')
    player.FacebookToken = String(progression.facebookToken || '')

    const powerLevelVersion = DataBase._number(
      progression.powerLevelWireVersion !== undefined ? progression.powerLevelWireVersion : 0
    )
    const migratePowerLevels = powerLevelVersion < DataBase.POWER_LEVEL_WIRE_VERSION
    const storedLevels = player.Brawler_level || {}
    const normalizedLevels = structuredClone(Players.Brawler_level)
    if (typeof storedLevels === 'object' && storedLevels !== null) {
      for (const [key, value] of Object.entries(storedLevels)) {
        let level = DataBase._number(value, 0)
        if (migratePowerLevels) {
          level -= 1
        }
        normalizedLevels[String(key)] = Math.max(0, level)
      }
    }
    player.Brawler_level = normalizedLevels
    if (migratePowerLevels) {
      progression.powerLevelWireVersion = DataBase.POWER_LEVEL_WIRE_VERSION
    }

    let storedPoints = player.brawlers_upgradium || {}
    if (typeof storedPoints !== 'object' || storedPoints === null) {
      storedPoints = structuredClone(Players.brawlers_upgradium)
    }
    const normalizedPoints = {}
    for (const [key, value] of Object.entries(storedPoints)) {
      normalizedPoints[String(key)] = Math.min(
        DataBase.MAX_POWER_POINTS,
        Math.max(0, DataBase._number(value))
      )
    }
    player.brawlers_upgradium = normalizedPoints
    player.trophy_road = Math.min(
      DataBase.TROPHY_ROAD_COMPLETE,
      Math.max(1, player.trophy_road)
    )
    return migratePowerLevels
  }

  static _load_account_from_connection (connection, player) {
    const row = DataBase._select_player(connection, 'token', player.token)
    if (row === null) {
      return false
    }

    const storedPoints = structuredClone(row[30])
    const storedPosition = DataBase._number(row[3])
    const migratePowerLevels = DataBase._apply_row(player, row)
    if (migratePowerLevels) {
      DataBase._write_state(
        connection,
        player.low_id,
        'brawlerPowerLevel',
        player.Brawler_level
      )
      DataBase._write_state(
        connection,
        player.low_id,
        'progression',
        player.progression
      )
    }
    if (!deepEqual(storedPoints, player.brawlers_upgradium)) {
      DataBase._write_state(
        connection,
        player.low_id,
        'brawlersUpgradePoints',
        player.brawlers_upgradium
      )
    }
    if (storedPosition !== player.trophy_road) {
      connection.prepare(
        'UPDATE players SET leagueReward = ? WHERE token = ?'
      ).run(player.trophy_road, player.token)
    }
    if (player.trophies >= player.highest_trophies) {
      player.highest_trophies = player.trophies
      connection.prepare(
        'UPDATE players SET highest_trophies = ? WHERE token = ?'
      ).run(player.highest_trophies, player.token)
    }
    return true
  }

  static loadAccount (self) {
    return DataBase._connection((connection) =>
      DataBase._load_account_from_connection(connection, self.player)
    )
  }

  // Refresh-only lookup of another player's club membership for the legacy
  // Writer broadcast paths (sendToAll / sendToOthers): they only read
  // self.player.club_low_id right after this call.
  static loadOtherAccount (self, lowId) {
    lowId = Math.trunc(Number(lowId) || 0) || 0
    const clubId = DataBase._connection((connection) => {
      const row = connection.prepare('SELECT clubID FROM players WHERE lowID = ?').get(lowId)
      return row ? DataBase._number(row.clubID) : 0
    })
    if (self && self.player) {
      self.player.club_low_id = clubId
    }
    return clubId
  }

  static createAccount (self) {
    const player = self.player
    player.BrawlersUnlockedState = Players.CreateNewBrawlersList()
    let progression = player.progression || {}
    if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
      progression = {}
    }
    progression.powerLevelWireVersion = DataBase.POWER_LEVEL_WIRE_VERSION
    player.progression = progression
    player.highest_trophies = Math.max(
      (player.trophies || 0),
      (player.highest_trophies || 0)
    )

    const data = {
      token: String(player.token),
      name: String((player.name !== undefined ? player.name : 'Guest')),
      leagueReward: DataBase._number((player.trophy_road !== undefined ? player.trophy_road : 1)),
      lowID: DataBase._number(player.low_id),
      tgid: DataBase._number((player.tgid || 0)),
      clubID: DataBase._number((player.club_low_id || 0)),
      clubRole: DataBase._number((player.club_role || 0)),
      playerExp: DataBase._number(
        (player.player_experience !== undefined ? player.player_experience : DataBase.PLAYER_EXPERIENCE)
      ),
      soloWins: DataBase._number((player.solo_wins || 0)),
      duoWins: DataBase._number((player.duo_wins || 0)),
      TvsTWins: DataBase._number((player.ThreeVSThree_wins || 0)),
      gems: DataBase._number((player.gems || 0)),
      gold: DataBase._number((player.gold || 0)),
      tokensdoubler: DataBase._number((player.tokensdoubler || 0)),
      battleTokens: DataBase._number((player.battle_tokens || 0)),
      tickets: DataBase._number((player.tickets || 0)),
      brawlerID: DataBase._number((player.brawler_id || 0)),
      skinID: DataBase._number((player.skin_id || 0)),
      trophies: DataBase._number((player.trophies || 0)),
      highest_trophies: DataBase._number(
        Math.max((player.trophies || 0), (player.highest_trophies || 0))
      ),
      profileIcon: DataBase._number((player.profile_icon || 0)),
      namecolor: DataBase._number((player.name_color || 0)),
      brawlBoxes: DataBase._number((player.brawl_boxes || 0)),
      bigBoxes: DataBase._number((player.big_boxes || 0)),
      starpower: DataBase._number((player.starpower || 0)),
      DoNotDistrub: DataBase._number((player.do_not_distrub || 0)),
      brawlersSkins: (player.brawlers_skins || {}),
      brawlersTrophies: (player.brawlers_trophies || {}),
      brawlersTrophiesForRank: (player.brawlers_trophies_in_rank || {}),
      brawlersUpgradePoints: (player.brawlers_upgradium || {}),
      brawlerPowerLevel: (player.Brawler_level || {}),
      brawlerStarPower: (player.Brawler_starPower || {}),
      UnlockedBrawlers: player.BrawlersUnlockedState,
      UnlockedSkins: (player.UnlockedSkins || { Skins: [] }),
      Friends: (player.Friends || {}),
      online: DataBase._number((player.online || 0)),
      Notifications: (player.Notifications || {}),
      progression: (player.progression || {}),
      roomID: DataBase._number((player.room_id || 0))
    }

    const columns = DataBase.PLAYER_STORAGE_COLUMNS.slice(1)
    const quotedColumns = columns.map((column) => `"${column}"`).join(', ')
    const placeholders = columns.map(() => '?').join(', ')
    const values = columns.map((column) => data[column])

    DataBase._connection((connection) => {
      connection.prepare(
        `INSERT INTO players (${quotedColumns}) VALUES (${placeholders})`
      ).run(...values)
      connection.prepare(
        'INSERT INTO social_presence(player_id, last_activity_at) VALUES (?, ?)'
      ).run(Math.trunc(player.low_id), Math.trunc(Date.now() / 1000))
      for (const column of DataBase.PLAYER_COLUMNS) {
        if (DataBase.STATE_COLUMN_SET.has(column)) {
          DataBase._write_state(
            connection, player.low_id, column, data[column]
          )
        }
      }
    })
    return player.low_id
  }

  static _update_value (whereColumn, whereValue, valueName, newValue) {
    return DataBase._update_values(
      whereColumn, whereValue, { [valueName]: newValue }
    )
  }

  static _write_values (connection, lowId, values) {
    if (!values || Object.keys(values).length === 0) {
      return true
    }
    for (const column of Object.keys(values)) {
      if (!DataBase.PLAYER_COLUMN_SET.has(column) || column === 'id' || column === 'lowID') {
        throw new Error(`Unsupported player column: ${column}`)
      }
    }
    const account = connection.prepare(
      'SELECT lowID FROM players WHERE lowID = ?'
    ).get(lowId)
    if (account === undefined) {
      return false
    }
    const scalar = {}
    for (const [column, value] of Object.entries(values)) {
      if (!DataBase.STATE_COLUMN_SET.has(column)) {
        scalar[column] = value
      }
    }
    if (Object.keys(scalar).length) {
      const assignments = Object.keys(scalar).map((column) => `"${column}" = ?`).join(', ')
      const parameters = Object.values(scalar)
      parameters.push(lowId)
      const info = connection.prepare(
        `UPDATE players SET ${assignments} WHERE lowID = ?`
      ).run(...parameters)
      if (info.changes !== 1) {
        return false
      }
    }
    for (const [column, value] of Object.entries(values)) {
      if (DataBase.STATE_COLUMN_SET.has(column)) {
        DataBase._write_state(connection, lowId, column, value)
      }
    }
    return true
  }

  static _update_values (whereColumn, whereValue, values) {
    if (whereColumn !== 'token' && whereColumn !== 'lowID') {
      throw new Error(`Unsupported lookup column: ${whereColumn}`)
    }
    for (const column of Object.keys(values)) {
      if (!DataBase.PLAYER_COLUMN_SET.has(column) || column === 'id' || column === 'lowID') {
        throw new Error(`Unsupported player column: ${column}`)
      }
    }
    if (!Object.keys(values).length) {
      return true
    }
    return DataBase._connection((connection) => {
      let lowId
      if (whereColumn === 'lowID') {
        lowId = Math.trunc(whereValue)
      } else {
        const account = connection.prepare(
          'SELECT lowID FROM players WHERE token = ?'
        ).get(whereValue)
        if (account === undefined) {
          return false
        }
        lowId = Math.trunc(account.lowID)
      }
      return DataBase._write_values(connection, lowId, values)
    })
  }

  static consume_home_reward_animations (player, expected) {
    const keys = ['keyReward', 'trophyReward', 'starKeyReward']
    try {
      expected = expected.map((value) => Math.trunc(value))
    } catch (error) {
      throw new Error('Recompensa de apresentação inválida')
    }
    if (!Array.isArray(expected) || expected.length !== 3) {
      throw new Error('Recompensa de apresentação inválida')
    }
    if (!expected.some((value) => value)) {
      return expected
    }
    const lowId = Math.trunc(player.low_id || 0) || 0
    const token = player.token || ''
    if (lowId <= 0 || typeof token !== 'string' || !token || token === 'None') {
      return null
    }
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const account = connection.prepare(
        'SELECT 1 FROM players WHERE lowID = ?'
      ).get(lowId)
      if (account === undefined) {
        throw new Error('Conta não encontrada ao concluir a apresentação')
      }
      const progression = DataBase._read_state(connection, lowId, 'progression')
      if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
        throw new Error('Progresso inválido ao concluir a apresentação')
      }
      const current = keys.map((key) => DataBase._number(progression[key] !== undefined ? progression[key] : 0))
      if (!deepEqual(current, expected)) {
        return current
      }
      const updated = structuredClone(progression)
      for (const key of keys) {
        updated[key] = 0
      }
      DataBase._write_state(connection, lowId, 'progression', updated)
      return [0, 0, 0]
    }, true)
  }

  static replaceValue (self, valueName, newValue) {
    const aliases = {
      availableTokens: 'battleTokens',
      tokens: 'battleTokens'
    }
    valueName = aliases[valueName] !== undefined ? aliases[valueName] : valueName
    const progressionFields = {
      starpoints: 'starPoints',
      starPoints: 'starPoints',
      tokensAnim: 'keyReward',
      trophiesAnim: 'trophyReward',
      bigTokensAnim: 'starKeyReward'
    }
    if (valueName in progressionFields) {
      let progression = structuredClone(self.player.progression || {})
      if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
        progression = {}
      }
      progression[progressionFields[valueName]] = DataBase._number(newValue)
      const updated = DataBase._update_value(
        'token', self.player.token, 'progression', progression
      )
      if (updated) {
        self.player.progression = progression
        const attribute = progressionFields[valueName]
        if (attribute === 'starPoints') {
          self.player.star_points = DataBase._number(newValue)
        } else {
          const animationNames = {
            keyReward: 'tokensAnim',
            trophyReward: 'trophiesAnim',
            starKeyReward: 'bigTokensAnim'
          }
          self.player[animationNames[attribute]] = DataBase._number(newValue)
        }
      }
      return updated
    }
    return DataBase._update_value(
      'token', self.player.token, valueName, newValue
    )
  }

  static replaceValues (self, values) {
    return DataBase._update_values('token', self.player.token, values)
  }

  static replaceOtherValue (self, lowId, valueName, newValue) {
    return DataBase._update_value('lowID', lowId, valueName, newValue)
  }

  static DeleteTrash (self) {
    DataBase._connection((connection) => {
      const count = connection.prepare(
        'SELECT COUNT(*) AS c FROM players WHERE name = ?'
      ).get('Guest').c
      if (count >= 15) {
        connection.prepare('DELETE FROM players WHERE name = ?').run('Guest')
      }
    })
  }

  static fixAccount (self) {
    for (const [column, value] of [
      ['trophies', 0],
      ['highest_trophies', 0],
      ['clubID', 0],
      ['gold', 100],
      ['gems', 0],
      ['tickets', 5],
      ['bigBoxes', 0],
      ['brawlBoxes', 0],
      ['tokensdoubler', 0],
      ['tgid', 0],
      ['playerExp', 0]
    ]) {
      DataBase.replaceValue(self, column, value)
    }

    self.player.brawlers_trophies[String(self.player.brawler_id)] = 0
    self.player.brawlers_trophies_in_rank[String(self.player.brawler_id)] = 0
    DataBase.replaceValue(
      self, 'brawlersTrophies', self.player.brawlers_trophies
    )
    DataBase.replaceValue(
      self,
      'brawlersTrophiesForRank',
      self.player.brawlers_trophies_in_rank
    )
  }

  static checkID (self, newId) {
    return DataBase._connection((connection) => {
      const row = connection.prepare(
        'SELECT 1 FROM players WHERE lowID = ?'
      ).get(newId)
      return row === undefined ? 1 : 0
    })
  }

  static sendNotifData (self, lowID, ID, text, type) {
    const row = DataBase.loadMembersById(self, lowID)
    if (row === null) {
      return false
    }
    const notifications = structuredClone(row[37])
    notifications[String(Object.keys(notifications).length)] = {
      ID,
      Index: 3,
      Read: false,
      Time: Date.now() / 1000,
      Text: text
    }
    if (ID === 81) {
      notifications[String(Object.keys(notifications).length - 1)].Type = type
    }
    return DataBase.replaceOtherValue(self, lowID, 'Notifications', notifications)
  }

  static loadOldAccount (self, nostId) {
    return DataBase._connection((connection) => {
      const info = connection.prepare(
        'UPDATE players SET token = ? WHERE tgid = ?'
      ).run(self.player.token, nostId)
      return info.changes > 0
    })
  }

  static update_presence (player, status, activityAt) {
    return DataBase._connection((connection) => {
      const info = connection.prepare(
        'UPDATE players SET online = ? WHERE lowID = ? AND token = ?'
      ).run(Math.trunc(status), Math.trunc(player.low_id), player.token)
      if (info.changes !== 1) {
        return false
      }
      connection.prepare(
        'INSERT INTO social_presence(player_id, last_activity_at) VALUES (?, ?) ' +
        'ON CONFLICT(player_id) DO UPDATE SET last_activity_at = excluded.last_activity_at'
      ).run(Math.trunc(player.low_id), Math.trunc(activityAt))
      return true
    })
  }

  static record_activity (player, activityAt) {
    return DataBase._connection((connection) => {
      const info = connection.prepare(
        'INSERT INTO social_presence(player_id, last_activity_at) ' +
        'SELECT lowID, ? FROM players WHERE lowID = ? AND token = ? ' +
        'ON CONFLICT(player_id) DO UPDATE SET last_activity_at = excluded.last_activity_at'
      ).run(Math.trunc(activityAt), Math.trunc(player.low_id), player.token)
      if (info.changes !== 1) {
        throw new Error('Conta não encontrada ao atualizar atividade')
      }
    })
  }

  static resetOnlineStatus () {
    DataBase._connection((connection) => {
      connection.exec('UPDATE players SET online = 0')
    })
  }

  static getLeaders (self) {
    return DataBase._connection((connection) => {
      return connection.prepare(
        'SELECT lowID, name, trophies, profileIcon, namecolor, clubID, playerExp ' +
        'FROM players ORDER BY trophies DESC, lowID ASC LIMIT 100'
      ).raw().all()
    })
  }

  static loadById (self, ID) {
    return DataBase._connection((connection) => {
      const row = DataBase._select_player(connection, 'lowID', ID)
      return row === null ? [] : [row]
    })
  }

  static loadMembersById (self, ID) {
    return DataBase._connection((connection) => {
      return DataBase._select_player(connection, 'lowID', ID)
    })
  }
}

DataBase.MAX_POWER_POINTS = 1410
DataBase.TROPHY_ROAD_COMPLETE = 95
DataBase.PLAYER_EXPERIENCE = 99999
DataBase.EXPERIENCE_MIGRATION_VERSION = 1
DataBase.POWER_LEVEL_WIRE_VERSION = 2

DataBase.PLAYER_COLUMNS = [
  'id',
  'token',
  'name',
  'leagueReward',
  'lowID',
  'tgid',
  'clubID',
  'clubRole',
  'playerExp',
  'soloWins',
  'duoWins',
  'TvsTWins',
  'gems',
  'gold',
  'tokensdoubler',
  'battleTokens',
  'tickets',
  'brawlerID',
  'skinID',
  'trophies',
  'highest_trophies',
  'profileIcon',
  'namecolor',
  'brawlBoxes',
  'bigBoxes',
  'starpower',
  'DoNotDistrub',
  'brawlersSkins',
  'brawlersTrophies',
  'brawlersTrophiesForRank',
  'brawlersUpgradePoints',
  'brawlerPowerLevel',
  'brawlerStarPower',
  'UnlockedBrawlers',
  'UnlockedSkins',
  'Friends',
  'online',
  'Notifications',
  'progression',
  'roomID'
]

DataBase.STATE_COLUMNS = [
  'brawlersSkins',
  'brawlersTrophies',
  'brawlersTrophiesForRank',
  'brawlersUpgradePoints',
  'brawlerPowerLevel',
  'brawlerStarPower',
  'UnlockedBrawlers',
  'UnlockedSkins',
  'Friends',
  'Notifications',
  'progression'
]

DataBase.PLAYER_STORAGE_COLUMNS = DataBase.PLAYER_COLUMNS.slice(0, 27).concat(['online', 'roomID'])
DataBase.RELATIONAL_SCHEMA_VERSION = 5

DataBase.PLAYER_TABLE_SCHEMA = `
        CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL DEFAULT 'Guest',
            leagueReward INTEGER NOT NULL DEFAULT 0,
            lowID INTEGER NOT NULL UNIQUE,
            tgid INTEGER NOT NULL DEFAULT 0,
            clubID INTEGER NOT NULL DEFAULT 0,
            clubRole INTEGER NOT NULL DEFAULT 0,
            playerExp INTEGER NOT NULL DEFAULT 99999,
            soloWins INTEGER NOT NULL DEFAULT 0,
            duoWins INTEGER NOT NULL DEFAULT 0,
            TvsTWins INTEGER NOT NULL DEFAULT 0,
            gems INTEGER NOT NULL DEFAULT 0,
            gold INTEGER NOT NULL DEFAULT 0,
            tokensdoubler INTEGER NOT NULL DEFAULT 0,
            battleTokens INTEGER NOT NULL DEFAULT 0,
            tickets INTEGER NOT NULL DEFAULT 0,
            brawlerID INTEGER NOT NULL DEFAULT 0,
            skinID INTEGER NOT NULL DEFAULT 0,
            trophies INTEGER NOT NULL DEFAULT 0,
            highest_trophies INTEGER NOT NULL DEFAULT 0,
            profileIcon INTEGER NOT NULL DEFAULT 0,
            namecolor INTEGER NOT NULL DEFAULT 0,
            brawlBoxes INTEGER NOT NULL DEFAULT 0,
            bigBoxes INTEGER NOT NULL DEFAULT 0,
            starpower INTEGER NOT NULL DEFAULT 0,
            DoNotDistrub INTEGER NOT NULL DEFAULT 0,
            online INTEGER NOT NULL DEFAULT 0,
            roomID INTEGER NOT NULL DEFAULT 0
        )
    `

DataBase.PLAYER_STATE_TABLE = `
        CREATE TABLE IF NOT EXISTS player_state_entries (
            player_id INTEGER NOT NULL,
            domain TEXT NOT NULL,
            path TEXT NOT NULL,
            parent_path TEXT,
            segment TEXT,
            position INTEGER NOT NULL DEFAULT 0,
            node_type TEXT NOT NULL,
            value_integer INTEGER,
            value_real REAL,
            value_text TEXT,
            PRIMARY KEY (player_id, domain, path),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        )
    `

DataBase.PLAYER_STATE_INDEX = `
        CREATE INDEX IF NOT EXISTS player_state_domain
            ON player_state_entries(player_id, domain)
    `

DataBase.PLAYER_STATE_SCHEMA = DataBase.PLAYER_STATE_TABLE + ';' + DataBase.PLAYER_STATE_INDEX
DataBase.PLAYER_SCHEMA = DataBase.PLAYER_TABLE_SCHEMA + ';' + DataBase.PLAYER_STATE_SCHEMA

DataBase.BATTLE_SCHEMA = `
        CREATE TABLE IF NOT EXISTS battle_reward_ledger (
            player_id INTEGER NOT NULL,
            battle_id TEXT NOT NULL,
            payload_hash TEXT NOT NULL DEFAULT '',
            game_mode INTEGER NOT NULL DEFAULT -1,
            rewards_json TEXT,
            is_current INTEGER NOT NULL DEFAULT 0,
            home_seen INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            completed_at INTEGER,
            PRIMARY KEY (player_id, battle_id),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE UNIQUE INDEX IF NOT EXISTS battle_reward_current
            ON battle_reward_ledger(player_id)
            WHERE is_current = 1;
        CREATE INDEX IF NOT EXISTS battle_reward_payload
            ON battle_reward_ledger(player_id, payload_hash);
        CREATE TABLE IF NOT EXISTS battle_result_outbox (
            player_id INTEGER NOT NULL,
            battle_id TEXT NOT NULL,
            result_json TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            PRIMARY KEY (player_id, battle_id),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
    `

DataBase.DAILY_REWARD_SCHEMA = `
        CREATE TABLE IF NOT EXISTS daily_token_limits (
            player_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            used INTEGER NOT NULL DEFAULT 0 CHECK (used BETWEEN 0 AND 700),
            updated_at INTEGER NOT NULL,
            PRIMARY KEY (player_id, day),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS battle_token_refill (
            player_id INTEGER PRIMARY KEY,
            next_refill_at INTEGER NOT NULL DEFAULT 0 CHECK (next_refill_at >= 0),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS daily_star_rewards (
            player_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            map_id INTEGER NOT NULL,
            amount INTEGER NOT NULL DEFAULT 1 CHECK (amount = 1),
            battle_id TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            PRIMARY KEY (player_id, day, map_id),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS daily_star_battle
            ON daily_star_rewards(player_id, battle_id);
    `

DataBase.CLUB_SCHEMA = `
        CREATE TABLE IF NOT EXISTS clubs (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            region TEXT NOT NULL DEFAULT 'RU',
            badge_id INTEGER NOT NULL DEFAULT 0,
            type INTEGER NOT NULL DEFAULT 1,
            required_trophies INTEGER NOT NULL DEFAULT 0,
            family_friendly INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS club_members (
            club_id INTEGER NOT NULL,
            player_id INTEGER NOT NULL,
            role INTEGER NOT NULL DEFAULT 1,
            joined_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (club_id, player_id),
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE,
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS club_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            event INTEGER NOT NULL,
            tick INTEGER NOT NULL DEFAULT 0,
            player_id INTEGER NOT NULL DEFAULT 0,
            player_name TEXT NOT NULL DEFAULT '',
            player_role INTEGER NOT NULL DEFAULT 0,
            message TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS club_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            sender_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS club_members_player
            ON club_members(player_id);
        CREATE INDEX IF NOT EXISTS club_messages_club
            ON club_messages(club_id, id);
        CREATE INDEX IF NOT EXISTS club_notifications_club
            ON club_notifications(club_id, id);
    `

DataBase.SOCIAL_SCHEMA = `
        CREATE TABLE IF NOT EXISTS social_presence (
            player_id INTEGER PRIMARY KEY,
            last_activity_at INTEGER NOT NULL,
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS friend_relations (
            owner_id INTEGER NOT NULL,
            friend_id INTEGER NOT NULL,
            state INTEGER NOT NULL,
            origin INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (owner_id, friend_id),
            FOREIGN KEY (owner_id) REFERENCES players(lowID) ON DELETE CASCADE,
            FOREIGN KEY (friend_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS friend_relations_friend
            ON friend_relations(friend_id, owner_id);
    `

DataBase.DATABASE_PATH = 'Database/players.sqlite'
DataBase.LEGACY_DATABASE_PATH = 'Database/players.db'
DataBase._initialized_paths = new Set()

DataBase.PLAYER_COLUMN_SET = new Set(DataBase.PLAYER_COLUMNS)
DataBase.STATE_COLUMN_SET = new Set(DataBase.STATE_COLUMNS)
DataBase.PLAYER_STORAGE_COLUMN_SET = new Set(DataBase.PLAYER_STORAGE_COLUMNS)

module.exports = DataBase
