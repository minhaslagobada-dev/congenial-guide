'use strict'
const net = require('net')
const fs = require('node:fs')
const path = require('node:path')

const { Crypto, CryptoError } = require('./Core/Crypto')
const Device = require('./Logic/Device')
const { Players } = require('./Logic/Player')
const packets = require('./Packets/LogicMessageFactory')
const LobbyInfoMessage = require('./Packets/Messages/Server/LobbyInfoMessage')
const Config = require('./Utils/Config')
const Helpers = require('./Utils/Helpers')
const { AsyncLock, AccountLocks } = require('./Utils/AsyncLock')
const { ValueError, ConnectionError } = require('./Utils/Errors')

const LOGGER = {
  warning: (...args) => console.warn(...args),
  exception: (...args) => console.error(...args)
}

function optionalRequire (path) {
  try {
    return require(path)
  } catch (error) {
    if (error && error.code === 'MODULE_NOT_FOUND' && String(error.message).includes(path)) {
      return null
    }
    throw error
  }
}

function socketErrorName (code) {
  switch (code) {
    case 'EPIPE': return 'BrokenPipeError'
    case 'ECONNRESET': return 'ConnectionResetError'
    case 'ECONNABORTED': return 'ConnectionAbortedError'
    case 'ETIMEDOUT': return 'timeout'
    default: return 'OSError'
  }
}

class SeasonTimer {
  constructor (delaySeconds, callback) {
    this.session_client = null
    this._delay = Math.max(0, delaySeconds) * 1000
    this._callback = callback
    this._handle = null
    this._cancelled = false
  }

  start () {
    this._handle = setTimeout(() => {
      if (!this._cancelled) this._callback()
    }, this._delay)
    if (this._handle.unref) this._handle.unref()
  }

  cancel () {
    this._cancelled = true
    if (this._handle) clearTimeout(this._handle)
  }
}

class Server {
  constructor (ip = null, port = null) {
    const settings = Config.GetValue()
    this.ip = ip !== null && ip !== undefined ? ip : (settings.ServerIP !== undefined ? settings.ServerIP : '0.0.0.0')
    this.port = port !== null && port !== undefined ? port : (settings.ServerPort !== undefined ? settings.ServerPort : 9339)
    this._ephemeralPort = port === 0
    this.max_packet_size = settings.MaxPacketSize !== undefined ? settings.MaxPacketSize : 1024 * 1024
    this.crypto_settings = settings.Crypto !== undefined ? settings.Crypto : { Enabled: true }
    this.clients_lock = new AsyncLock()
    this._account_locks = new AccountLocks()
    this.Clients = {
      ClientCounts: 0,
      Clients: {},
      RegistryLock: this.clients_lock,
      AccountLock: (lowId) => this.account_lock(lowId)
    }
    this._season_timers = {}
    this.running = false
    this.scid_client = null
    this.server = null
    this.battleTransport = null

    const PresenceService = optionalRequire('./Logic/PresenceService')
    if (PresenceService) PresenceService.bind_clients(this.Clients)
  }

  account_lock (lowId) {
    return this._account_locks.acquire(lowId)
  }

  start_scid () {
    const settings = Config.GetValue()
    const Runtime = optionalRequire('./SCIDClient/Runtime')
    if (!Runtime) return null
    const scidSettings = settings.SCID || {}
    const enabled = scidSettings.Enabled === undefined ? true : !!scidSettings.Enabled
    if (!enabled) {
      Runtime.set_service(null)
      return null
    }
    const Remote = optionalRequire('./SCIDClient/Remote')
    if (!Remote) return null
    if (this.scid_client === null) {
      this.scid_client = new Remote.RemoteSCIDClient(settings)
    }
    Runtime.set_service(this.scid_client)
    console.log('SCIDClient | Integração remota configurada')
    return null
  }

  stop_scid () {
    const Runtime = optionalRequire('./SCIDClient/Runtime')
    if (Runtime) Runtime.set_service(null)
    this.scid_client = null
  }

  async start () {
    const settings = Config.GetValue()

    new Crypto(this.crypto_settings)

    let ClubService = optionalRequire('./Logic/ClubService')
    if (ClubService && ClubService.ClubService) ClubService = ClubService.ClubService
    if (ClubService) {
      const migration = ClubService.migrate_legacy()
      if (migration && Object.values(migration).some((value) => !!value)) {
        console.log(`Server | Legacy club migration: ${JSON.stringify(migration)}`)
      }
    }

    let GameRoomService = optionalRequire('./Logic/GameRoomService')
    if (GameRoomService && GameRoomService.GameRoomService) GameRoomService = GameRoomService.GameRoomService
    if (GameRoomService) GameRoomService.init()

    this.running = true
    this.server = net.createServer((client) => this._on_connection(client))
    await new Promise((resolve, reject) => {
      this.server.once('error', reject)
      this.server.listen(this.port, this.ip, () => resolve())
    })
    this.port = this.server.address().port
    if (settings.Battle && settings.Battle.Enabled) {
      const { BattleTransport } = require('./Logic/Battle/Network/BattleTransport')
      const battleSettings = { ...settings.Battle }
      // Server(port=0) requests an isolated listener, including its UDP peer.
      if (this._ephemeralPort) battleSettings.Port = 0
      try {
        this.battleTransport = new BattleTransport(battleSettings)
        this.battleTransport.on('transportError', error => {
          LOGGER.warning(`Battle UDP | ${error.code || error.name}: ${error.message}`)
        })
        await this.battleTransport.start()
        const { BattleCoordinator } = require('./Logic/Battle/BattleCoordinator')
        const { NativeBattleBridge } = require('./Logic/Battle/NativeBattleBridge')
        const nativePython = path.join(__dirname, '.venv-native', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
        const nativeRuntime = this.nativeBattleRuntime = new NativeBattleBridge({
          python: process.env.PYTHON || (fs.existsSync(nativePython) ? nativePython : 'python3'),
          library: process.env.LIBG_V13 || path.join(__dirname, 'Native/V13/libg.so')
        })
        this.battleCoordinator = new BattleCoordinator(this.battleTransport, { ...battleSettings, NativeRuntime: nativeRuntime })
        this.battleCoordinator.on('battleError', error => LOGGER.warning(`Battle | ${error.message}`))
        console.log(`Battle UDP | Listening on ${battleSettings.BindIP}:${this.battleTransport.gateway.port}`)
      } catch (error) {
        this.running = false
        if (this.nativeBattleRuntime) this.nativeBattleRuntime.close()
        if (this.battleTransport) await this.battleTransport.close()
        this.server.close()
        throw error
      }
    }

    const version = `${settings.ClientMajor}.${settings.ClientMinor}.${settings.ClientBuild}`
    const cryptoEnabled = this.crypto_settings.Enabled === undefined ? true : !!this.crypto_settings.Enabled
    const transport = cryptoEnabled ? 'V13 crypto ATIVADA' : 'raw V13 transport'
    console.log(`Server | NostBrawl R120 V13 - client ${version}`)
    console.log(`Server | Listening on ${this.ip}:${this.port} (${transport})`)
    console.log(
      'Server | SQLite: ' +
      `${((settings.Database && settings.Database.Path) || 'Database/players.sqlite')}`
    )
    try {
      const { driverName } = require('./Database/SqliteDriver')
      console.log(`Server | SQLite driver: ${driverName()}`)
    } catch (error) {
      console.log(`Server | SQLite driver ERROR: ${error.message}`)
    }

    const Store = optionalRequire('./Store')
    const storeSettings = settings.Store || {}
    const storeEnabled = storeSettings.Enabled !== undefined
      ? !!storeSettings.Enabled
      : true
    if (Store && storeEnabled) {
      Store.start(this).catch((error) => {
        console.error('Server | Lakey Store falhou ao iniciar:', error && error.stack ? error.stack : error)
      })
    }
  }

  _on_connection (client) {
    if (!this.running) {
      client.destroy()
      return
    }
    client.setNoDelay(true)
    Helpers.PlayersCount += 1
    const address = [client.remoteAddress, client.remotePort]
    console.log(`Server | New connection from ${address[0]}:${address[1]}`)
    new ClientThread(client, address, this).start()
  }

  close () {
    this.running = false
    if (this.battleCoordinator) this.battleCoordinator.close()
    const battleClosed = this.battleTransport ? this.battleTransport.close() : Promise.resolve()
    if (this.server) {
      try {
        this.server.close()
      } catch (error) {
      }
    }
    return battleClosed
  }

  _cancel_season_timer (key, client = null) {
    const timer = this._season_timers[key]
    if (timer == null || (client != null && timer.session_client !== client)) {
      return
    }
    delete this._season_timers[key]
    timer.cancel()
  }

  _deliver_season_notification (player, client, key, notification) {
    try {
      const NotifAdd = optionalRequire('./Packets/Messages/Server/NotifAdd')
      if (!NotifAdd) return
      new NotifAdd(client, player, null, notification).send()
    } catch (error) {
      LOGGER.warning(`Season notification delivery failed for ${key}: ${error.message}`)
    }
  }

  schedule_season (player, client) {
    return this.account_lock((player.low_id ?? 0)).run(
      () => this._schedule_season_locked(player, client)
    )
  }

  _schedule_season_locked (player, client) {
    const SeasonService = optionalRequire('./Logic/SeasonService')
    if (!SeasonService) return null
    const key = String((player.low_id ?? 0))
    const current = this.Clients.Clients[key]
    if (!current || current.SocketInfo !== client) {
      return null
    }
    if (!SeasonService.is_persistent(player) || !(player.logged_in ?? false)) {
      this._cancel_season_timer(key, client)
      return null
    }
    const result = SeasonService.sync(player)
    const delay = Math.max(
      0.0,
      result.endsAt - Date.now() / 1000 - Server.SEASON_PUSH_LEAD
    )
    const timer = new SeasonTimer(
      delay,
      () => this._season_timer_fired(player, client, key, result.endsAt)
    )
    timer.session_client = client
    const rechecked = this.Clients.Clients[key]
    if (!rechecked || rechecked.SocketInfo !== client) {
      return null
    }
    this._cancel_season_timer(key)
    this._season_timers[key] = timer
    timer.start()
    if (result.reset && result.notification != null) {
      this._deliver_season_notification(
        player, client, key, result.notification
      )
    }
    return timer
  }

  _season_timer_fired (player, client, key, expectedEndsAt) {
    this.account_lock((player.low_id ?? 0)).run(
      () => this._season_timer_fired_locked(player, client, key, expectedEndsAt)
    ).catch((error) => {
      LOGGER.exception(`Season timer failed for account ${key}`, error && error.stack ? error.stack : error)
    })
  }

  _season_timer_fired_locked (player, client, key, expectedEndsAt) {
    const SeasonService = optionalRequire('./Logic/SeasonService')
    if (!SeasonService) return
    const current = this.Clients.Clients[key]
    if (!current || current.SocketInfo !== client) {
      return
    }
    if (!(player.logged_in ?? false)) {
      return
    }
    const progression = player.progression || {}
    const season = progression[SeasonService.STATE_KEY] || {}
    if (season.endsAt !== expectedEndsAt) {
      return
    }
    try {
      const result = SeasonService.end_now(
        player,
        { now: expectedEndsAt, expected_ends_at: expectedEndsAt }
      )
      if (result != null) {
        this._deliver_season_notification(
          player, client, key, result.notification
        )
      }
      this.schedule_season(player, client)
    } catch (error) {
      LOGGER.exception('Season timer failed for account', key, error && error.stack ? error.stack : error)
    }
  }

  register_client (player, client, address = null) {
    return this.account_lock((player.low_id ?? 0)).run(
      () => this._register_client_locked(player, client, address)
    )
  }

  _register_client_locked (player, client, address = null) {
    const key = String(player.low_id)
    const DataBase = require('./Database/DatabaseManager')
    const now = Math.floor(Date.now() / 1000)
    const online = Math.trunc((player.online ?? 1) || 0)
    if (!DataBase.update_presence(player, online, now)) {
      throw new ValueError('Conta não encontrada ao registrar presença')
    }
    player.last_activity_at = now
    this.Clients.Clients[String(player.low_id)] = {
      SocketInfo: client,
      Crypto: player.crypto,
      Lock: player.send_lock,
      Status: online,
      StatusSince: now,
      LastActivity: now,
      Player: player
    }
    this.Clients.ClientCounts = Object.keys(this.Clients.Clients).length
    player.ClientDict = this.Clients

    let ClubService = optionalRequire('./Logic/ClubService')
    if (ClubService && ClubService.ClubService) ClubService = ClubService.ClubService
    if (ClubService) ClubService.refresh_online_player(player, player.low_id)

    const GameSessions = optionalRequire('./SCIDClient/GameSessions')
    if (GameSessions) GameSessions.GAME_SESSIONS.register(player, client, address)

    this.schedule_season(player, client)

    const PresenceService = optionalRequire('./Logic/PresenceService')
    if (PresenceService) PresenceService.publish(player)

    console.log(
      `Server | Account ${player.low_id} logged in; players online: ` +
      `${this.Clients.ClientCounts}`
    )
  }

  unregister_client (player, client) {
    return this.account_lock((player.low_id ?? 0)).run(
      () => this._unregister_client_locked(player, client)
    )
  }

  _unregister_client_locked (player, client) {
    const key = String((player.low_id ?? 0))
    const current = this.Clients.Clients[key]
    if (current && current.SocketInfo === client) {
      delete this.Clients.Clients[key]
      this._cancel_season_timer(key, client)
    }
    this.Clients.ClientCounts = Object.keys(this.Clients.Clients).length

    const GameSessions = optionalRequire('./SCIDClient/GameSessions')
    if (GameSessions) GameSessions.GAME_SESSIONS.unregister(player, client)
  }
}

Server.Clients = { ClientCounts: 0, Clients: {} }
Server.SEASON_PUSH_LEAD = 0.5

class ClientThread {
  constructor (client, address, server) {
    this.client = client
    this.address = address
    this.server = server
    this.device = new Device(client)
    this.player = new Players(this.device)
    this.player.crypto = new Crypto(server.crypto_settings)
    this.player.ClientDict = server.Clients
    this.player.battleTransport = server.battleTransport || null
    this.player.battleCoordinator = server.battleCoordinator || null

    this._rx = Buffer.alloc(0)
    this._queue = Promise.resolve()
    this._finished = false
    this._socket_error = null
    this._trace = []
  }

  _record_trace (direction, packetId, payload) {
    const hex = Buffer.isBuffer(payload) ? payload.subarray(0, 48).toString('hex') : ''
    this._trace.push(`${direction}${packetId}:${hex}`)
    if (this._trace.length > 8) this._trace.shift()
  }

  start () {
    this.client.on('data', (chunk) => this._on_data(chunk))
    this.client.on('error', (error) => this._on_error(error))
    this.client.on('close', () => this._on_close())
  }

  _on_data (chunk) {
    if (this._finished) return
    this._rx = this._rx.length ? Buffer.concat([this._rx, chunk]) : chunk
    this._queue = this._queue.then(() => this._drain()).catch(() => {})
  }

  _on_error (error) {
    this._socket_error = error
    try {
      this.client.destroy()
    } catch (ignored) {
    }
  }

  _on_close () {
    const finalize = () => {
      if (this._finished) return
      let reason
      if (this._socket_error) {
        reason = `${socketErrorName(this._socket_error.code)}: ${this._socket_error.message}`
      } else if (this._rx.length > 0) {
        reason = 'ConnectionError: Connection closed in the middle of a packet'
      } else {
        reason = 'client EOF (the APK closed the socket)'
      }
      this._finish(reason)
    }
    this._queue = this._queue.then(finalize).catch(() => finalize())
  }

  async _drain () {
    while (!this._finished) {
      if (this._rx.length < 7) return

      const packetId = this._rx.readUInt16BE(0)
      const length = this._rx.readUIntBE(2, 3)

      if (length > this.server.max_packet_size) {
        const reason = `invalid packet length ${length} for ID ${packetId}`
        LOGGER.warning(`Closing ${this.address[0]}: packet ${packetId} has invalid length ${length}`)
        await this._finish(reason)
        return
      }

      if (this._rx.length < 7 + length) return

      const data = length
        ? Buffer.from(this._rx.buffer, this._rx.byteOffset + 7, length)
        : Buffer.alloc(0)
      this._rx = this._rx.subarray(7 + length)

      try {
        await this._step(packetId, data)
      } catch (error) {
        await this._fail_dispatch(error)
        return
      }
    }
  }

  async _step (packetId, data) {
    let decrypted
    try {
      decrypted = this.player.crypto.decrypt(packetId, data)
    } catch (error) {
      if (error instanceof CryptoError) {
        const reason = `crypto error on packet ${packetId}: ${error.message}`
        LOGGER.warning(`Cryptography error from ${this.address[0]} on packet ${packetId}: ${error.message}`)
        await this._finish(reason)
        return
      }
      throw error
    }

    if (this._finished) return

    if (this.player.logged_in ?? false) {
      const accountIds = this._dispatch_account_ids(packetId, decrypted)
      await this.server._account_locks.run(accountIds, async () => {
        if (this._finished) return
        const PresenceService = optionalRequire('./Logic/PresenceService')
        if (PresenceService && !PresenceService.record_activity(this.player, this.client)) {
          throw new ConnectionError('Sessão substituída')
        }
        if (packetId === 10101) {
          throw new ConnectionError('Login repetido na sessão autenticada')
        }
        this._record_trace('rx:', packetId, decrypted)
        await this._dispatch(packetId, decrypted)
      })
    } else {
      this._record_trace('rx:', packetId, decrypted)
      await this._dispatch(packetId, decrypted)
    }
  }

  async _fail_dispatch (error) {
    let reason
    if (
      error instanceof ConnectionError ||
      ['ConnectionAbortedError', 'ConnectionResetError', 'BrokenPipeError'].includes(error.name)
    ) {
      reason = `${error.name}: ${error.message}`
    } else if (error && error.code && String(error.code).startsWith('E')) {
      reason = `${socketErrorName(error.code)}: ${error.message}`
    } else if (error instanceof ValueError) {
      reason = `malformed packet: ${error.message}`
      LOGGER.warning(`Malformed packet from ${this.address[0]}: ${error.message}`)
    } else {
      reason = `server error: ${error.name}: ${error.message}`
      LOGGER.exception(`Unhandled client error from ${this.address[0]}`, error && error.stack ? error.stack : error)
    }
    await this._finish(reason)
  }

  async _finish (reason) {
    if (this._finished) return
    this._finished = true
    if (this.player.battleCoordinator) this.player.battleCoordinator.disconnect(this.player, this.client)
    if (this.player.battleTransport) this.player.battleTransport.release(this.player, this.client)

    const battle = this.player.battle_thread
    if (battle != null) {
      battle.started = 0
    }
    this.player.battle_thread = null
    this.player.battle_end = null
    this.player.battle_end_id = null

    await this.server.account_lock((this.player.low_id ?? 0)).run(async () => {
      if (this.player.logged_in ?? false) {
        try {
          this._release_game_room()
        } catch (error) {
          LOGGER.warning(`Could not update ${(this.player.low_id ?? 0)} in the active GameRoom`)
        }
        try {
          const PresenceService = optionalRequire('./Logic/PresenceService')
          if (
            PresenceService &&
            PresenceService.set_status(this.player, 0, this.client, true)
          ) {
            PresenceService.publish(this.player)
          }
        } catch (error) {
          LOGGER.warning(`Could not clear online state for ${this.player.low_id}`)
        }
        this.player.logged_in = false
      }

      await this.server.unregister_client(this.player, this.client)
    })

    try {
      this.client.destroy()
    } catch (ignored) {
    }
    Helpers.PlayersCount = Math.max(0, Helpers.PlayersCount - 1)
    console.log(`Server | ${this.address[0]} disconnected; reason: ${reason}`)
    if (this._trace.length) {
      console.log(`Server | ${this.address[0]} last packets: ${this._trace.join(' | ')}`)
    }
  }

  _release_game_room () {
    let GameRoomService = optionalRequire('./Logic/GameRoomService')
    if (GameRoomService && GameRoomService.GameRoomService) GameRoomService = GameRoomService.GameRoomService
    let GameRoomGateway = optionalRequire('./Logic/GameRoomGateway')
    if (GameRoomGateway && GameRoomGateway.GameRoomGateway) GameRoomGateway = GameRoomGateway.GameRoomGateway
    if (!GameRoomService || !GameRoomGateway) return null

    const outcome = GameRoomService.disconnect(this.player)
    if (outcome == null) {
      return null
    }
    const room = outcome.room
    if (room != null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, room)
    }
    for (const member of (outcome.disbanded || [])) {
      GameRoomGateway.send_left(
        this.player,
        Math.trunc(member.low_id),
        GameRoomService.DISBAND_REASON
      )
      const participant = member._player
      if (participant != null) {
        GameRoomService.sync_presence(participant, GameRoomService.HOME_PRESENCE)
      }
    }
    return outcome
  }

  async _finish_login (message) {
    const accountId = Math.trunc((this.player.low_id ?? 0) || 0)
    return this.server.account_lock(accountId).run(async () => {
      const DataBase = require('./Database/DatabaseManager')
      if (!DataBase.loadAccount(message) || this.player.low_id !== accountId) {
        return message._fail(9, 'Invalid account credentials.')
      }
      const success = await message._send_success(true)
      if (!success) {
        return false
      }
      const settings = Config.GetValue()
      if (settings.SendLobbyInfo ?? false) {
        new LobbyInfoMessage(this.client, this.player).send()
      }
      await this.server.register_client(this.player, this.client, this.address)
      const FriendListMessage = require('./Packets/Messages/Server/Friend/FriendListMessage')
      new FriendListMessage(this.client, this.player).send()
      const clubId = Math.trunc((this.player.club_low_id ?? 0) || 0)
      if (clubId) {
        const AllianceDataMessage = require('./Packets/Messages/Server/Alliance/Alliance_Data_Message')
        new AllianceDataMessage(this.client, this.player, 0, clubId).send()
      }
      const PresenceService = optionalRequire('./Logic/PresenceService')
      if (PresenceService) PresenceService.sync_view(this.player)
      message._resume_room()
      return true
    })
  }

  _dispatch_account_ids (packetId, data) {
    const ids = new Set([Math.trunc(this.player.low_id)])
    if (packetId === 14352) {
      const MessageClass = packets.get(packetId)
      if (MessageClass != null) {
        const message = new MessageClass(this.client, this.player, data)
        message.decode()
        if (message.target_high_id === 0 && message.target_id > 0) {
          ids.add(Math.trunc(message.target_id))
        }
      }
    }
    return [...ids].sort((a, b) => a - b)
  }

  async _dispatch (packetId, data) {
    const MessageClass = packets.get(packetId)
    if (MessageClass == null) {
      console.log(`Client | Unhandled packet ${packetId}; length: ${data.length}`)
      return
    }
    const message = new MessageClass(this.client, this.player, data)
    const settings = Config.GetValue()
    if (settings.ShowPacketsInLog ?? false) {
      console.log(
        `Client | ${message.constructor.name} received; ` +
        `ID: ${packetId}. Length: ${data.length}`
      )
    }
    if (packetId === 10101) {
      message.account_lock = (lowId) => this.server.account_lock(lowId)
      message.finish_login = (msg) => this._finish_login(msg)
    }
    message.decode()
    await message.process()
  }
}

module.exports = { Server, ClientThread }

if (require.main === module) {
  const server = new Server()
  let stopping = false
  const shutdown = () => {
    if (stopping) return
    stopping = true
    console.log('\nServer | Server stopped')
    server.running = false
    server.stop_scid()
    try {
      const DataBase = require('./Database/DatabaseManager')
      DataBase.resetOnlineStatus()
    } catch (error) {
      LOGGER.warning('Could not reset account online states during shutdown')
    }
    server.close()
    process.exit(0)
  }
  process.on('SIGINT', shutdown)
  server.start_scid()
  server.start().catch((error) => {
    LOGGER.exception('Server failed', error && error.stack ? error.stack : error)
    process.exit(1)
  })
}
