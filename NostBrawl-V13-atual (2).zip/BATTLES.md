> Estado da reconstrução nativa: [Native/V13/README.md](Native/V13/README.md). O motor descrito abaixo ainda usa regras aproximadas e não representa a implementação completa extraída da biblioteca v13.

# Batalhas online v13 — estado verificável

O projeto continua sendo o servidor Node anexado. O servidor Python NostBrawl é referência parcial; a biblioteca v13 define o protocolo. A v36 ajuda a localizar conceitos, mas seus IDs de comando, offsets e formatos não são aplicados diretamente à v13.

**A execução no APK ainda não foi confirmada. Não considerar esta versão uma entrega final de todas as mecânicas.** Os testes abaixo exercitam conexões reais de protocolo e a biblioteca ARM64; não executam a renderização do aplicativo.

## Entrada e sincronização

- 20559 inclui o LogicLong de oito bytes antes do nome de cada participante. Bots têm identificador de conta zero.
- O campo após a seed é a categoria de carregamento, não a variação do modo: categoria1 aloca seis vagas,3 aloca três,6 aloca dez. O mapa seleciona o modo independentemente. Enviar0 no Gem Grab alocava dez vagas no cliente.
- Fluxo inicial:20559 →24112 → visão24109 por TCP criptografado, sem esperar10177 ou o primeiro datagrama. O TCP também transporta visões maiores que o orçamento UDP, sem apagar entidades para caber num datagrama.
- UDP usa o cabeçalho opaco nativo de dez bytes e o caminho de chave vazia. O TCP mantém a criptografia original. Sessões são associadas a conta, conexão e IP.
- Entrada10555 tem contador,categoria,código,X,Y,alvo. Na categoria1, movimento é100, habilidades usam o ID da linha skills.csv, seleção do Super é107/108. Mira direta é relativa; arremessos e tipos específicos de carga usam coordenadas absolutas.
- Caixas, cofres e demais personagens estáticos usam o prefixo curto exigido por Speed0/AutoAttackDamage0. Indicadores de veneno, invisibilidade e posse de bola seguem as ramificações nativas.
- O mundo avança em passos de50ms; clientes não determinam posição final, dano ou resultado. Inputs são limitados, ordenados, confirmados e deduplicados.

## Fila e ciclo de vida

A fila pública conta15 segundos a partir do primeiro grupo. Uma formação completa pode começar antes. Ao vencer o prazo, as vagas restantes recebem bots do servidor. Grupos de amigos permanecem juntos. Cancelar ou desconectar remove o grupo; não se cria partida sem humano.

Salas privadas usam uma fila separada por sala:15 segundos e bots nas vagas livres, ou início imediato com formação completa. Mudança de mapa/composição, retirada de pronto e desconexão cancelam a espera. Partidas privadas não concedem progressão nem consomem fichas/dobradores.

Bots usam o mesmo combate e colisões que humanos e não criam sessões de rede. Saída do último humano, prazo de carregamento, erro de execução e desligamento liberam as partidas. Abortos com conexão viva devolvem os dados de casa. Resultado competitivo usa o ledger transacional existente; repetição do mesmo resultado não duplica recompensas. Um resultado enviado pelo cliente não substitui a batalha autoritativa.

O resultado autoritativo é gravado em uma caixa de saída SQLite antes de conceder recompensas/enviar o pacote. Após reinício, o login restaura e liquida o resultado pelo mesmo ledger, antes de enviar os dados de casa. Se a tela de resultado não foi confirmada com GoHome, Jogar reapresenta esse resultado antes de iniciar outra partida. Repetir14110 após envio não duplica a tela. Somente a confirmação da tela remove o registro durável. Esse fluxo tem teste com processo separado, falha de escrita e repetição de liquidação; a apresentação da recuperação no APK ainda precisa de validação.

## Combate, mapas e objetivos

- Dados dos55 grupos de mapas,60 localidades e22 heróis habilitados, preservando IDs originais.
- Colisões contínuas com paredes, limites, caixas e cofres; deslizamento, caminhos, destruição e recuperação da vegetação.
- Ataques principais e Supers: disparos múltiplos, rajadas, dispersão, voo direto/indireto, fusível desde o lançamento, voo constante, ricochete, encadeamento, veneno, cura, invocações, minas, bombas, invisibilidade, saltos e cargas.
- Correções específicas: a cura da Poco não causa dano inimigo; ondas sobrepostas não multiplicam cura/dano; a Piper não causa dano direto ao pousar; suas bombas explodem sem precisar de vítima próxima; o Darryl ricocheteia; projéteis terrestres não atingem quem está no ar.
- Recarga espera o cooldown. Regeneração dos heróis usa13% após três segundos sem dano/ataque. Modificadores Big Game vêm de globals.csv.
- Gem Grab: coleta, queda de gemas na morte, empate, troca de liderança e prazo de vitória. Bounty: pontuação das eliminações. Heist: cofres por equipe e porcentagens. Showdown solo/duplo: classificações, parceiro/respawn e veneno que fecha até o centro. Brawl Ball: posse, chute, gols, reposição, prorrogação e fim. Cooperativos: objetivos, ondas/chefe e condições finitas de vitória/derrota.

Esses comportamentos têm testes no motor. Isso não certifica fidelidade integral de física, animações, ondas e balanceamento ao servidor original.

## Testes reproduzíveis

```sh
npm ci
npm run test:battle
npm run test:battle:regression
```

Esses comandos criam cópia temporária com bancos novos e SCID/loja externos desabilitados. **Não executar diretamente os testes legados que apagam bancos no diretório de produção.**

A regressão cobre login, criptografia, economia, loja, equipes e retorno para casa. Integração online: seis clientes reais de protocolo; um humano mais cinco bots após15 segundos; UDP e somente TCP; comando nativo de movimento, snapshots, objetivo, resultado, recompensa e limpeza.

Validação ARM64 opcional:

```sh
python3 -m pip install -r scripts/native_v13/requirements.txt
LIBG_V13=/caminho/v13/libg.so PYTHON=python3 node scripts/test_native_v13.js
```

Casos:2360 estados de personagens;1112 projéteis/áreas/itens, verificando também destino/progresso/fusível; cabeçalhos de60 localidades;142 carregamentos e rejeição de três formatos inválidos;88 casos pelo leitor e consumidor de comandos;600 visões completas iniciais/em combate dos60 mapas. CSVs, alocação de entidades e callbacks gráficos são controlados no emulador; a leitura dos bits e os manipuladores indicados são código real da biblioteca.

## Rede e instalação

Manter o nome `config.json`. Na atualização, preservar o arquivo do proprietário e toda a pasta Database. O pacote para instalação nova fornece configuração genérica, sem as credenciais particulares ou contas do anexo.

`Battle.BindIP` é o endereço local. `Battle.AdvertiseHost` é um IPv4 numérico alcançável pelo celular; vazio usa o endereço local da conexão TCP. Em servidor atrás de NAT, configurar o IPv4 anunciado e encaminhar a porta UDP. `Battle.Port` não muda `ServerPort` TCP. SCID fica desabilitado na configuração genérica; somente habilitar com a configuração real do serviço.

## Pendências explícitas

1. Confirmar no APK que a entrada ultrapassa100%, renderiza personagens/mapa e aceita movimentação/ataques em dois aparelhos. Nenhum teste aqui substitui isso.
2. Poderes de estrela não estão aplicados ao combate. Não afirmar cobertura de todas as habilidades passivas.
3. Validar no cliente a fidelidade de todas as regras, trajetórias, temporizações, chefes e modos; parte das regras foi reconstruída de CSVs/referências e possui apenas validação do servidor.
4. Reconexão não retoma a entidade de uma partida em andamento; a saída é tratada como desconexão/eliminação.
5. Validar no APK o fluxo de reapresentação de resultado pendente após reinício. A persistência, recuperação, liquidação única e confirmação foram verificadas no servidor.
6. Capacidade de200 jogadores fica para etapa futura, conforme solicitado. Não foi revalidada nesta etapa.

## Fontes

Bibliotecas Yohohoyohohohoh:6265742ce2b43107717bc0249274e8f31ad9aa2f. Referência V36:3879ad6e7e6cf317f234a9c898959515d81f072a. Biblioteca v13 ARM64 SHA256:782ca3ed0a404cb1a28a9b65808c5ef5a40e57d5ada5ead54ae01540bbeb87db.

Funções v13 relevantes:20559.decode0x20fe1c; alocação de vagas0xda014; entrada de comando0x3f9fcc e consumidor0xcd610; mundo0x139398; projétil0x387814; UDPConnectionInfo.encode/decode0x4fb394/0x35880c. Scripts nativos estão em scripts/native_v13.
