'use strict'
const assert = require('node:assert/strict')
const { EventEmitter, once } = require('node:events')
const { NativeBattleBridge } = require('../Logic/Battle/NativeBattleBridge')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
class Transport extends EventEmitter {
  constructor () { super(); this.gateway = { port: 12345 }; this.attaches = 0; this.failAt = 0 }
  attach (player, client) {
    if (++this.attaches === this.failAt) throw new Error('Injected attachment failure')
    player.battleTransport = this
    const session = { player, client, header: Buffer.alloc(10), host: '127.0.0.1', input: new InputBuffer(), closed: false }
    player.udp_session = session; return session
  }
  release (player, client, reason) {
    const session = player.udp_session
    if (!session || session.closed || session.client !== client) return false
    session.closed = true; player.udp_session = null; this.emit('release', session, reason); return true
  }
  send () { return false }
}
async function main () {
  const runtime = new NativeBattleBridge(); const transport = new Transport()
  const coordinator = new BattleCoordinator(transport, { NativeRuntime: runtime })
  clearInterval(coordinator.timer)
  const errors = []; coordinator.on('battleError', error => errors.push(error))
  let now = 0; coordinator.matchmaker.now = () => now
  let identity = 40000; let lastId
  const originalCreate = runtime.create.bind(runtime)
  runtime.create = (...args) => { lastId = args[0]; return originalCreate(...args) }
  const member = () => ({ player: { low_id: ++identity, logged_in: true, name: 'Native lifecycle', brawler_id: 0, skin_id: 0, Brawler_level: {} },
    client: { destroyed: false, writes: [], write (bytes) { this.writes.push(bytes); return true } } })
  const map = coordinator.assets.named('locations', 'Gemgrab1').id
  try {
    const cancelled = member(); coordinator.enqueue([cancelled], map)
    transport.attach(cancelled.player, cancelled.client)
    transport.release(cancelled.player, cancelled.client, 'timeout')
    assert(coordinator.matchmaker.players.has(cancelled.player.low_id), 'A home UDP timeout cannot cancel matchmaking')
    assert(coordinator.cancel(cancelled.player, cancelled.client)); now = 15000; coordinator.step()
    assert.equal(coordinator.worlds.size, 0)
    const human = member(); coordinator.enqueue([human], map); now += 14999; coordinator.step()
    assert.equal(coordinator.worlds.size, 0); now++; coordinator.step()
    let world = coordinator.accounts.get(human.player.low_id)
    assert(world && world.nativeActive); assert.equal(world.players.filter(player => player.bot).length, 5)
    transport.emit('input', human.player.udp_session); coordinator.step()
    assert.equal(world.phase, 'running')
    coordinator.disconnect(human.player, human.client)
    assert.equal(world.nativeActive, false); assert.equal(coordinator.accounts.size, 0)
    const party = [member(), member()]
    coordinator.enqueue(party, map); now += 15000
    transport.failAt = transport.attaches + 2; coordinator.step()
    assert.equal(coordinator.worlds.size, 0); assert.equal(coordinator.accounts.size, 0)
    assert(party.every(entry => !entry.player.udp_session))
    assert.throws(() => runtime.frame(lastId), /Unknown native match/)
    coordinator.step(); world = coordinator.accounts.get(party[0].player.low_id)
    assert(world, 'Preparation failure must leave tickets available for retry')
    for (const entry of party) transport.emit('input', entry.player.udp_session)
    coordinator.step(); coordinator.disconnect(party[0].player, party[0].client)
    assert.equal(world.phase, 'running'); assert.equal(coordinator.worlds.size, 1)
    coordinator.disconnect(party[1].player, party[1].client)
    assert.equal(coordinator.worlds.size, 0)
    const active = member(); coordinator.enqueue([active], map); now += 15000; coordinator.step()
    const queued = member(); coordinator.enqueue([queued], map)
    const failed = once(runtime, 'engineFailure')
    await runtime.worker.terminate(); await failed
    assert.equal(coordinator.worlds.size, 0); assert.equal(coordinator.accounts.size, 0)
    assert.equal(coordinator.matchmaker.players.size, 0)
    assert.equal(coordinator.engineFailed, true)
    assert.equal(active.player.udp_session, null)
    assert.throws(() => coordinator.enqueue([member()], map), /Motor nativo indisponível/)
    assert.equal(errors.length, 2, errors.map(error => error.stack).join('\n'))
    console.log('Native coordinator: queue cancellation, exact 15s deadline, native bot fill, loading, disconnects, failed-attachment rollback/retry, engine-failure cleanup and queue release')
  } finally { coordinator.close() }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
