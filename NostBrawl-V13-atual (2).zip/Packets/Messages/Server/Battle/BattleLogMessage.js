'use strict'
const Writer = require('../../../../Utils/Writer')
const Config = require('../../../../Utils/Config')

class BattleLogMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 23458
    this.player = player
  }

  encode () {
    this.writeBoolean(true)

    this.writeVint(0)

    this.writeVint(0)
    this.writeVint(0)
    this.writeVint(1)
    this.writeVint(6)
    this.writeVint(120)
    this.writeUInt8(0)
    this.writeScId(15, 95)
    this.writeVint(2)
    this.writeVint(0)

    this.writeInt(0)
    this.writeInt(0)

    this.writeVint(1)
    this.writeUInt8(1)

    this.writeVint(0)

    this.writeVint(0)
    this.writeUInt8(0)
    this.writeVint(0)
    this.writeUInt8(0)
    this.writeVint(0)

    if (Config.GetValue().ShowPacketsInLog) {
      console.log('[INFO] Message BattleLogMessage has been sent.')
    }
  }
}

module.exports = BattleLogMessage
