'use strict'

const fs = require('fs')

const DataBase = require('../../../../Database/DatabaseManager')
const NotificationFactory = require('../../../../Logic/NotificationFactory')
const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const LoginFailedMessage = require('../../Server/Login/LoginFailedMessage')
const LoginOkMessage = require('../../Server/Login/LoginOkMessage')
const { SCIDGame } = require('../../../../SCIDClient/Game')
const { MAX_COMPRESSED_SIZE, decode_compressed_string } = require('../../../../SCIDClient/Protocol')
const { SCIDError } = require('../../../../SCIDClient/Models')
const Config = require('../../../../Utils/Config')
const Helpers = require('../../../../Utils/Helpers')
const { BSMessageReader } = require('../../../../Utils/Reader')

const LOGGER = {
  info: (...args) => console.log(...args),
  warning: (...args) => console.warn(...args),
  exception: (...args) => console.error(...args)
}

class LoginMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.initial_bytes = initialBytes
    this.player = player
    this.client = client
    this.scid_token = null
    this.scid_account = null
    this.scid_error = false
    this.banned = { banned_low_id: [] }
  }

  decode () {
    this.enable_native_v13()
    this.player.high_id = this.read_int()
    this.player.low_id = this.read_int()
    this.player.token = this.read_string()

    this.major = this.read_int()
    this.minor = this.read_int()
    this.build = this.read_int()
    this.fingerprint_sha = this.read_string()

    this.read_string()
    this.player.device.OpenUDID = this.read_string()
    this.player.device.AndroidID = this.read_string()
    this.player.device.OSVersion = this.read_string()
    try {
      this._decode_optional_fields()
    } catch (error) {
      if (error instanceof Error) {
        this.scid_error = true
      } else {
        throw error
      }
    }

    try {
      this.banned = JSON.parse(fs.readFileSync('JSON/banned.json', 'utf-8'))
    } catch (error) {
      LOGGER.warning('Could not read JSON/banned.json; assuming no bans')
    }
  }

  _at_end () {
    return this.tell() >= this.initial_bytes.length
  }

  _decode_optional_fields () {
    if (this._at_end()) return
    this.readScId()
    this.read_string()
    if (this._at_end()) return
    this.read_string()
    if (this._at_end()) return
    this.read_string()
    if (this._at_end()) return
    this.read_boolean()
    if (this._at_end()) return
    this.read_string()
    this.read_string()
    if (this._at_end()) return
    this.read_string()
    if (this._at_end()) return
    this.read_boolean()
    this.read_string()
    if (this._at_end()) return
    this.read_int()
    if (this._at_end()) return
    this.read_Vint()
    this.read_string()
    this.read_string()
    if (this._at_end()) return
    this.read_string()
    if (this._at_end()) return
    this.read_string()
    this.read_string()
    this.read_Vint()
    if (this._at_end()) return
    this.read_string()
    this.read_string()
    this.read_string()
    if (this._at_end()) return

    const envelopeOffset = this.tell()
    const envelopeSize = this.read_int()
    if (envelopeSize === 0xFFFFFFFF) {
      if (!this._at_end()) {
        throw new Error('Dados residuais após o campo SCID nulo')
      }
      return
    }
    if (envelopeSize < 4 || envelopeSize > MAX_COMPRESSED_SIZE) {
      throw new Error('Campo SCID inválido')
    }
    this._read_exact(envelopeSize)
    const [token, end] = decode_compressed_string(this.initial_bytes, envelopeOffset)
    if (end !== this.initial_bytes.length) {
      throw new Error('Dados residuais após o token SCID')
    }
    this.scid_token = token
  }

  _fail (errorCode, message = '') {
    const helloVersion = [
      this.player.client_major !== undefined ? this.player.client_major : null,
      this.player.client_minor !== undefined ? this.player.client_minor : null,
      this.player.client_build !== undefined ? this.player.client_build : null
    ]
    LOGGER.warning(
      `Login rejected: code=${errorCode} version=${this.major}.${this.minor}.${this.build} ` +
      `hello=${helloVersion} maintenance=${this.player.maintenance} ` +
      `patch=${this.player.patch} ` +
      `fingerprint_match=${this.fingerprint_sha === this.player.patch_sha} ` +
      `received_sha=${this.fingerprint_sha} expected_sha=${this.player.patch_sha}`
    )
    this.player.err_code = errorCode
    this.player.logged_in = false
    new LoginFailedMessage(this.client, this.player, message).send()
    return false
  }

  async _send_success (deferRegistration = false) {
    LOGGER.info(
      `Login accepted: version=${this.major}.${this.minor}.${this.build} ` +
      `hello=${[
        this.player.client_major !== undefined ? this.player.client_major : null,
        this.player.client_minor !== undefined ? this.player.client_minor : null,
        this.player.client_build !== undefined ? this.player.client_build : null
      ]} maintenance=${this.player.maintenance} patch=${this.player.patch} ` +
      `fingerprint_match=${this.fingerprint_sha === this.player.patch_sha}`
    )
    try {
      NotificationFactory.ensure_star_shelly(this.player)
      if (NotificationFactory.has_scid_connection(this.player)) {
        NotificationFactory.ensure_wizard_barley(this.player)
      }
    } catch (error) {
      LOGGER.exception('Could not create the login skin notifications', error)
    }
    this.player.online = 2
    if (!deferRegistration) {
      DataBase.replaceValue(this, 'online', 2)
    }
    new LoginOkMessage(this.client, this.player).send()
    require('../../../../Logic/Battle/ResultOutbox').ResultOutbox.restore(this.player)
    new OwnHomeDataMessage(this.client, this.player).send()
    const clubLowId = this.player.club_low_id || 0
    if (clubLowId) {
      const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
      const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
      new MyAllianceMessage(this.client, this.player, clubLowId).send()
      new AllianceStreamMessage(this.client, this.player, clubLowId, 0).send()
    }
    if (Math.trunc(this.player.do_not_distrub || 0) === 1) {
      const SetInvitesBlockedOkMessage = require('../../Server/Gameroom/SetInvitesBlockedOkMessage')
      new SetInvitesBlockedOkMessage(this.client, this.player).send()
    }
    if (!deferRegistration) {
      this._resume_room()
    }
    this.player.logged_in = true
    return true
  }

  _resume_room () {
    let GameRoomServiceModule
    try {
      GameRoomServiceModule = require('../../../../Logic/GameRoomService')
    } catch (error) {
      if (error && error.code === 'MODULE_NOT_FOUND') {
        return
      }
      throw error
    }
    const GameRoomService = GameRoomServiceModule.GameRoomService || GameRoomServiceModule
    const GameRoomGateway = require('../../../../Logic/GameRoomGateway').GameRoomGateway
    GameRoomService.clear_offline_invites(this.player)
    if (Math.trunc(this.player.room_id || 0) > 0) {
      const room = GameRoomService.resume(this.player)
      if (room !== null && room !== undefined) {
        GameRoomGateway.broadcast_data(this.player, room, this.client)
      }
    }
  }

  async process () {
    const settings = Config.GetValue()

    if (this.major !== settings.ClientMajor) {
      return this._fail(
        8,
        'Your client is outdated. This server requires Brawl Stars ' +
        `${settings.ClientMajor}.${settings.ClientMinor}.${settings.ClientBuild}.`
      )
    }

    if (this.banned.banned_low_id !== undefined && this.banned.banned_low_id.includes(this.player.low_id)) {
      return this._fail(11, 'This account is banned from the server.')
    }

    if (this.player.maintenance) {
      return this._fail(10)
    }

    if (this.player.patch && this.fingerprint_sha !== this.player.patch_sha) {
      return this._fail(7)
    }

    if (this.scid_error) {
      return this._fail(9, 'Invalid Supercell ID credentials.')
    }

    let requestedLowId = this.player.low_id
    try {
      requestedLowId = SCIDGame.before_account_load(this, requestedLowId)
      if (this.banned.banned_low_id !== undefined && this.banned.banned_low_id.includes(this.player.low_id)) {
        return this._fail(11, 'This account is banned from the server.')
      }
      const newAccount = requestedLowId === 0
      if (!newAccount && this.player.high_id !== 0) {
        return this._fail(9, 'Invalid account credentials.')
      }
      if (newAccount) {
        this.player.low_id = Helpers.randomID(this)
        this.player.high_id = 0
        this.player.token = Helpers.randomStringDigits(this)
      } else if (!this.player.token) {
        return this._fail(9, 'Invalid account credentials.')
      }

      const runLocked = async () => {
        try {
          if (newAccount) {
            DataBase.createAccount(this)
          } else {
            const found = DataBase.loadAccount(this)
            if (found === false || this.player.low_id !== requestedLowId) {
              return this._fail(9, 'Invalid account credentials.')
            }
          }
          SCIDGame.after_account_load(this)
        } catch (error) {
          if (error instanceof SCIDError) {
            LOGGER.warning(`SCID login rejected: ${error.code}`)
            return this._fail(9, 'Invalid Supercell ID credentials.')
          }
          LOGGER.exception('Database failure while processing login', error)
          return this._fail(9, 'Could not access the account database.')
        }

        const finishLogin = this.finish_login !== undefined ? this.finish_login : null
        if (finishLogin !== null) {
          return finishLogin(this)
        }
        return this._send_success()
      }

      const accountLock = this.account_lock !== undefined ? this.account_lock : null
      if (accountLock) {
        return accountLock(this.player.low_id).run(runLocked)
      }
      return await runLocked()
    } catch (error) {
      if (error instanceof SCIDError) {
        LOGGER.warning(`SCID login rejected: ${error.code}`)
        return this._fail(9, 'Invalid Supercell ID credentials.')
      }
      LOGGER.exception('Database failure while preparing login', error)
      return this._fail(9, 'Could not access the account database.')
    }
  }
}

module.exports = LoginMessage
