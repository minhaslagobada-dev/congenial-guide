'use strict'

const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class GoHomeFromOfflinePractiseMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.unknown = this.read_boolean()
    this.ensure_end()
  }

  process () {
    require('../../../../Logic/Battle/ResultOutbox').ResultOutbox.acknowledge(this.player)
    if (this.player.battleCoordinator) this.player.battleCoordinator.disconnect(this.player, this.client)
    if (this.player.battleTransport) this.player.battleTransport.release(this.player, this.client, 'home')
    const { BattleInstanceService } = require('../../../../Logic/BattleInstances')
    const battle = this.player.battle_thread !== undefined ? this.player.battle_thread : null
    if (battle !== null) {
      battle.started = 0
      this.player.battle_thread = null
    }
    BattleInstanceService.mark_home(this.player)
    new OwnHomeDataMessage(this.client, this.player).send()
    return null
  }
}

module.exports = GoHomeFromOfflinePractiseMessage
