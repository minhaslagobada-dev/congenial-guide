'use strict'
const DataBase = require('../../../../Database/DatabaseManager')
const Skins = require('../../../../Files/CsvLogic/Skins')
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

function deepCopy (value) {
  if (value === null || value === undefined) return value
  return JSON.parse(JSON.stringify(value))
}

class TeamChangeMemberSettingsMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.brawler_reference = [0, -1]
    this.skin_reference = [0, -1]
    this.unknown = 0
  }

  decode () {
    this.unknown = this.read_Vint()
    this.skin_reference = this.readScId()
    this.ensure_end()
  }

  process () {
    const [, skinId] = this.skin_reference
    const brawlerId = Skins.getBrawler(skinId)
    this.brawler_reference = [16, Math.trunc(brawlerId)]
    this.player.brawler_id = Math.trunc(brawlerId)
    this.player.skin_id = Math.trunc(skinId)
    let selected = deepCopy(this.player.brawlers_skins)
    if (typeof selected !== 'object' || selected === null) {
      selected = {}
    }
    selected[String(this.player.brawler_id)] = this.player.skin_id
    this.player.brawlers_skins = selected
    DataBase.replaceValue(this, 'skinID', this.player.skin_id)
    DataBase.replaceValue(this, 'brawlerID', this.player.brawler_id)
    DataBase.replaceValue(this, 'brawlersSkins', selected)
    const room = GameRoomService.set_member_settings(
      this.player, this.player.brawler_id, this.player.skin_id
    )
    if (room !== null) {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
    }
    return room
  }
}

module.exports = TeamChangeMemberSettingsMessage
