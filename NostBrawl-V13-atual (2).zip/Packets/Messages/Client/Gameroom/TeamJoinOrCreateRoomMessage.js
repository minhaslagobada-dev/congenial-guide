'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamCode = require('../../../../Logic/TeamCode')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamJoinOrCreateRoomMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.code = ''
  }

  decode () {
    this.code = this.read_string()
    this.ensure_end()
  }

  process () {
    let highId, roomId
    try {
      ;[highId, roomId] = TeamCode.to_id(this.code)
    } catch (error) {
      return null
    }
    if (highId !== 0) {
      return null
    }
    let room
    let previous = null
    let departed = false
    if (roomId === 0) {
      ;[room, previous, departed] = GameRoomService.create_transition(
        this.player, 0, -64, 0, false
      )
    } else {
      try {
        ;[room, previous, departed] = GameRoomService.request_join_transition(
          this.player, roomId
        )
      } catch (error) {
        if (error instanceof GameRoomFullError) {
          new TeamErrorMessage(this.client, this.player, 2).send()
          return null
        }
        throw error
      }
    }
    if (room === null) {
      return null
    }
    if (departed) {
      GameRoomGateway.send_left(
        this.player, this.player.low_id, 0, this.client
      )
    }
    if (previous !== null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, previous)
    }
    GameRoomGateway.broadcast_data_and_stream(
      this.player, room, this.client
    )
    GameRoomService.sync_presence(this.player, GameRoomService.TEAM_PRESENCE)
    return room
  }
}

module.exports = TeamJoinOrCreateRoomMessage
