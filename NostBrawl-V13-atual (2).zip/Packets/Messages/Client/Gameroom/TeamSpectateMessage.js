'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamSpectateMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.map_slot = 0
    this.room_id = 0
    this.requested_map = 0
  }

  decode () {
    this.map_slot = this.read_Vint()
    this.room_id = this.read_Vint()
    this.requested_map = this.read_Vint()
    this.ensure_end()
  }

  process () {
    let room = null
    let previous = null
    let departed = false
    const seen = new Set()
    for (const roomId of [this.room_id, this.requested_map, this.map_slot]) {
      if (seen.has(roomId)) continue
      seen.add(roomId)
      if (roomId <= 0) continue
      try {
        ;[room, previous, departed] = GameRoomService.request_join_transition(
          this.player, roomId
        )
      } catch (error) {
        if (error instanceof GameRoomFullError) {
          new TeamErrorMessage(this.client, this.player, 2).send()
          return null
        }
        throw error
      }
      if (room !== null) break
    }
    if (room === null) return null
    if (departed) {
      GameRoomGateway.send_left(
        this.player, this.player.low_id, 0, this.client
      )
    }
    if (previous !== null) {
      GameRoomGateway.broadcast_data_and_stream(this.player, previous)
    }
    GameRoomGateway.broadcast_data_and_stream(
      this.player, room, this.client
    )
    return room
  }
}

module.exports = TeamSpectateMessage
