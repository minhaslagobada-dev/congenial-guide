'use strict'
const { BattleInstanceService } = require('../../../../Logic/BattleInstances')
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const MatchMakingCancelledMessage = require('../../Server/Battle/MatchMakingCancelledMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class OnPlay extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this._payload_length = initialBytes.length
    this.initialBytes = initialBytes
    this.v17_layout = false
    this.mapSlot = 0
    this.map_id = 0
    this.roomType = 0
    this.CardID = 0
    this.MapIndex = 0
  }

  decode () {
    if (this.player.battleCoordinator) {
      const { Reader } = require('../../../../Logic/Battle/Network/V13BattleCodec')
      const reader = new Reader(this.initialBytes)
      const dataClass = reader.vint()
      this.selectedBrawler = dataClass ? reader.vint() : null
      if (dataClass && dataClass !== 16) throw new (require('../../../../Utils/Errors').ValueError)('Referência de brawler inválida')
      this.unknown = reader.vint(); this.mapSlot = reader.vint()
      this.unknown2 = reader.vint(); this.unknown3 = reader.vint(); reader.end()
      return
    }
    this.mapSlot = this.read_Vint()
    this.CardID = this.read_Vint()
    this.map_id = this.CardID
    this.roomType = this.read_Vint()
    this.v17_layout = this.tell() >= this._payload_length
    if (!this.v17_layout) {
      this.MapIndex = this.read_Vint()
    } else {
      this.MapIndex = this.roomType
    }
  }

  process () {
    if (this.player.battleCoordinator) {
      const { EventRotation } = require('../../../../Logic/EventRotation')
      const event = EventRotation.resolve_slot(this.player, this.mapSlot)
      if (this.selectedBrawler !== null && this.selectedBrawler !== undefined && this.selectedBrawler !== this.player.brawler_id) {
        throw new (require('../../../../Utils/Errors').ValueError)('Seleção de brawler divergente')
      }
      return this.player.battleCoordinator.enqueue([{ player: this.player, client: this.client }], event.map_id)
    }
    BattleInstanceService.begin(this.player)
    if (this.v17_layout) {
      const room = GameRoomService.create(
        this.player, this.mapSlot, this.map_id, this.roomType
      )
      GameRoomGateway.deliver_data(this.client, this.player, room)
      new MatchMakingCancelledMessage(this.client, this.player).send()
      return room
    }
    this.player.map_id = 15
    this.player.mmplayers = 1
    new MatchMakingCancelledMessage(this.client, this.player).send()
    return null
  }
}

module.exports = OnPlay
