# nodebrawl-core
The world's first open source Brawl Stars private server core written on JavaScript. <br>
*[Now uses <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Classes">Classes</a> instead of <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions">Functions!</a>]*

* [Русский язык](/README-ru.md)
* Try [nightly](https://github.com/tailsjs/nodebrawl-core/tree/nightly) version of core!

## Requirements
* [NodeJS](https://nodejs.org/)
* Python 3.10 ou posterior, com suporte a `venv` (motor ARM64 original via Unicorn)

## Setting up
1. Download/clone a repository
2. Type in console `npm install`
3. `npm run setup:native`
4. `npm start`

Mantenha `config.json` e os bancos atuais ao atualizar. O motor usa `Native/V13/libg.so`, extraída do APK fornecido. `PYTHON` e `LIBG_V13` permitem indicar caminhos alternativos. Em hospedagem com NAT/container, configure `Battle.AdvertiseHost` com o IPv4 alcançável pelos clientes e encaminhe a porta de batalha tanto em TCP como em UDP.

Os detalhes de implementação, testes e limites de validação estão em [Native/V13/README.md](Native/V13/README.md).

* Use o cliente v13 correspondente à biblioteca incluída, com o redirecionamento de rede do seu servidor.

## Why game isn't loading?
Esta versão executa as batalhas pela biblioteca ARM64 original. Os testes de protocolo e motor não substituem a verificação visual no APK. Consulte o console de TCP/UDP e a documentação do motor para diagnosticar carregamento.

![screen](/Screens/console.png)

## Forks:
 * [nodebrawl-core-http](https://github.com/TailedTeam/nodebrawl-core-http)

## Telegram bot — propriedade única do token (409 Conflict)

O Telegram permite **um único consumidor de getUpdates por token** (ou um webhook).
Se outro processo já estiver em polling com o mesmo token, as chamadas falham com
`409 Conflict`.

Regras implementadas em `Store/TelegramBot.js`:

- **`Store.BotPolling`** no `config.json`: `"auto"` (padrão), `true` ou `false`.
  Em `auto` + `Mode: "agent"`, este processo **não** faz polling — o site externo
  (kg-bsz02) é o dono do bot. Em `Mode: "embedded"`, faz polling normalmente.
- Ao assumir o token: `deleteWebhook` (derruba webhook residual que roubaria os
  updates) + `getMe` com log da identidade (`@bot`, pid).
- 409: disputa a cada 30s por até 6 vezes (~3 min). Persistindo, o bot **cede o
  token e encerra neste processo**, com instrução no log. Nunca fica em loop
  infinito silencioso.
- `stop()` aborta o long-poll em voo (término imediato em SIGINT/SIGTERM).
- Token inválido/revogado (401/404): encerra sem retentar.

### Se o conflito vier de OUTRA hospedagem

1. Descubra quem mais usa o token: procure nos seus hosts por processos com o
   mesmo `BotToken` (`grep -r "BotToken" config.json`, `ps aux | grep -E "node|python"`).
2. Se achar: deixe **apenas um** processo com polling ligado; nos outros,
   `"BotPolling": false` (Node) / `"BotPolling": false` (site Python).
3. Se **não** achar (token vazou ou esquecido em algum lugar): no @BotFather,
   `/revoke` → token novo. Atualize o `config.json` **somente do dono** do bot.
   O /revoke derruba instantaneamente qualquer poller estranho.
4. Webhook: este servidor já chama `deleteWebhook` ao iniciar. Para conferir:
   `https://api.telegram.org/bot<TOKEN>/getWebhookInfo` deve mostrar `"url": ""`.

Testes: `npm test` inclui `scripts/smoke_bot.js` (17 cenários com um Telegram
falso local: claim ordenado, 409 limitado, stop abortando long-poll, token fatal,
propriedade por modo, recovery de erro transitório e comandos preservados).
