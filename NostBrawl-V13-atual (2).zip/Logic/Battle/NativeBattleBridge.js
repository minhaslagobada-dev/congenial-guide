'use strict'
const { EventEmitter } = require('node:events')
const { Worker } = require('node:worker_threads')
const path = require('node:path')
const { decodeInput } = require('./Network/V13BattleCodec')

// Keep the coordinator's atomic matchmaking/tick API while the worker thread
// handles child-process IO. The original native frame runs on the Python side.
class NativeBattleBridge extends EventEmitter {
  constructor (options = {}) {
    super(); this.closed = false; this.timeout = options.timeout || 5000
    this.control = new SharedArrayBuffer(8); this.buffer = new SharedArrayBuffer(2097152)
    this.signal = new Int32Array(this.control)
    this.worker = new Worker(path.join(__dirname, 'NativeBattleThread.js'), { workerData: { options, control: this.control, buffer: this.buffer } })
    this.worker.on('error', error => this.fail(error))
    this.worker.on('message', message => { if (message.engineFailure) this.fail(new Error(message.engineFailure)) })
    this.worker.on('exit', code => { if (!this.closed) this.fail(new Error(`Native bridge exited (${code})`)) })
    try { this.read(35000) } catch (error) { this.closed = true; this.worker.terminate(); throw error }
  }
  read (timeout) {
    if (Atomics.wait(this.signal, 0, 0, timeout) === 'timed-out') {
      this.fail(new Error('Native bridge timed out')); throw new Error('Native bridge timed out')
    }
    const state = Atomics.load(this.signal, 0); const length = Atomics.load(this.signal, 1)
    if (length <= 0 || length > this.buffer.byteLength) throw new Error('Invalid native bridge response size')
    const message = JSON.parse(Buffer.from(new Uint8Array(this.buffer, 0, length)).toString())
    if (state !== 1 || message.error) {
      const error = new Error(message.error || 'Native bridge failed')
      if (message.fatal) this.fail(error)
      throw error
    }
    return message.result
  }
  request (command, fields = {}) {
    if (this.closed) throw new Error('Native engine closed')
    Atomics.store(this.signal, 0, 0); Atomics.store(this.signal, 1, 0)
    this.worker.postMessage({ command, fields, control: this.control, buffer: this.buffer })
    return this.read(this.timeout)
  }
  create (matchId, location, seed, players) { return this.request('create', { matchId, location, seed, players }) }
  frame (matchId) { return this.request('frame', { matchId }) }
  input (matchId, playerIndex, bytes) {
    decodeInput(bytes)
    return this.request('input', { matchId, playerIndex, hex: bytes.toString('hex') })
  }
  destroy (matchId) { return this.request('destroy', { matchId }) }
  fail (error) {
    if (this.closed) return
    this.closed = true; this.worker.terminate(); this.emit('engineFailure', error)
  }
  close () {
    if (this.closed) return
    try { this.request('shutdown') } finally { this.closed = true; this.worker.terminate() }
  }
}
module.exports = { NativeBattleBridge }
