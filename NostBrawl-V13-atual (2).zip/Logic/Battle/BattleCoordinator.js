'use strict'
const crypto = require('node:crypto')
const { EventEmitter } = require('node:events')
const { battleAssets } = require('./World/BattleAssets')
const { Matchmaker } = require('./Matchmaker')
const { BattleWorld } = require('./Game/BattleWorld')
const { visionPayload } = require('./Game/V13WorldCodec')
const { BattleInstanceService } = require('../BattleInstances')
const UDPInfo = require('../../Packets/Messages/Server/Battle/UDPConnectionInfo')
const Vision = require('../../Packets/Messages/Server/Battle/AuthoritativeVisionUpdateMessage')
const StartLoading = require('../../Packets/Messages/Server/Battle/StartLoadingMessage')
const Status = require('../../Packets/Messages/Server/Battle/MatchMakingStatusMessage')
const Cancelled = require('../../Packets/Messages/Server/Battle/MatchMakingCancelledMessage')
const { ValueError } = require('../../Utils/Errors')

class BattleCoordinator extends EventEmitter {
  constructor (transport, settings = {}) {
    super(); this.transport = transport; this.assets = battleAssets()
    this.nativeRuntime = settings.NativeRuntime || null
    this.maxPlayers = settings.MaxPlayers || 200
    this.matchmaker = new Matchmaker(this.assets, this.maxPlayers)
    this.worlds = new Map(); this.accounts = new Map(); this.closed = false
    this.privateRooms = new Map(); this.privatePlayers = new Map()
    this.metrics = { steps: 0, worldsStarted: 0, worldsFinished: 0, snapshots: 0, tcpSnapshots: 0, failures: 0 }
    this.onNativeFailure = error => {
      this.engineFailed = true
      this.metrics.failures++; this.emit('battleError', error)
      this.matchmaker.close()
      for (const ticket of Array.from(this.privateRooms.values())) this.removePrivateRoom(ticket, true)
      for (const world of Array.from(this.worlds.values())) world.finish(null, 'server-error')
    }
    if (this.nativeRuntime) this.nativeRuntime.on('engineFailure', this.onNativeFailure)
    this.matchmaker.on('status', (ticket, found, seconds) => {
      for (const member of ticket.members) this.deliver(() => new Status(member.client, member.player, seconds, found, ticket.mode.capacity).send())
    })
    this.matchmaker.on('cancel', ticket => {
      if (ticket.roomId) for (const member of ticket.members) require('../GameRoomService').GameRoomService.set_ready(member.player, false)
      for (const member of ticket.members) this.deliver(() => new Cancelled(member.client, member.player).send())
    })
    this.onInput = (session) => {
      const world = this.accounts.get(session.player.low_id)
      if (!world) return
      const entry = world.players.find(p => p.player === session.player && p.client === session.client)
      if (entry) { entry.session = session; entry.ready = true }
    }
    this.onRelease = (session, reason) => {
      if (reason === 'battle-start-failed' || (reason === 'timeout' && !this.accounts.has(session.player.low_id))) return
      this.disconnect(session.player, session.client)
    }
    transport.on('input', this.onInput); transport.on('release', this.onRelease)
    this.timer = setInterval(() => this.step(), 50); this.timer.unref()
  }

  deliver (action) {
    try { return action() } catch (error) { this.emit('battleError', error); return false }
  }

  enqueue (members, mapId) {
    if (this.engineFailed) {
      for (const member of members) if (!member.client.destroyed) this.deliver(() => new Cancelled(member.client, member.player).send())
      throw new ValueError('Motor nativo indisponível; verifique o erro de batalha no console')
    }
    if (this.closed) throw new ValueError('Servidor de batalhas encerrado')
    for (const member of members) if (member.player.pendingBattleResult) {
      require('./ResultOutbox').ResultOutbox.send(member.player, member.client)
      return null
    }
    const active = Array.from(this.accounts.keys()).filter(id => !this.matchmaker.players.has(id)).length
    if (active + this.matchmaker.players.size + this.privatePlayers.size + members.length > this.maxPlayers) throw new ValueError('Servidor de batalhas cheio')
    for (const member of members) if (this.accounts.has(member.player.low_id) || this.privatePlayers.has(member.player.low_id)) throw new ValueError('Jogador já está em batalha ou sala privada')
    return this.matchmaker.enqueue(members, mapId)
  }

  readyRoom (player, room) {
    if (this.closed || this.engineFailed) throw new ValueError('Motor de batalhas indisponível')
    if (!room.members.length || !room.members.every(member => member.ready)) return null
    const registry = player.ClientDict && player.ClientDict.Clients
    const members = room.members.map(member => {
      const session = registry && registry[String(member.low_id)]
      if (!session || !session.Player || session.SocketInfo.destroyed) throw new ValueError('Membro da sala desconectado')
      return { player: session.Player, client: session.SocketInfo }
    })
    const mode = require('./World/GameModes').rules(this.assets.tables.locations[room.map_id].GameMode)
    if (room.practice) {
      return this.queuePrivateRoom(player, room, members, mode)
    }
    const ticket = this.enqueue(members, room.map_id)
    ticket.roomId = room.id
    return ticket
  }

  cancel (player, client) {
    if (this.accounts.has(player.low_id)) return false
    const privateRoom = this.privatePlayers.get(player.low_id)
    if (privateRoom && privateRoom.members.some(m => m.player === player && m.client === client)) { this.removePrivateRoom(privateRoom, true); return true }
    if (this.matchmaker.cancel(player, client)) return true
    if (!client.destroyed) this.deliver(() => new Cancelled(client, player).send())
    return false
  }

  start (selected, mapId) {
    let players = []
    for (const { ticket, team } of selected) for (const member of ticket.members) players.push({ ...member, team, index: players.length, session: null })
    const mode = require('./World/GameModes').rules(this.assets.tables.locations[mapId].GameMode)
    const capacities = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
    const humanCount = players.length
    if (!humanCount) throw new ValueError('A partida precisa de pelo menos um jogador conectado')
    const level = Math.round(players.reduce((sum, entry) => sum + (entry.powerLevel || 0), 0) / Math.max(1, humanCount))
    const Skins = require('../../Files/CsvLogic/Skins')
    for (let team = 0; team < capacities.length && !this.nativeRuntime; team++) {
      const present = players.filter(entry => entry.team === team).length
      if (present > capacities[team]) throw new ValueError('Equipe maior que a capacidade do modo')
      for (let slot = present; slot < capacities[team]; slot++) {
        const hero = this.assets.heroes[crypto.randomInt(this.assets.heroes.length)]
        const index = players.length
        players.push({ bot: true, team, index, session: null, client: null, brawlerId: hero.id,
          skinId: Skins.get_default_skin(hero.id), powerLevel: level,
          player: { low_id: -(index + 1), high_id: 0, name: 'Bot ' + (index - humanCount + 1), brawler_id: hero.id, Brawler_level: {} } })
      }
    }
    if (!this.nativeRuntime && players.length !== mode.capacity) throw new ValueError('Quantidade de participantes incompatível com o mapa')
    const id = crypto.randomBytes(16).toString('hex'); const seed = crypto.randomInt(2147483647)
    const world = this.nativeRuntime
      ? new (require('./Game/NativeBattleWorld').NativeBattleWorld)(id, this.assets, mapId, players, seed, this.nativeRuntime)
      : new BattleWorld(id, this.assets, mapId, players, seed)
    players = world.players
    const humans = players.filter(entry => !entry.bot)
    world.on('cleanupError', error => { this.metrics.failures++; this.emit('battleError', error) })
    // Build world and validate the initial snapshots before consuming tickets.
    const begun = []
    try {
      for (const entry of humans) visionPayload(world, entry, this.assets)
      for (const entry of humans) {
        BattleInstanceService.begin(entry.player); begun.push(entry)
        entry.session = this.transport.attach(entry.player, entry.client)
      }
    } catch (error) {
      world.finish(null, 'server-error')
      for (const entry of begun) {
        this.deliver(() => BattleInstanceService.mark_home(entry.player))
        this.deliver(() => this.transport.release(entry.player, entry.client, 'battle-start-failed'))
      }
      throw error
    }
    world.on('finished', result => this.finished(world, result))
    this.worlds.set(world.id, world)
    for (const entry of humans) this.accounts.set(entry.player.low_id, world)
    const participants = players.map(entry => ({ index: entry.index, team: entry.team,
      name: entry.player.name, low_id: entry.bot ? 0 : entry.player.low_id, high_id: entry.bot ? 0 : entry.player.high_id || 0,
      brawler_id: entry.brawlerId, skin_id: entry.skinId, bot: Boolean(entry.bot) }))
    for (const entry of humans) {
      entry.player.map_id = mapId; entry.player.onlineBattle = world; entry.player.authoritativeBattleResult = null
      this.deliver(() => {
        new StartLoading(entry.client, entry.player, { map_id: mapId, battle_seed: world.seed, loading_game_type: world.loadingGameType }, participants).send()
        new UDPInfo(entry.client, entry.player).send()
        this.sendTcpVision(world, entry, visionPayload(world, entry, this.assets))
      })
    }
    for (const { ticket } of selected) if (ticket.roomId) require('../GameRoomService').GameRoomService.begin_battle(ticket.members[0].player)
    this.metrics.worldsStarted++; return world
  }

  step () {
    if (this.closed || this.engineFailed) return
    this.metrics.steps++
    try { this.pollPrivateRooms() } catch (error) { this.metrics.failures++; this.emit('battleError', error) }
    try { this.matchmaker.poll((selected, mapId) => this.start(selected, mapId)) } catch (error) { this.metrics.failures++; this.emit('battleError', error) }
    for (const world of Array.from(this.worlds.values())) {
      try {
        world.step()
        if (world.phase === 'finished') continue
        for (const entry of world.players) {
          if (entry.bot || !entry.session || entry.session.closed || entry.client.destroyed) continue
          const payload = visionPayload(world, entry, this.assets)
          // Bootstrap over encrypted TCP, independently of UDP reachability.
          // Oversized snapshots also use TCP instead of deleting live objects.
          if (!entry.session.endpoint || payload.length > 1370) this.sendTcpVision(world, entry, payload)
          else if (this.transport.send(entry.session, 24109, payload)) this.metrics.snapshots++
        }
      } catch (error) {
        this.metrics.failures++; this.emit('battleError', error); world.finish(null, 'server-error')
      }
    }
    if (this.metrics.steps % 20 === 0) for (const mapId of this.matchmaker.buckets.keys()) this.matchmaker.notify(mapId)
  }

  sendTcpVision (world, entry, payload, final = false) {
    // Bound socket buffering; the authoritative clock never waits for a peer.
    if (!final && entry.client.writableLength > 262144) return false
    new Vision(entry.client, entry.player, payload).send()
    this.metrics.tcpSnapshots++
    return true
  }

  finished (world, result) {
    // The native end flag must reach the client before its result packet.
    // Use one TCP channel for both so UDP/TCP reordering cannot invert them.
    if (world.nativeVisionPayload && result.reason === 'native-game-over') {
      for (const entry of world.players) {
        if (entry.bot || !entry.session || entry.session.closed || entry.client.destroyed) continue
        this.deliver(() => this.sendTcpVision(world, entry, visionPayload(world, entry, this.assets), true))
      }
    }
    this.worlds.delete(world.id); this.metrics.worldsFinished++
    for (const entry of world.players) {
      if (entry.bot) continue
      this.accounts.delete(entry.player.low_id)
      if (entry.player.onlineBattle === world) entry.player.onlineBattle = null
      const { GameRoomService } = require('../GameRoomService')
      this.deliver(() => GameRoomService.end_battle(entry.player))
      // Abort paths cannot grant competitive rewards.
      if (!['loading-timeout', 'server-error', 'shutdown', 'abandoned'].includes(result.reason)) this.deliver(() => this.result(world, entry))
      else if (result.reason !== 'shutdown' && entry.player.token && !entry.client.destroyed && !entry.client.readableEnded) {
        this.deliver(() => {
          BattleInstanceService.mark_home(entry.player)
          const Home = require('../../Packets/Messages/Server/Home/OwnHomeDataMessage')
          new Home(entry.client, entry.player).send()
        })
      }
      this.transport.release(entry.player, entry.client, 'battle-ended')
    }
  }

  result (world, entry) {
    const { BattleEndData, BattleEndService, BattleParticipant } = require('../BattleEnd')
    const [gameMode] = BattleEndService.game_mode(world.mapId)
    const ranked = [2, 5].includes(gameMode)
    const outcome = world.outcome.winner === null ? 2 : world.outcome.winner === entry.team ? 0 : 1
    const hash = crypto.createHash('sha256').update(world.id + ':' + entry.player.low_id + ':' + JSON.stringify(world.outcome)).digest('hex')
    const participants = world.players.map(other => new BattleParticipant({ brawlerId: other.brawlerId, skinId: other.skinId, team: other.team,
      isPlayer: !other.bot, name: other.player.name, lowId: other.bot ? 0 : other.player.low_id, highId: other.bot ? 0 : other.player.high_id || 0, powerLevel: other.powerLevel + 1 }))
    const data = new BattleEndData({ battleResult: ranked ? entry.rank || 1 : outcome, submittedResult: entry.team,
      rank: entry.rank || 1, mapSlot: entry.player.map_slot || 0, mapId: world.mapId, gameMode,
      locationGameMode: world.mode.name, participants, battleId: hash, localIndex: entry.index })
    data.practice = Boolean(world.practice)
    if (world.nativeVisionPayload) data.mvp_index = Number.isInteger(world.state.mvpIndex) ? world.state.mvpIndex : -1
    const ledgerId = BattleInstanceService.resolve_result(entry.player, hash, gameMode)
    BattleEndService.apply_to_player(entry.player, data); entry.player.battle_end_id = ledgerId
    entry.player.authoritativeBattleResult = data
    const { ResultOutbox } = require('./ResultOutbox')
    ResultOutbox.save(entry.player, data, ledgerId)
    require('../BattleResultAdapter').apply_battle_result_rewards(entry.player, gameMode, ledgerId)
    ResultOutbox.send(entry.player, entry.client)
  }

  disconnect (player, client) {
    const privateRoom = this.privatePlayers.get(player.low_id)
    if (privateRoom && privateRoom.members.some(m => m.player === player && m.client === client)) this.removePrivateRoom(privateRoom, true)
    this.matchmaker.cancel(player, client, 'disconnect')
    const world = this.accounts.get(player.low_id)
    if (!world) return
    const entry = world.players.find(p => p.player === player && p.client === client)
    if (!entry) return
    entry.disconnected = true
    if (world.disconnectPlayer) { world.disconnectPlayer(entry); return }
    const char = world.characters.get(player.low_id)
    if (char && char.hp > 0) world.damage(char, char.hp, null)
    if (world.phase === 'loading' || world.players.filter(p => !p.bot).every(p => p.disconnected)) world.finish(null, 'abandoned')
  }

  close () {
    if (this.closed) return
    this.closed = true; clearInterval(this.timer); this.matchmaker.close()
    for (const ticket of Array.from(this.privateRooms.values())) this.removePrivateRoom(ticket, true)
    for (const world of Array.from(this.worlds.values())) world.finish(null, 'shutdown')
    if (this.nativeRuntime) {
      this.nativeRuntime.off('engineFailure', this.onNativeFailure)
      this.nativeRuntime.close()
    }
    this.transport.off('input', this.onInput); this.transport.off('release', this.onRelease)
  }
}
Object.assign(BattleCoordinator.prototype, require('./PrivateRooms'))
module.exports = { BattleCoordinator }
