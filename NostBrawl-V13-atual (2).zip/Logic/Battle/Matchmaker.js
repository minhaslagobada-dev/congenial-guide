'use strict'

const { EventEmitter } = require('events')
const { performance } = require('perf_hooks')
const { rules } = require('./World/GameModes')
const MATCHMAKING_WAIT_MS = 15000
const { ValueError } = require('../../Utils/Errors')

class Matchmaker extends EventEmitter {
  constructor (assets, maxPlayers = 200, { now = () => performance.now() } = {}) {
    super()
    this.assets = assets
    this.now = now
    this.maxPlayers = maxPlayers
    this.players = new Map()
    this.buckets = new Map()
    this.nextId = 1
    this.closed = false
  }

  enqueue (members, mapId) {
    if (this.closed) throw new ValueError('Matchmaking encerrado')
    const location = this.assets.tables.locations[mapId]
    if (!location || !location.AllowedMaps || location.Disabled === 'true') throw new ValueError('Mapa de matchmaking inválido')
    const mode = rules(location.GameMode)
    if (!Array.isArray(members) || !members.length || members.length > mode.teamSize) throw new ValueError('Tamanho da equipe incompatível com o modo')
    const ids = members.map(member => member.player.low_id)
    if (new Set(ids).size !== ids.length) throw new ValueError('Jogador duplicado na equipe')
    for (const member of members) {
      if (!member.player.logged_in || !Number.isSafeInteger(member.player.low_id) || member.player.low_id <= 0 || member.client.destroyed) throw new ValueError('Jogador não conectado')
      this.assets.hero(member.player.brawler_id)
      const unlocked = member.player.BrawlersUnlockedState
      if (unlocked && !Number(unlocked[member.player.brawler_id])) throw new ValueError('Brawler não desbloqueado')
    }
    const previous = this.players.get(ids[0])
    if (previous && previous.mapId === mapId && previous.members.length === members.length && previous.members.every(m => ids.includes(m.player.low_id))) return previous
    if (ids.some(id => this.players.has(id))) throw new ValueError('Jogador já está no matchmaking')
    if (this.players.size + members.length > this.maxPlayers) throw new ValueError('Capacidade do matchmaking atingida')
    const ticket = { id: this.nextId++, mapId, mode, members: members.map(member => ({ ...member, brawlerId: member.player.brawler_id, skinId: member.player.skin_id || 0, powerLevel: Math.max(0, Math.min(9, Number((member.player.Brawler_level || {})[member.player.brawler_id]) || 0)) })), joinedAt: this.now(), state: 'queued' }
    if (!this.buckets.has(mapId)) this.buckets.set(mapId, [])
    this.buckets.get(mapId).push(ticket)
    for (const member of members) this.players.set(member.player.low_id, ticket)
    this.notify(mapId)
    return ticket
  }

  notify (mapId) {
    const bucket = this.buckets.get(mapId) || []
    const count = bucket.reduce((sum, ticket) => sum + ticket.members.length, 0)
    const seconds = bucket.length ? Math.max(0, Math.ceil((bucket[0].joinedAt + MATCHMAKING_WAIT_MS - this.now()) / 1000)) : 0
    for (const ticket of bucket) this.emit('status', ticket, Math.min(count, ticket.mode.capacity), seconds)
  }

  cancel (player, client = null, reason = 'cancelled') {
    const ticket = this.players.get(player.low_id)
    if (!ticket || ticket.state !== 'queued' || (client && !ticket.members.some(m => m.player === player && m.client === client))) return false
    this.remove(ticket)
    ticket.state = reason
    this.emit('cancel', ticket, reason)
    this.notify(ticket.mapId)
    return true
  }

  remove (ticket) {
    for (const member of ticket.members) if (this.players.get(member.player.low_id) === ticket) this.players.delete(member.player.low_id)
    const bucket = this.buckets.get(ticket.mapId)
    if (bucket) {
      const index = bucket.indexOf(ticket)
      if (index >= 0) bucket.splice(index, 1)
      if (!bucket.length) this.buckets.delete(ticket.mapId)
    }
  }

  // Party-sized bin packing keeps a party together and gives the oldest party
  // priority. A full human roster can start before the timeout.
  select (bucket) {
    if (!bucket.length) return null
    const mode = bucket[0].mode
    const teams = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
    const selected = []
    const failed = new Set()
    const search = index => {
      if (teams.every(n => n === 0)) return true
      if (index >= bucket.length) return false
      const key = index + ':' + teams.slice().sort((a, b) => a - b).join(',')
      if (failed.has(key)) return false
      const ticket = bucket[index]; const size = ticket.members.length
      const seen = new Set()
      for (let team = 0; team < teams.length; team++) {
        if (teams[team] < size || seen.has(teams[team])) continue
        seen.add(teams[team]); teams[team] -= size; selected.push({ ticket, team })
        if (search(index + 1)) return true
        selected.pop(); teams[team] += size
      }
      if (index !== 0 && search(index + 1)) return true
      failed.add(key)
      return false
    }
    return search(0) ? selected.slice() : null
  }

  selectExpired (bucket) {
    if (!bucket.length || this.now() < bucket[0].joinedAt + MATCHMAKING_WAIT_MS) return null
    const mode = bucket[0].mode
    const capacity = mode.cooperative ? [mode.capacity] : (mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize))
    const remaining = capacity.slice()
    const selected = []
    for (const ticket of bucket) {
      const size = ticket.members.length
      let best = -1
      for (let team = 0; team < remaining.length; team++) {
        if (remaining[team] < size) continue
        if (best < 0 || (capacity[team] - remaining[team]) / capacity[team] < (capacity[best] - remaining[best]) / capacity[best]) best = team
      }
      if (best >= 0) { remaining[best] -= size; selected.push({ ticket, team: best }) }
      if (remaining.every(n => n === 0)) break
    }
    return selected.length ? selected : null
  }

  poll (startMatch) {
    for (const [mapId] of Array.from(this.buckets)) {
      let selected
      while ((selected = this.select(this.buckets.get(mapId) || []) || this.selectExpired(this.buckets.get(mapId) || []))) {
        // Preparing a world is synchronous; consume queue entries only once
        // preparation succeeds. The coordinator returns the started session.
        const result = startMatch(selected, mapId)
        if (!result) break
        for (const { ticket } of selected) { this.remove(ticket); ticket.state = 'matched' }
        this.emit('match', result)
        this.notify(mapId)
      }
    }
  }

  close () {
    this.closed = true
    for (const bucket of Array.from(this.buckets.values())) for (const ticket of bucket.slice()) {
      this.remove(ticket); ticket.state = 'shutdown'; this.emit('cancel', ticket, 'shutdown')
    }
  }
}
module.exports = { Matchmaker, MATCHMAKING_WAIT_MS }
