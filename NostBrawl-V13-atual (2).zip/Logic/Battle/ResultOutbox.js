'use strict'
const DataBase = require('../../Database/DatabaseManager')
const { BattleEndData, BattleEndService } = require('../BattleEnd')
const { apply_battle_result_rewards } = require('../BattleResultAdapter')
// Retain the authoritative result until GoHome acknowledges its screen. Socket
// writes alone do not prove that a phone received the result before disconnect.
class ResultOutbox {
  static save (player, data, ledgerId) {
    DataBase._connection(connection => connection.prepare(
      'INSERT OR IGNORE INTO battle_result_outbox(player_id,battle_id,result_json,created_at) VALUES(?,?,?,?)'
    ).run(player.low_id, ledgerId, JSON.stringify(data), Math.floor(Date.now() / 1000)), true)
    player.pendingBattleResult = { data, ledgerId }
  }

  static restore (player) {
    if (!player.token) return null
    const row = DataBase._connection(connection => connection.prepare(
      'SELECT battle_id,result_json FROM battle_result_outbox WHERE player_id=? ORDER BY created_at,battle_id LIMIT 1'
    ).get(player.low_id))
    if (!row) return null
    const data = Object.assign(Object.create(BattleEndData.prototype), JSON.parse(row.result_json))
    player.pendingBattleResult = { data, ledgerId: row.battle_id }
    ResultOutbox.apply(player)
    // Settle before OwnHomeData, even if a previous process died before rewards
    // were committed. The existing ledger makes repeated settlement idempotent.
    apply_battle_result_rewards(player, data.game_mode, row.battle_id)
    return data
  }

  static apply (player) {
    const pending = player.pendingBattleResult
    if (!pending) return false
    BattleEndService.apply_to_player(player, pending.data)
    player.battle_end_id = pending.ledgerId
    player.authoritativeBattleResult = pending.data
    return true
  }

  static send (player, client) {
    if (!ResultOutbox.apply(player)) return false
    if (!client || client.destroyed || client.readableEnded || client.writableEnded) return false
    const Messages = require('../../Packets/Messages/Client/Battle/AskForBattleEndMessage').RESULT_MESSAGES
    new Messages[player.pendingBattleResult.data.game_mode](client, player).send()
    player.pendingBattleResultSent = true
    return true
  }

  static acknowledge (player) {
    if (!player.pendingBattleResult || !player.pendingBattleResultSent) return false
    const id = player.pendingBattleResult.ledgerId
    DataBase._connection(connection => connection.prepare('DELETE FROM battle_result_outbox WHERE player_id=? AND battle_id=?').run(player.low_id, id), true)
    player.pendingBattleResult = null; player.pendingBattleResultSent = false
    return true
  }
}
module.exports = { ResultOutbox }
