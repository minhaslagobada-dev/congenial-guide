'use strict'
const { EventEmitter } = require('node:events')
const { spawn } = require('node:child_process')
const path = require('node:path')
const fs = require('node:fs')
const { decodeInput } = require('./Network/V13BattleCodec')

// Owns a persistent original-v13 engine process. Errors invalidate every match
// in this process; callers receive engineFailure and must release their sessions.
class NativeBattleRuntime extends EventEmitter {
  constructor ({ python, library = process.env.LIBG_V13 || path.resolve(__dirname, '../../Native/V13/libg.so'), timeout = 5000 } = {}) {
    super()
    const virtualPython = path.resolve(__dirname, '../../.venv-native', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
    this.python = python || process.env.PYTHON || (fs.existsSync(virtualPython) ? virtualPython : 'python3')
    this.library = library; this.timeout = timeout
    this.pending = new Map(); this.nextId = 1; this.closed = false; this.output = ''; this.stderr = ''
  }

  start () {
    if (this.starting) return this.starting
    if (this.closed) return Promise.reject(new Error('Native engine closed'))
    if (!this.library) return Promise.reject(new Error('LIBG_V13 must identify the supplied client library'))
    this.starting = new Promise((resolve, reject) => {
      this.readyReject = reject
      this.startTimer = setTimeout(() => this.fail(new Error('Native engine startup timed out')), 30000)
      const script = path.resolve(__dirname, '../../scripts/native_v13/battle_worker.py')
      this.child = spawn(this.python, ['-u', script], { env: { ...process.env, LIBG_V13: this.library }, stdio: ['pipe', 'pipe', 'pipe'] })
      this.child.on('error', error => this.fail(error))
      this.child.stdin.on('error', error => this.fail(error))
      this.child.on('exit', (code, signal) => {
        if (!this.closed) this.fail(new Error(`Native engine exited (${code ?? signal}): ${this.stderr}`))
      })
      this.child.stderr.on('data', bytes => { this.stderr = (this.stderr + bytes.toString()).slice(-4096) })
      this.child.stdout.setEncoding('utf8')
      this.child.stdout.on('data', text => {
        this.output += text
        if (this.output.length > 2097152) { this.fail(new Error('Native IPC output exceeded limit')); return }
        let end
        while ((end = this.output.indexOf('\n')) >= 0) {
          const line = this.output.slice(0, end); this.output = this.output.slice(end + 1)
          let message
          try { message = JSON.parse(line) } catch (_) { this.fail(new Error('Invalid native IPC response')); return }
          if (message.event === 'ready') {
            if (message.engine !== 'original-v13-arm64') { this.fail(new Error('Unexpected battle engine')); return }
            clearTimeout(this.startTimer); this.readyReject = null; resolve(this); continue
          }
          const request = this.pending.get(message.requestId)
          if (!request) { this.fail(new Error('Unexpected native request ID')); return }
          clearTimeout(request.timer); this.pending.delete(message.requestId)
          if (message.error) request.reject(new Error(message.error)); else request.resolve(message.result)
          if (message.fatal) { this.fail(new Error(message.error)); return }
        }
      })
    })
    return this.starting
  }

  async request (command, fields = {}) {
    await this.start()
    if (this.closed) throw new Error('Native engine closed')
    if (this.pending.size >= 256) throw new Error('Native engine request backlog exceeded')
    const requestId = this.nextId++
    if (this.nextId > 2147483647) this.nextId = 1
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.fail(new Error(`Native ${command} timed out`)), this.timeout)
      this.pending.set(requestId, { resolve, reject, timer })
      const line = JSON.stringify({ ...fields, command, requestId }) + '\n'
      if (Buffer.byteLength(line) > 131072) {
        clearTimeout(timer); this.pending.delete(requestId); reject(new Error('Native request too large')); return
      }
      this.child.stdin.write(line, error => { if (error) this.fail(error) })
    })
  }

  create (matchId, location, seed, players) { return this.request('create', { matchId, location, seed, players }) }
  frame (matchId) { return this.request('frame', { matchId }) }
  input (matchId, playerIndex, bytes) {
    decodeInput(bytes) // Bound vectors and reject malformed network data before C++ allocation.
    return this.request('input', { matchId, playerIndex, hex: bytes.toString('hex') })
  }
  destroy (matchId) { return this.request('destroy', { matchId }) }

  fail (error) {
    if (this.closed) return
    this.closed = true; clearTimeout(this.startTimer)
    if (this.readyReject) { this.readyReject(error); this.readyReject = null }
    for (const request of this.pending.values()) { clearTimeout(request.timer); request.reject(error) }
    this.pending.clear()
    if (this.child) this.child.kill()
    this.emit('engineFailure', error)
  }

  async close () {
    if (this.closed) return
    if (!this.starting) { this.closed = true; return }
    try { await this.request('shutdown') } finally {
      this.closed = true; clearTimeout(this.startTimer)
      if (this.child) { this.child.stdin.end(); this.child.kill() }
    }
  }
}
module.exports = { NativeBattleRuntime }
